# Changelog

## 0.7.0 — 2026-09-24

Prepared a self-contained repository/ZIP release based on the available 0.6 environment preview (integrated base 0.4). The unavailable 0.5 advanced water branch is not represented as merged.

Replaced the uncertain-permission Python modeling kit with an independently implemented Node backend; removed its source, old generated models and setup/dependency chain. Rebuilt all seven original Seedwork starter recipes. Added strict supported-subset validation, full-resolution lossless PNG handling, deterministic PBR generation, explicit tangent generation and exact reference/compacted GLB auditing. Legacy sculpt/stamp/decal features fail explicitly.

Added an offline plan/schema/context/model/project CLI, three starter plans, atomic new project output and first-launch bootstrap that does not overwrite subsequent edits. Added ChatGPT handoff instructions and agent workflow guidance, with explicit archive/client capability boundaries.

Retained the World Studio, 42-tool interface, environment gallery, embedded host workflow and basic earlier water. Updated current version metadata, active instructions, provenance records, model references and release checks. Removed an unreferenced old forest GLB snapshot; editable example worlds remain. Added project credit for Adam S. Barnett without replacing dependency authorship or required notices.

Added deterministic dependency-free release tooling, source/asset checksums, a machine-readable capability and attribution inventory, clean-export rules and manually dispatched draft GitHub release configuration. No GitHub publication is implied by this archive.

This changes the native model visual baseline; it is not a lossless reproduction of the excluded kit. It does not upgrade Three.js r140, provide scans, implement new advanced water, add a hosted ChatGPT app, or certify every GPU/platform.
