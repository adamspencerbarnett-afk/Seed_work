import { writeFileSync } from 'node:fs';
import { make, recipe, summary } from '../core/world.mjs';

try {
  const prompt = process.argv[2] ?? 'A forest island with village and ruins, seed 1847';
  const file = process.argv[3] ?? 'sample.world.json';
  const plan = recipe(prompt);
  const world = make(plan.options);
  writeFileSync(file, JSON.stringify(world, null, 2));
  console.log(JSON.stringify({ file, ...summary(world), notes: plan.notes, limitation: plan.limitation }, null, 2));
} catch (e) {
  console.error(e.message);
  process.exitCode = 1;
}
