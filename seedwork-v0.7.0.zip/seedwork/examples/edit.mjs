const port = Number(process.env.PORT ?? 4173);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid PORT.');
const url = `http://127.0.0.1:${port}`;

async function edit() {
  const res = await fetch(`${url}/api/session`, { signal: AbortSignal.timeout(5000) });
  const state = await res.json();
  if (!res.ok) throw new Error(state.error ?? `HTTP ${res.status}`);
  const s = state.world.terrain.size / 2;
  const args = { type: 'lamp', x: Math.max(-s, Math.min(s, state.world.spawn.x + 3)), z: state.world.spawn.z };
  const run = await fetch(`${url}/api/tool`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${state.token}` },
    body: JSON.stringify({ name: 'object_add', args, rev: state.rev, key: crypto.randomUUID() }),
    signal: AbortSignal.timeout(10000)
  });
  const out = await run.json();
  if (!run.ok) throw new Error(out.error ?? `HTTP ${run.status}`);
  console.log(JSON.stringify({ rev: out.rev, result: out.result }, null, 2));
}

edit().catch(e => { console.error(e.message); process.exitCode = 1; });
