import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const port = Number(process.env.PORT ?? 4173);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid PORT.');
const root = resolve(import.meta.dirname, '..');
const token = readFileSync(resolve(process.env.SEEDWORK_DIR ?? resolve(root, '.seedwork'), 'token'), 'utf8').trim();
const url = `http://127.0.0.1:${port}`;

async function call(name, args = {}) {
  const res = await fetch(`${url}/api/tool`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ name, args }),
    signal: AbortSignal.timeout(25000)
  });
  const out = await res.json();
  if (!res.ok) throw Object.assign(new Error(out.error ?? `HTTP ${res.status}`), { code: out.code, details: out.details });
  return out.result;
}

async function main() {
  const project = await call('project_inspect');
  if (process.argv.includes('--inspect')) {
    console.log(JSON.stringify({ project, assets: await call('asset_search', { q: 'bench', limit: 5 }) }, null, 2));
    return;
  }
  const host = project.hosts.find(h => project.manifest.requiredTests.every(t => h.tests.includes(t)));
  if (!host) throw new Error('Attach a host that registers the required tests before running this example. Nothing was edited.');
  let change = await call('change_begin', { rev: project.rev, key: crypto.randomUUID(), label: 'Agent-staged oak bench' });
  console.log(JSON.stringify({ change: change.id, status: 'Draft created; no publication.' }));
  const item = `bench_${crypto.randomUUID()}`;
  change = await call('change_apply', {
    id: change.id,
    seq: change.seq,
    key: crypto.randomUUID(),
    ops: [
      { op: 'asset_use', key: 'agent_bench', ref: 'starter.bench' },
      { op: 'item_add', id: item, asset: 'agent_bench', pos: [-5, .035, -4], rot: [0, 90, 0], name: 'Agent-proposed oak bench' }
    ]
  });
  const check = await call('change_check', { id: change.id });
  if (!check.valid || check.stale) throw new Error('Draft requires review before preview.');
  await call('change_preview', { id: change.id, seq: change.seq, host: host.id });
  const tests = [];
  for (const test of project.manifest.requiredTests) tests.push(await call('scene_test', { host: host.id, test }));
  const capture = await call('scene_capture', { host: host.id });
  console.log(JSON.stringify({ change: change.id, seq: change.seq, tests: tests.map(({ test, passed, checks }) => ({ test, passed, checks })), capture: capture.capture, diff: change.diff, next: 'Select this draft in Host Lab, inspect the actual scene and evidence, then approve and commit or discard. This script never approves or publishes.' }, null, 2));
  if (tests.some(t => !t.passed)) process.exitCode = 2;
}

main().catch(error => {
  console.error(JSON.stringify({ code: error.code, error: error.message, details: error.details, note: 'Inspect any printed draft ID before retrying. No implicit rebase or automatic publication occurs.' }));
  process.exitCode = 1;
});
