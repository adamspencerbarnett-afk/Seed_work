import { createGame } from './game.mjs';
import { createRuntime, createGlbLoader } from './sdk/index.mjs';
const game = createGame({ THREE, canvas: document.getElementById('game'), mats: './materials/' });
const runtime = createRuntime({ THREE, parent: game.scene, load: createGlbLoader({ Loader: THREE.GLTFLoader, url: hash => `./assets/${hash}.glb`, shadows: true }) });
const status = document.getElementById('status');
try {
  const response = await fetch('./scene.json'); if (!response.ok) throw new Error('Scene could not be loaded.');
  const doc = await response.json(); await runtime.setScene(doc);
  runtime.root.updateMatrixWorld(true);
  const boxes = [];
  for (const item of doc.items) for (const bounds of doc.assets[item.asset].boxes) {
    const box = new THREE.Box3(new THREE.Vector3(...bounds[0]), new THREE.Vector3(...bounds[1])).applyMatrix4(runtime.get(item.id).matrixWorld);
    boxes.push({ min: box.min.toArray(), max: box.max.toArray() });
  }
  game.setContent(() => boxes);
  status.textContent = `${doc.items.length} authored objects · Drag to orbit · Walk: WASD / arrows / E gate`;
  window.gameDemo = { game, runtime, ready: true };
} catch (e) { status.textContent = e.message; window.gameDemo = { game, runtime, ready: false, error: e.message }; }
document.getElementById('walk').addEventListener('click', () => game.setWalk(true));
document.getElementById('overview').addEventListener('click', () => game.setWalk(false));
document.getElementById('gate').addEventListener('click', game.toggleGate);
