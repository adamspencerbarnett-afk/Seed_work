import { setTimeout as delay } from 'node:timers/promises';

const url = `http://127.0.0.1:${process.env.PORT || 4173}`;

async function main() {
  const res = await fetch(`${url}/api/session`);
  if (!res.ok) throw new Error(`Session failed: HTTP ${res.status}`);
  const start = await res.json();
  const call = async (name, args = {}, rev) => {
    const res = await fetch(`${url}/api/tool`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${start.token}` }, body: JSON.stringify({ name, args, ...(rev === undefined ? {} : { rev, key: crypto.randomUUID() }) }) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  };
  const { recipe } = (await call('model_template', { template: 'part' })).result;
  recipe.name = 'Workshop_Part';
  recipe.parts[0].size[0] = .45;
  let job = (await call('model_build', { recipe })).result.job;
  const end = Date.now() + 150000;
  while (['queued', 'running'].includes(job.state)) {
    if (Date.now() > end) throw new Error('Build wait timed out. Inspect the job before retrying.');
    await delay(400);
    job = (await call('model_status', { job: job.id })).result.job;
  }
  if (job.state !== 'ready') throw new Error(job.error || `Build ended: ${job.state}`);
  const key = 'm_workshop_part';
  const published = await call('model_publish', { job: job.id, key }, start.rev);
  const result = await call('object_add', { type: key, x: Math.min(start.world.terrain.size / 2 - 2, start.world.spawn.x + 3), z: start.world.spawn.z }, published.rev);
  console.log(JSON.stringify({ job: job.id, model: key, exact: job.result.report.exact.passed, object: result.result, rev: result.rev }, null, 2));
}

main().catch(e => { console.error(e.message); process.exitCode = 1; });
