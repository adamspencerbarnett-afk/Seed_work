import { createEnvironment, bindAtmosphere, createEnvTools, preset } from '../../sdk/environment/index.mjs';

export function attachEnv(h) {
  const env = createEnvironment({
    THREE: h.THREE,
    parent: h.scene,
    camera: h.camera,
    config: preset('rain'),
    field: {
      bounds: [-40, -40, 80, 80],
      range: [-10, 70],
      size: 256,
      ground: h.ground,
      roof: h.roof
    }
  });
  let offFrame = () => {};
  let offTerrain = () => {};
  try {
    env.bind(h.groundMesh, { wet: 1, snow: 1, ice: 0.2 });
    env.bind(h.buildings, { wet: 0.8, snow: 1 });
    env.bind(h.leaves, { wet: 0.3, snow: 0.5, foliage: 1 });
    bindAtmosphere(env, {
      scene: h.scene,
      sun: h.sun,
      hemi: h.hemi,
      background: false
    });
    offFrame = h.onFrame(dt => {
      if (!Number.isFinite(dt) || dt < 0 || dt > 5) {
        throw new RangeError('The host must define its policy for long stalls.');
      }
      let left = dt;
      while (left > 0) {
        const step = Math.min(1, left);
        env.update(step);
        left -= step;
      }
      env.sync();
    });
    offTerrain = h.onTerrain(() => env.invalidateField());
    return {
      env,
      tools: createEnvTools(env),
      dispose() {
        offFrame();
        offTerrain();
        env.dispose();
      }
    };
  } catch (error) {
    offFrame();
    offTerrain();
    env.dispose();
    throw error;
  }
}
