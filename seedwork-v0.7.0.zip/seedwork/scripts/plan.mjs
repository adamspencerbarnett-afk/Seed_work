import { readFileSync, writeFileSync, mkdirSync, existsSync, rmSync, renameSync, cpSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { make, check } from '../core/world.mjs';
import { tool, TOOLS, WORLD_WRITES } from '../core/tools.mjs';
import { MODEL_KEY, bindings, worldInputs } from '../core/models.mjs';
import { validate, jsonSafe } from '../sdk/core/schema.mjs';
import { compile } from '../modeler/compiler.mjs';
import { releaseFiles } from './files.mjs';

const root = resolve(import.meta.dirname, '..');
const read = file => JSON.parse(readFileSync(file, 'utf8'));
const closed = (properties, required = []) => ({ type: 'object', properties, required, additionalProperties: false });
export const PLAN_SCHEMA = closed({
  format: { const: 'seedwork.plan/1' },
  world: TOOLS.find(t => t.name === 'world_make').inputSchema,
  models: { type: 'array', maxItems: 32, items: closed({ key: { type: 'string', pattern: '^m_[a-z0-9_]{1,28}$' }, template: { type: 'string', enum: ['drum', 'crate', 'arch', 'bench', 'pallet', 'pier', 'part'] }, recipe: { type: 'object' } }, ['key']) },
  ops: { type: 'array', maxItems: 128, items: closed({ name: { type: 'string', maxLength: 64 }, args: { type: 'object' } }, ['name']) }
}, ['format', 'world']);
export function validatePlan(plan) {
  jsonSafe(plan); validate(plan, PLAN_SCHEMA);
  const keys = new Set();
  for (const model of plan.models ?? []) {
    if (!MODEL_KEY.test(model.key) || keys.has(model.key)) throw new Error('Model keys must be valid and unique.');
    keys.add(model.key);
    if (Boolean(model.template) === Boolean(model.recipe)) throw new Error('Each model needs exactly one template or recipe.');
  }
  for (const op of plan.ops ?? []) {
    const def = TOOLS.find(t => t.name === op.name);
    if (!def || !WORLD_WRITES.has(op.name) || op.name.startsWith('model_') || ['world_make', 'world_recipe', 'world_batch', 'world_undo', 'world_redo', 'asset_bind', 'asset_unbind'].includes(op.name)) throw new Error(`Plan operation ${op.name} is not allowed.`);
    validate(op.args ?? {}, def.inputSchema);
  }
  return plan;
}
export function buildPlan(plan, { inputs = '', cache = '', phase = () => {} } = {}) {
  validatePlan(plan);
  let world = make(plan.world);
  const index = read(resolve(root, 'modeler/starter/index.json')), assets = {}, maps = {}, models = [], results = [];
  for (const def of plan.models ?? []) {
    let result, bytes;
    if (def.template) {
      const entry = index.models.find(e => e.template === def.template);
      if (!entry) throw new Error(`Missing starter ${def.template}.`);
      result = structuredClone(entry.result); bytes = readFileSync(resolve(root, 'modeler/starter', `${result.hash}.glb`));
      if (createHash('sha256').update(bytes).digest('hex') !== result.hash) throw new Error('Starter asset hash failed.');
    } else ({ bytes, result } = compile(def.recipe, { inputs, cache, phase }));
    const { report, ...descriptor } = result;
    world.models ??= {}; world.models[def.key] = descriptor; assets[result.hash] = bytes.toString('base64'); models.push({ key: def.key, hash: result.hash, report });
  }
  for (let i = 0; i < (plan.ops ?? []).length; i++) {
    const op = plan.ops[i];
    try { const out = tool(world, op.name, op.args ?? {}); world = out.world; results.push({ operation: i, name: op.name, ...out.result }); }
    catch (e) { throw new Error(`Plan operation ${i} (${op.name}): ${e.message}`); }
  }
  check(world);
  for (const hash of Object.values(bindings(world))) if (!assets[hash]) throw new Error('Plan references an asset not included in its output.');
  for (const hash of worldInputs(world)) {
    const bytes = readFileSync(resolve(inputs, `${hash}.png`));
    if (createHash('sha256').update(bytes).digest('hex') !== hash) throw new Error('Plan input hash failed.'); maps[hash] = bytes.toString('base64');
  }
  const binary = [...Object.values(assets), ...Object.values(maps)].reduce((n, b) => n + Buffer.byteLength(b, 'base64'), 0);
  if (binary > 64 * 1024 * 1024) throw new Error('Plan assets exceed the 64 MiB portable-bundle limit.');
  return { pack: { seedworkPack: 1, world, assets, inputs: maps }, report: { models, operations: results, validation: tool(world, 'world_validate').result, visualReview: 'Not run by this command. Open the project and inspect it in the browser.', externalNetwork: false } };
}
export function writePlan(plan, target, { inputs = '', standalone = false } = {}) {
  target = resolve(target);
  if (existsSync(target)) throw new Error('Output exists. Use a new folder; existing projects are not overwritten.');
  const temp = `${target}.seedwork-${randomUUID()}`;
  mkdirSync(dirname(target), { recursive: true }); mkdirSync(temp);
  try {
    const built = buildPlan(plan, { inputs, cache: resolve(temp, '.cache/model-materials') });
    if (standalone) for (const name of releaseFiles(root)) {
      const out = resolve(temp, name); mkdirSync(dirname(out), { recursive: true }); cpSync(resolve(root, name), out);
    }
    const project = standalone ? resolve(temp, 'project') : temp; mkdirSync(project, { recursive: true });
    writeFileSync(resolve(project, 'start.seedpack.json'), JSON.stringify(built.pack));
    writeFileSync(resolve(project, 'world.world.json'), JSON.stringify(built.pack.world, null, 2) + '\n');
    writeFileSync(resolve(project, 'plan.json'), JSON.stringify(plan, null, 2) + '\n');
    writeFileSync(resolve(project, 'report.json'), JSON.stringify(built.report, null, 2) + '\n');
    writeFileSync(resolve(project, 'README.md'), '# Generated Seedwork project\n\n' + (standalone ? 'Run `node server.mjs` from the parent folder. On the first launch, Seedwork imports `project/start.seedpack.json`. Subsequent launches preserve `.seedwork/` edits instead of overwriting them. Use the editor’s Play world action for traversal.\n' : 'In Seedwork, open `start.seedpack.json` with Open world + assets. The JSON-only file is not a complete asset backup.\n') + '\nThis is a playable world-authoring project, not an automatically complete game. See report.json for data validation and remaining visual/gameplay review. To revise the running world, use revision-checked tools; do not delete its local data.\n');
    rmSync(resolve(temp, '.cache'), { force: true, recursive: true });
    renameSync(temp, target);
    return { path: target, standalone, models: built.report.models.length, objects: built.pack.world.objects.length, validation: built.report.validation };
  } catch (e) { rmSync(temp, { force: true, recursive: true }); throw e; }
}
