import { readFileSync, writeFileSync, mkdirSync, readdirSync, unlinkSync } from 'node:fs';
import { resolve } from 'node:path';
import { compile } from '../modeler/compiler.mjs';

const root = resolve(import.meta.dirname, '..'), dir = resolve(root, 'modeler/starter');
const prior = (() => { try { return JSON.parse(readFileSync(resolve(dir, 'index.json'))).models; } catch { return []; } })();
const catalog = JSON.parse(readFileSync(resolve(root, 'modeler/catalog.json'))), models = [];
const keep = new Set(['index.json']);
mkdirSync(dir, { recursive: true });
for (const template of catalog.templates) {
  process.stdout.write(`Building ${template.id}\n`);
  const { bytes, reference, result } = compile(template.recipe, { cache: resolve(root, '.cache/model-materials') });
  writeFileSync(resolve(dir, `${result.hash}.glb`), bytes); keep.add(`${result.hash}.glb`);
  models.push({ template: template.id, result });
  if (process.env.SEEDWORK_REF_DIR) { const out = resolve(process.env.SEEDWORK_REF_DIR, template.id); mkdirSync(out, { recursive: true }); writeFileSync(resolve(out, 'reference.glb'), reference); }
  process.stdout.write(JSON.stringify({ template: template.id, hash: result.hash, ...result.report.packed }) + '\n');
}
writeFileSync(resolve(dir, 'index.json'), JSON.stringify({ version: 1, compiler: 'seedwork-native/0.7.0', models }, null, 2) + '\n');
for (const name of readdirSync(dir)) if (!keep.has(name)) unlinkSync(resolve(dir, name));

const changes = new Map(prior.map(entry => [entry.result.hash, models.find(e => e.template === entry.template)?.result]).filter(([, result]) => result));
function update(value) {
  if (Array.isArray(value)) return value.map(update);
  if (!value || typeof value !== 'object') return value;
  const next = changes.get(value.hash);
  if (next && value.recipe) { const { report, ...model } = next; return 'report' in value ? next : model; }
  if (next && value.size && value.boxes) {
    return { ...value, hash: next.hash, size: [next.width, next.height, next.depth], boxes: next.boxes, sockets: { ...value.sockets, top: { pos: [0, next.height, 0], rot: [0, 0, 0] }, left: { pos: [-next.width / 2, 0, 0], rot: [0, 0, 0] }, right: { pos: [next.width / 2, 0, 0], rot: [0, 0, 0] } }, ...(value.source ? { source: { ...value.source, recipe: next.recipe, build: next.build } } : {}) };
  }
  return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, k === 'hash' && changes.has(v) ? changes.get(v).hash : update(v)]));
}
function updateExamples(dir) {
  for (const name of readdirSync(dir, { withFileTypes: true })) {
    const file = resolve(dir, name.name);
    if (name.isDirectory()) updateExamples(file);
    else if (name.name.endsWith('.json')) { const value = JSON.parse(readFileSync(file)), next = update(value); if (JSON.stringify(value) !== JSON.stringify(next)) writeFileSync(file, JSON.stringify(next, null, 2) + '\n'); }
  }
}
updateExamples(resolve(root, 'examples'));
