import { deflateRawSync } from 'node:zlib';
import { readFileSync, statSync } from 'node:fs';
import { resolve } from 'node:path';
import { crc32 } from '../modeler/png.mjs';

export function zip(root, files, folder = 'seedwork') {
  if (!/^[a-z0-9._-]+$/i.test(folder) || files.length > 65535) throw new Error('Invalid ZIP folder or file count.');
  const local = [], central = []; let offset = 0;
  const day = (2026 - 1980) << 9 | 9 << 5 | 24;
  for (const file of [...files].sort()) {
    if (file.includes('..') || file.startsWith('/') || file.includes('\\')) throw new Error('Unsafe ZIP path.');
    const name = Buffer.from(`${folder}/${file}`), data = readFileSync(resolve(root, file)), packed = deflateRawSync(data, { level: 6 }), crc = crc32(data);
    if (data.length > 0xffffffff || packed.length > 0xffffffff || name.length > 65535) throw new Error('ZIP32 size limit exceeded.');
    const head = Buffer.alloc(30); head.writeUInt32LE(0x04034b50); head.writeUInt16LE(20, 4); head.writeUInt16LE(0x800, 6); head.writeUInt16LE(8, 8); head.writeUInt16LE(day, 12); head.writeUInt32LE(crc, 14); head.writeUInt32LE(packed.length, 18); head.writeUInt32LE(data.length, 22); head.writeUInt16LE(name.length, 26);
    local.push(head, name, packed);
    const dir = Buffer.alloc(46); dir.writeUInt32LE(0x02014b50); dir.writeUInt16LE(0x0314, 4); dir.writeUInt16LE(20, 6); dir.writeUInt16LE(0x800, 8); dir.writeUInt16LE(8, 10); dir.writeUInt16LE(day, 14); dir.writeUInt32LE(crc, 16); dir.writeUInt32LE(packed.length, 20); dir.writeUInt32LE(data.length, 24); dir.writeUInt16LE(name.length, 28);
    const mode = statSync(resolve(root, file)).mode & 0o111 ? 0o100755 : 0o100644;
    dir.writeUInt32LE((mode << 16) >>> 0, 38); dir.writeUInt32LE(offset, 42); central.push(dir, name); offset += head.length + name.length + packed.length;
    if (offset > 0xffffffff) throw new Error('ZIP32 archive too large.');
  }
  const end = Buffer.alloc(22), size = central.reduce((n, b) => n + b.length, 0);
  end.writeUInt32LE(0x06054b50); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(size, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, ...central, end]);
}
