import { readdirSync, lstatSync } from 'node:fs';
import { resolve, relative, sep } from 'node:path';

const excluded = new Set(['.git', '.seedwork', '.cache', '.venv', 'node_modules', '__pycache__', 'dist', 'reports', 'runtime-game', 'model-builds', 'material-cache', 'model-inputs', 'project', '.DS_Store', 'Thumbs.db']);
export function releaseFiles(root) {
  const files = [];
  function visit(dir) {
    for (const name of readdirSync(dir).sort()) {
      if (excluded.has(name) || name === '.env' || name.startsWith('.env.') || /\.(?:pyc|tmp|log|pem|key|p12|pfx)$/.test(name) || name.startsWith('.test-data') || name.endsWith('-browser-report')) continue;
      const path = resolve(dir, name), stat = lstatSync(path), rel = relative(root, path).split(sep).join('/');
      if (stat.isSymbolicLink()) throw new Error(`Symlinks are not allowed in release sources: ${rel}`);
      if (stat.isDirectory()) visit(path); else if (stat.isFile()) files.push(rel);
    }
  }
  visit(resolve(root)); return files.sort();
}
