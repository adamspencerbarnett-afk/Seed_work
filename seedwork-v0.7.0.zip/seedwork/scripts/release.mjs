import { readFileSync, writeFileSync, mkdirSync, existsSync, renameSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { toolCatalog } from '../services/tools.mjs';
import { releaseFiles } from './files.mjs';
import { zip } from './zip.mjs';
import { verify } from './verify.mjs';
import { PLAN_SCHEMA } from './plan.mjs';

const root = resolve(import.meta.dirname, '..');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
export function prepare(dir = root) {
  const read = name => JSON.parse(readFileSync(resolve(dir, name), 'utf8')), put = (name, data) => writeFileSync(resolve(dir, name), JSON.stringify(data, null, 2) + '\n');
  const pkg = read('package.json'); if (!/^\d+\.\d+\.\d+$/.test(pkg.version)) throw new Error('Expected a release version.');
  put('plan.schema.json', PLAN_SCHEMA);
  put('tools.manifest.json', { format: 'seedwork.tools/1', version: pkg.version, tools: toolCatalog(true) });
  const vendor = read('notices/vendor-verification.json');
  for (const entry of vendor) if (sha(readFileSync(resolve(dir, entry.file))) !== entry.sha256) throw new Error(`Vendor file changed since review: ${entry.file}`);
  put('SBOM.json', { format: 'seedwork.inventory/1', version: pkg.version, author: 'Adam S. Barnett', runtimeDependencies: [{ name: 'Three.js', version: 'r140', license: 'MIT', notice: 'public/vendor/THREE-LICENSE.txt', files: vendor.map(v => ({ path: v.file, sha256: v.sha256 })) }], requiredExternalRuntimes: ['Node.js >=22', 'WebGL-capable browser'], downloadedRuntimePackages: [], inheritedNotice: 'notices/seedwork-prior-MIT.txt', originalPermission: 'README.md#commercial-use-permission', nativeModels: read('modeler/starter/index.json').models.map(m => ({ template: m.template, path: `modeler/starter/${m.result.hash}.glb`, sha256: m.result.hash, compiler: m.result.build })), assetFiles: releaseFiles(dir).filter(f => f.startsWith('public/assets/') && /\.(png|glb)$/.test(f)).map(path => ({ path, sha256: sha(readFileSync(resolve(dir, path))), source: 'Original procedural Seedwork artwork; retained prior MIT notice.' })) });
  put('RELEASE.json', { format: 'seedwork.release/1', version: pkg.version, date: '2026-09-24', author: 'Adam S. Barnett', base: '0.6 environment preview (integrated 0.4 base)', advancedWater05Merged: false, nativeModeler: 'Independent Node compiler; excluded legacy kit is not distributed', renderer: 'Three.js r140', tools: toolCatalog(true).length, manifest: 'SHA256SUMS', evidence: 'docs/TESTS.md', publication: 'Prepared archive; no remote publication implied.', build: 'node scripts/release.mjs', reproducibility: 'Sorted source, fixed ZIP metadata and deterministic compression for the same Node/zlib toolchain; not a digital signature.' });
  const files = releaseFiles(dir).filter(f => f !== 'SHA256SUMS');
  writeFileSync(resolve(dir, 'SHA256SUMS'), files.map(f => `${sha(readFileSync(resolve(dir, f)))}  ${f}`).join('\n') + '\n');
  return { ...verify(dir), files: releaseFiles(dir) };
}
export function release({ dir = root, out } = {}) {
  const report = prepare(dir), name = `seedwork-v${report.version}.zip`, path = out ? resolve(out) : resolve(dir, 'dist', name);
  if (!path.endsWith('.zip')) throw new Error('Release output must end with .zip.');
  mkdirSync(dirname(path), { recursive: true }); const bytes = zip(dir, report.files);
  writeFileSync(`${path}.tmp`, bytes); renameSync(`${path}.tmp`, path);
  const hash = sha(bytes); writeFileSync(`${path}.sha256`, `${hash}  ${path.split(/[\\/]/).at(-1)}\n`);
  return { version: report.version, path, bytes: bytes.length, sha256: hash, files: report.files.length, tools: report.tools, starters: report.starters.length };
}
if (process.argv[1] && resolve(process.argv[1]) === resolve(import.meta.filename)) {
  try {
    const args = process.argv.slice(2); if (args.length && (args.length !== 2 || args[0] !== '--out')) throw new Error('Usage: node scripts/release.mjs [--out archive.zip]');
    console.log(JSON.stringify(release({ out: args[1] }), null, 2));
  } catch (e) { console.error(e.message); process.exitCode = 1; }
}
