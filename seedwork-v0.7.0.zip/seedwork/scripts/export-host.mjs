import { readFileSync, writeFileSync, existsSync, mkdirSync, cpSync, rmSync, renameSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { checkScene } from '../sdk/core/scene.mjs';
import { digest } from '../services/store.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const options = {};
for (let i = 2; i < process.argv.length; i += 2) {
  const name = process.argv[i], value = process.argv[i + 1];
  if (!['--data', '--out', '--scene'].includes(name) || !value) throw new Error('Usage: node scripts/export-host.mjs --out ../courtyard-game [--data .seedwork] [--scene examples/courtyard.scene.json]');
  options[name.slice(2)] = value;
}
const data = resolve(options.data ?? process.env.SEEDWORK_DIR ?? join(root, '.seedwork'));
const target = resolve(options.out ?? join(root, 'runtime-game'));
if (existsSync(target) || existsSync(`${target}.tmp`)) throw new Error('The export directory must not exist. Choose a new path; existing projects are never overwritten.');
const saved = options.scene ? { doc: JSON.parse(readFileSync(resolve(options.scene), 'utf8')), rev: null } : JSON.parse(readFileSync(join(data, 'project.json'), 'utf8'));
checkScene(saved.doc);
const doc = structuredClone(saved.doc);
for (const asset of Object.values(doc.assets)) delete asset.source;
const hashes = [...new Set(Object.values(doc.assets).map(a => a.hash))], files = [];
for (const hash of hashes) {
  const paths = [join(data, 'assets', `${hash}.glb`), join(root, 'modeler/starter', `${hash}.glb`)];
  const file = paths.find(p => existsSync(p)); if (!file) throw new Error(`Missing approved asset: ${hash}`);
  const bytes = readFileSync(file); if (createHash('sha256').update(bytes).digest('hex') !== hash) throw new Error(`Asset integrity failure: ${hash}`);
  files.push({ file, hash, bytes: bytes.length });
}
const out = `${target}.tmp`;
try {
  for (const p of ['sdk/core', 'vendor', 'assets', 'materials', 'notices']) mkdirSync(join(out, p), { recursive: true });
  for (const name of ['index.mjs', 'three.mjs', 'glb.mjs', 'LICENSE']) cpSync(join(root, 'sdk', name), join(out, 'sdk', name));
  for (const name of ['schema.mjs', 'scene.mjs', 'math.mjs']) cpSync(join(root, 'sdk/core', name), join(out, 'sdk/core', name));
  for (const name of ['three-r140.min.js', 'GLTFLoader-r140.js', 'THREE-LICENSE.txt']) cpSync(join(root, 'public/vendor', name), join(out, 'vendor', name));
  for (const material of ['ground', 'masonry', 'rock']) for (const map of ['color', 'normal', 'orm']) cpSync(join(root, 'public/assets/materials', `${material}-${map}.png`), join(out, 'materials', `${material}-${map}.png`));
  cpSync(join(root, 'public/host/game.mjs'), join(out, 'game.mjs'));
  for (const file of files) cpSync(file.file, join(out, 'assets', `${file.hash}.glb`));
  for (const name of ['index.html', 'app.mjs', 'serve.mjs']) cpSync(join(root, 'examples/runtime-template', name), join(out, name));
  cpSync(join(root, 'notices/seedwork-prior-MIT.txt'), join(out, 'notices/seedwork-prior-MIT.txt'));
  writeFileSync(join(out, 'THIRD_PARTY.md'), '# Runtime credits\n\nSeedwork project direction and original additions: Adam S. Barnett, developed with AI assistance. Retained Seedwork contributions and procedural materials: notices/seedwork-prior-MIT.txt and sdk/LICENSE. Three.js authors: vendor/THREE-LICENSE.txt (r140). These MIT notices authorize commercial redistribution subject to their terms. Original model recipes and new compiler maps were authored for Seedwork; user-imported assets require their own permission review. No ownership transfer is implied by conversion.\n');
  writeFileSync(join(out, 'notices/seedwork-release-permission.txt'), readFileSync(join(root, 'README.md'), 'utf8').split('## Commercial-use permission')[1].split('## Release maintenance')[0].trim() + '\n');
  writeFileSync(join(out, 'scene.json'), JSON.stringify(doc));
  writeFileSync(join(out, 'build.json'), JSON.stringify({ format: 'seedwork.runtime/1', seedwork: '0.7.0', revision: saved.rev ?? null, sourceHash: digest(saved.doc), runtimeHash: digest(doc), assets: files.map(({ hash, bytes }) => ({ hash, bytes })), note: 'Runtime-only template: host gameplay and native static assets. Source recipes are omitted. No authoring services, credentials, MCP, or Python are bundled.' }, null, 2));
  writeFileSync(join(out, 'README.md'), '# Standalone courtyard game\n\nRun `node serve.mjs`, then open `http://127.0.0.1:4180`. This serves static files only. No Seedwork authoring service, Python, MCP, AI account, or network asset download is required.\n\nThis template retains the host game and exports the committed project scene. GLB bytes are copied and hash-verified, not remeshed or resized. Recipes and source input maps remain in the authoring project and are not a complete editable backup here. The original project is unchanged.\n\nControls: drag to orbit, wheel to zoom, Walk, WASD, arrows, E gate, Escape overview. Collision is the demonstration host\'s compound AABB system, not general mesh physics.\n');
  renameSync(out, target);
  console.log(JSON.stringify({ path: target, objects: doc.items.length, assets: files.length, glbBytes: files.reduce((n, f) => n + f.bytes, 0), hash: digest(doc) }, null, 2));
} catch (e) { rmSync(out, { recursive: true, force: true }); throw e; }
