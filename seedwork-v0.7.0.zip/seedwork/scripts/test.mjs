import { readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = resolve(import.meta.dirname, '..');
const files = readdirSync(resolve(root, 'tests')).filter(n => n.endsWith('.test.mjs')).sort().map(n => resolve(root, 'tests', n));
const result = spawnSync(process.execPath, ['--test', ...files], { cwd: root, stdio: 'inherit', shell: false });
if (result.error) throw result.error;
process.exitCode = result.status ?? 1;
