import { performance } from 'node:perf_hooks';
import { make, height, canWalk, rand } from '../core/world.mjs';
import { sample, collider } from '../core/spatial.mjs';
const w=make(),field=sample(w),col=collider(w,field),rng=rand(172),pts=Array.from({length:10000},()=>[(rng()-.5)*120,(rng()-.5)*120]);
function measure(fn){let result=0;const t=performance.now();for(const [x,z]of pts)result+=Number(fn(x,z));return {ms:performance.now()-t,checksum:result};}
measure((x,z)=>height(w,x,z));measure(field.get);measure((x,z)=>canWalk(w,x,z));measure(col.walk);
const out={node:process.version,points:pts.length,objects:w.objects.length,note:'CPU wall-clock microbenchmark; excludes index build and rendering. Results vary by machine.',height:{reference:[],cached:[]},collision:{reference:[],indexed:[]}};
for(let i=0;i<5;i++){out.height.reference.push(measure((x,z)=>height(w,x,z)));out.height.cached.push(measure(field.get));out.collision.reference.push(measure((x,z)=>canWalk(w,x,z)));out.collision.indexed.push(measure(col.walk));}
console.log(JSON.stringify(out,null,2));
