import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { toolCatalog } from '../services/tools.mjs';
import { doctor } from '../modeler/compiler.mjs';
import { PLAN_SCHEMA } from './plan.mjs';
import { releaseFiles } from './files.mjs';

const root = resolve(import.meta.dirname, '..');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
export function verify(dir = root) {
  const read = name => JSON.parse(readFileSync(resolve(dir, name), 'utf8')), pkg = read('package.json'), errors = [], rows = [];
  if (!existsSync(resolve(dir, 'SHA256SUMS'))) throw new Error('SHA256SUMS is missing. Build a reviewed release with node scripts/release.mjs.');
  const listed = new Set();
  for (const line of readFileSync(resolve(dir, 'SHA256SUMS'), 'utf8').trim().split('\n')) {
    const m = /^([a-f0-9]{64})  ([^\r\n]+)$/.exec(line);
    if (!m || m[2].startsWith('/') || m[2].includes('..') || m[2].includes('\\') || listed.has(m[2])) { errors.push('Invalid or duplicate checksum entry.'); continue; }
    listed.add(m[2]);
    try { if (sha(readFileSync(resolve(dir, m[2]))) !== m[1]) errors.push(`Changed file: ${m[2]}`); } catch { errors.push(`Missing file: ${m[2]}`); }
  }
  for (const name of releaseFiles(dir)) if (name !== 'SHA256SUMS' && !listed.has(name)) errors.push(`Unlisted source file: ${name}`);
  for (const name of ['RELEASE.json', 'seedwork-capabilities.json', 'tools.manifest.json', 'ATTRIBUTION.json', 'SBOM.json', 'sdk/package.json']) if (read(name).version !== pkg.version) errors.push(`Version mismatch: ${name}`);
  if (JSON.stringify(read('tools.manifest.json').tools) !== JSON.stringify(toolCatalog(true))) errors.push('Tool manifest differs from executable schemas.');
  if (JSON.stringify(read('plan.schema.json')) !== JSON.stringify(PLAN_SCHEMA)) errors.push('Plan schema differs from executable validation.');
  if (Object.keys(pkg.dependencies ?? {}).length) errors.push('Unexpected npm runtime dependencies.');
  if (existsSync(resolve(dir, 'modeler/kit')) || existsSync(resolve(dir, 'modeler/worker.py')) || existsSync(resolve(dir, 'setup-modeler.mjs'))) errors.push('Excluded modeling component is present.');
  for (const name of ['README.md', 'START_HERE_CHATGPT.md', 'AGENTS.md', 'THIRD_PARTY.md', 'notices/seedwork-prior-MIT.txt', 'sdk/LICENSE', 'public/vendor/THREE-LICENSE.txt']) if (!listed.has(name)) errors.push(`Required instructions or notice missing: ${name}`);
  const info = doctor();
  for (const model of read('modeler/starter/index.json').models) {
    const result = model.result, file = `modeler/starter/${result.hash}.glb`;
    if (result.build.version !== pkg.version || result.build.source !== info.source) errors.push(`Stale compiler provenance: ${model.template}`);
    if (sha(readFileSync(resolve(dir, file))) !== result.hash || !result.report.exact.passed) errors.push(`Starter failed integrity: ${model.template}`);
    rows.push({ template: model.template, hash: result.hash, bytes: result.report.packed.bytes });
  }
  const result = { passed: !errors.length, version: pkg.version, checkedFiles: listed.size, tools: read('tools.manifest.json').tools.length, starters: rows, errors };
  if (errors.length) { const e = new Error(errors.join('\n')); e.result = result; throw e; }
  return result;
}
if (process.argv[1] && resolve(process.argv[1]) === resolve(import.meta.filename)) {
  try { console.log(JSON.stringify(verify(), null, 2)); } catch (e) { console.error(JSON.stringify(e.result ?? { error: e.message }, null, 2)); process.exitCode = 1; }
}
