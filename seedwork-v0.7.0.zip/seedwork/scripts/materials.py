from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import map_coordinates, gaussian_filter

out = Path(__file__).resolve().parents[1] / 'public/assets/materials'
out.mkdir(parents=True, exist_ok=True)
N = 512
y, x = np.mgrid[0:N, 0:N] / N
rng = np.random.default_rng(2147)

def noise(n, m=None):
    a = rng.random((m or n, n))
    return map_coordinates(a, [y * a.shape[0], x * a.shape[1]], order=3, mode='grid-wrap')

def fbm():
    return sum(noise(n) * w for n, w in [(4,.32),(8,.25),(16,.18),(32,.13),(64,.08),(128,.04)])

def save(name, color, h, rough=.85, strength=5):
    dx = (np.roll(h,-1,1)-np.roll(h,1,1))*strength
    dy = (np.roll(h,-1,0)-np.roll(h,1,0))*strength
    normal = np.stack([-dx,dy,np.ones_like(h)],-1)
    normal /= np.linalg.norm(normal,axis=-1)[...,None]
    cavity = np.clip(.92 + (h-gaussian_filter(h,3,mode='wrap'))*.8,.4,1)
    orm = np.stack([cavity,np.clip(rough+(h-.5)*.15,.15,1),np.zeros_like(h)],-1)
    for suffix, a in [('color',color),('normal',normal*.5+.5),('orm',orm)]:
        Image.fromarray(np.uint8(np.clip(a,0,1)*255)).save(out/f'{name}-{suffix}.png', optimize=True)

n = fbm(); fine = noise(160)
h = n*.5+fine*.2
color = np.stack([.44+n*.28,.43+n*.26,.37+n*.23],-1) * (.78+fine[...,None]*.35)
save('ground',color,h,.95,7)

n=fbm(); h = n*.75+noise(128)*.13
color=np.stack([.26+n*.46,.27+n*.43,.26+n*.39],-1)
veins=np.exp(-((noise(12)-.45)*26)**2)*.08
color += veins[...,None]
save('rock',color,h,.87,8)

n=fbm(); grooves=np.abs(np.sin(x*np.pi*26+noise(8,3)*4))
h = n*.3+grooves*.32+noise(96,6)*.18
color=np.stack([.15+h*.32,.10+h*.23,.065+h*.15],-1)
save('bark',color,h,.96,9)

n=noise(48,3); h = n*.35+np.abs(np.sin(x*np.pi*80+n*6))*.10
plank=np.minimum((x*5)%1,1-(x*5)%1)
h-=np.exp(-plank*110)*.25
color=np.stack([.25+h*.5,.17+h*.41,.105+h*.26],-1)*(1-np.exp(-plank[...,None]*130)*.55)
save('wood',color,h,.85,6)

n=fbm(); row=np.floor(y*8); px=(x*4+(row%2)*.5)%1; py=(y*8)%1
edge=np.minimum(np.minimum(px,1-px)*.8,np.minimum(py,1-py))
mortar=np.clip((edge-.018)/.03,0,1)
block=noise(16,8)
h=mortar*(.36+n*.15)+noise(128)*.035
base=np.stack([.47+n*.28,.43+n*.26,.36+n*.26],-1)
color=base*mortar[...,None]+np.array([.23,.215,.18])*(1-mortar[...,None])
save('masonry',color,h,.91,9)

n=fbm(); py=(y*12)%1; px=(x*9+(np.floor(y*12)%2)*.5)%1
edge=np.minimum(px,1-px)
h=np.clip(py*1.25,0,1)*.13+noise(128)*.025
h-=np.exp(-edge*160)*.12
color=np.stack([.23+n*.16,.24+n*.16,.235+n*.17],-1)*(1-np.exp(-edge[...,None]*100)*.45)*(0.78+py[...,None]*.22)
save('slate',color,h,.77,8)

n=fbm(); h=noise(160)*.10+n*.08
color=np.stack([.67+n*.18,.64+n*.17,.56+n*.18],-1)
save('plaster',color,h,.98,4)

n=fbm(); h=noise(128)*.11+n*.15
color=np.stack([.66+n*.28,.70+n*.26,.74+n*.23],-1)
save('snow',color,h,.64,6)

n=fbm(); h = np.sin((x*22+noise(8)*.08)*np.pi*2)*.045+noise(128)*.025
color=np.stack([.63+n*.25,.52+n*.25,.35+n*.28],-1)
save('sand',color,h,.9,5)

n=fbm(); h=n*.12+noise(128)*.1
color=np.stack([.19+n*.25,.25+n*.28,.105+n*.18],-1)
save('leaf',color,h,.84,3)

im=Image.new('RGBA',(512,512)); d=ImageDraw.Draw(im)
r=np.random.default_rng(87)
d.line([(255,475),(256,25)],fill=(77,63,34,255),width=6)
for yy in range(35,464,7):
    width=int((1-abs(yy-260)/270)*185)
    for side in [-1,1]:
        ex=256+side*width; ey=yy-37
        d.line([(256,yy),(ex,ey)], fill=(48,64,30,255),width=3)
        for t in np.linspace(.10,.98,13):
            a=256+(ex-256)*t; b=yy+(ey-yy)*t
            length=float(r.uniform(15,27)); col=(int(r.integers(37,65)),int(r.integers(60,92)),int(r.integers(25,46)),255)
            d.line([(a,b),(a+side*length*.7,b-length)],fill=col,width=2)
            d.line([(a,b),(a+side*length*.7,b+length*.52)],fill=col,width=2)
im.save(out/'needles-color.png',optimize=True)
manifest={'version':1,'resolution':512,'license':'Original Seedwork procedural textures; MIT. Not scanned or photographed.','materials':['ground','rock','bark','wood','masonry','slate','plaster','snow','sand','leaf'],'channels':{'color':'sRGB','normal':'linear tangent-space OpenGL','orm':'linear: R ambient occlusion, G roughness, B metallic'},'compression':'PNG lossless; no GPU texture compression'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Wrote',len(list(out.glob('*.png'))),'textures')
