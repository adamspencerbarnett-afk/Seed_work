import { createEnvironment, bindAtmosphere, createEnvTools, preset, PRESET_NAMES } from '/sdk/environment/index.mjs';
import { createStudy } from './scene.mjs';
const T = window.THREE, $ = id => document.getElementById(id);
const renderer = new T.WebGLRenderer({ canvas: $('view'), antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(devicePixelRatio); renderer.outputEncoding = T.sRGBEncoding; renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = .95;
renderer.physicallyCorrectLights = true; renderer.shadowMap.enabled = true; renderer.shadowMap.type = T.PCFSoftShadowMap; renderer.shadowMap.autoUpdate = false;
const camera = new T.PerspectiveCamera(44, 1, .12, 160);
const target = new T.Vector3(-.8, 2.4, 1), state = { yaw: .72, tilt: .33, dist: 26, paused: false, preset: 'clear', dirty: true, last: performance.now(), frames: 0, shadow: '' };
const toast = text => { $('toast').textContent = text; $('toast').classList.add('show'); setTimeout(() => $('toast').classList.remove('show'), 4000); };
const download = (text, name, type = 'application/json') => { const url = URL.createObjectURL(new Blob([text], { type })), a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 2000); };
function placeCamera() { camera.position.set(target.x + Math.sin(state.yaw) * Math.cos(state.tilt) * state.dist, target.y + Math.sin(state.tilt) * state.dist, target.z + Math.cos(state.yaw) * Math.cos(state.tilt) * state.dist); camera.lookAt(target); camera.updateMatrixWorld(); }
placeCamera();
let study, env, tools, undoAtmosphere, raf;
const errors = []; window.addEventListener('error', event => { errors.push(event.message); toast(event.message); });
try {
  study = await createStudy(renderer);
  env = createEnvironment({ THREE: T, parent: study.scene, camera, field: { bounds: [-35, -35, 70, 70], range: [-10, 30], size: 256, ground: study.ground, roof: study.roof } });
  env.bind(study.groups.ground, { wet: 1, snow: 1, ice: .28 }); env.bind(study.groups.stone, { wet: .85, snow: 1, ice: .2 }); env.bind(study.groups.wood, { wet: .78, snow: .9, ice: .08 }); env.bind(study.groups.foliage, { wet: .35, snow: .5, foliage: 1 }); env.bind(study.groups.ice, { wet: .2, snow: 1, ice: 1 });
  undoAtmosphere = bindAtmosphere(env, { scene: study.scene, sun: study.sun, hemi: study.hemi, background: true });
  env.subscribe(({ config, surface }) => {
    study.ice.visible = surface.ice > .08;
    const key = config.foliage.retention.toFixed(8);
    if (state.shadow !== key) { renderer.shadowMap.needsUpdate = true; state.shadow = key; }
  });
  tools = createEnvTools(env);
  $('busy').hidden = true;
} catch (error) { $('busy').textContent = `Cannot initialize: ${error.message}`; throw error; }
const labels = { clear: ['Summer', 'Clear / dry'], rain: ['Rain', 'Wet surfaces'], snow: ['Snow', 'Sheltered cover'], ice: ['Freeze', 'Ice & frost'], autumn: ['Autumn', 'Leaves & litter'], mist: ['Mist', 'Distance haze'], thaw: ['Thaw', 'Evolving surfaces'] };
$('presets').innerHTML = PRESET_NAMES.map((n, i) => `<button data-preset="${n}" aria-label="${labels[n][0]}"><b>${String(i + 1).padStart(2, '0')} ${labels[n][0]}</b><small>${labels[n][1]}</small></button>`).join('');
const fields = [
  ['Rain', 'weather.rain', 0, 1, .01], ['Snowfall', 'weather.snow', 0, 1, .01], ['Wetness', 'surface.wet', 0, 1, .01], ['Snow cover', 'surface.snow', 0, 1, .01], ['Ice / frost', 'surface.ice', 0, 1, .01], ['Autumn tint', 'foliage.autumn', 0, 1, .01], ['Leaf retention', 'foliage.retention', 0, 1, .01], ['Temperature', 'weather.temperature', -30, 30, 1], ['Wind X', 'weather.wind.0', -10, 10, .1], ['Fog density', 'atmosphere.fog', 0, .08, .001]
];
$('sliders').innerHTML = fields.map(([label, path, min, max, step]) => `<label class="slider"><span>${label}<output id="out-${path}"></output></span><input aria-label="${label}" data-field="${path}" type="range" min="${min}" max="${max}" step="${step}"></label>`).join('');
function fieldsFromConfig() {
  const c = env.climate.config;
  for (const [, path] of fields) { const value = path.split('.').reduce((o, key) => o[key], c); document.querySelector(`[data-field="${path}"]`).value = value; $(`out-${path}`).textContent = path === 'weather.temperature' ? `${value} °C` : path === 'weather.wind.0' ? `${value.toFixed(1)} m/s` : path === 'atmosphere.fog' ? value.toFixed(3) : `${Math.round(value * 100)}%`; }
  $('evolve').checked = c.simulation.enabled; $('title').textContent = c.name;
  document.querySelectorAll('[data-preset]').forEach(b => b.classList.toggle('active', b.dataset.preset === state.preset));
}
function apply(name) { env.preset(name); state.preset = name; state.dirty = true; fieldsFromConfig(); }
document.querySelectorAll('[data-preset]').forEach(b => b.onclick = () => apply(b.dataset.preset));
document.querySelectorAll('[data-field]').forEach(input => input.oninput = () => {
  const [section, key, index] = input.dataset.field.split('.'), value = +input.value;
  const patch = { [section]: { [key]: value } };
  if (index !== undefined) { patch[section][key] = [...env.climate.config[section][key]]; patch[section][key][+index] = value; }
  env.set(patch); state.preset = ''; state.dirty = true; fieldsFromConfig();
});
$('pause').onclick = () => { state.paused = !state.paused; $('pause').textContent = state.paused ? 'Resume' : 'Pause'; $('status').textContent = state.paused ? 'PAUSED' : 'LIVE'; state.dirty = true; };
$('evolve').onchange = () => { env.set({ simulation: { enabled: $('evolve').checked } }); state.dirty = true; };
$('reference').onchange = () => { env.setReference($('reference').checked); state.dirty = true; };
$('home').onclick = () => { target.set(-.8, 2.4, 1); Object.assign(state, { yaw: .72, tilt: .33, dist: 26, dirty: true }); };
$('detail').onclick = () => { target.set(3.7, .4, 3.6); Object.assign(state, { yaw: .8, tilt: .19, dist: 9.5, dirty: true }); };
$('save').onclick = () => download(JSON.stringify(env.snapshot(), null, 2), 'seedwork-climate.json');
$('load').onclick = () => $('file').click();
$('file').onchange = async () => { try { const file = $('file').files[0]; if (!file) return; if (file.size > 64000) throw Error('Climate file is limited to 64 KiB.'); env.restore(JSON.parse(await file.text())); state.preset = ''; fieldsFromConfig(); state.dirty = true; toast('Climate restored.'); } catch (e) { toast(e.message); } finally { $('file').value = ''; } };
$('shot').onclick = () => { render(); const a = document.createElement('a'); a.download = 'seedwork-environment.png'; a.href = renderer.domElement.toDataURL('image/png'); a.click(); };
$('tool').onchange = () => { $('args').value = JSON.stringify($('tool').value === 'environment_preset' ? { name: 'rain' } : $('tool').value === 'environment_set' ? { config: env.climate.config } : {}, null, 2); };
$('run').onclick = () => { try { const args = JSON.parse($('args').value); $('result').textContent = JSON.stringify(tools.call($('tool').value, args), null, 2); state.preset = $('tool').value === 'environment_preset' ? args.name : ''; state.dirty = true; fieldsFromConfig(); } catch (e) { $('result').textContent = `${e.code ?? 'ERROR'}: ${e.message}`; } };
let drag = null;
renderer.domElement.onpointerdown = e => { drag = [e.clientX, e.clientY]; renderer.domElement.setPointerCapture(e.pointerId); };
renderer.domElement.onpointermove = e => { if (!drag) return; state.yaw -= (e.clientX - drag[0]) * .005; state.tilt = Math.max(.025, Math.min(1.3, state.tilt + (e.clientY - drag[1]) * .004)); drag = [e.clientX, e.clientY]; state.dirty = true; };
renderer.domElement.onpointerup = () => { drag = null; }; renderer.domElement.onpointercancel = () => { drag = null; };
renderer.domElement.addEventListener('wheel', e => { e.preventDefault(); state.dist = Math.max(3, Math.min(60, state.dist * Math.exp(e.deltaY * .001))); state.dirty = true; }, { passive: false });
window.addEventListener('keydown', e => { if (e.target.matches('input,textarea,select')) return; if (+e.key >= 1 && +e.key <= 7) apply(PRESET_NAMES[+e.key - 1]); });
const resize = new ResizeObserver(() => { const box = renderer.domElement.parentElement; renderer.setSize(box.clientWidth, box.clientHeight, false); camera.aspect = box.clientWidth / Math.max(1, box.clientHeight); camera.updateProjectionMatrix(); state.dirty = true; }); resize.observe(renderer.domElement.parentElement);
function render() {
  placeCamera(); env.sync(); renderer.render(study.scene, camera); state.frames++;
  const stats = env.inspect(), count = stats.emitters.reduce((n, e) => n + e.submitted, 0), field = stats.field;
  $('metrics').innerHTML = `<div><span>Scene draw calls</span><strong>${renderer.info.render.calls}</strong></div><div><span>Particle instances</span><strong>${count.toLocaleString()}</strong></div><div><span>Field builds</span><strong>${field.builds}</strong></div><div><span>Exposure grid</span><strong>${field.size}²</strong></div>`;
  state.dirty = false;
}
function frame(now) {
  const dt = Math.max(0, (now - state.last) / 1000); state.last = now;
  if (!state.paused) { let left = Math.min(dt, 5); while (left > 0) { const step = Math.min(1, left); env.update(step); left -= step; } }
  if (!state.paused || state.dirty) render(); raf = requestAnimationFrame(frame);
}
fieldsFromConfig(); render(); raf = requestAnimationFrame(frame);
window.envLab = { env, study, renderer, camera, state, tools, errors, ready: true, render, apply, pause(value = true) { state.paused = value; $('pause').textContent = value ? 'Resume' : 'Pause'; $('status').textContent = value ? 'PAUSED' : 'LIVE'; }, fixed(name, time = 2) { this.pause(); env.preset(name); const snap = env.snapshot(); snap.time = time; env.restore(snap); state.preset = name; fieldsFromConfig(); render(); }, async dispose() { cancelAnimationFrame(raf); resize.disconnect(); undoAtmosphere(); env.dispose(); study.dispose(); renderer.dispose(); } };
