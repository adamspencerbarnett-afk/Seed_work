const T = window.THREE;
export async function createStudy(renderer) {
  const scene = new T.Scene(); scene.background = new T.Color('#bacbd6');
  const root = new T.Group(); scene.add(root);
  const mats = {}, textures = [], loader = new T.TextureLoader();
  const load = async (name, color, repeat) => {
    const map = await new Promise((ok, no) => loader.load(`/assets/materials/${name}.png`, ok, undefined, no));
    map.wrapS = map.wrapT = T.RepeatWrapping; map.repeat.set(repeat, repeat); map.anisotropy = renderer.capabilities.getMaxAnisotropy();
    map.encoding = color ? T.sRGBEncoding : T.LinearEncoding; textures.push(map); return map;
  };
  for (const name of ['ground', 'wood', 'bark', 'slate', 'rock', 'masonry']) {
    const [map, normal, orm] = await Promise.all([load(`${name}-color`, true, 1), load(`${name}-normal`, false, 1), load(`${name}-orm`, false, 1)]);
    mats[name] = new T.MeshStandardMaterial({ map, normalMap: normal, roughnessMap: orm, aoMap: orm, aoMapIntensity: .6, roughness: 1, metalness: 0, normalScale: new T.Vector2(.55, .55) }); mats[name].name = name;
  }
  mats.ground.color.set('#7d805b').convertSRGBToLinear();
  const sun = new T.DirectionalLight('#fff3d9', 2.35); sun.position.set(-18, 28, 12); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -27, right: 27, top: 27, bottom: -27, near: 1, far: 90 }); sun.shadow.normalBias = .025; sun.shadow.bias = -.00006; scene.add(sun); scene.add(sun.target);
  const hemi = new T.HemisphereLight('#d6e5f4', '#656353', .85); scene.add(hemi);
  const width = 256, height = 128, data = new Float32Array(width * height * 4);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const up = Math.cos((1 - y / (height - 1)) * Math.PI), i = (y * width + x) * 4;
    const col = new T.Color(up > 0 ? '#bbcedb' : '#766e5f').convertSRGBToLinear();
    const glow = Math.pow(Math.max(0, Math.cos((x / width - .34) * Math.PI * 2)), 14) * Math.pow(Math.max(0, up), 3) * 1.8;
    data[i] = col.r * .85 + glow; data[i + 1] = col.g * .85 + glow * .95; data[i + 2] = col.b * .85 + glow * .87; data[i + 3] = 1;
  }
  const sky = new T.DataTexture(data, width, height, T.RGBAFormat, T.FloatType); sky.mapping = T.EquirectangularReflectionMapping; sky.needsUpdate = true;
  const pmrem = new T.PMREMGenerator(renderer), env = pmrem.fromEquirectangular(sky); scene.environment = env.texture; pmrem.dispose(); sky.dispose();
  const ground = (x, z) => -.15 + Math.sin(x * .12) * Math.sin(z * .15) * .22 + Math.max(0, Math.hypot(x * .85, z) - 13) * .075;
  const add = (g, m, pos, rot = [0, 0, 0], owner = root) => { if (g.attributes.uv && !g.attributes.uv2) g.setAttribute('uv2', g.attributes.uv.clone()); const mesh = new T.Mesh(g, m); mesh.position.fromArray(pos); mesh.rotation.set(...rot); mesh.castShadow = true; mesh.receiveShadow = true; owner.add(mesh); return mesh; };
  const boxGeo = new T.BoxGeometry(1, 1, 1);
  const box = (size, pos, material, rot, owner) => { const mesh = add(boxGeo, material, pos, rot, owner); mesh.scale.fromArray(size); return mesh; };
  const geo = new T.PlaneGeometry(70, 70, 160, 160); geo.rotateX(-Math.PI / 2);
  const a = geo.attributes.position, uv = geo.attributes.uv;
  for (let i = 0; i < a.count; i++) { a.setY(i, ground(a.getX(i), a.getZ(i))); uv.setXY(i, a.getX(i) / 3, a.getZ(i) / 3); }
  geo.computeVertexNormals(); const terrain = add(geo, mats.ground, [0, 0, 0]); terrain.castShadow = false;
  const groups = { ground: new T.Group(), stone: new T.Group(), wood: new T.Group(), foliage: new T.Group(), ice: new T.Group() }; for (const g of Object.values(groups)) root.add(g);
  root.remove(terrain); groups.ground.add(terrain);
  const pathMat = mats.rock.clone(); pathMat.color.set('#958978'); pathMat.roughness = 1;
  for (let i = 0; i < 32; i++) {
    const z = -3 + i * .56, x = Math.sin(z * .16) * 1.1 + .4;
    box([1.45 + Math.sin(i) * .08, .075, .49], [x, ground(x, z) + .01, z], pathMat, [0, Math.cos(i * .6) * .04, 0], groups.stone);
  }
  const cx = -5.5, cz = -1.9, base = ground(cx, cz);
  const dark = new T.MeshStandardMaterial({ color: '#252c2b', roughness: .8 });
  const frame = mats.wood.clone(); frame.color.set('#736557');
  const wall = mats.wood.clone(); wall.color.set('#9e8771');
  box([5.9, .5, 4.9], [cx, base + .25, cz], mats.masonry, undefined, groups.stone);
  for (const side of [-1, 1]) {
    for (let i = 0; i < 14; i++) box([.4, 2.7, .15], [cx - 2.65 + i * .41, base + 1.85, cz + side * 2.35], wall, undefined, groups.wood);
    for (let i = 0; i < 11; i++) box([.15, 2.7, .4], [cx + side * 2.86, base + 1.85, cz - 2.05 + i * .41], wall, undefined, groups.wood);
    for (const dx of [-2.78, 2.78]) box([.16, 2.9, .23], [cx + dx, base + 1.9, cz + side * 2.38], frame, undefined, groups.wood);
  }
  for (const side of [-1, 1]) box([6.65, .13, 2.95], [cx, base + 3.85, cz + side * 1.17], mats.slate, [side * Math.PI / 7, 0, 0], groups.stone);
  box([6.4, .13, .14], [cx, base + 4.49, cz], mats.slate, undefined, groups.stone);
  box([1.05, 2.08, .13], [cx + .6, base + 1.54, cz + 2.47], dark, undefined, groups.wood);
  box([1.22, .14, .2], [cx + .6, base + 2.63, cz + 2.5], frame, undefined, groups.wood);
  for (const dx of [-1.85, 1.75]) {
    box([1.1, .92, .12], [cx + dx, base + 2.0, cz + 2.47], dark, undefined, groups.wood);
    box([1.22, .09, .21], [cx + dx, base + 2.5, cz + 2.5], frame, undefined, groups.wood);
    box([1.22, .09, .26], [cx + dx, base + 1.51, cz + 2.52], frame, undefined, groups.wood);
    box([.05, .92, .15], [cx + dx, base + 2.0, cz + 2.57], frame, undefined, groups.wood);
  }
  for (let i = 0; i < 13; i++) box([.45, .12, 1.7], [cx - 2.76 + i * .46, base + .57, cz + 3.17], mats.wood, undefined, groups.wood);
  for (const dx of [-2.85, 2.85]) box([.17, 2.4, .17], [cx + dx, base + 1.85, cz + 3.95], frame, undefined, groups.wood);
  box([6.3, .12, 2.15], [cx, base + 3.12, cz + 3.15], mats.slate, [.07, 0, 0], groups.stone);
  box([1.55, .22, .9], [cx + .6, base + .18, cz + 4.4], mats.masonry, undefined, groups.stone);
  box([.75, 1.8, .72], [cx - 1.6, base + 4.35, cz - .7], mats.masonry, undefined, groups.stone);
  const roof = (x, z) => {
    if (Math.abs(x - (cx - 1.6)) < .375 && Math.abs(z - (cz - .7)) < .36) return base + 5.25;
    if (x > cx - 3.325 && x < cx + 3.325 && z > cz - 2.65 && z < cz + 2.65) return base + (Math.abs(z - cz) < .07 ? 4.555 : 3.85 + 1.17 * Math.tan(Math.PI / 7) + .065 / Math.cos(Math.PI / 7) - Math.abs(z - cz) * Math.tan(Math.PI / 7));
    if (x > cx - 3.15 && x < cx + 3.15 && z >= cz + 2.1 && z < cz + 4.22) return base + 3.12 + .06 / Math.cos(.07) - (z - cz - 3.15) * Math.tan(.07);
    return null;
  };
  const lightMat = new T.MeshStandardMaterial({ color: '#a88c5a', emissive: '#ffd5a0', emissiveIntensity: 2, roughness: .25 });
  box([.16, .22, .1], [cx + 1.35, base + 2.8, cz + 2.6], lightMat, undefined, root);
  const warm = new T.PointLight('#ffc882', .7, 5, 2); warm.position.set(cx + 1.35, base + 2.8, cz + 2.9); root.add(warm);
  const random = (() => { let n = 712; return () => { n = (Math.imul(n, 1664525) + 1013904223) >>> 0; return n / 4294967296; }; })();
  const rockGeo = new T.IcosahedronGeometry(1, 3), rp = rockGeo.attributes.position;
  for (let i = 0; i < rp.count; i++) { const x = rp.getX(i), y = rp.getY(i), z = rp.getZ(i), k = 1 + Math.sin(x * 8 + y * 5) * Math.cos(z * 7) * .10 + Math.sin(x * 3 - z * 2) * .09; rp.setXYZ(i, x * k, y * k * .7, z * k); }
  rockGeo.computeVertexNormals();
  const smooth = new Map(), rn = rockGeo.attributes.normal;
  for (let i = 0; i < rp.count; i++) { const key = [rp.getX(i), rp.getY(i), rp.getZ(i)].map(v => v.toFixed(6)).join(','); if (!smooth.has(key)) smooth.set(key, new T.Vector3()); smooth.get(key).add(new T.Vector3().fromBufferAttribute(rn, i)); }
  for (let i = 0; i < rp.count; i++) { const key = [rp.getX(i), rp.getY(i), rp.getZ(i)].map(v => v.toFixed(6)).join(','); const n = smooth.get(key).clone().normalize(); rn.setXYZ(i, n.x, n.y, n.z); }
  rockGeo.setAttribute('uv2', rockGeo.attributes.uv.clone());
  const rocks = new T.InstancedMesh(rockGeo, mats.rock, 65), tmp = new T.Object3D();
  for (let i = 0; i < rocks.count; i++) { const angle = random() * Math.PI * 2, r = i < 25 ? 4.1 + random() * .65 : 9 + random() * 12, x = i < 25 ? 5.2 + Math.cos(angle) * r : Math.cos(angle) * r, z = i < 25 ? 3.8 + Math.sin(angle) * r * .74 : Math.sin(angle) * r; tmp.position.set(x, ground(x, z) + .12, z); const s = .25 + random() * .55; tmp.scale.set(s * 1.5, s, s); tmp.rotation.set(random() * .4, random() * 6, random() * .3); tmp.updateMatrix(); rocks.setMatrixAt(i, tmp.matrix); }
  rocks.castShadow = rocks.receiveShadow = true; groups.stone.add(rocks);
  const leafCanvas = document.createElement('canvas'); leafCanvas.width = leafCanvas.height = 128; const ctx = leafCanvas.getContext('2d');
  ctx.clearRect(0, 0, 128, 128); ctx.fillStyle = '#70864c'; ctx.beginPath(); ctx.moveTo(64, 2); ctx.bezierCurveTo(6, 35, 10, 75, 64, 125); ctx.bezierCurveTo(120, 78, 120, 35, 64, 2); ctx.fill();
  ctx.strokeStyle = '#a0a16c'; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(64, 3); ctx.lineTo(64, 125); ctx.stroke();
  for (let y = 22; y < 116; y += 11) { ctx.beginPath(); ctx.moveTo(64, y + 7); ctx.lineTo(64 - Math.sin(y / 128 * Math.PI) * 40, y - 12); ctx.moveTo(64, y + 7); ctx.lineTo(64 + Math.sin(y / 128 * Math.PI) * 40, y - 12); ctx.stroke(); }
  const leafTex = new T.CanvasTexture(leafCanvas); leafTex.encoding = T.sRGBEncoding; textures.push(leafTex);
  const leafMat = new T.MeshStandardMaterial({ map: leafTex, alphaTest: .4, roughness: .86, side: T.DoubleSide });
  const leafGeo = new T.PlaneGeometry(.19, .33, 1, 2); leafGeo.setAttribute('uv2', leafGeo.attributes.uv.clone());
  const trees = [[-13, -8], [-2, -10], [8, -8], [14, 0], [-15, 5], [18, 10], [-12, 14], [3, -16], [17, -11], [-19, -13], [24, 18], [-9, 22]];
  const leaves = new T.InstancedMesh(leafGeo, leafMat, trees.length * 1400); leaves.castShadow = leaves.receiveShadow = true; groups.foliage.add(leaves);
  const branches = new Map();
  const branch = (a, b, r1, r2) => {
    const ratio = r2 / r1; if (!branches.has(ratio)) branches.set(ratio, new T.CylinderGeometry(ratio, 1, 1, 10, 2));
    const dir = new T.Vector3().subVectors(b, a), m = add(branches.get(ratio), mats.bark, new T.Vector3().addVectors(a, b).multiplyScalar(.5).toArray(), undefined, groups.wood); m.scale.set(r1, dir.length(), r1); m.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), dir.normalize()); return m;
  };
  let leafIndex = 0;
  for (const [x, z] of trees) {
    const baseY = ground(x, z), height = 7 + random() * 2, sway = (random() - .5) * .65;
    branch(new T.Vector3(x, baseY, z), new T.Vector3(x + sway, baseY + height, z), .24, .065);
    const ends = [];
    for (let j = 0; j < 9; j++) { const a = j * 2.39, y = baseY + 2.8 + j * .45, start = new T.Vector3(x + sway * .4, y, z), end = new T.Vector3(x + Math.cos(a) * (2.25 - j * .1), y + 1.5, z + Math.sin(a) * (2.25 - j * .1)); branch(start, end, .07, .014); ends.push(end); for (const sign of [-1, 1]) branch(end.clone().lerp(start, .4), end.clone().add(new T.Vector3(Math.sin(a) * sign * .65, .5, Math.cos(a) * sign * .65)), .025, .006); }
    for (let j = 0; j < 1400; j++) { const end = ends[j % ends.length], ang = random() * Math.PI * 2, u = random() * 2 - 1, r = Math.cbrt(random()) * 1.5; tmp.position.set(end.x + Math.sqrt(1 - u * u) * Math.cos(ang) * r, end.y + u * r * .75, end.z + Math.sqrt(1 - u * u) * Math.sin(ang) * r); tmp.rotation.set(random() * Math.PI, random() * Math.PI * 2, random() * Math.PI); const s = .75 + random() * .7; tmp.scale.setScalar(s); tmp.updateMatrix(); leaves.setMatrixAt(leafIndex++, tmp.matrix); }
  }
  const iceCanvas = document.createElement('canvas'); iceCanvas.width = iceCanvas.height = 1024; const ic = iceCanvas.getContext('2d');
  ic.fillStyle = '#879f9f'; ic.fillRect(0, 0, 1024, 1024);
  for (let i = 0; i < 2400; i++) { const x = random() * 1024, y = random() * 1024, r = random() * 2 + .3; ic.fillStyle = `rgba(210,229,230,${.04 + random() * .17})`; ic.beginPath(); ic.arc(x, y, r, 0, Math.PI * 2); ic.fill(); }
  for (let j = 0; j < 18; j++) { let x = random() * 1024, y = random() * 1024; const a = random() * Math.PI * 2; ic.strokeStyle = `rgba(221,239,236,${.2 + random() * .3})`; ic.lineWidth = .4 + random() * 1.4; ic.beginPath(); ic.moveTo(x, y); for (let k = 0; k < 20; k++) { x += Math.cos(a + (random() - .5) * 1.1) * 16; y += Math.sin(a + (random() - .5) * 1.1) * 16; ic.lineTo(x, y); } ic.stroke(); }
  const iceMap = new T.CanvasTexture(iceCanvas); iceMap.encoding = T.sRGBEncoding; textures.push(iceMap);
  const iceMat = new T.MeshPhysicalMaterial({ map: iceMap, color: '#c1d6da', roughness: .115, metalness: 0, clearcoat: .95, clearcoatRoughness: .065, transmission: .65, thickness: .25, ior: 1.31, attenuationColor: '#578e98', attenuationDistance: 3.5 });
  const iceGeo = new T.CircleGeometry(3.95, 128); iceGeo.rotateX(-Math.PI / 2); iceGeo.scale(1, 1, .74);
  const ice = add(iceGeo, iceMat, [5.2, .17, 3.8], undefined, groups.ice); ice.castShadow = false;
  const bed = new T.CircleGeometry(4, 128); bed.rotateX(-Math.PI / 2); bed.scale(1, 1, .74); add(bed, mats.rock, [5.2, .02, 3.8], undefined, groups.stone);
  for (let j = 0; j < 2; j++) {
    const bx = 1.7 + j * 5, bz = -5.2, by = ground(bx, bz);
    for (const x of [-.8, .8]) box([.15, .6, .6], [bx + x, by + .32, bz], mats.wood, undefined, groups.wood);
    for (const z of [-.2, 0, .2]) box([2.15, .07, .17], [bx, by + .68, bz + z], mats.wood, undefined, groups.wood);
    box([2.12, .32, .08], [bx, by + 1.05, bz - .27], mats.wood, [.1, 0, 0], groups.wood);
  }
  for (const group of Object.values(groups)) {
    const batches = new Map();
    for (const mesh of [...group.children]) if (mesh.isMesh && !mesh.isInstancedMesh) {
      const key = mesh.geometry.uuid + mesh.material.uuid;
      if (!batches.has(key)) batches.set(key, []); batches.get(key).push(mesh);
    }
    for (const batch of batches.values()) if (batch.length > 1) {
      const first = batch[0], inst = new T.InstancedMesh(first.geometry, first.material, batch.length); inst.castShadow = first.castShadow; inst.receiveShadow = first.receiveShadow;
      batch.forEach((m, i) => { m.updateMatrix(); inst.setMatrixAt(i, m.matrix); group.remove(m); }); group.add(inst);
    }
  }
  const sampleGround = (x, z) => ((x - 5.2) ** 2 / 15.6 + (z - 3.8) ** 2 / 8.55 < 1 ? .17 : ground(x, z));
  return { scene, root, groups, sun, hemi, ground: sampleGround, roof, ice, ready: true, dispose() { const geometry = new Set(), materials = new Set(Object.values(mats)); root.traverse(n => { if (n.geometry) geometry.add(n.geometry); for (const m of [].concat(n.material ?? [])) materials.add(m); }); geometry.forEach(g => g.dispose()); materials.forEach(m => m.dispose()); textures.forEach(t => t.dispose()); sun.shadow.map?.dispose(); sun.shadow.mapPass?.dispose(); env.dispose(); root.removeFromParent(); scene.remove(sun, sun.target, hemi); scene.environment = null; } };
}
