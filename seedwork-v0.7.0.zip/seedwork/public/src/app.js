import { bindings } from '/core/models.mjs';
import { Workshop } from './workshop.js';
import { loadPack, prunePack } from './imports.js';
import { Engine } from './engine.js';
import { glb } from './glb.js';
import { height, META, TYPES, meta, types, clamp, check } from '/core/world.mjs';
import { TOOLS } from '/core/tools.mjs';
import { PALETTES } from './assets.js';

const $ = id => document.getElementById(id);
const state = { world: null, rev: -1, undo: 0, redo: 0, token: '', busy: false, selected: null, biome: 'forest', asset: 'pine', brush: 'raise', category: 'All', pending: -1 };
let engine, toastTimer, source, images;
const icon = id => `<svg aria-hidden="true"><use href="#i-${id}"/></svg>`;
const assetIcon = type => ['pine', 'oak', 'rock', 'mushroom', 'cactus'].includes(type) ? 'mountain' : type === 'crystal' ? 'spark' : 'cube';

function toast(message, error = false) {
  clearTimeout(toastTimer); $('toast').textContent = String(message); $('toast').classList.toggle('error', error); $('toast').hidden = false;
  toastTimer = setTimeout(() => { $('toast').hidden = true; }, error ? 7000 : 4200);
}

function log(name, detail = '') {
  const row = document.createElement('div'), title = document.createElement('span');
  title.textContent = name; row.append(title, document.createTextNode(`${new Date().toLocaleTimeString()}${detail ? ` · ${detail}` : ''}`));
  $('log').prepend(row); while ($('log').children.length > 20) $('log').lastChild.remove();
}

function busy(on) {
  state.busy = on; document.body.classList.toggle('busy', on); $('save-status').textContent = on ? 'Committing changes…' : 'Saved on this device';
}

async function api(path, data, method = 'POST') {
  if (data && ['POST', 'PUT'].includes(method) && data.key === undefined) data = { ...data, key: crypto.randomUUID() };
  const res = await fetch(path, { method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${state.token}` }, body: JSON.stringify(data) });
  const out = await res.json();
  if (!res.ok) {
    if (out.world && out.rev !== undefined) await apply(out);
    throw new Error(out.error ?? `Request failed (${res.status}).`);
  }
  return out;
}

async function run(name, args = {}, home = false) {
  if (state.busy) { toast('Wait for the current operation to finish.'); return null; }
  if (engine.playing && !TOOLS.find(t => t.name === name)?.readOnly) { toast('Exit the playable preview before editing.', true); return null; }
  busy(true);
  try {
    const out = await api('/api/tool', { name, args, rev: state.rev });
    await apply(out, home);
    if (out.result?.object) select(out.result.object.id);
    $('tool-result').textContent = JSON.stringify({ rev: out.rev, ...out.result }, null, 2);
    log(name, `revision ${out.rev}`);
    if (name === 'object_scatter') toast(`Placed ${out.result.placed} of ${out.result.requested} objects on suitable terrain.`);
    else if (name === 'world_recipe') {
      $('recipe-notes').textContent = `${out.result.notes.join(' · ') || 'Current settings used.'} Unsupported details are ignored by the local parser.`;
      $('recipe-notes').hidden = false; toast(`Generated ${out.world.name} · ${out.world.objects.length} objects.`);
    } else if (name === 'world_validate') {
      const r = out.result;
      dialog('World integrity', [r.valid ? 'Document schema: valid.' : 'Document schema: invalid.', r.playableSpawn ? `Dry, unobstructed spawn: found at X ${r.spawn.x.toFixed(1)}, Z ${r.spawn.z.toFixed(1)}.` : 'No playable spawn was found.', `Collectibles: ${r.crystals}.`, ...r.warnings, r.note].join('\n\n'));
    } else if (name === 'world_undo' || name === 'world_redo') toast(out.result.message);
    return out;
  } catch (e) { toast(e.message, true); $('tool-result').textContent = e.message; log('Operation rejected', e.message); return null; }
  finally { busy(false); if (state.pending > state.rev) sync(); }
}

async function sync() {
  try {
    const data = await (await fetch('/api/world')).json();
    if (!state.busy && data.rev > state.rev) { await apply(data); log('External tool update', `revision ${data.rev}`); toast('World updated by another tool client.'); }
  } catch { $('save-status').textContent = 'Connection interrupted'; }
}

async function apply(data, home = false) {
  if (data.rev < state.rev) return;
  await loadPack(bindings(data.world), data.world.models ?? {});
  if (data.rev < state.rev) return;
  const changed = state.rev !== data.rev || !state.world;
  const artChanged = state.world?.biome !== data.world.biome || JSON.stringify(bindings(state.world ?? {})) !== JSON.stringify(bindings(data.world));
  Object.assign(state, { world: data.world, rev: data.rev, undo: data.undo, redo: data.redo });
  if (changed) {
    if (!types(data.world).includes(state.asset)) { state.asset = 'pine'; engine.asset = 'pine'; }
    state.biome = data.world.biome; engine.load(data.world, home); prunePack(bindings(data.world));
    if (!data.world.objects.some(o => o.id === state.selected)) state.selected = null;
    setFields(); sceneList(); inspector(); drawMap();
    if (artChanged && images) { images=engine.thumbnails();assets(images); }
    $('asset-status').textContent = Object.keys(bindings(data.world)).length ? `${Object.keys(data.world.assets ?? {}).length} replacement slots · ${Object.keys(data.world.models ?? {}).length} native models. Save world + assets for portable backup.` : 'Authored procedural assets. No external asset pack loaded.';
  }
  $('undo').disabled = !state.undo; $('redo').disabled = !state.redo;
  $('rev').textContent = `Revision ${state.rev}`;
  $('save-status').textContent = 'Saved on this device';
}

function setFields() {
  const w = state.world, t = w.terrain;
  $('crumb-name').textContent = w.name; $('world-name').textContent = w.name;
  $('world-kicker').textContent = `${w.biome.toUpperCase()} / SEED ${w.seed}`;
  $('world-desc').textContent = `${t.size} × ${t.size} m · ${w.objects.length} editable objects`;
  $('object-count').textContent = `${w.objects.length} objects`;
  $('seed').value = w.seed;
  if (![...$('size').options].some(o => +o.value === t.size)) $('size').add(new Option(`${t.size} × ${t.size} m`, t.size));
  for (const k of ['size', 'relief', 'density', 'shape', 'water']) $(k).value = t[k];
  $('time').value = w.sky.time;
  $('env-state').textContent = w.environment ? w.environment.name : 'Base scene / effects detached';
  $('stroke-count').textContent = `${t.stamps.length} / 96 strokes`;
  document.querySelectorAll('[data-biome]').forEach(b => b.classList.toggle('active', b.dataset.biome === w.biome));
  ranges();
}

function ranges() {
  $('relief-out').textContent = `${$('relief').value} m`;
  $('density-out').textContent = `${Math.round(Number($('density').value) * 100)}%`;
  $('radius-out').textContent = `${$('radius').value} m`;
  $('power-out').textContent = state.brush === 'flatten' ? `${Math.min(1, Number($('power').value)).toFixed(1)}` : Number($('power').value).toFixed(1);
  if (engine) { engine.radius = Number($('radius').value); engine.showBrush(); }
}

function options() {
  return { seed: Number($('seed').value), biome: state.biome, size: Number($('size').value), relief: Number($('relief').value), density: Number($('density').value), water: Number($('water').value), shape: $('shape').value, time: $('time').value };
}

function tab(name) {
  document.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  for (const n of ['world', 'assets', 'tools']) $(`panel-${n}`).hidden = n !== name;
}

function mode(name) {
  if (engine.playing) return;
  if (name === 'move' && !state.selected) { toast('Select an object first, then use Move.'); name = 'select'; }
  engine.mode = name;
  document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('active', b.dataset.mode === name));
  const labels = { select: 'Select & inspect', move: 'Click terrain to move', place: `Place ${meta(state.world, state.asset).name}`, sculpt: `${state.brush[0].toUpperCase() + state.brush.slice(1)} terrain`, spawn: 'Click to set spawn' };
  $('mode-label').textContent = labels[name]; engine.showBrush();
}

function select(id) {
  state.selected = id; engine.select(id);
  document.querySelectorAll('.scene-item').forEach(b => b.classList.toggle('active', b.dataset.id === id));
  inspector(); drawMap();
}

function sceneList() {
  const q = $('scene-search').value.toLowerCase().trim();
  const all = state.world.objects.filter(o => `${o.id} ${meta(state.world, o.type).name}`.toLowerCase().includes(q));
  const items = all.slice(0, 250), frag = document.createDocumentFragment();
  for (const o of items) {
    const b = document.createElement('button'); b.className = `scene-item${o.id === state.selected ? ' active' : ''}`; b.dataset.id = o.id;
    const name = document.createElement('span'); name.className = 'obj-name'; name.textContent = meta(state.world, o.type).name;
    const tail = document.createElement('small'); tail.textContent = o.id.split('_').at(-1);
    b.innerHTML = icon(assetIcon(o.type)); b.append(name, tail); b.onclick = () => select(o.id); b.ondblclick = () => engine.focus(o.id); frag.append(b);
  }
  if (!items.length || all.length > items.length) {
    const end = document.createElement('div'); end.className = 'scene-end'; end.textContent = !items.length ? 'No matching objects.' : `Showing ${items.length} of ${all.length}. Refine your search.`; frag.append(end);
  }
  $('scene-list').replaceChildren(frag);
}

function inspector() {
  const o = state.world.objects.find(o => o.id === state.selected);
  $('empty-inspector').hidden = Boolean(o); $('object-inspector').hidden = !o; $('focus').disabled = !o;
  if (!o) return;
  $('sel-name').textContent = meta(state.world, o.type).name; $('sel-id').textContent = o.id;
  for (const k of ['x', 'y', 'z', 'rot', 'scale']) $(`obj-${k}`).value = Number(o[k].toFixed(3));
  $('obj-solid').checked = o.solid;
  for (const k of ['x', 'z']) { $(`obj-${k}`).min = -state.world.terrain.size / 2; $(`obj-${k}`).max = state.world.terrain.size / 2; }
}

function drawMap() {
  if (!state.world) return;
  const canvas = $('map'), ctx = canvas.getContext('2d'), w = state.world, p = PALETTES[w.biome], s = w.terrain.size;
  const small = document.createElement('canvas'); small.width = small.height = 72; const sc = small.getContext('2d');
  const rgb = hex => [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));
  const land = rgb(p.grass), sand = rgb(p.sand), water = rgb(p.water), img = sc.createImageData(72, 72);
  for (let z = 0; z < 72; z++) for (let x = 0; x < 72; x++) {
    const h = engine.field.get((x / 72 - 0.5) * s, (z / 72 - 0.5) * s), i = (z * 72 + x) * 4;
    const color = h < w.terrain.water ? water : h < w.terrain.water + 1 ? sand : land;
    const shade = h < w.terrain.water ? 0.57 : 0.76 + clamp(h / 40, 0, 0.25);
    for (let k = 0; k < 3; k++) img.data[i + k] = color[k] * shade; img.data[i + 3] = 255;
  }
  sc.putImageData(img, 0, 0); ctx.imageSmoothingEnabled = false; ctx.drawImage(small, 0, 0, canvas.width, canvas.height);
  for (const o of w.objects) {
    if (['pine', 'oak', 'mushroom', 'cactus', 'rock'].includes(o.type) && o.id !== state.selected) continue;
    const x = (o.x / s + 0.5) * canvas.width, y = (o.z / s + 0.5) * canvas.height;
    ctx.fillStyle = o.id === state.selected ? '#fbffd9' : o.type === 'crystal' ? '#aaf4e2' : '#e0bc86';
    ctx.fillRect(x - 1.5, y - 1.5, 3, 3);
  }
  const x = (w.spawn.x / s + 0.5) * canvas.width, y = (w.spawn.z / s + 0.5) * canvas.height;
  ctx.strokeStyle = '#e3f2c3'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI * 2); ctx.stroke();
  $('map-size').textContent = `${s} m · spawn ○`;
}

function assets(images) {
  const frag = document.createDocumentFragment();
  for (const type of types(state.world)) {
    const m = meta(state.world, type); if (state.category !== 'All' && state.category !== m.cat) continue;
    const b = document.createElement('button'); b.className = `asset-card${state.asset === type ? ' active' : ''}`; b.dataset.asset = type;
    const img = new Image(); img.src = images[type]; img.alt = `${m.name} 3D preview`;
    const name = document.createElement('strong'); name.textContent = m.name;
    const cat = document.createElement('span'); cat.textContent = m.cat.toUpperCase();
    b.append(img, name, cat); b.onclick = () => { state.asset = type; engine.asset = type; assets(images); mode('place'); toast(`${m.name} selected. Click dry terrain to place it.`); }; frag.append(b);
  }
  $('asset-grid').replaceChildren(frag);
}

function filename(ext) {
  return `${state.world.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'world'}.${ext}`;
}

function download(data, name, type) {
  const url = URL.createObjectURL(new Blob([data], { type })), a = document.createElement('a');
  a.href = url; a.download = name; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function dialog(title, text, pre = false) {
  const h = document.createElement('h2'); h.textContent = title;
  const el = document.createElement(pre ? 'pre' : 'p'); el.textContent = text; el.style.whiteSpace = 'pre-wrap';
  $('dialog-content').replaceChildren(h, el); $('dialog').showModal();
}

function help() {
  $('dialog-content').innerHTML = '<h2>Find your way around.</h2><p>Changes are saved locally after each successful operation. Generate replaces the current world and can be undone. Save JSON backs up procedural worlds; imported assets need Save world + assets for a portable backup.</p>';
  for (const [name, key] of [['Orbit / pan / zoom', 'Drag / right-drag / wheel'], ['Select / place / terrain', 'V / B / T'], ['Move selected → click terrain', 'G'], ['Frame selection / world', 'F / Home'], ['Duplicate / delete selected', 'Ctrl+D / Delete'], ['Undo / redo', 'Ctrl+Z / Ctrl+Shift+Z'], ['Preview movement / sprint / hop', 'WASD / Shift / Space'], ['Exit preview or active tool', 'Esc']]) {
    const row = document.createElement('div'); row.className = 'shortcut';
    const a = document.createElement('span'); a.textContent = name; const b = document.createElement('kbd'); b.textContent = key; row.append(a, b); $('dialog-content').append(row);
  }
  $('dialog').showModal();
}

async function duplicate() {
  const o = state.world.objects.find(o => o.id === state.selected); if (!o) return;
  const { id, ...args } = o, limit = state.world.terrain.size / 2;
  args.x = clamp(args.x + 3, -limit, limit); args.z = clamp(args.z + 3, -limit, limit);
  await run('object_add', args);
}

function setToolDesc(reset = false) {
  const t = TOOLS.find(t => t.name === $('tool-name').value); $('tool-desc').textContent = t.description;
  if (reset) {
    const examples = { environment_preset: { name: 'snow' }, environment_set: { config: state.world.environment ?? { schema: 'seedwork.environment/1', name: 'Custom', seed: 732, weather: { rain: .5, snow: 0, wind: [1, 0], temperature: 10 }, surface: { wet: .7, snow: 0, ice: 0 }, foliage: { autumn: 0, retention: 1, litter: .05 }, atmosphere: { fog: .01, cloud: .7, light: 1 }, simulation: { enabled: false, rate: 1 } } }, environment_inspect: {}, world_inspect: { objects: false }, world_make: { biome: 'fantasy', seed: 482, density: 0.6 }, world_recipe: { prompt: 'A snowy island with ruins at sunset' }, terrain_set: { relief: 12, water: 1.4 }, terrain_brush: { x: 0, z: 0, mode: 'raise', radius: 7, power: 1 }, object_add: { type: state.asset, x: 5, z: 5 }, object_update: { id: state.selected ?? state.world.objects[0]?.id ?? 'object_id', scale: 1.5 }, object_remove: { id: state.selected ?? 'select_an_object_first' }, object_scatter: { type: state.asset, count: 20, radius: 35 }, spawn_set: { x: 0, z: 13 } };
    $('tool-args').value = JSON.stringify(examples[t.name] ?? {}, null, 2);
  }
}

async function init() {
  const res = await fetch('/api/session'); if (!res.ok) throw new Error('The local server did not return a session.');
  const data = await res.json(); state.token = data.token;
  engine = new Engine($('viewport'), {
    pick: async ({ id, point }) => {
      if (state.busy) return;
      if (engine.mode === 'select') { select(id); return; }
      if (!point) return;
      const x = Number(point.x.toFixed(2)), z = Number(point.z.toFixed(2));
      if (engine.mode === 'move' && state.selected) await run('object_update', { id: state.selected, x, z });
      if (engine.mode === 'place') {
        if (height(state.world, x, z) < state.world.terrain.water + 0.1) return toast('Choose dry land, or raise the ground first.', true);
        await run('object_add', { type: state.asset, x, z });
      }
      if (engine.mode === 'sculpt') await run('terrain_brush', { x, z, radius: Number($('radius').value), mode: state.brush, power: Math.min(state.brush === 'flatten' ? 1 : 8, Number($('power').value)) });
      if (engine.mode === 'spawn') { await run('spawn_set', { x, z }); mode('select'); toast(`Preferred spawn set to ${x}, ${z}.`); }
    },
    hover: p => { $('coords').textContent = `X ${p.x.toFixed(1)} · Z ${p.z.toFixed(1)}`; },
    stats: s => {
      $('fps').textContent = `${s.fps} fps`; $('calls').textContent = `${s.calls} draws`; $('tris').textContent = `${(s.tris / 1000).toFixed(1)}k triangles`;
      if (s.playing) $('play-time').textContent = `${String(Math.floor(s.time / 60)).padStart(2, '0')}:${String(Math.floor(s.time % 60)).padStart(2, '0')}`;
    },
    play: s => {
      document.body.classList.toggle('is-playing', s.playing); $('play-hud').hidden = !s.playing;
      $('play').innerHTML = s.playing ? `${icon('stop')}<span>Exit preview</span>` : `${icon('play')}<span>Play world</span>`;
      if (s.playing) { $('goal-title').textContent = s.total ? 'Find the quartz specimens' : 'Explore your world'; $('goal-count').textContent = `${s.count} / ${s.total}`; $('play-time').textContent = '00:00'; }
    },
    collect: (n, total) => { $('goal-count').textContent = `${n} / ${total}`; if (n === total) { $('goal-title').textContent = 'All specimens recovered'; toast('Field test complete. Your world document is unchanged.'); } else toast(`Quartz specimen recovered · ${n} / ${total}`); },
    error: m => toast(m, true)
  });
  await engine.ready; await apply(data, true); $('splash').hidden = true;
  images = engine.thumbnails(); assets(images);
  $('import-asset').onclick = () => { if (engine.playing || state.busy) return toast('Exit preview and finish the current operation first.', true); if (!TYPES.includes(state.asset)) return toast('Native models use Model Workshop, not replacement slots.', true); $('asset-file').click(); };
  $('asset-file').onchange = async () => {
    const file = $('asset-file').files[0]; if (!file) return;
    const type = state.asset; busy(true);
    try {
      const res = await fetch('/api/asset', {method:'POST',headers:{'Content-Type':'model/gltf-binary',Authorization:`Bearer ${state.token}`},body:await file.arrayBuffer()});
      const info = await res.json(); if (!res.ok) throw new Error(info.error);
      await loadPack({[type]:info.hash});
      busy(false); const result = await run('asset_bind', {type,hash:info.hash});
      if (result) { images = engine.thumbnails(); assets(images); $('asset-status').textContent = `${meta(state.world, type).name} · ${info.meshes} meshes · ${(info.bytes/1024/1024).toFixed(1)} MiB. Use Save world + assets for a portable project.`; toast(`Replaced every ${meta(state.world, type).name} instance. Undo restores the previous binding.`); }
    } catch(e) { toast(e.message,true); } finally { $('asset-file').value='';busy(false); }
  };
  $('reset-asset').onclick = async () => { if (!TYPES.includes(state.asset)) return toast('Native models are not replacement slots. Use model_remove to remove the type.', true); if (await run('asset_unbind',{type:state.asset})) { images=engine.thumbnails();assets(images);$('asset-status').textContent='Procedural prefab restored for the selected slot.'; } };
  $('save-pack').onclick = async () => {
    try { const res=await fetch('/api/bundle',{headers:{Authorization:`Bearer ${state.token}`}}),pack=await res.json();if(!res.ok)throw new Error(pack.error);download(JSON.stringify(pack),filename('seedpack.json'),'application/json');toast('Saved portable world and embedded GLB assets.'); } catch(e){toast(e.message,true);}
  };
  $('pause-scene').onchange = e => { engine.freeze = e.target.checked; engine.dirty = true; };
  $('cache-shadows').onchange = e => { engine.cacheShadows = e.target.checked; engine.shadowDirty(); };
  $('cull-scene').onchange = e => { engine.cull = e.target.checked; engine.dirty = true; };
  $('audit-render').onclick = () => dialog('Renderer audit', JSON.stringify(engine.audit(), null, 2), true);
  $('save-audit').onclick = () => download(JSON.stringify(engine.audit(), null, 2), 'seedwork-render-audit.json', 'application/json');
  document.querySelectorAll('[data-tab]').forEach(b => { b.onclick = () => tab(b.dataset.tab); });
  document.querySelectorAll('[data-mode]').forEach(b => { b.onclick = () => { mode(b.dataset.mode); if (b.dataset.mode === 'place') tab('assets'); if (b.dataset.mode === 'sculpt') tab('world'); }; });
  document.querySelectorAll('[data-biome]').forEach(b => { b.onclick = () => { state.biome = b.dataset.biome; document.querySelectorAll('[data-biome]').forEach(x => x.classList.toggle('active', x === b)); $('prompt').value = ''; }; });
  document.querySelectorAll('[data-brush]').forEach(b => { b.onclick = () => { state.brush = b.dataset.brush; document.querySelectorAll('[data-brush]').forEach(x => x.classList.toggle('active', x === b)); mode('sculpt'); ranges(); }; });
  document.querySelectorAll('[data-cat]').forEach(b => { b.onclick = () => { state.category = b.dataset.cat; document.querySelectorAll('[data-cat]').forEach(x => x.classList.toggle('active', x === b)); assets(images); }; });
  for (const k of ['relief', 'density', 'radius', 'power']) $(k).oninput = ranges;
  $('generate').onclick = () => run('world_recipe', { prompt: $('prompt').value.trim() || `${state.biome} ${$('shape').value}`, options: options() }, true);
  $('apply-env').onclick = () => run('environment_preset', { name: $('env-preset').value });
  $('clear-env').onclick = () => run('environment_preset', { name: 'off' });
  $('apply-terrain').onclick = () => { const { seed, ...opts } = options(); run('terrain_set', opts); };
  $('rand').onclick = () => { const n = new Uint32Array(1); crypto.getRandomValues(n); $('seed').value = n[0]; };
  $('scatter').onclick = () => run('object_scatter', { type: state.asset, count: Number($('scatter-count').value), radius: Number($('scatter-radius').value) });
  $('time').onchange = () => run('terrain_set', { time: $('time').value });
  $('grid').onclick = () => { engine.showGrid = !engine.showGrid; engine.grid.visible = engine.showGrid; $('grid').classList.toggle('active', engine.showGrid); };
  $('home').onclick = () => engine.home(); $('focus').onclick = () => engine.focus(state.selected);
  $('undo').onclick = () => run('world_undo'); $('redo').onclick = () => run('world_redo');
  $('play').onclick = () => { try { if (engine.playing) engine.stop(); else engine.start(); } catch (e) { toast(e.message, true); } };
  $('scene-search').oninput = sceneList;
  for (const k of ['x', 'y', 'z', 'rot', 'scale']) $(`obj-${k}`).onchange = () => { if (state.selected) run('object_update', { id: state.selected, [k]: Number($(`obj-${k}`).value) }); };
  $('obj-solid').onchange = () => { if (state.selected) run('object_update', { id: state.selected, solid: $('obj-solid').checked }); };
  $('duplicate').onclick = duplicate; $('delete').onclick = () => { if (state.selected) run('object_remove', { id: state.selected }); };
  $('map').onclick = e => {
    const r = $('map').getBoundingClientRect(), s = state.world.terrain.size;
    const x = ((e.clientX - r.left) / r.width - 0.5) * s, z = ((e.clientY - r.top) / r.height - 0.5) * s;
    engine.target.set(x, height(state.world, x, z), z); engine.dist = s * 0.7;
  };
  $('save').onclick = () => { download(JSON.stringify(state.world, null, 2), filename('world.json'), 'application/json'); toast(Object.keys(bindings(state.world)).length ? 'Saved JSON references only. Use Assets → Save world + assets to include GLBs.' : 'Portable world document saved.'); };
  $('open').onclick = () => $('file').click();
  $('file').onchange = async () => {
    const file = $('file').files[0]; if (!file) return;
    if (state.busy || engine.playing) { $('file').value = ''; return toast('Finish the current operation and exit preview before importing.', true); }
    busy(true);
    try {
      if (file.size > 96 * 1024 * 1024) throw new Error('Bundle files must be smaller than 96 MiB.');
      const parsed = JSON.parse(await file.text());
      if (parsed.seedworkPack === 1) { await apply(await api('/api/bundle', {pack:parsed,rev:state.rev}, 'PUT'), true); toast('World and asset bundle restored.'); return; }
      if (file.size > 8 * 1024 * 1024) throw new Error('Standalone world JSON must be smaller than 8 MiB.');
      const world = check(parsed);
      await apply(await api('/api/world', { world, rev: state.rev }, 'PUT'), true); toast(`Opened ${world.name}.`); log('Imported world', world.name);
    } catch (e) { toast(e.message, true); }
    finally { busy(false); $('file').value = ''; }
  };
  $('export').onclick = () => {
    try { if (engine.playing) return toast('Exit preview before exporting.', true); if (engine.weatherKit && !window.confirm('GLB exports the base static materials, not live rain, snow, frost or foliage changes. Keep world JSON for the environment. Continue?')) return; const out = glb(engine.root, { material: m => engine.weatherKit?.sourceMaterial(m) ?? m }); download(out, filename('glb'), 'model/gltf-binary'); toast(`Exported static meshes with embedded PBR textures · ${(out.byteLength / 1024 / 1024).toFixed(1)} MB. Base materials only; gameplay and environment remain in native world data.`); }
    catch (e) { toast(`Export failed: ${e.message}`, true); }
  };
  $('shot').onclick = () => { const a = document.createElement('a'); a.href = engine.screenshot(); a.download = filename('png'); a.click(); };
  $('help').onclick = help; $('close-dialog').onclick = () => $('dialog').close();
  $('dialog').addEventListener('click', e => { if (e.target === $('dialog')) { const r = $('dialog').getBoundingClientRect(); if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) $('dialog').close(); } });
  $('validate').onclick = () => run('world_validate');
  for (const t of TOOLS) $('tool-name').add(new Option(t.name, t.name)); $('tool-name').value = 'object_scatter'; setToolDesc();
  $('tool-name').onchange = () => setToolDesc(true);
  $('run-tool').onclick = () => { try { run($('tool-name').value, JSON.parse($('tool-args').value)); } catch (e) { toast(`Invalid JSON: ${e.message}`, true); } };
  $('connect').onclick = () => {
    dialog('Connect an MCP client', 'Start Seedwork first. Add this stdio server in a client supporting MCP 2025-11-25. Replace the path with the absolute path on your machine. External model usage may have a cost. This grants the client access to edit this local world.');
    const pre = document.createElement('pre'); pre.textContent = JSON.stringify({ mcpServers: { seedwork: { command: 'node', args: ['/absolute/path/to/seedwork/mcp.mjs'] } } }, null, 2); $('dialog-content').append(pre);
  };
  window.addEventListener('keydown', e => {
    if (document.querySelector('#workshop')?.open || $('dialog').open || e.target.matches('input, textarea, select')) {
      if (e.target === $('prompt') && (e.ctrlKey || e.metaKey) && e.key === 'Enter') $('generate').click();
      return;
    }
    if (e.key === 'Escape') { if (engine.playing) engine.stop(); else mode('select'); return; }
    if (engine.playing) return;
    const mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
    if (mod && k === 'z') { e.preventDefault(); run(e.shiftKey ? 'world_redo' : 'world_undo'); }
    else if (mod && k === 'y') { e.preventDefault(); run('world_redo'); }
    else if (mod && k === 'd') { e.preventDefault(); duplicate(); }
    else if (mod && k === 's') { e.preventDefault(); $('save').click(); }
    else if (!mod && k === 'v') mode('select');
    else if (!mod && k === 'g') mode('move');
    else if (!mod && k === 'b') { tab('assets'); mode('place'); }
    else if (!mod && k === 't') { tab('world'); mode('sculpt'); }
    else if (!mod && k === 'f') engine.focus(state.selected);
    else if (e.key === 'Home') { e.preventDefault(); engine.home(); }
    else if (e.key === 'Delete' && state.selected) run('object_remove', { id: state.selected });
  });
  source = new EventSource('/api/events');
  source.onmessage = async e => {
    const event = JSON.parse(e.data);
    state.pending = Math.max(state.pending, event.rev);
    if (event.rev > state.rev && !state.busy) await sync();
  };
  source.onerror = () => { $('save-status').textContent = 'Server disconnected · reconnecting'; };
  source.onopen = async () => {
    try { const s = await (await fetch('/api/session')).json(); state.token = s.token; if (!state.busy) await apply(s); } catch { $('save-status').textContent = 'Server disconnected'; }
  };
  log('Workspace opened', 'Procedural tools ready');
  const workshop = new Workshop(engine, { run, toast, download, getWorld: () => state.world, getToken: () => state.token, place: key => { state.asset = key; engine.asset = key; tab('assets'); assets(images); mode('place'); } });
  engine.workshop = workshop;
  $('open-modeler').onclick = () => workshop.show();
  $('asset-modeler').onclick = () => workshop.show(state.world.models?.[state.asset] ? state.asset : null);
  window.seedwork = { engine, workshop, run, glb, get world() { return state.world; }, get rev() { return state.rev; }, get selected() { return state.selected; }, get ready() { return true; } };
}

init().catch(e => {
  console.error(e); $('splash').hidden = false;
  $('splash').querySelector('h2').textContent = 'The engine could not start.';
  $('splash').querySelector('p').textContent = `${e.message} Start the included Node server and open its local address in a desktop browser with WebGL enabled.`;
});
