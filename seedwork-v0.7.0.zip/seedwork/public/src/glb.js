const T = window.THREE;

export function glb(root, { material: resolveMaterial = m => m } = {}) {
  const doc = { asset: { version: '2.0', generator: 'Seedwork 0.7.0 — base static exporter' }, scene: 0, scenes: [{ nodes: [] }], nodes: [], meshes: [], materials: [], accessors: [], bufferViews: [], buffers: [], images: [], textures: [], samplers: [], extensionsUsed: [] };
  const chunks = [], geoCache = new Map(), matCache = new Map(), meshCache = new Map(), texCache = new Map();
  let length = 0;
  const addData = (array, target) => {
    const bytes = new Uint8Array(array.buffer, array.byteOffset, array.byteLength), padded = new Uint8Array(Math.ceil(bytes.length / 4) * 4);
    padded.set(bytes); chunks.push(padded);
    const i = doc.bufferViews.length;
    doc.bufferViews.push({ buffer: 0, byteOffset: length, byteLength: bytes.length, target }); length += padded.byteLength; return i;
  };
  const accessor = (array, size, target, bounds = false) => {
    const view = addData(array, target), item = { bufferView: view, componentType: array instanceof Float32Array ? 5126 : array instanceof Uint32Array ? 5125 : 5123, count: array.length / size, type: { 1: 'SCALAR', 2: 'VEC2', 3: 'VEC3', 4: 'VEC4' }[size] };
    if (bounds) {
      const min = Array(size).fill(Infinity), max = Array(size).fill(-Infinity);
      for (let i = 0; i < array.length; i++) { const k = i % size; min[k] = Math.min(min[k], array[i]); max[k] = Math.max(max[k], array[i]); }
      item.min = min; item.max = max;
    }
    doc.accessors.push(item); return doc.accessors.length - 1;
  };
  const geometry = geo => {
    if (geoCache.has(geo.uuid)) return geoCache.get(geo.uuid);
    const attributes = {};
    for (const [name, semantic] of [['position', 'POSITION'], ['normal', 'NORMAL'], ['tangent','TANGENT'], ['color', 'COLOR_0'], ['uv', 'TEXCOORD_0'], ['uv2', 'TEXCOORD_1']]) {
      const a = geo.attributes[name]; if (!a) continue;
      const out = new Float32Array(a.count * a.itemSize);
      for (let i = 0; i < a.count; i++) for (let j = 0; j < a.itemSize; j++) out[i * a.itemSize + j] = a.array[i * a.itemSize + j];
      attributes[semantic] = accessor(out, a.itemSize, 34962, name === 'position');
    }
    const g = { attributes };
    if (geo.index) g.indices = accessor(geo.index.count > 65535 || geo.attributes.position.count > 65535 ? new Uint32Array(geo.index.array) : new Uint16Array(geo.index.array), 1, 34963);
    geoCache.set(geo.uuid, g); return g;
  };
  const texture = (tex, uvSet = 0) => {
    let index = texCache.get(tex.uuid);
    if (index === undefined) {
      if (!tex.image || !tex.image.width) throw new Error(`Texture ${tex.name} is not loaded.`);
      const canvas = document.createElement('canvas'); canvas.width = tex.image.width; canvas.height = tex.image.height;
      const ctx = canvas.getContext('2d');
      if (tex.flipY) { ctx.translate(0, canvas.height); ctx.scale(1, -1); }
      ctx.drawImage(tex.image, 0, 0);
      const bytes = Uint8Array.from(atob(canvas.toDataURL('image/png').split(',')[1]), c => c.charCodeAt(0));
      const image = doc.images.length; doc.images.push({ name: tex.name, mimeType: 'image/png', bufferView: addData(bytes) });
      const sampler = doc.samplers.length;
      const wrap = n => n === T.RepeatWrapping ? 10497 : n === T.MirroredRepeatWrapping ? 33648 : 33071;
      doc.samplers.push({ magFilter: 9729, minFilter: 9987, wrapS: wrap(tex.wrapS), wrapT: wrap(tex.wrapT) });
      index = doc.textures.length; doc.textures.push({ source: image, sampler }); texCache.set(tex.uuid, index);
    }
    const info = { index, texCoord: uvSet };
    if (tex.repeat.x !== 1 || tex.repeat.y !== 1 || tex.offset.x || tex.offset.y || tex.rotation) {
      if (!doc.extensionsUsed.includes('KHR_texture_transform')) doc.extensionsUsed.push('KHR_texture_transform');
      info.extensions = { KHR_texture_transform: { offset: tex.offset.toArray(), scale: tex.repeat.toArray(), rotation: tex.rotation } };
    }
    return info;
  };
  const material = (m, tint) => {
    m = resolveMaterial(m);
    if (m.userData?.seedworkEnvironment) throw new Error('Live environment shaders cannot be serialized into GLB. Resolve base materials explicitly or detach the environment.');
    const c = m.color.clone().multiply(tint), key = `${m.uuid}:${c.r.toFixed(5)}:${c.g.toFixed(5)}:${c.b.toFixed(5)}`;
    if (matCache.has(key)) return matCache.get(key);
    const out = { name: m.name || `Material ${doc.materials.length + 1}`, pbrMetallicRoughness: { baseColorFactor: [Math.min(1,c.r), Math.min(1,c.g), Math.min(1,c.b), m.opacity ?? 1], metallicFactor: m.metalness ?? 0, roughnessFactor: m.roughness ?? 0.85 }, doubleSided: m.side === T.DoubleSide };
    if (m.transparent) out.alphaMode = 'BLEND';
    if (m.alphaTest > 0) { out.alphaMode = 'MASK'; out.alphaCutoff = m.alphaTest; }
    if (m.map) out.pbrMetallicRoughness.baseColorTexture = texture(m.map);
    if (m.roughnessMap) out.pbrMetallicRoughness.metallicRoughnessTexture = texture(m.roughnessMap);
    if (m.normalMap) out.normalTexture = { ...texture(m.normalMap), scale: m.normalScale.x };
    if (m.aoMap) out.occlusionTexture = { ...texture(m.aoMap, 1), strength: m.aoMapIntensity };
    if (m.emissiveMap) out.emissiveTexture = texture(m.emissiveMap);
    if (m.isMeshBasicMaterial) {out.extensions={KHR_materials_unlit:{}};if(!doc.extensionsUsed.includes('KHR_materials_unlit'))doc.extensionsUsed.push('KHR_materials_unlit');}
    if (m.clearcoat) {
      out.extensions = { KHR_materials_clearcoat: { clearcoatFactor: m.clearcoat, clearcoatRoughnessFactor: m.clearcoatRoughness } };
      const coat=out.extensions.KHR_materials_clearcoat;
      if(m.clearcoatMap)coat.clearcoatTexture=texture(m.clearcoatMap);
      if(m.clearcoatRoughnessMap)coat.clearcoatRoughnessTexture=texture(m.clearcoatRoughnessMap);
      if(m.clearcoatNormalMap)coat.clearcoatNormalTexture={...texture(m.clearcoatNormalMap),scale:m.clearcoatNormalScale.x};
      if (!doc.extensionsUsed.includes('KHR_materials_clearcoat')) doc.extensionsUsed.push('KHR_materials_clearcoat');
    }
    if (m.emissive) {
      out.emissiveFactor = [m.emissive.r, m.emissive.g, m.emissive.b].map(c => c * Math.min(1, m.emissiveIntensity));
      if (m.emissiveIntensity > 1) {
        out.extensions ??= {}; out.extensions.KHR_materials_emissive_strength = { emissiveStrength: m.emissiveIntensity };
        if (!doc.extensionsUsed.includes('KHR_materials_emissive_strength')) doc.extensionsUsed.push('KHR_materials_emissive_strength');
      }
    }
    const i = doc.materials.length; doc.materials.push(out); matCache.set(key, i); return i;
  };
  const add = (mesh, matrix, name, tint = new T.Color(1, 1, 1)) => {
    if (Array.isArray(mesh.material)) throw new Error('This exporter only supports one material per mesh.');
    const mi = material(mesh.material, tint), key = `${mesh.geometry.uuid}:${mi}`;
    let index = meshCache.get(key);
    if (index === undefined) {
      index = doc.meshes.length; doc.meshes.push({ primitives: [{ ...geometry(mesh.geometry), material: mi }] }); meshCache.set(key, index);
    }
    doc.scenes[0].nodes.push(doc.nodes.length);
    doc.nodes.push({ name, mesh: index, matrix: matrix.toArray() });
  };
  root.updateMatrixWorld(true);
  root.traverse(obj => {
    if (!obj.isMesh) return;
    if (obj.isInstancedMesh) {
      const matrix = new T.Matrix4(), world = new T.Matrix4(), tint = new T.Color();
      for (let i = 0; i < obj.count; i++) {
        obj.getMatrixAt(i, matrix); if (Math.abs(matrix.determinant()) < 1e-12) continue;
        world.multiplyMatrices(obj.matrixWorld, matrix);
        if (obj.instanceColor) obj.getColorAt(i, tint); else tint.setRGB(1, 1, 1);
        add(obj, world, obj.userData.ids?.[i] ?? obj.name, tint);
      }
    } else add(obj, obj.matrixWorld, obj.name);
  });
  doc.buffers.push({ byteLength: length });
  const raw = new TextEncoder().encode(JSON.stringify(doc)), jsonLen = Math.ceil(raw.length / 4) * 4;
  const total = 12 + 8 + jsonLen + 8 + length, buf = new ArrayBuffer(total), view = new DataView(buf), out = new Uint8Array(buf);
  view.setUint32(0, 0x46546c67, true); view.setUint32(4, 2, true); view.setUint32(8, total, true);
  view.setUint32(12, jsonLen, true); view.setUint32(16, 0x4e4f534a, true); out.fill(32, 20, 20 + jsonLen); out.set(raw, 20);
  let at = 20 + jsonLen; view.setUint32(at, length, true); view.setUint32(at + 4, 0x004e4942, true); at += 8;
  for (const chunk of chunks) { out.set(chunk, at); at += chunk.length; }
  return buf;
}
