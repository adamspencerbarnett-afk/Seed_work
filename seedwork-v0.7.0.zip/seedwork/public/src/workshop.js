const T = window.THREE;
const $ = id => document.getElementById(id);
const copy = v => structuredClone(v);
const keyOf = name => `m_${name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 28) || 'model'}`;
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

const html = `
<dialog id="workshop" aria-labelledby="wk-title">
  <header class="wk-head"><div><span class="eyebrow">SEEDWORK / NATIVE AUTHORING</span><h2 id="wk-title">Model Workshop<span>0.7</span></h2></div><div class="wk-head-right"><span class="tag green">METERS · QUALITY LOCKED</span><button id="wk-close" aria-label="Close model workshop">Close ×</button></div></header>
  <div class="wk-body">
    <aside class="wk-left"><label class="field-label" for="wk-template">Start with a construction recipe</label><select id="wk-template"></select><p id="wk-brief" class="caption"></p>
      <label class="field-label" for="wk-library">Or edit a world model</label><select id="wk-library"><option value="">Choose a published model…</option></select>
      <div class="section-divider"></div><div class="section-title"><span class="eyebrow">ASSEMBLY PARTS</span><span id="wk-part-count" class="muted tiny"></span></div><div id="wk-parts" class="wk-parts"></div>
      <div class="wk-add"><select id="wk-shape" aria-label="New primitive shape"><option>box</option><option>cylinder</option><option>ellipsoid</option><option>torus</option><option>bowl</option><option>lathe</option><option>hose</option><option>plate</option></select><button id="wk-add">+ Part</button></div><div class="wk-row"><button id="wk-copy">Duplicate part</button><button id="wk-delete">Delete part</button></div>
      <div class="section-divider"></div><p id="wk-health" class="caption">Checking local modeler…</p><p class="caption">Offline recipe compiler. No neural model, scan library or image-to-3D service is connected.</p>
    </aside>
    <section class="wk-center"><div class="wk-view-head"><span id="wk-model-name">Choose a recipe</span><div class="wk-row"><button id="wk-fit">Fit</button><button data-look="pbr" class="active">PBR</button><button data-look="clay">Clay</button><button data-look="wire">Wire</button></div></div>
      <div class="wk-view" id="wk-view"><canvas id="wk-canvas" tabindex="0" aria-label="Model inspection viewport"></canvas><div id="wk-empty">Build the recipe to inspect its actual geometry.</div><div class="wk-view-note">Drag to orbit · Wheel to zoom · Click a part to select</div></div>
      <div class="wk-readout"><span id="wk-size">Real scale, not fitted to a prefab slot</span><span id="wk-stats">No model loaded</span></div>
      <div class="wk-progress"><span id="wk-phase">Ready to author</span><button id="wk-cancel" hidden>Cancel build</button></div><div id="wk-quality" class="wk-quality">Shape → materials → inspect → exact compaction → publish. A build never replaces a placed asset until you publish it.</div>
      <details class="wk-source"><summary>Editable source recipe · eight primitives, transforms and PBR materials</summary><textarea id="wk-json" spellcheck="false" aria-label="Full model recipe"></textarea><div class="wk-row"><button id="wk-json-apply">Apply source edits</button><button id="wk-recipe-save">Save recipe</button><button id="wk-recipe-load">Open recipe</button></div><input type="file" id="wk-recipe-file" accept=".json" hidden></details>
    </section>
    <aside class="wk-right"><span class="eyebrow">MODEL</span><label>Name<input id="wk-name" maxlength="64"></label><label>World type ID<input id="wk-key" maxlength="30" placeholder="m_my_model"></label><div class="wk-row"><label>Seed<input id="wk-seed" type="number" min="0" max="2147483647"></label><label>Authored texture size<select id="wk-tex"><option>64</option><option>128</option><option>256</option><option>512</option><option selected>1024</option><option>2048</option></select></label></div>
      <p class="caption">Changing resolution is an explicit authoring choice. Full surface maps must match this size. Height maps must match it; compiled maps and meshes are then preserved exactly.</p><div class="section-divider"></div><div class="section-title"><span class="eyebrow">SELECTED PART</span><button id="wk-solo">Solo</button></div><div id="wk-fields"></div><p class="caption">The release compiler supports dimensioned geometry and full PBR maps. Legacy sculpt, stamp and decal fields are rejected, not silently dropped.</p>
      <details class="wk-mat"><summary>Material & source maps</summary><label for="wk-mat-select">Material<select id="wk-mat-select"></select></label><div class="wk-row"><select id="wk-mat-kind" aria-label="New material type"><option>wood</option><option>stone</option><option>paint</option><option>steel</option><option>concrete</option><option>solid</option></select><button id="wk-mat-add">+ Material</button></div><div class="wk-row"><label>Roughness<input id="wk-rough" type="number" min="0" max="1" step="0.01"></label><label>Metal fraction<input id="wk-metal" type="number" min="0" max="1" step="0.01"></label></div><label>Color (source sRGB)<input id="wk-color" type="color"></label><label>Upload a source PNG into<select id="wk-map-kind"><option value="image">Base color</option><option value="normal">Tangent normal</option><option value="orm">Packed AO / roughness / metal</option><option value="height">Grayscale height</option></select></label><button id="wk-upload">Upload PNG</button><input id="wk-map-file" type="file" accept="image/png" hidden><p id="wk-map-ref" class="caption">Uploaded maps and recipes travel with Save world + assets.</p></details>
    </aside>
  </div><footer class="wk-foot"><span id="wk-draft">Recipe is editable</span><div class="wk-row"><button id="wk-report" disabled>Build audit</button><button id="wk-glb" disabled>Save model GLB</button><button id="wk-build" class="btn line">Build & inspect</button><button id="wk-publish" class="btn primary" disabled>Publish to world</button></div></footer>
</dialog>`;

function primitive(shape, mat, name) {
  const p = { name, shape, mat, pos: [0, .5, 0] };
  if (shape === 'box') Object.assign(p, { size: [.5, .5, .5], bevel: .003 });
  if (shape === 'cylinder') Object.assign(p, { radius: .2, length: .5, steps: 96 });
  if (shape === 'ellipsoid') Object.assign(p, { size: [.5, .6, .4], steps: 96, rings: 48 });
  if (shape === 'torus') Object.assign(p, { radius: .2, tube: .03, steps: 96, rings: 24 });
  if (shape === 'bowl') Object.assign(p, { size: [.7, .25, 1], depth: .012, steps: 96, rings: 12 });
  if (shape === 'lathe') Object.assign(p, { profile: [[0, 0], [.2, 0], [.2, .4], [.16, .5], [0, .5]], steps: 96 });
  if (shape === 'hose') Object.assign(p, { points: [[-.2, 0, 0], [0, .3, 0], [.2, .3, .2]], radius: .015, steps: 16, samples: 32 });
  if (shape === 'plate') Object.assign(p, { points: [[-.3, 0], [.3, 0], [.2, .3], [-.2, .3]], depth: .03 });
  return p;
}

export class Workshop {
  constructor(engine, hooks) {
    this.e = engine; this.h = hooks; this.open = false; this.dirty = true; this.look = 'pbr'; this.part = 0; this.solo = false; this.job = null; this.result = null; this.draft = null; this.loadId = 0; this.sourceDirty = false;
    document.body.insertAdjacentHTML('beforeend', html);
    this.dialog = $('workshop'); this.canvas = $('wk-canvas'); this.ctx = this.canvas.getContext('2d', { alpha: false });
    this.scene = new T.Scene(); this.scene.background = new T.Color('#20262a').convertSRGBToLinear();
    this.scene.add(new T.HemisphereLight('#ffffff', '#b4b1a8', .45));
    this.sun = new T.DirectionalLight('#fff6e7', 2.6); this.sun.castShadow = true; this.sun.shadow.mapSize.set(2048, 2048); this.sun.shadow.bias = -.00008; this.sun.shadow.normalBias = .0008; this.sun.shadow.radius = 2; this.scene.add(this.sun); this.scene.add(this.sun.target);
    const fill = new T.DirectionalLight('#d6e5f0', .65); fill.position.set(4, 3, -4); this.scene.add(fill);
    this.ground = new T.Mesh(new T.PlaneGeometry(200, 200), new T.MeshStandardMaterial({ color: new T.Color('#65635c').convertSRGBToLinear(), roughness: .9, metalness: 0 })); this.ground.rotation.x = -Math.PI / 2; this.ground.position.y = -.0015; this.ground.receiveShadow = true; this.scene.add(this.ground);
    this.camera = new T.PerspectiveCamera(34, 1, .002, 1000); this.target = new T.Vector3(); this.yaw = .65; this.tilt = .38; this.dist = 3;
    this.box = new T.Box3Helper(new T.Box3(), '#d9e6c1'); this.box.visible = false; this.scene.add(this.box);
    this.clay = new T.MeshStandardMaterial({ color: '#b4b3ac', roughness: .7 }); this.wire = new T.MeshBasicMaterial({ color: '#c1d3ca', wireframe: true });
    this.obs = new ResizeObserver(() => { this.dirty = true; }); this.obs.observe($('wk-view'));
    this.bind();
  }

  async call(name, args = {}) {
    const res = await fetch('/api/tool', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${this.h.getToken()}` }, body: JSON.stringify({ name, args }) });
    const out = await res.json(); if (!res.ok) throw new Error(out.error); return out.result;
  }

  fail(e) { $('wk-phase').textContent = e.message; this.h.toast(e.message, true); }

  async show(key = null) {
    if (this.e.playing) return this.h.toast('Exit the playable preview before modeling.', true);
    this.open = true; this.dialog.showModal(); this.dirty = true; this.e.keys.clear();
    try {
      if (!this.catalog) this.catalog = await (await fetch('/api/model/catalog')).json();
      $('wk-template').replaceChildren(...this.catalog.templates.map(t => new Option(t.name, t.id)));
      $('wk-library').replaceChildren(new Option('Choose a published model…', ''), ...Object.entries(this.h.getWorld().models ?? {}).map(([id, m]) => new Option(m.name, id)));
      $('wk-health').textContent = this.catalog.health.ok ? `Node ${this.catalog.health.node} · Seedwork compiler · offline builds ready` : 'Native compiler failed to start. Run node seedwork.mjs doctor.';
      if (key) await this.edit(key);
      else if (!this.draft) {
        let saved;
        try { saved = JSON.parse(localStorage.getItem('seedwork.workshop.draft.v1')); } catch {}
        if (['seedwork.recipe/1', 'ai3d.recipe/1'].includes(saved?.recipe?.schema)) { const preset = this.catalog.templates.find(t => same(t.recipe, saved.recipe)); if (preset) { await this.template(preset.id); this.key = saved.key; this.refresh(); } else { this.draft = saved.recipe; this.key = saved.key; this.refresh(); } }
        else await this.template(this.catalog.templates[0].id);
      } else this.refresh();
    } catch (e) { this.fail(e); }
  }

  close() { this.open = false; this.dialog.close(); this.e.resize(); this.e.shadowDirty(); this.e.render(); }

  async template(id) {
    const t = this.catalog.templates.find(t => t.id === id); $('wk-template').value = id; $('wk-library').value = '';
    this.loadId++; this.clearModel(); $('wk-empty').hidden = false;
    this.sourceDirty = false; this.draft = copy(t.recipe); this.key = keyOf(t.recipe.name); this.part = 0; this.result = null; this.job = null; this.refresh();
    if (t.starter) {
      const out = await this.call('model_status', { job: t.starter }); this.job = out.job.id; this.result = out.job.result; await this.preview(this.result); this.mark();
    }
  }

  async edit(key) {
    const model = this.h.getWorld().models[key]; $('wk-library').value = key; this.key = key; this.sourceDirty = false; this.draft = copy(model.recipe); this.part = 0; this.result = null; this.job = null; this.refresh(); await this.preview(model);
    $('wk-phase').textContent = 'Published model loaded. Build edits before publishing a new revision.';
  }

  refresh() {
    const d = this.draft; if (!d) return;
    $('wk-name').value = d.name; $('wk-key').value = this.key; $('wk-seed').value = d.seed ?? 42; $('wk-tex').value = d.texture_size ?? 512; $('wk-brief').textContent = d.brief ?? ''; $('wk-model-name').textContent = d.name.replaceAll('_', ' ');
    $('wk-part-count').textContent = `${d.parts.length} / 192`;
    this.part = Math.max(0, Math.min(this.part, d.parts.length - 1));
    $('wk-parts').replaceChildren(...d.parts.map((p, i) => { const b = document.createElement('button'); b.textContent = p.name.replaceAll('_', ' '); b.title = `${p.shape} · ${p.mat}`; b.classList.toggle('active', i === this.part); b.onclick = () => { this.part = i; this.refresh(); }; return b; }));
    $('wk-mat-select').replaceChildren(...Object.keys(d.materials).map(k => new Option(k, k))); $('wk-mat-select').value = d.parts[this.part]?.mat ?? Object.keys(d.materials)[0];
    this.fields(); this.matFields(); this.mark(); this.highlight();
  }

  fields() {
    const host = $('wk-fields'), p = this.draft.parts[this.part]; host.replaceChildren(); if (!p) return;
    const label = (text, child) => { const l = document.createElement('label'); l.append(document.createTextNode(text), child); return l; };
    const name = document.createElement('input'); name.value = p.name; name.maxLength = 64; name.onchange = () => { p.name = name.value; this.refresh(); }; host.append(label(`${p.shape} · part name`, name));
    const mat = document.createElement('select'); mat.append(...Object.keys(this.draft.materials).map(k => new Option(k, k))); mat.value = p.mat; mat.onchange = () => { p.mat = mat.value; this.refresh(); }; host.append(label('Material', mat));
    for (const [key, title, fallback] of [['pos', 'Position · meters', [0, 0, 0]], ['rot', 'Rotation · degrees', [0, 0, 0]], ['size', 'Dimensions · meters', null]]) {
      if (!p[key] && !fallback) continue;
      const row = document.createElement('div'); row.className = 'wk-vec';
      for (let i = 0; i < 3; i++) { const input = document.createElement('input'); input.type = 'number'; input.step = key === 'rot' ? '1' : '.001'; input.value = (p[key] ?? fallback)[i]; input.setAttribute('aria-label', `${key} ${'XYZ'[i]}`); input.onchange = () => { if (!Number.isFinite(+input.value)) return; p[key] ??= [...fallback]; p[key][i] = +input.value; this.mark(); }; row.append(input); }
      host.append(label(title, row));
    }
    for (const k of ['bevel', 'radius', 'length', 'inner', 'top', 'tube', 'depth', 'steps', 'rings']) if (p[k] !== undefined) {
      const input = document.createElement('input'); input.type = 'number'; input.step = ['steps', 'rings'].includes(k) ? '1' : '.001'; input.value = p[k]; input.onchange = () => { p[k] = +input.value; this.mark(); }; host.append(label(k + (['steps', 'rings'].includes(k) ? '' : ' · meters'), input));
    }
  }

  matFields() {
    const m = this.draft?.materials[$('wk-mat-select').value]; if (!m) return;
    $('wk-rough').value = m.rough ?? .82; $('wk-metal').value = m.metal ?? (m.kind === 'steel' ? .9 : 0);
    const rgb = m.color ?? [.6, .6, .6]; $('wk-color').value = '#' + rgb.map(c => Math.round(Math.min(1, Math.max(0, c)) * 255).toString(16).padStart(2, '0')).join('');
  }

  mark() {
    const stale = this.sourceDirty || !this.result || !same(this.draft, this.result.recipe);
    $('wk-draft').textContent = stale ? 'Unbuilt source changes · publish is locked' : 'Inspected build matches the source recipe';
    $('wk-publish').disabled = stale || !this.job; $('wk-report').disabled = !this.result?.report; $('wk-glb').disabled = !this.result?.hash;
    if (!this.sourceDirty) $('wk-json').value = JSON.stringify(this.draft, null, 2);
    try { localStorage.setItem('seedwork.workshop.draft.v1', JSON.stringify({ recipe: this.draft, key: this.key })); } catch {}
  }

  async build() {
    if (this.sourceDirty) return this.fail(new Error('Apply source edits before building.'));
    if (this.building) return;
    this.building = true; $('wk-build').disabled = true; $('wk-cancel').hidden = false; this.result = null; this.mark();
    try {
      const source = copy(this.draft), out = await this.call('model_build', { recipe: source }); let job = out.job; this.job = job.id;
      for (;;) {
        $('wk-phase').textContent = job.phase;
        if (['ready', 'failed', 'cancelled'].includes(job.state)) break;
        await new Promise(r => setTimeout(r, 400)); job = (await this.call('model_status', { job: job.id })).job;
      }
      if (job.state !== 'ready') throw new Error(job.error || 'Build cancelled; published models are unchanged.');
      this.result = job.result; await this.preview(this.result); this.mark();
      $('wk-phase').textContent = job.cached ? 'Verified build cache hit · ready to publish' : 'Build complete · inspect before publishing';
    } catch (e) { this.fail(e); }
    finally { this.building = false; $('wk-build').disabled = false; $('wk-cancel').hidden = true; }
  }

  async publish() {
    if (this.sourceDirty || !this.result || !this.job || !same(this.draft, this.result.recipe)) throw new Error('Build the current source before publishing.');
    const key = $('wk-key').value, out = await this.h.run('model_publish', { job: this.job, key });
    if (!out) return;
    this.key = key; this.close(); this.h.place(key); this.h.toast(`${out.result.model.name} published at real meter scale. Click terrain to place it. Existing instances were updated.`);
  }

  clearModel() {
    if (!this.model) return;
    const geos = new Set(), mats = new Set(), tex = new Set();
    this.model.traverse(o => { if (o.isMesh) { geos.add(o.geometry); const m = o.userData.pbr ?? o.material; mats.add(m); for (const v of Object.values(m)) if (v?.isTexture) tex.add(v); } });
    this.scene.remove(this.model); for (const g of geos) g.dispose(); for (const m of mats) m.dispose(); for (const t of tex) t.dispose(); this.model = null;
  }

  async preview(result) {
    const ticket = ++this.loadId, res = await fetch(`/api/asset/${result.hash}`);
    if (!res.ok) throw new Error('The compiled model asset is unavailable.');
    const bytes = await res.arrayBuffer();
    if (ticket !== this.loadId) return;
    await this.loadModel(bytes, result, ticket);
  }

  async loadModel(bytes, result, ticket = this.loadId) {
    const gltf = await new Promise((done, fail) => new T.GLTFLoader().parse(bytes, '', done, fail));
    if (ticket !== this.loadId) { const old = this.model; this.model = gltf.scene; this.clearModel(); this.model = old; return; }
    this.clearModel(); this.model = gltf.scene; let order = 0; this.model.traverse(o => { if (o.isMesh) { o.renderOrder = ++order; o.castShadow = true; o.receiveShadow = true; o.userData.pbr = o.material; } }); this.scene.add(this.model); this.model.updateMatrixWorld(true); this.measures = result; this.solo = false; this.look = 'pbr'; this.fit(); this.highlight();
    $('wk-empty').hidden = true; $('wk-model-name').textContent = result.name;
    $('wk-size').textContent = `${result.width.toFixed(3)} × ${result.height.toFixed(3)} × ${result.depth.toFixed(3)} m · X / Y / Z`;
    if (result.report) {
      const r = result.report, saved = r.raw.bytes - r.packed.bytes;
      $('wk-stats').textContent = `${r.packed.drawn_triangles.toLocaleString()} triangles · ${(r.packed.bytes / 1048576).toFixed(2)} MiB`;
      $('wk-quality').textContent = `Exact compaction: ${r.exact.passed ? 'PASS' : 'FAIL'} · ${Math.max(0, saved).toLocaleString()} bytes removed · triangle corners, textures and transforms unchanged. Material cache: ${r.materials.hits} reused / ${r.materials.misses} baked. This is not a photorealism certification.`;
    } else { $('wk-stats').textContent = 'Published native asset'; $('wk-quality').textContent = 'The source recipe is retained. Rebuild to create a new audited revision.'; }
    this.dirty = true;
  }

  fit() {
    if (!this.measures) return;
    const m = this.measures, s = Math.max(m.width, m.height, m.depth); this.span = s; this.camera.near = Math.max(.0001, s * .1); this.camera.far = Math.max(1, s * 20); this.target.set(0, m.height * .48, 0); this.dist = s * 2.6; this.yaw = .66; this.tilt = .38;
    this.sun.position.set(-s * 2.5, s * 3.4, s * 2.6); this.sun.target.position.set(0, m.height * .4, 0); Object.assign(this.sun.shadow.camera, { left: -s, right: s, top: s, bottom: -s, near: .01, far: s * 12 }); this.sun.shadow.camera.updateProjectionMatrix(); this.dirty = true;
  }

  highlight() {
    if (!this.model) return;
    const name = this.draft?.parts[this.part]?.name; this.box.visible = false;
    this.model.traverse(o => { if (!o.isMesh) return; o.visible = !this.solo || o.name === name; o.material = this.look === 'clay' ? this.clay : this.look === 'wire' ? this.wire : o.userData.pbr; });
    $('wk-solo').classList.toggle('active', this.solo); document.querySelectorAll('[data-look]').forEach(b => b.classList.toggle('active', b.dataset.look === this.look)); this.dirty = true;
  }

  tick() { if (this.dirty && this.open && this.model) this.draw(); }

  draw() {
    const r = this.e.renderer, host = $('wk-view'), w = Math.max(1, host.clientWidth), h = Math.max(1, host.clientHeight), ratio = window.devicePixelRatio;
    if (this.canvas.width !== Math.round(w * ratio) || this.canvas.height !== Math.round(h * ratio)) { this.canvas.width = Math.round(w * ratio); this.canvas.height = Math.round(h * ratio); }
    this.camera.aspect = w / h; this.camera.position.set(this.target.x + Math.sin(this.yaw) * Math.cos(this.tilt) * this.dist, this.target.y + Math.sin(this.tilt) * this.dist, this.target.z + Math.cos(this.yaw) * Math.cos(this.tilt) * this.dist); this.camera.lookAt(this.target); this.camera.updateProjectionMatrix();
    this.scene.environment = this.e.env?.texture ?? null;
    r.setSize(w, h, false); r.setPixelRatio(ratio); r.shadowMap.enabled = true; r.shadowMap.needsUpdate = true; r.render(this.scene, this.camera); this.ctx.drawImage(r.domElement, 0, 0, this.canvas.width, this.canvas.height); this.last = { calls: r.info.render.calls, triangles: r.info.render.triangles, geometries: r.info.memory.geometries, textures: r.info.memory.textures }; this.dirty = false;
  }

  bind() {
    const safe = fn => async (...args) => { try { await fn(...args); } catch (e) { this.fail(e); } };
    $('wk-close').onclick = () => this.close(); this.dialog.addEventListener('cancel', e => { e.preventDefault(); this.close(); });
    $('wk-template').onchange = safe(e => this.template(e.target.value)); $('wk-library').onchange = safe(e => e.target.value && this.edit(e.target.value));
    $('wk-build').onclick = () => this.build(); $('wk-publish').onclick = safe(() => this.publish()); $('wk-cancel').onclick = safe(() => this.job && this.call('model_cancel', { job: this.job }));
    $('wk-fit').onclick = () => this.fit(); $('wk-solo').onclick = () => { this.solo = !this.solo; this.highlight(); }; document.querySelectorAll('[data-look]').forEach(b => { b.onclick = () => { this.look = b.dataset.look; this.highlight(); }; });
    for (const [id, k] of [['wk-name', 'name'], ['wk-seed', 'seed'], ['wk-tex', 'texture_size']]) $(id).onchange = () => { this.draft[k] = k === 'name' ? $(id).value : Number($(id).value); this.mark(); };
    $('wk-key').onchange = () => { this.key = $('wk-key').value; this.mark(); };
    $('wk-add').onclick = () => { if (this.draft.parts.length >= 192) return this.fail(new Error('Part limit reached.')); let n = this.draft.parts.length + 1; while (this.draft.parts.some(p => p.name === `part_${n}`)) n++; this.draft.parts.push(primitive($('wk-shape').value, Object.keys(this.draft.materials)[0], `part_${n}`)); this.part = this.draft.parts.length - 1; this.refresh(); };
    $('wk-copy').onclick = () => { if (this.draft.parts.length >= 192) return; const p = copy(this.draft.parts[this.part]); let n = 1; while (this.draft.parts.some(x => x.name === `${p.name.slice(0, 50)}_${n}`)) n++; p.name = `${p.name.slice(0, 50)}_${n}`; this.draft.parts.push(p); this.part = this.draft.parts.length - 1; this.refresh(); };
    $('wk-delete').onclick = () => { if (this.draft.parts.length < 2) return this.fail(new Error('An assembly needs at least one part.')); this.draft.parts.splice(this.part, 1); this.refresh(); };
    $('wk-json-apply').onclick = safe(() => { const d = JSON.parse($('wk-json').value); if (!['seedwork.recipe/1', 'ai3d.recipe/1'].includes(d.schema) || !d.parts?.length || !d.materials) throw new Error('Expected a Seedwork or compatible legacy recipe.'); this.sourceDirty = false; this.draft = d; this.refresh(); });
    $('wk-json').oninput = () => { this.sourceDirty = true; $('wk-publish').disabled = true; $('wk-draft').textContent = 'Unapplied JSON edits · Apply source edits before building'; };
    $('wk-recipe-save').onclick = () => this.h.download(JSON.stringify(this.draft, null, 2), `${this.draft.name}.recipe.json`, 'application/json'); $('wk-recipe-load').onclick = () => $('wk-recipe-file').click();
    $('wk-recipe-file').onchange = safe(async e => { const f = e.target.files[0]; if (!f) return; if (f.size > 160 * 1024) throw new Error('Recipe exceeds 160 KiB.'); const d = JSON.parse(await f.text()); if (!['seedwork.recipe/1', 'ai3d.recipe/1'].includes(d.schema) || !d.parts?.length) throw new Error('Expected a Seedwork or compatible legacy recipe.'); this.sourceDirty = false; this.draft = d; this.key = keyOf(d.name); this.part = 0; this.refresh(); e.target.value = ''; });
    $('wk-report').onclick = () => this.result?.report && this.h.download(JSON.stringify(this.result.report, null, 2), `${this.draft.name}.audit.json`, 'application/json'); $('wk-glb').onclick = safe(async () => { if (!this.result) return; const res = await fetch(`/api/asset/${this.result.hash}`); if (!res.ok) throw new Error('Model GLB unavailable.'); this.h.download(await res.arrayBuffer(), `${this.result.recipe.name}.glb`, 'model/gltf-binary'); });
    $('wk-mat-add').onclick = safe(() => { const mats = this.draft.materials, kind = $('wk-mat-kind').value; if (Object.keys(mats).length >= 32) throw new Error('At most 32 materials.'); let n = 1; while (mats[`${kind}_${n}`]) n++; const key = `${kind}_${n}`; mats[key] = { kind, rough: kind === 'steel' ? .4 : .72, metal: kind === 'steel' ? 1 : 0, bump: .0002, normal_strength: .35 }; this.draft.parts[this.part].mat = key; this.refresh(); });
    $('wk-mat-select').onchange = () => this.matFields();
    for (const [id, key] of [['wk-rough', 'rough'], ['wk-metal', 'metal']]) $(id).onchange = () => { this.draft.materials[$('wk-mat-select').value][key] = Number($(id).value); this.mark(); };
    $('wk-color').onchange = () => { const h = $('wk-color').value; this.draft.materials[$('wk-mat-select').value].color = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255); this.mark(); };
    $('wk-upload').onclick = () => $('wk-map-file').click(); $('wk-map-file').onchange = safe(async e => { const f = e.target.files[0]; if (!f) return; const res = await fetch('/api/model/input', { method: 'POST', headers: { 'Content-Type': 'image/png', Authorization: `Bearer ${this.h.getToken()}` }, body: await f.arrayBuffer() }), info = await res.json(); if (!res.ok) throw new Error(info.error); const m = this.draft.materials[$('wk-mat-select').value], k = $('wk-map-kind').value; m[k] = info.ref; if (['image', 'normal', 'orm'].includes(k) && info.width === info.height && [64, 128, 256, 512, 1024, 2048].includes(info.width)) m.tex_size = info.width; $('wk-map-ref').textContent = `${info.width} × ${info.height} · ${info.ref}`; this.mark(); e.target.value = ''; });
    this.canvas.addEventListener('pointerdown', e => { this.down = { x: e.clientX, y: e.clientY, total: 0 }; this.canvas.setPointerCapture(e.pointerId); });
    this.canvas.addEventListener('pointermove', e => { if (!this.down) return; const dx = e.clientX - this.down.x, dy = e.clientY - this.down.y; this.down.total += Math.hypot(dx, dy); this.down.x = e.clientX; this.down.y = e.clientY; this.yaw -= dx * .008; this.tilt = Math.max(-.12, Math.min(1.5, this.tilt + dy * .006)); this.dirty = true; });
    this.canvas.addEventListener('pointerup', e => { const down = this.down; this.down = null; if (this.canvas.hasPointerCapture(e.pointerId)) this.canvas.releasePointerCapture(e.pointerId); if (!down || down.total > 4 || !this.model) return; const b = this.canvas.getBoundingClientRect(), ray = new T.Raycaster(); ray.setFromCamera(new T.Vector2((e.clientX - b.left) / b.width * 2 - 1, -(e.clientY - b.top) / b.height * 2 + 1), this.camera); const hit = ray.intersectObject(this.model, true).find(h => h.object.visible); const i = hit ? this.draft.parts.findIndex(p => p.name === hit.object.name) : -1; if (i >= 0) { this.part = i; this.refresh(); } });
    this.canvas.addEventListener('pointercancel', () => { this.down = null; }); this.canvas.addEventListener('wheel', e => { e.preventDefault(); this.dist = Math.max(.02, Math.min((this.span ?? 1) * 12, this.dist * Math.exp(e.deltaY * .001))); this.dirty = true; }, { passive: false });
  }
}
