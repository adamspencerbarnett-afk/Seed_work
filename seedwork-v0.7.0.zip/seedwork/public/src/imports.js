import { META } from '/core/world.mjs';
import { merge } from './surface.js';
const T = window.THREE;
const loaded = new Map(), pending = new Map();

function clean(source) {
  const geo = new T.BufferGeometry();
  for (const key of ['position', 'normal', 'tangent', 'uv', 'uv2', 'color']) {
    const a = source.attributes[key]; if (!a) continue;
    const data = new Float32Array(a.count * a.itemSize);
    for (let i = 0; i < a.count; i++) for (let k = 0; k < a.itemSize; k++) { let v=[a.getX,a.getY,a.getZ,a.getW][k].call(a,i); const arr=a.isInterleavedBufferAttribute?a.data.array:a.array; if(a.normalized){const bits=arr.BYTES_PER_ELEMENT*8,signed=arr instanceof Int8Array||arr instanceof Int16Array||arr instanceof Int32Array;v=signed?Math.max(-1,v/(2**(bits-1)-1)):v/(2**bits-1);}data[i*a.itemSize+k]=v; }
    geo.setAttribute(key, new T.BufferAttribute(data, a.itemSize));
  }
  if (source.index) geo.setIndex(new T.BufferAttribute(new Uint32Array(source.index.array), 1));
  if (!geo.attributes.normal) geo.computeVertexNormals();
  if (!geo.attributes.uv2 && geo.attributes.uv) geo.setAttribute('uv2', geo.attributes.uv.clone());
  return geo;
}

export async function loadPack(bindings = {}, models = {}) {
  await Promise.all(Object.entries(bindings).map(async ([type, hash]) => {
    const key = `${type}:${hash}`;
    if (loaded.has(key)) return;
    if (!pending.has(key)) pending.set(key, (async () => {
      const res = await fetch(`/api/asset/${hash}`);
      if (!res.ok) throw new Error(`Missing asset for ${type}. Open its .seedpack.json bundle to restore the asset.`);
      const bytes = await res.arrayBuffer();
      const result = await new Promise((resolve, reject) => new T.GLTFLoader().parse(bytes, '', resolve, reject));
      result.scene.updateMatrixWorld(true);
      const box = new T.Box3().setFromObject(result.scene), size = box.getSize(new T.Vector3()), center = box.getCenter(new T.Vector3());
      if (!Number.isFinite(size.y) || size.y < .00001) throw new Error('Asset must have nonzero finite height.');
      const native = Object.hasOwn(models, type);
      const scale = native ? 1 : Math.min(META[type].height / size.y, META[type].width / Math.max(size.x, size.z, .001));
      const norm = native ? new T.Matrix4() : new T.Matrix4().makeScale(scale, scale, scale).multiply(new T.Matrix4().makeTranslation(-center.x, -box.min.y, -center.z));
      const groups = new Map(), original = new Set();
      result.scene.traverse(o => {
        if (!o.isMesh) return;
        if (Array.isArray(o.material)) throw new Error('Export separate glTF primitives for different materials.');
        if (o.matrixWorld.determinant()<=0) throw new Error('Bake mirrored transforms before import.');
        const material = o.material, geo = clean(o.geometry); original.add(o.geometry);
        geo.applyMatrix4(new T.Matrix4().multiplyMatrices(norm, o.matrixWorld));
        if (material.normalScale && Math.abs(material.normalScale.x) !== Math.abs(material.normalScale.y)) throw new Error('Use equal X/Y normal-map strength before importing.');
        material.roughness ??= 1; material.metalness ??= 0;
        material.userData.imported = true;
        material.flatShading = false;
        const layout = Object.entries(geo.attributes).map(([k, a]) => `${k}:${a.itemSize}`).sort().join('|');
        const group = `${material.uuid}:${layout}`;
        if (!groups.has(group)) groups.set(group, { material, list: [] });
        groups.get(group).list.push(geo);
      });
      const entries = [];
      for (const {material, list} of groups.values()) entries.push({ geo: merge(list), mat: material });
      for (const g of original) g.dispose();
      loaded.set(key, entries);
    })().catch(e => { pending.delete(key); throw e; }));
    await pending.get(key);
  }));
}

export function withPack(base, bindings = {}) {
  if (!Object.keys(bindings).length) return base;
  const out = { ...base, geo: {...base.geo}, mat: {...base.mat}, recipes: {...base.recipes} };
  for (const [type, hash] of Object.entries(bindings)) {
    const entries = loaded.get(`${type}:${hash}`);
    if (!entries) throw new Error(`Asset ${type} is not ready.`);
    out.recipes[type] = entries.map(({geo, mat}, i) => {
      const key = `import-${type}-${hash}-${i}`;
      out.geo[key] = geo; out.mat[key] = mat;
      return {g:key,m:key,pos:[0,0,0],rot:[0,0,0],scale:[1,1,1]};
    });
  }
  return out;
}

export function prunePack(bindings = {}) {
  const active = new Set(Object.entries(bindings).map(([type,hash])=>`${type}:${hash}`));
  for (const [key,entries] of loaded) if (!active.has(key)) {
    const textures = new Set();
    for (const {geo,mat} of entries) { geo.dispose(); for (const value of Object.values(mat)) if(value?.isTexture) textures.add(value); mat.dispose(); }
    for (const tex of textures) tex.dispose();
    loaded.delete(key);pending.delete(key);
  }
}
