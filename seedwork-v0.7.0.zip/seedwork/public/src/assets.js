import { rand, noise } from '/core/world.mjs';
import { withPack } from './imports.js';
import { material, needles, uv, merge } from './surface.js';
const T = window.THREE;
const cache = new Map();

export const PALETTES = {
  forest: { grass: '#727d4a', low: '#8b8a63', high: '#777b60', sand: '#b0a087', stone: '#82817b', leaf: '#627344', leaf2: '#78814b', wood: '#65523e', roof: '#666761', crystal: '#d5d8ca', cap: '#9a8566', sky: '#b6cbd5', water: '#526d69' },
  desert: { grass: '#b6a27b', low: '#c4b18b', high: '#a59375', sand: '#c5b696', stone: '#9f9483', leaf: '#687657', leaf2: '#788266', wood: '#776756', roof: '#626767', crystal: '#d9d5c7', cap: '#a59478', sky: '#c4cbd0', water: '#547875' },
  snow: { grass: '#d6dce0', low: '#c6cdd2', high: '#eef0ee', sand: '#9fa9ac', stone: '#838c90', leaf: '#54665c', leaf2: '#68756b', wood: '#655f57', roof: '#657076', crystal: '#d8e1df', cap: '#a69784', sky: '#b6c8d5', water: '#526b78' },
  fantasy: { grass: '#798165', low: '#8a8970', high: '#6a7563', sand: '#b4aa98', stone: '#82847d', leaf: '#61734f', leaf2: '#7e8962', wood: '#675c4b', roof: '#64716b', crystal: '#bdcecf', cap: '#978274', sky: '#bacbd4', water: '#537676' }
};

function transformed(g, pos, scale = [1, 1, 1], rot = [0, 0, 0]) {
  const m = new T.Matrix4().compose(new T.Vector3(...pos), new T.Quaternion().setFromEuler(new T.Euler(...rot)), new T.Vector3(...scale));
  g.applyMatrix4(m); return g;
}

function limb(a, b, r1, r2, sides = 9) {
  const start = new T.Vector3(...a), end = new T.Vector3(...b), dir = end.clone().sub(start), len = dir.length();
  const g = new T.CylinderGeometry(r2, r1, len, sides, 2);
  const tex = g.attributes.uv;
  for (let i = 0; i < tex.count; i++) tex.setXY(i, tex.getX(i) * Math.max(0.5, r1 * 8), tex.getY(i) * len * 0.7);
  g.applyQuaternion(new T.Quaternion().setFromUnitVectors(new T.Vector3(0, 1, 0), dir.normalize()));
  g.translate(...start.add(end).multiplyScalar(0.5).toArray()); return g;
}

export function kit(biome, bindings = {}) {
  if (cache.has(biome)) return withPack(cache.get(biome), bindings);
  const p = PALETTES[biome], geo = {}, recipes = {};
  const mat = {
    wood: material('wood'), bark: material('bark'), stone: material('rock'), wall: material('plaster'), masonry: material('masonry'), roof: material('slate'),
    leaf: material('leaf', { color: '#d1d6b6', side: T.DoubleSide, vertexColors: true }), needles: needles(),
    grass: material('leaf', { color: '#e7e4c2', side: T.DoubleSide, vertexColors: true }),
    dark: new T.MeshStandardMaterial({ color: '#181d1b', roughness: 0.23, metalness: 0 }),
    metal: new T.MeshStandardMaterial({ color: '#50504a', roughness: 0.56, metalness: 0.8 }),
    light: new T.MeshStandardMaterial({ color: '#ccc2a7', roughness: 0.3, emissive: '#ffd2a0', emissiveIntensity: 0.05 }),
    cap: material('plaster', { color: '#af9064', roughness: 0.88 }),
    crystal: new T.MeshPhysicalMaterial({ color: '#d9dbd5', roughness: 0.13, metalness: 0, clearcoat: 1, clearcoatRoughness: 0.11 }),
    ground: material(biome === 'desert' ? 'sand' : biome === 'snow' ? 'snow' : 'ground', { vertexColors: true, roughness: 1 })
  };
  for (const [name, m] of Object.entries(mat)) {
    m.name ||= `Seedwork / ${name}`;
    if (m.normalScale) m.normalScale.setScalar(name === 'ground' ? .38 : name === 'stone' ? .55 : name === 'wall' ? .25 : .7);
    if (!m.map) { m.color.convertSRGBToLinear(); m.emissive?.convertSRGBToLinear(); }
  }
  const build = (type, fn) => {
    const parts = new Map();
    const put = (name, g) => { if (!parts.has(name)) parts.set(name, []); parts.get(name).push(g); };
    const box = (name, pos, scale, rot) => {
      const g = new T.BoxGeometry(...scale), p = g.attributes.position, n = g.attributes.normal, a = g.attributes.uv;
      const tile = name === 'masonry' ? 2 : name === 'wood' ? 1.5 : 1;
      for (let i=0;i<p.count;i++) {
        const nx=Math.abs(n.getX(i)),ny=Math.abs(n.getY(i));
        a.setXY(i,(nx>.5?p.getZ(i):p.getX(i))/tile,(ny>.5?-p.getZ(i):p.getY(i))/tile);
      }
      g.setAttribute('uv2',a.clone());put(name,transformed(g,pos,[1,1,1],rot));
    };
    const pole = (name, a, b, r1, r2) => put(name, limb(a, b, r1, r2));
    fn(put, box, pole);
    recipes[type] = [];
    for (const [m, list] of parts) {
      const key = `${type}-${m}`; geo[key] = merge(list);
      recipes[type].push({ g: key, m, pos: [0, 0, 0], scale: [1, 1, 1], rot: [0, 0, 0] });
    }
  };
  build('pine', (put, box, pole) => {
    const rng = rand('pine-real-7');
    pole('bark', [0, 0, 0], [0.10, 6.9, 0.04], 0.19, 0.024);
    for (let k = 0; k < 36; k++) {
      const y = 1.55 + k * 0.142, a = k * 2.399, len = (7.3 - y) * 0.32 * (0.83 + rng() * 0.30);
      const end = [Math.cos(a) * len, y - 0.22, Math.sin(a) * len];
      pole('bark', [0, y, 0], end, 0.037 * (len + 0.2), 0.007);
      for (let j = 0; j < 5; j++) {
        const t = 0.29 + j * 0.16, side = j % 2 ? 1 : -1;
        const ex = end[0] * t, ez = end[2] * t, ay = y - 0.22 * t;
        for (let c = 0; c < 2; c++) put('needles', transformed(new T.PlaneGeometry(0.63 + len * 0.20, 0.9), [ex + Math.cos(a + side * 1.4) * .17, ay, ez + Math.sin(a + side * 1.4) * .17], [1,1,1], [-1.02 + c * 0.6, a + side * .5, rng() * .35]));
      }
    }
  });
  build('oak', (put, box, pole) => {
    const rng = rand('oak-real-3');
    pole('bark', [0,0,0], [.12,3.4,.08], .29, .12);
    for (let i = 0; i < 16; i++) {
      const a = i * 2.399, y = 2.0 + rng() * 2, len = 1.15 + rng() * 1.4;
      const end = [Math.cos(a) * len, y + .75 + rng() * .6, Math.sin(a) * len];
      pole('bark', [.07,y,.04], end, .08, .017);
      for (let b = 0; b < 3; b++) {
        const a2 = a + (b - 1) * .9, end2 = [end[0]+Math.cos(a2)*.65,end[1]+.4,end[2]+Math.sin(a2)*.65];
        pole('bark', end, end2, .024, .006);
        for (let j = 0; j < 17; j++) {
          const angle = rng()*Math.PI*2, r = Math.sqrt(rng())*.83;
          const pos = [end2[0]+Math.cos(angle)*r,end2[1]+(rng()-.5)*1.1,end2[2]+Math.sin(angle)*r];
          const leaf = new T.BufferGeometry();
          leaf.setAttribute('position',new T.Float32BufferAttribute([0,0,-.15,-.10,0,-.035,0,.028,0,.10,0,-.035,0,0,.19],3));
          leaf.setAttribute('uv',new T.Float32BufferAttribute([.5,0,0,.38,.5,.48,1,.38,.5,1],2));
          leaf.setIndex([0,2,1,0,3,2,1,2,4,2,3,4]);
          leaf.computeVertexNormals(); const ps=leaf.attributes.position;
          const colors = new Float32Array(ps.count*3), tint = .78+rng()*.25;
          for (let v=0;v<ps.count;v++) colors.set([tint,tint,tint],v*3);
          leaf.setAttribute('color',new T.BufferAttribute(colors,3));
          put('leaf', transformed(leaf,pos,[1.5,1.5,1.5],[rng()*.7,angle,rng()*.5]));
        }
      }
    }
  });
  build('rock', put => {
    for (let k=0;k<2;k++) {
      const g = new T.IcosahedronGeometry(1,3), ps=g.attributes.position;
      for (let i=0;i<ps.count;i++) {
        const x=ps.getX(i),y=ps.getY(i),z=ps.getZ(i), d=.78+noise(x*2+z*.3,y*2-z,91+k)*.30+noise(x*7,y*7+z,5)*.1;
        ps.setXYZ(i,x*d,y*d,z*d);
      }
      g.computeVertexNormals(); put('stone', transformed(g,[k*.9,k?.32:.61,k*.5],k?[.76,.63,.68]:[1.3,.94,1.13],[.1,k*.6,.12]));
    }
  });
  build('house', (put,box,pole) => {
    box('masonry',[0,.15,0],[5.3,.6,4.4]); box('wall',[0,1.85,0],[4.85,3.1,4]);
    for (const x of [-2.4,0,2.4]) box('wood',[x,1.85,2.03],[.16,3.1,.16]);
    box('wood',[0,3.3,2.03],[4.95,.19,.17]);
    const rise=1.65, half=2.9, angle=Math.atan2(rise,half), len=Math.hypot(half,rise);
    for (const side of [-1,1]) {
      const roof=new T.BoxGeometry(len,.12,5.1); uv(roof,3.0);
      put('roof',transformed(roof,[side*half*.5,3.38+rise*.5,0],[1,1,1],[0,0,-side*angle]));
      box('wood',[side*half,3.38,0],[.15,.2,5.2]);
      box('wood',[side*half*.5,3.38+rise*.5,2.55],[len,.19,.14],[0,0,-side*angle]);
    }
    box('wood',[0,1.35,2.045],[.99,2.15,.12]);
    box('masonry',[0,.34,2.65],[1.6,.32,1.0]);
    for (const x of [-1.5,1.5]) {
      box('dark',[x,2.1,2.055],[.87,.97,.07]);
      for (const dx of [-.49,0,.49]) box('wood',[x+dx,2.1,2.1],[.06,1.12,.08]);
      for (const yy of [1.56,2.1,2.64]) box('wood',[x,yy,2.11],[1.02,.065,.12]);
      box('masonry',[x,1.53,2.13],[1.15,.12,.3]);
    }
    box('masonry',[1.55,4.55,-.75],[.64,2,.74]); box('masonry',[1.55,5.54,-.75],[.79,.13,.9]);
    box('dark',[1.55,5.62,-.75],[.45,.01,.5]);
    const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute([-2.4,3.36,2,2.4,3.36,2,0,4.82,2,-2.4,3.36,-2,0,4.82,-2,2.4,3.36,-2],3));g.setAttribute('uv',new T.Float32BufferAttribute([0,0,2.4,0,1.2,.73,0,0,1.2,.73,2.4,0],2));g.setAttribute('uv2',g.attributes.uv.clone());g.computeVertexNormals();put('wall',g);
  });
  build('tower',(put,box,pole)=>{
    put('masonry',transformed(uv(new T.CylinderGeometry(1.65,1.95,8.2,32),4),[0,4.1,0]));
    for(const y of [.24,7.9]) put('masonry',transformed(uv(new T.CylinderGeometry(2.05,2.05,.35,32),4),[0,y,0]));
    for(let i=0;i<12;i++){const a=i*Math.PI/6;box('masonry',[Math.sin(a)*1.88,8.65,Math.cos(a)*1.88],[.64,1.0,.49],[0,a,0]);}
    box('dark',[0,1.4,1.94],[.9,2.1,.08]);
    for(const y of [3.5,6]) for(let i=0;i<4;i++){const a=i*Math.PI/2;box('dark',[Math.sin(a)*1.80,y,Math.cos(a)*1.80],[.3,1.12,.07],[0,a,0]);}
  });
  build('crystal',(put)=>{
    const rng=rand('quartz');
    for(let i=0;i<9;i++) {
      const a=rng()*Math.PI*2,r=rng()*.28,h=.25+rng()*.55;
      const g=new T.CylinderGeometry(.065,.095,h,6);put('crystal',transformed(g,[Math.cos(a)*r,h*.5,Math.sin(a)*r],[1,1,1],[.10*Math.sin(a),a,.18*Math.cos(a)]));
      put('crystal',transformed(new T.ConeGeometry(.065,.12,6),[Math.cos(a)*r,h+.05,Math.sin(a)*r]));
    }
    put('stone',transformed(new T.IcosahedronGeometry(.35,2),[0,.06,0],[1,.3,1]));
  });
  build('mushroom',(put,box,pole)=>{
    for(let i=0;i<5;i++) {
      const a=i*2.4,r=i?.23:0,h=i?.18+i*.028:.4;
      pole('wall',[Math.cos(a)*r,0,Math.sin(a)*r],[Math.cos(a)*r,h,Math.sin(a)*r],.025,.018);
      put('cap',transformed(new T.SphereGeometry(.16,16,8,0,Math.PI*2,0,Math.PI*.53),[Math.cos(a)*r,h,Math.sin(a)*r],[1,.45,1]));
      put('wall',transformed(new T.ConeGeometry(.15,.045,24),[Math.cos(a)*r,h-.013,Math.sin(a)*r],[1,1,1],[Math.PI,0,0]));
    }
  });
  build('arch',(put,box)=>{
    for(const x of [-2.3,2.3]) for(let i=0;i<5;i++)box('masonry',[x,.43+i*.82,0],[1.04,.8,1.22]);
    for(let i=0;i<13;i++){
      const a=i*Math.PI/13,b=(i+1)*Math.PI/13,shape=new T.Shape();
      shape.moveTo(Math.cos(a)*2.82,Math.sin(a)*2.82);shape.absarc(0,0,2.82,a,b,false);shape.lineTo(Math.cos(b)*1.78,Math.sin(b)*1.78);shape.absarc(0,0,1.78,b,a,true);shape.closePath();
      const g=uv(new T.ExtrudeGeometry(shape,{depth:1.2,bevelEnabled:true,bevelSize:.015,bevelThickness:.015,bevelSegments:1,steps:1,curveSegments:4}),.5);
      put('masonry',transformed(g,[0,3.72,-.6]));
    }
  });
  build('cactus',(put,box,pole)=>{
    const body=(a,b,r)=>{const g=limb(a,b,r,r*.96,48),ps=g.attributes.position;for(let i=0;i<ps.count;i++){const x=ps.getX(i),z=ps.getZ(i);const f=1+Math.cos(Math.atan2(z,x)*12)*.07;ps.setXYZ(i,x*f,ps.getY(i),z*f);}g.computeVertexNormals();put('leaf',g);};
    body([0,0,0],[0,3.7,0],.24);put('leaf',transformed(new T.SphereGeometry(.235,24,12),[0,3.7,0]));
    for(const side of [-1,1]){pole('leaf',[0,1.6,0],[side*.72,1.6,0],.14,.14);pole('leaf',[side*.72,1.6,0],[side*.72,2.65,0],.14,.13);put('leaf',transformed(new T.SphereGeometry(.13,18,10),[side*.72,2.65,0]));}
  });
  build('lamp',(put,box,pole)=>{
    pole('metal',[0,0,0],[0,2.35,0],.055,.035);box('masonry',[0,.05,0],[.4,.1,.4]);
    box('metal',[0,2.3,0],[.46,.07,.46]);box('light',[0,2.55,0],[.29,.44,.29]);
    for(const x of [-.19,.19])for(const z of [-.19,.19])box('metal',[x,2.55,z],[.032,.5,.032]);
    put('metal',transformed(new T.ConeGeometry(.37,.25,4),[0,2.89,0],[1,1,1],[0,Math.PI/4,0]));
  });
  build('crate',(put,box)=>{
    for(let i=0;i<6;i++){const a=-.625+i*.25;box('wood',[a,.75,.73],[.238,1.5,.065]);box('wood',[a,.75,-.73],[.238,1.5,.065]);box('wood',[.73,.75,a],[.065,1.5,.238]);box('wood',[-.73,.75,a],[.065,1.5,.238]);box('wood',[a,1.47,0],[.238,.06,1.5]);}
    for(const z of [-.78,.78])for(const y of [.2,1.27])box('wood',[0,y,z],[1.57,.16,.055]);
    for(const x of [-.62,.62])for(const y of [.2,1.27])for(const z of [-.812,.812])put('metal',transformed(new T.SphereGeometry(.023,6,4),[x,y,z],[1,1,.4]));
  });
  const assets={mat,geo,recipes,palette:p};cache.set(biome,assets);return withPack(assets, bindings);
}

export function groupFor(type, assets) {
  const group = new T.Group();
  for (const p of assets.recipes[type]) {
    const mesh = new T.Mesh(assets.geo[p.g], assets.mat[p.m]);
    mesh.position.set(...p.pos); mesh.scale.set(...p.scale); mesh.rotation.set(...p.rot);
    mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh);
  }
  return group;
}
