import { createEnvironment, bindAtmosphere } from '/sdk/environment/index.mjs';
import { bindings } from '/core/models.mjs';
import { SEG, height, rawHeight, pathZ, noise, clamp, hash, META, meta, canWalk, findSpawn } from '/core/world.mjs';
import { kit, groupFor } from './assets.js';
import { prepare, sky, uv, merge } from './surface.js';
import { sample, collider, groundKey } from '/core/spatial.mjs';
const T = window.THREE;

export class Engine {
  constructor(host, events = {}) {
    this.host = host; this.events = events; this.mode = 'select'; this.asset = 'pine'; this.radius = 7;
    this.keys = new Set(); this.selected = null; this.playing = false; this.collected = new Set();
    this.renderer = new T.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: false });
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.outputEncoding = T.sRGBEncoding;
    this.renderer.toneMapping = T.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.physicallyCorrectLights = true;
    this.renderer.shadowMap.autoUpdate = false;
    this.metrics = { terrainBuilds: 0, batchBuilds: 0, matrixUpdates: 0, shadowUpdates: 0, loads: 0 };
    this.cull = true; this.cacheShadows = true; this.freeze = false; this.dirty = true;
    this.ready = prepare(this.renderer);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = T.PCFSoftShadowMap;
    host.prepend(this.renderer.domElement);
    this.canvas = this.renderer.domElement;
    this.canvas.setAttribute('aria-label', 'Interactive 3D world viewport'); this.canvas.tabIndex = 0;
    this.scene = new T.Scene();
    this.camera = new T.PerspectiveCamera(42, 1, 0.1, 1000);
    this.target = new T.Vector3(); this.yaw = 0.78; this.tilt = 0.72; this.dist = 160;
    this.hemi = new T.HemisphereLight('#e6f1ff', '#65714e', 0.65); this.scene.add(this.hemi);
    this.sun = new T.DirectionalLight('#fff2d1', 1.4); this.sun.position.set(-45, 75, 35);
    this.sun.castShadow = true; this.sun.shadow.mapSize.set(4096, 4096);
    Object.assign(this.sun.shadow.camera, { left: -95, right: 95, top: 95, bottom: -95, near: 1, far: 230 });
    this.sun.shadow.bias = -0.00012; this.sun.shadow.normalBias = 0.055;
    this.scene.add(this.sun); this.scene.add(this.sun.target);
    this.frustum = new T.Frustum(); this.viewMat = new T.Matrix4();
    this.ray = new T.Raycaster(); this.pointer = new T.Vector2();
    this.box = new T.Box3Helper(new T.Box3(), '#d1f5a2');
    this.box.material.depthTest = false; this.box.material.transparent = true; this.box.material.opacity = 0.9;
    this.box.renderOrder = 10; this.box.visible = false; this.scene.add(this.box);
    const brushGeo = new T.BufferGeometry();
    brushGeo.setAttribute('position', new T.BufferAttribute(new Float32Array(65 * 3), 3));
    this.brush = new T.Line(brushGeo, new T.LineBasicMaterial({ color: '#e0ffc0', depthTest: false, transparent: true, opacity: 0.9 }));
    this.brush.renderOrder = 9; this.brush.visible = false; this.scene.add(this.brush);
    this.clock = new T.Clock(); this.frames = 0; this.tick = 0; this.elapsed = 0;
    this.resizeObs = new ResizeObserver(() => this.resize()); this.resizeObs.observe(host);
    this.bind(); this.resize(); this.frame = this.frame.bind(this); requestAnimationFrame(this.frame);
  }

  bind() {
    this.canvas.addEventListener('contextmenu', e => e.preventDefault());
    this.canvas.addEventListener('pointerdown', e => {
      if (e.button > 2) return;
      this.canvas.focus({ preventScroll: true });
      this.down = { x: e.clientX, y: e.clientY, px: e.clientX, py: e.clientY, button: e.button, pan: e.button === 2 || e.button === 1 || e.shiftKey, travel: 0 };
      this.canvas.setPointerCapture(e.pointerId);
    });
    this.canvas.addEventListener('pointermove', e => {
      if (this.down) {
        const d = this.down, dx = e.clientX - d.px, dy = e.clientY - d.py;
        d.travel += Math.hypot(dx, dy); d.px = e.clientX; d.py = e.clientY;
        if (d.travel > 3) {
          if (d.pan && !this.playing) {
            const k = this.dist * 0.0012;
            this.target.x += (-dx * Math.cos(this.yaw) + dy * Math.sin(this.yaw)) * k;
            this.target.z += (dx * Math.sin(this.yaw) + dy * Math.cos(this.yaw)) * k;
          } else { this.yaw -= dx * 0.005; this.tilt = clamp(this.tilt + dy * (this.playing ? -.004 : .004), this.playing ? -1.3 : .18, this.playing ? 1.3 : 1.45); }
        }
      }
      this.dirty = true;
      if (!this.playing && this.world) {
        const hit = this.groundHit(e);
        this.hover = hit?.point ?? null;
        if (this.hover) this.events.hover?.(this.hover);
        this.showBrush();
      }
    });
    this.canvas.addEventListener('pointerup', e => {
      const d = this.down; this.down = null;
      if (this.canvas.hasPointerCapture(e.pointerId)) this.canvas.releasePointerCapture(e.pointerId);
      if (!d || d.travel > 5 || d.button !== 0 || this.playing) return;
      this.setRay(e);
      const hits = this.ray.intersectObjects(this.batches ?? [], false);
      const hit = hits[0], id = hit ? hit.object.userData.ids[hit.instanceId] : null;
      const ground = this.ray.intersectObject(this.terrain, false)[0];
      this.events.pick?.({ id, point: ground?.point ?? null });
    });
    this.canvas.addEventListener('pointercancel', () => { this.down = null; });
    this.canvas.addEventListener('pointerleave', () => { this.brush.visible = false; this.dirty = true; });
    this.canvas.addEventListener('wheel', e => { this.dirty = true; e.preventDefault(); if (this.playing) return; this.dist = clamp(this.dist * Math.exp(e.deltaY * 0.001), 1.2, 460); }, { passive: false });
    window.addEventListener('keydown', e => {
      if (e.target.matches('input, textarea, select') || !this.playing) return;
      if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'ShiftLeft', 'ShiftRight'].includes(e.code)) { e.preventDefault(); this.keys.add(e.code); }
    });
    window.addEventListener('keyup', e => this.keys.delete(e.code));
    window.addEventListener('blur', () => { this.keys.clear(); this.down = null; });
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.keys.clear(); this.dirty = true; });
    this.canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); this.events.error?.('Graphics context lost. Save your world and reload the page.'); });
  }

  resize() {
    this.dirty = true;
    const w = this.host.clientWidth, h = this.host.clientHeight;
    this.renderer.setSize(w, h); this.camera.aspect = w / Math.max(1, h); this.camera.updateProjectionMatrix();
  }

  setRay(e) {
    const r = this.canvas.getBoundingClientRect();
    this.pointer.set((e.clientX - r.left) / r.width * 2 - 1, -(e.clientY - r.top) / r.height * 2 + 1);
    this.ray.setFromCamera(this.pointer, this.camera);
  }

  groundHit(e) {
    if (!this.terrain) return null;
    this.setRay(e); return this.ray.intersectObject(this.terrain, false)[0];
  }

  shadowDirty() { this.renderer.shadowMap.needsUpdate = true; this.dirty = true; }

  disposeRoot() {
    if (!this.root) return;
    this.terrain?.geometry.dispose(); this.water?.geometry.dispose(); this.water?.material.dispose();
    if (this.grid) { this.scene.remove(this.grid); this.grid.geometry.dispose(); this.grid.material.dispose(); }
    for (const b of this.batches ?? []) b.dispose?.();
    this.cover?.geometry.dispose(); this.cover?.dispose?.();
    this.scene.remove(this.root);
  }

  load(world, home = false) {
    const started = performance.now();
    if (this.playing) this.stop();
    const key = groundKey(world), old = this.world;
    this.metrics.loads++;
    if (!this.root || key !== this.groundKey) {
      this.disposeRoot(); this.world = world; this.assets = kit(world.biome, bindings(world)); this.field = sample(world); this.groundKey = key;
      this.root = new T.Group(); this.root.name = world.name;
      this.batches = []; this.slots = new Map(); this.chunks = new Map();
      this.root.userData = { seedworkVersion: 1, seed: world.seed, renderVersion: '0.3.0' }; this.scene.add(this.root);
      this.buildTerrain(); this.buildAssets(); this.buildGrid(); this.buildCover(); this.light();
    } else {
      this.world = world; this.root.name = world.name;
      const packChanged = JSON.stringify(bindings(old)) !== JSON.stringify(bindings(world));
      if (packChanged) this.assets = kit(world.biome, bindings(world));
      const prior = new Map(old.objects.map(o => [o.id, o])), dirty = new Set();
      const cell = o => `${Math.floor(o.x / 32)}:${Math.floor(o.z / 32)}`;
      for (const o of world.objects) {
        const prev = prior.get(o.id);
        if (!prev || o.type !== prev.type || cell(o) !== cell(prev)) {
          dirty.add(cell(o)); if (prev) dirty.add(cell(prev));
        } else if (o.x !== prev.x || o.z !== prev.z || o.y !== prev.y || o.rot !== prev.rot || o.scale !== prev.scale) this.updateObject(o);
        prior.delete(o.id);
      }
      for (const o of prior.values()) dirty.add(cell(o));
      if (packChanged) this.buildAssets(new Set([...this.chunks.keys(), ...world.objects.map(o => cell(o))]));
      else if (dirty.size) this.buildAssets(dirty);
      const blocks = w => JSON.stringify(w.objects.filter(o => ['house', 'tower', 'arch', 'rock', 'crate'].includes(o.type)).map(o=>[o.id,o.type,o.x,o.z,o.scale]));
      if (blocks(old) !== blocks(world) || old.terrain.density !== world.terrain.density) this.buildCover();
      if (JSON.stringify(old.sky) !== JSON.stringify(world.sky)) this.light();
    }
    this.collision = collider(world, this.field);
    this.byId = new Map(world.objects.map(o => [o.id, o]));
    this.crystals = world.objects.filter(o => o.type === 'crystal');
    if (home || !this.didHome) { this.home(); this.didHome = true; }
    this.syncWeather();
    this.select(this.selected); this.showBrush(); this.scene.updateMatrixWorld(true); this.shadowDirty();
    this.metrics.lastEditMs = performance.now() - started;
  }

  clearWeather() {
    this.weatherAtmosphere?.(); this.weatherAtmosphere = null;
    this.weatherLinks?.forEach(off => off()); this.weatherLinks = new Map();
    this.weatherKit?.dispose(); this.weatherKit = null; this.weatherKey = null; this.weatherDoc = null;
  }

  syncWeather() {
    const w = this.world, size = w.terrain.size;
    if (!w.environment) { if (this.weatherKit) { this.clearWeather(); this.light(); } return; }
    if (this.weatherKit && this.weatherSize !== size) this.clearWeather();
    const structures = w.objects.filter(o => ['house', 'tower'].includes(o.type) && !w.assets?.[o.type]);
    const ground = (x, z) => Math.max(this.field.get(x, z), w.terrain.water);
    const roof = (x, z) => {
      let top = null;
      for (const o of structures) {
        const a = -o.rot * Math.PI / 180, dx = x - o.x, dz = z - o.z, lx = (Math.cos(a) * dx + Math.sin(a) * dz) / o.scale, lz = (-Math.sin(a) * dx + Math.cos(a) * dz) / o.scale;
        let h = null;
        if (o.type === 'house' && Math.abs(lx) <= 2.9 && Math.abs(lz) <= 2.56) h = 5.11 - Math.abs(lx) * 1.65 / 2.9;
        if (o.type === 'tower' && Math.hypot(lx, lz) <= 1.7) h = 8.15;
        if (h !== null) top = Math.max(top ?? -Infinity, this.field.get(o.x, o.z) + o.y + h * o.scale);
      }
      return top;
    };
    const key = JSON.stringify([this.groundKey, structures]);
    if (!this.weatherKit) {
      this.weatherKit = createEnvironment({ THREE: T, parent: this.scene, camera: this.camera, config: w.environment, field: { bounds: [-size / 2, -size / 2, size, size], range: [-160, 600], size: 192, ground, roof }, radius: 24 });
      this.weatherSize = size; this.weatherLinks = new Map(); this.weatherKey = key; this.weatherDoc = JSON.stringify(w.environment);
    } else {
      if (this.weatherKey !== key) { this.weatherKit.invalidateField({ ground, roof }); this.weatherKey = key; }
      if (this.weatherDoc !== JSON.stringify(w.environment)) { this.weatherKit.set(w.environment); this.weatherDoc = JSON.stringify(w.environment); }
    }
    const nodes = [this.terrain, ...this.batches, this.cover].filter(n => n?.material?.isMeshStandardMaterial && (n.material.onBeforeCompile === T.Material.prototype.onBeforeCompile || this.weatherLinks.has(n)));
    const live = new Set(nodes);
    for (const [node, off] of this.weatherLinks) if (!live.has(node)) { off(); this.weatherLinks.delete(node); }
    for (const node of nodes) if (!this.weatherLinks.has(node)) {
      const foliage = node !== this.cover && /\/ leaf$/.test(node.material.name) ? 1 : 0;
      this.weatherLinks.set(node, this.weatherKit.bind(node, { wet: .8, snow: node === this.cover ? .45 : 1, foliage, ice: node === this.terrain ? .12 : 0 }));
    }
    if (this.weatherLight !== JSON.stringify(w.sky) || !this.weatherAtmosphere) {
      this.weatherAtmosphere?.(); this.light();
      this.weatherAtmosphere = bindAtmosphere(this.weatherKit, { scene: this.scene, sun: this.sun, hemi: this.hemi, background: true });
      this.weatherLight = JSON.stringify(w.sky);
    }
    this.weatherKit.sync();
  }

  buildTerrain() {
    this.metrics.terrainBuilds++;
    const w = this.world, p = this.assets.palette, size = w.terrain.size;
    const geo = new T.BufferGeometry(), pos = [], colors = [], tex = [], indices = [];
    const low = new T.Color(p.low).convertSRGBToLinear(), grass = new T.Color(p.grass).convertSRGBToLinear(), high = new T.Color(p.high).convertSRGBToLinear(), sand = new T.Color(p.sand).convertSRGBToLinear(), stone = new T.Color(p.stone).convertSRGBToLinear(), col = new T.Color();
    for (let iz = 0; iz <= SEG; iz++) for (let ix = 0; ix <= SEG; ix++) {
      const x = ix * this.field.step - size / 2, z = iz * this.field.step - size / 2, h = this.field.data[iz * (SEG + 1) + ix];
      pos.push(x, h, z); tex.push(x * .42, -z * .42);
      const n = noise(x * 0.11, z * 0.11, w.seed + 911);
      col.copy(low).lerp(grass, clamp(n * 1.8, 0, 1));
      if (h > 9) col.lerp(high, Math.min(.6, (h - 9) * .08));
      const slope = Math.abs(this.field.get(x + 0.7, z) - h) + Math.abs(this.field.get(x, z + 0.7) - h);
      col.lerp(stone, clamp((slope - .55) * .7, 0, .85));
      if (h < w.terrain.water + 1.3) col.lerp(sand, 1 - clamp((h - w.terrain.water - .3) / 1, 0, 1));
      const path = Math.abs(z - pathZ(x, size));
      if (path < 2.4 && h > w.terrain.water && Math.abs(x) < size * .37) col.lerp(sand, (1 - path / 2.4) * .9);
      const wet = 1 - clamp((h - w.terrain.water) / .55, 0, 1);
      col.multiplyScalar(1.65 * (1 - wet * .28)); colors.push(Math.min(1,col.r), Math.min(1,col.g), Math.min(1,col.b));
      if (iz < SEG && ix < SEG) { const a = iz * (SEG + 1) + ix, b = a + 1, c = a + SEG + 1, d = c + 1; indices.push(a, c, b, b, c, d); }
    }
    geo.setAttribute('position', new T.Float32BufferAttribute(pos, 3)); geo.setAttribute('color', new T.Float32BufferAttribute(colors, 3)); geo.setAttribute('uv', new T.Float32BufferAttribute(tex, 2)); geo.setAttribute('uv2', geo.attributes.uv.clone()); geo.setIndex(indices); geo.computeVertexNormals();
    this.terrain = new T.Mesh(geo, this.assets.mat.ground); this.terrain.name = 'Terrain'; this.terrain.receiveShadow = true; this.terrain.castShadow = true; this.root.add(this.terrain);
    const waterGeo = new T.PlaneGeometry(size * 5, size * 5, 160, 160); waterGeo.rotateX(-Math.PI / 2);
    const waterMat = new T.MeshPhysicalMaterial({ color: '#607b78', roughness: .16, metalness: 0, clearcoat: 1, clearcoatRoughness: .12, ior: 1.333 });
    waterMat.name = 'Water / dielectric / analytic wave normals'; waterMat.color.convertSRGBToLinear(); this.waterShader = null;
    waterMat.onBeforeCompile = shader => {
      shader.uniforms.swTime = { value: this.elapsed }; this.waterShader = shader;
      shader.vertexShader = `uniform float swTime;\n${shader.vertexShader}`
        .replace('#include <begin_vertex>', '#include <begin_vertex>\ntransformed.y += sin(position.x * .47 + position.z * .31 + swTime * .8) * .055 + sin(position.x * -.83 + position.z * .59 + swTime * 1.2) * .018;')
        .replace('#include <beginnormal_vertex>', '#include <beginnormal_vertex>\nfloat waveA = cos(position.x * .47 + position.z * .31 + swTime * .8) * .055; float waveB = cos(position.x * -.83 + position.z * .59 + swTime * 1.2) * .018; objectNormal = normalize(vec3(-waveA*.47 + waveB*.83, 1.0, -waveA*.31 - waveB*.59));');
    };
    waterMat.customProgramCacheKey = () => 'seedwork-water-v2';
    this.water = new T.Mesh(waterGeo, waterMat); this.water.position.y = w.terrain.water; this.water.name = 'Water'; this.water.receiveShadow = true; this.root.add(this.water);
  }

  buildAssets(only = null) {
    this.metrics.batchBuilds++;
    const groups = new Map(), dummy = new T.Object3D();
    if (only) {
      for (const key of only) for (const b of this.chunks.get(key) ?? []) { this.root.remove(b); b.dispose?.(); }
      for (const key of only) this.chunks.delete(key);
    }
    for (const o of this.world.objects) {
      const cell = `${Math.floor(o.x / 32)}:${Math.floor(o.z / 32)}`;
      if (only && !only.has(cell)) continue;
      for (const p of this.assets.recipes[o.type]) {
        const key = `${cell}:${p.g}:${p.m}`;
        if (!groups.has(key)) groups.set(key, { cell, p, items: [] });
        groups.get(key).items.push(o);
      }
    }
    for (const [key, b] of groups) {
      const mesh = new T.InstancedMesh(this.assets.geo[b.p.g], this.assets.mat[b.p.m], b.items.length);
      mesh.name = key; mesh.userData.ids = [];
      for (let i = 0; i < b.items.length; i++) {
        const o = b.items[i];
        dummy.position.set(o.x, this.field.get(o.x, o.z) + o.y, o.z); dummy.rotation.set(0, T.MathUtils.degToRad(o.rot), 0); dummy.scale.setScalar(o.scale); dummy.updateMatrix(); mesh.setMatrixAt(i, dummy.matrix);
        const tint = this.world.models?.[o.type] ? 1 : .87 + (hash(o.id) % 100) * .0015;
        mesh.setColorAt(i, new T.Color(tint, tint, tint)); mesh.userData.ids.push(o.id);
      }
      mesh.instanceMatrix.setUsage(T.DynamicDrawUsage); mesh.instanceMatrix.needsUpdate = true; mesh.instanceColor.needsUpdate = true;
      mesh.castShadow = true; mesh.receiveShadow = true; mesh.frustumCulled = false;
      this.root.add(mesh);
      if (!this.chunks.has(b.cell)) this.chunks.set(b.cell, []);
      this.chunks.get(b.cell).push(mesh);
    }
    this.batches = [...this.chunks.values()].flat(); this.slots = new Map();
    for (const mesh of this.batches) {
      mesh.userData.ids.forEach((id, index) => { if (!this.slots.has(id)) this.slots.set(id, []); this.slots.get(id).push({ mesh, index }); });
      this.bounds(mesh);
    }
  }

  bounds(mesh) {
    const box = new T.Box3(), local = mesh.geometry.boundingBox ?? (mesh.geometry.computeBoundingBox(), mesh.geometry.boundingBox), mat = new T.Matrix4(), tmp = new T.Box3();
    for (let i = 0; i < mesh.count; i++) { mesh.getMatrixAt(i, mat); box.union(tmp.copy(local).applyMatrix4(mat)); }
    mesh.userData.bounds = box; mesh.userData.sphere = box.getBoundingSphere(new T.Sphere());
  }

  updateObject(o) {
    const dummy = new T.Object3D();
    dummy.position.set(o.x, this.field.get(o.x, o.z) + o.y, o.z); dummy.rotation.y = T.MathUtils.degToRad(o.rot); dummy.scale.setScalar(o.scale); dummy.updateMatrix();
    for (const { mesh, index } of this.slots.get(o.id) ?? []) { mesh.setMatrixAt(index, dummy.matrix); mesh.instanceMatrix.needsUpdate = true; this.bounds(mesh); this.metrics.matrixUpdates++; }
  }

  buildCover() {
    if (this.cover) { this.root.remove(this.cover); this.cover.geometry.dispose(); this.cover.dispose?.(); }
    const w = this.world;
    if (w.biome === 'desert' || w.biome === 'snow') { this.cover = null; return; }
    const geos = [];
    for (let j = 0; j < 7; j++) {
      const a = j * 2.4, r = .11 * Math.sqrt(j), x = Math.cos(a)*r, z = Math.sin(a)*r, h = .20 + (j % 3)*.08, dx = Math.cos(a)*.032, dz = Math.sin(a)*.032;
      const g = new T.BufferGeometry();
      g.setAttribute('position', new T.Float32BufferAttribute([x-dx,0,z-dz,x+dx,0,z+dz,x+.05+dx,h*.55,z+dz,x-dx,0,z-dz,x+.05+dx,h*.55,z+dz,x+.05-dx,h*.55,z-dz,x+.05-dx,h*.55,z-dz,x+.05+dx,h*.55,z+dz,x+.11,h,z],3));
      g.setAttribute('uv',new T.Float32BufferAttribute([0,0,1,0,1,.5,0,0,1,.5,0,.5,0,.5,1,.5,.5,1],2));
      const colors = new Float32Array(27); for(let k=0;k<9;k++){const v=g.attributes.position.getY(k)/h;colors.set([.42+v*.5,.46+v*.48,.38+v*.36],k*3);}g.setAttribute('color',new T.BufferAttribute(colors,3));g.computeVertexNormals();geos.push(g);
    }
    const g = merge(geos), points = [], blocked = w.objects.filter(o => ['house','tower','arch','rock','crate'].includes(o.type));
    const count = Math.round(10000 * (0.35 + w.terrain.density));
    for(let i=0;i<count;i++) {
      const x=((hash(`${w.seed}:gx:${i}`)%100000)/100000-.5)*w.terrain.size*.92,z=((hash(`${w.seed}:gz:${i}`)%100000)/100000-.5)*w.terrain.size*.92;
      if(this.field.get(x,z)<w.terrain.water+.7||Math.abs(z-pathZ(x,w.terrain.size))<2.0||noise(x*.12,z*.12,w.seed)<.34)continue;
      if(blocked.some(o=>Math.hypot(o.x-x,o.z-z)<Math.max(1,meta(this.world, o.type).radius)*o.scale+.2))continue;
      points.push([x,z]);
    }
    const mesh = new T.InstancedMesh(g,this.assets.mat.grass,points.length),d=new T.Object3D();
    points.forEach(([x,z],i)=>{d.position.set(x,this.field.get(x,z),z);d.rotation.y=i*2.399;d.scale.setScalar(.72+(i%13)*.054);d.updateMatrix();mesh.setMatrixAt(i,d.matrix);});
    mesh.instanceMatrix.needsUpdate=true;mesh.name='Derived ground cover';mesh.userData.ids=points.map((_,i)=>`cover_${i}`);mesh.castShadow=false;mesh.receiveShadow=true;mesh.frustumCulled=false;
    this.cover=mesh;this.root.add(mesh);
  }

  buildGrid() {
    const pts = [], w = this.world, s = w.terrain.size, step = s / 16;
    for (let a = -s / 2; a <= s / 2 + 0.001; a += step) for (let b = -s / 2; b < s / 2; b += step / 4) {
      pts.push(a, this.field.get(a, b) + 0.09, b, a, this.field.get(a, b + step / 4) + 0.09, b + step / 4);
      pts.push(b, this.field.get(b, a) + 0.09, a, b + step / 4, this.field.get(b + step / 4, a) + 0.09, a);
    }
    const geo = new T.BufferGeometry(); geo.setAttribute('position', new T.Float32BufferAttribute(pts, 3));
    this.grid = new T.LineSegments(geo, new T.LineBasicMaterial({ color: '#d9e4ca', transparent: true, opacity: 0.22 }));
    this.grid.visible = Boolean(this.showGrid); this.scene.add(this.grid);
  }

  light() {
    if (this.weatherAtmosphere) { this.weatherAtmosphere(); this.weatherAtmosphere = null; this.weatherLight = null; }
    const time = this.world.sky.time;
    if (this.skyTime !== time) {
      this.env?.dispose(); this.skyTex?.dispose();
      const env = sky(time); this.skyTex = env.tex;
      const pmrem = new T.PMREMGenerator(this.renderer); this.env = pmrem.fromEquirectangular(env.tex); pmrem.dispose();
      this.scene.environment = this.env.texture; this.scene.background = this.skyTex;
      this.sun.position.copy(env.sun).multiplyScalar(130); this.skyTime = time;
    }
    const fog = new T.Color(time === 'night' ? '#252e38' : time === 'sunset' ? '#b9b2a7' : '#b0c3c9').convertSRGBToLinear();
    this.scene.fog = new T.FogExp2(fog, .001 + this.world.sky.fog * .003);
    this.sun.color.set(time === 'night' ? '#aec5dd' : time === 'sunset' ? '#ffe0b7' : '#fff5e6').convertSRGBToLinear();
    this.sun.intensity = time === 'night' ? .35 : time === 'sunset' ? 3.0 : 3.3;
    this.hemi.intensity = time === 'night' ? .08 : .26;
    const extent = this.world.terrain.size * .75;
    Object.assign(this.sun.shadow.camera, { left: -extent, right: extent, top: extent, bottom: -extent, near: 1, far: 340 });
    this.sun.shadow.camera.updateProjectionMatrix();
    this.assets.mat.light.emissiveIntensity = time === 'night' ? 2.5 : time === 'sunset' ? .9 : .05;
    this.shadowDirty();
  }

  home() {
    if (this.playing) return;
    this.target.set(0, 4, 0); this.yaw = 0.88; this.tilt = 0.48; this.dist = this.world.terrain.size * 1.13; this.dirty = true;
  }

  focus(id) {
    const o = this.world.objects.find(o => o.id === id);
    if (!o || this.playing) return;
    this.target.set(o.x, this.field.get(o.x, o.z) + o.y + meta(this.world, o.type).height * o.scale * 0.4, o.z);
    this.dist = Math.max(3, meta(this.world, o.type).height * o.scale * 2.8); this.dirty = true;
  }

  select(id) {
    this.dirty = true; this.selected = id;
    const o = this.world.objects.find(o => o.id === id);
    this.box.visible = Boolean(o) && !this.playing;
    if (!o) return;
    const m = meta(this.world, o.type), r = m.width * o.scale * 0.65, y = this.field.get(o.x, o.z) + o.y;
    this.box.box.set(new T.Vector3(o.x - r, y, o.z - r), new T.Vector3(o.x + r, y + m.height * o.scale, o.z + r));
  }

  showBrush() {
    this.dirty = true; this.brush.visible = Boolean(this.hover && ['sculpt', 'place', 'move', 'spawn'].includes(this.mode) && !this.playing);
    if (!this.brush.visible) return;
    const p = this.brush.geometry.attributes.position, r = this.mode === 'sculpt' ? this.radius : this.mode === 'place' ? Math.max(1, meta(this.world, this.asset).radius) : 1;
    for (let i = 0; i <= 64; i++) {
      const a = i / 64 * Math.PI * 2, x = this.hover.x + Math.cos(a) * r, z = this.hover.z + Math.sin(a) * r;
      p.setXYZ(i, x, Math.max(this.field.get(x, z), this.world.terrain.water) + 0.1, z);
    }
    p.needsUpdate = true; this.brush.geometry.computeBoundingSphere();
  }

  start() {
    const spawn = findSpawn(this.world);
    this.editCam = { target: this.target.clone(), yaw: this.yaw, tilt: this.tilt, dist: this.dist };
    this.collected.clear(); this.hidden = []; this.keys.clear(); this.playing = true; this.playTime = 0; this.jump = 0; this.vel = 0;
    this.player = { x: spawn.x, z: spawn.z, y: this.field.get(spawn.x, spawn.z) };
    this.avatar = new T.Group();
    this.scene.add(this.avatar);
    this.dist = 0; this.tilt = 0; this.box.visible = false; this.brush.visible = false; this.grid.visible = false;
    this.target.set(spawn.x, this.player.y + 1.2, spawn.z);
    this.goal = this.crystals.length; this.shadowDirty();
    this.canvas.focus({ preventScroll: true }); this.events.play?.({ playing: true, count: 0, total: this.goal, time: 0 });
  }

  stop() {
    if (!this.playing) return;
    this.playing = false; this.keys.clear();
    this.avatar.traverse(o => { o.geometry?.dispose(); o.material?.dispose(); }); this.scene.remove(this.avatar);
    Object.assign(this, { yaw: this.editCam.yaw, tilt: this.editCam.tilt, dist: this.editCam.dist }); this.target.copy(this.editCam.target);
    this.collected.clear();
    for (const item of this.hidden) { item.mesh.setMatrixAt(item.index, item.matrix); item.mesh.instanceMatrix.needsUpdate = true; }
    this.hidden = [];
    this.grid.visible = Boolean(this.showGrid); this.select(this.selected); this.shadowDirty(); this.events.play?.({ playing: false });
  }

  updatePlay(dt) {
    const k = this.keys, p = this.player;
    const f = (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) - (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0);
    const r = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0);
    const norm = Math.hypot(f, r) || 1, speed = k.has('ShiftLeft') || k.has('ShiftRight') ? 10 : 6;
    const dx = (-Math.sin(this.yaw) * f + Math.cos(this.yaw) * r) / norm * speed * dt;
    const dz = (-Math.cos(this.yaw) * f - Math.sin(this.yaw) * r) / norm * speed * dt;
    const tryMove = (x, z) => this.collision.walk(x, z) && Math.abs(this.field.get(x, z) - this.field.get(p.x, p.z)) < 0.65;
    if (tryMove(p.x + dx, p.z)) p.x += dx;
    if (tryMove(p.x, p.z + dz)) p.z += dz;
    if (k.has('Space') && this.jump <= 0) { this.vel = 6; this.keys.delete('Space'); }
    this.vel -= 18 * dt; this.jump = Math.max(0, this.jump + this.vel * dt); if (!this.jump) this.vel = 0;
    p.y = this.field.get(p.x, p.z) + this.jump;
    this.avatar.position.set(p.x, p.y, p.z);
    if (f || r) this.avatar.rotation.y = Math.atan2(-dx, -dz);
    this.target.lerp(new T.Vector3(p.x, p.y + 1, p.z), 1 - Math.exp(-dt * 9));
    this.playTime += dt;
    for (const o of this.crystals) if (o.type === 'crystal' && !this.collected.has(o.id) && Math.hypot(p.x - o.x, p.z - o.z) < o.scale * 1.3 + 0.7 && Math.abs(p.y - (this.field.get(o.x, o.z) + o.y)) < 3) {
      this.collected.add(o.id); const hide = new T.Matrix4().makeScale(0, 0, 0);
      for (const {mesh: b, index: i} of this.slots.get(o.id) ?? []) { const matrix = new T.Matrix4(); b.getMatrixAt(i, matrix); this.hidden.push({mesh:b,index:i,matrix}); b.setMatrixAt(i,hide); b.instanceMatrix.needsUpdate=true; } this.shadowDirty();
      this.events.collect?.(this.collected.size, this.goal);
    }
  }

  render() {
    this.camera.position.set(this.target.x + Math.sin(this.yaw) * Math.cos(this.tilt) * this.dist, this.target.y + Math.sin(this.tilt) * this.dist, this.target.z + Math.cos(this.yaw) * Math.cos(this.tilt) * this.dist);
    if (this.playing) {
      const p=this.player;this.camera.position.set(p.x,p.y+1.65,p.z);this.camera.lookAt(p.x-Math.sin(this.yaw)*Math.cos(this.tilt),p.y+1.65+Math.sin(this.tilt),p.z-Math.cos(this.yaw)*Math.cos(this.tilt));
    } else this.camera.lookAt(this.target);
    this.camera.updateMatrixWorld(true);
    if (!this.cacheShadows) this.renderer.shadowMap.needsUpdate = true;
    const shadow = this.renderer.shadowMap.needsUpdate;
    this.scene.updateMatrixWorld(true);
    const frustum = this.frustum.setFromProjectionMatrix(this.viewMat.multiplyMatrices(this.camera.projectionMatrix, this.camera.matrixWorldInverse));
    for (const b of this.batches) b.visible = shadow || !this.cull || frustum.intersectsSphere(b.userData.sphere);
    if (this.waterShader) this.waterShader.uniforms.swTime.value = this.elapsed;
    this.weatherKit?.sync();
    this.renderer.render(this.scene, this.camera);
    if (shadow) this.metrics.shadowUpdates++;
    this.dirty = false;
  }

  frame() {
    requestAnimationFrame(this.frame);
    const raw = this.clock.getDelta(), dt = Math.min(raw, .04);
    if (this.workshop?.open) { this.workshop.tick(); return; }
    if (!this.world || document.hidden) return;
    if (!this.freeze) { this.elapsed += dt; this.weatherKit?.update(dt); }
    if (this.playing) this.updatePlay(dt);
    const moving = [this.target.x,this.target.y,this.target.z,this.yaw,this.tilt,this.dist,this.grid.visible,this.box.visible].join();
    if (!this.freeze || this.dirty || this.playing || moving !== this.lastView) { this.render(); this.frames++; this.lastView = moving; }
    this.tick += raw;
    if (this.tick >= .7) {
      this.events.stats?.({ fps: Math.round(this.frames / this.tick), calls: this.renderer.info.render.calls, tris: this.renderer.info.render.triangles, playing: this.playing, time: this.playTime ?? 0 });
      this.frames = 0; this.tick = 0;
    }
  }

  screenshot() { this.render(); return this.canvas.toDataURL('image/png'); }

  audit() {
    const gl = this.renderer.getContext();
    return { version: '0.3.0', runtime: `Three.js r${T.REVISION}`, metrics: {...this.metrics}, draws: this.renderer.info.render.calls, triangles: this.renderer.info.render.triangles, geometries: this.renderer.info.memory.geometries, textures: this.renderer.info.memory.textures, chunks: this.chunks.size, batches: this.batches.length, culled: this.batches.filter(b=>!b.visible).length, objects: this.world.objects.length, groundCover: this.cover?.count ?? 0, pixelRatio: this.renderer.getPixelRatio(), nativePixelRatio: window.devicePixelRatio, shadowSize: this.sun.shadow.mapSize.x, maxTextureSize: gl.getParameter(gl.MAX_TEXTURE_SIZE), culling: this.cull, cachedShadows: this.cacheShadows, animationPaused: this.freeze, terrainResolution: SEG, note: 'Draw and triangle counters describe the last render, not GPU time or total scene complexity.' };
  }

  thumbnails() {
    const renderer=this.renderer,size=renderer.getSize(new T.Vector2()),ratio=renderer.getPixelRatio(),clear=renderer.getClearColor(new T.Color()),alpha=renderer.getClearAlpha(),shadows=renderer.shadowMap.enabled,needs=renderer.shadowMap.needsUpdate;
    const scene=new T.Scene();scene.background=new T.Color('#151e20').convertSRGBToLinear();scene.environment=this.env.texture;
    scene.add(new T.HemisphereLight('#ffffff','#7e8272',.8));
    const sun=new T.DirectionalLight('#fff0d5',2.3);sun.position.set(-8,12,9);scene.add(sun);
    const camera=new T.PerspectiveCamera(32,150/118,.1,100),images={};
    try {
      renderer.setPixelRatio(1);renderer.setSize(150,118,false);renderer.shadowMap.enabled=false;
      for(const type of Object.keys(this.assets.recipes)) {
        const group=groupFor(type,this.assets);scene.add(group);
        const h=meta(this.world, type).height,d=Math.max(h,meta(this.world, type).width)*2.2;
        camera.position.set(d*.75,h*.55+d*.42,d);camera.lookAt(0,h*.45,0);
        renderer.render(scene,camera);images[type]=renderer.domElement.toDataURL('image/png');scene.remove(group);
      }
    } finally {
      renderer.setPixelRatio(ratio);renderer.setSize(size.x,size.y,false);renderer.setClearColor(clear,alpha);renderer.shadowMap.enabled=shadows;renderer.shadowMap.needsUpdate=needs;this.dirty=true;this.render();
    }
    return images;
  }
}
