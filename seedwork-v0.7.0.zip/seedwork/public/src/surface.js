import { rand, noise } from '/core/world.mjs';
const T = window.THREE;
const maps = new Map();
let ready;

export function prepare(renderer) {
  if (ready) return ready;
  const names = ['ground', 'rock', 'bark', 'wood', 'masonry', 'slate', 'plaster', 'snow', 'sand', 'leaf'];
  const loader = new T.TextureLoader();
  const anisotropy = Math.min(16, renderer.capabilities.getMaxAnisotropy());
  ready = Promise.all(names.flatMap(name => ['color', 'normal', 'orm'].map(async role => {
    const tex = await loader.loadAsync(`/assets/materials/${name}-${role}.png`);
    tex.name = `${name}-${role}`; tex.encoding = role === 'color' ? T.sRGBEncoding : T.LinearEncoding;
    tex.wrapS = tex.wrapT = T.RepeatWrapping; tex.anisotropy = anisotropy;
    maps.set(`${name}-${role}`, tex);
  })).concat([(async () => {
    const tex = await loader.loadAsync('/assets/materials/needles-color.png');
    tex.name = 'needle-cutout'; tex.encoding = T.sRGBEncoding; tex.anisotropy = anisotropy;
    maps.set('needles', tex);
  })()]));
  return ready;
}

export function material(name, opts = {}) {
  const m = new T.MeshStandardMaterial({ map: maps.get(`${name}-color`), normalMap: maps.get(`${name}-normal`), roughnessMap: maps.get(`${name}-orm`), aoMap: maps.get(`${name}-orm`), roughness: 1, metalness: 0, ...opts });
  m.name = `Seedwork / ${name}`;
  m.color.convertSRGBToLinear();
  return m;
}

export function needles() {
  const m = new T.MeshStandardMaterial({ map: maps.get('needles'), color: '#e2e4d4', roughness: 0.9, side: T.DoubleSide, alphaTest: 0.45, alphaToCoverage: true });
  m.name = 'Seedwork / pine needles'; m.color.convertSRGBToLinear();
  return m;
}

export function uv(geo, scale = 1) {
  if (geo.attributes.uv) {
    const a = geo.attributes.uv;
    for (let i = 0; i < a.count; i++) a.setXY(i, a.getX(i) * scale, a.getY(i) * scale);
    geo.setAttribute('uv2', a.clone());
  }
  return geo;
}

export function merge(list) {
  const sizes = { position: 3, normal: 3, uv: 2, uv2: 2 };
  if (list.some(g => g.attributes.color)) sizes.color = Math.max(...list.map(g => g.attributes.color?.itemSize ?? 3));
  if (list.every(g => g.attributes.tangent)) sizes.tangent = 4;
  const vertices = list.reduce((n, g) => n + g.attributes.position.count, 0);
  const count = list.reduce((n, g) => n + (g.index?.count ?? g.attributes.position.count), 0);
  const data = Object.fromEntries(Object.entries(sizes).map(([k, size]) => [k, new Float32Array(vertices * size)]));
  const indices = vertices > 65535 ? new Uint32Array(count) : new Uint16Array(count);
  let base = 0, at = 0;
  for (const geo of list) {
    const n = geo.attributes.position.count;
    for (const [key, size] of Object.entries(sizes)) {
      const a = geo.attributes[key] ?? (key === 'uv2' ? geo.attributes.uv : null);
      for (let i = 0; i < n; i++) for (let k = 0; k < size; k++) data[key][(base + i) * size + k] = a && k < a.itemSize ? a.array[i * a.itemSize + k] : key === 'color' ? 1 : 0;
    }
    for (let i = 0; i < (geo.index?.count ?? n); i++) indices[at++] = base + (geo.index ? geo.index.getX(i) : i);
    base += n; geo.dispose();
  }
  const out = new T.BufferGeometry();
  for (const [key, size] of Object.entries(sizes)) out.setAttribute(key, new T.BufferAttribute(data[key], size));
  out.setIndex(new T.BufferAttribute(indices, 1)); out.computeBoundingBox(); out.computeBoundingSphere();
  return out;
}

export function sky(time) {
  const width = 512, height = 256, data = new Float32Array(width * height * 4);
  const top = new T.Color(time === 'night' ? '#101b30' : time === 'sunset' ? '#7396bf' : '#4d8ccb').convertSRGBToLinear();
  const horizon = new T.Color(time === 'night' ? '#344250' : time === 'sunset' ? '#eec7a0' : '#d0dce0').convertSRGBToLinear();
  const ground = new T.Color('#4f5545').convertSRGBToLinear();
  const sun = new T.Vector3(time === 'sunset' ? -0.91 : -0.43, time === 'sunset' ? 0.27 : 0.81, 0.4).normalize();
  const light = time === 'night' ? 0.09 : 1.1;
  const c = new T.Color(), dir = new T.Vector3();
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const theta = (1 - y / (height - 1)) * Math.PI, phi = x / width * Math.PI * 2;
    dir.set(-Math.cos(phi) * Math.sin(theta), Math.cos(theta), Math.sin(phi) * Math.sin(theta));
    const elev = Math.max(0, dir.y);
    c.copy(horizon).lerp(top, Math.pow(elev, 0.52));
    if (dir.y < 0) c.lerp(ground, Math.min(1, -dir.y * 8));
    const cloud = Math.max(0, noise(dir.x * 4 + 10, dir.z * 4 + 10, 82) + noise(dir.x * 13, dir.z * 13, 52) * 0.22 - 0.63) * 1.3 * Math.min(1, elev * 6);
    c.lerp(horizon, cloud * 0.8).multiplyScalar(light);
    const dot = Math.max(0, dir.dot(sun));
    const disc = time === 'night' ? 0 : Math.pow(dot, 7500) * 16 + Math.pow(dot, 60) * 0.18;
    const i = (y * width + x) * 4;
    data[i] = c.r + disc; data[i + 1] = c.g + disc * 0.93; data[i + 2] = c.b + disc * 0.77; data[i + 3] = 1;
  }
  const tex = new T.DataTexture(data, width, height, T.RGBAFormat, T.FloatType);
  tex.mapping = T.EquirectangularReflectionMapping; tex.encoding = T.LinearEncoding; tex.needsUpdate = true;
  return { tex, sun };
}
