import { createGame } from './game.mjs';
import { attach } from './integration.mjs';

const $ = id => document.getElementById(id);
const game = createGame({ THREE, canvas: $('game'), onHud: () => { $('gate').textContent = game.state.gate ? 'Close gate' : 'Open gate'; $('walk').classList.toggle('active', game.state.walk); $('orbit').classList.toggle('active', !game.state.walk); $('hint').textContent = game.state.walk ? 'WASD move · drag to look · E gate · Esc overview' : 'Drag to orbit · scroll to zoom'; } });
let token, kit = null, project = null, change = null, selected = null, busy = false;
const log = (title, data) => { $('log').textContent = `${title}\n${typeof data === 'string' ? data : JSON.stringify(data, null, 2)}`; };
const api = async (path, data, method = data === undefined ? 'GET' : 'POST') => {
  if (!token) token = (await (await fetch('/api/session')).json()).token;
  const res = await fetch(path, { method, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, ...(data === undefined ? {} : { body: JSON.stringify(data) }) });
  const out = await res.json(); if (!res.ok) throw Object.assign(new Error(out.error ?? `HTTP ${res.status}`), { code: out.code, details: out.details }); return out;
};
const call = async (name, args = {}) => (await api('/api/tool', { name, args })).result;
const controls = () => {
  const connected = Boolean(kit);
  for (const id of ['stage', 'begin', 'undo', 'redo', 'profile']) $(id).disabled = busy || !connected;
  for (const id of ['preview', 'check', 'discard', 'apply', 'test', 'capture']) $(id).disabled = busy || !connected || !change || change.state !== 'open';
  $('attach').disabled = busy || connected; $('detach').disabled = busy || !connected;
  $('approve').disabled = busy || !connected || !change || !$('ack').checked;
  $('commit').disabled = busy || !connected || !change?.approval;
  $('transform').disabled = busy || !connected || !selected;
};
const showChange = () => {
  $('ack').checked = false;
  const box = $('checks'); box.replaceChildren();
  if (!change) box.textContent = 'No draft selected.';
  else {
    const status = document.createElement('div'); status.textContent = `${change.label} · sequence ${change.seq} · ${change.diff.count} affected`; box.append(status);
    for (const e of change.evidence) { const div = document.createElement('div'); div.textContent = e.type === 'test' ? `${e.passed ? 'PASS' : 'FAIL'}  ${e.test}` : 'CAPTURE  native PNG retained'; if (e.type === 'test' && !e.passed) div.className = 'fail'; box.append(div); }
    if (change.approval) { const div = document.createElement('div'); div.textContent = 'APPROVED  exact draft'; box.append(div); }
  }
  controls();
};
const refresh = async () => {
  project = await api('/api/project');
  $('project-meta').textContent = `${project.manifest.id} · revision ${project.rev} · ${project.doc.items.length} published items`;
  const select = $('changes'); select.replaceChildren(new Option('Choose an open change', ''));
  for (const c of project.changes) select.add(new Option(`${c.label} · ${c.seq}${c.stale ? ' · stale' : ''}`, c.id));
  if (change) { change = await call('change_read', { id: change.id }); if (change.state === 'open') select.value = change.id; else change = null; }
  showChange(); return project;
};
const syncItems = () => {
  const doc = kit?.runtime.snapshot().doc;
  const select = $('items'), old = select.value; select.replaceChildren();
  for (const item of doc?.items ?? []) select.add(new Option(item.name, item.id));
  select.value = old; if (!select.value && doc?.items.length) select.value = doc.items[0].id;
  setSelected();
  const meta = kit?.runtime.meta;
  $('loaded').textContent = meta ? `${meta.change ? 'DRAFT' : 'COMMITTED'} · rev ${meta.rev}${meta.seq !== null ? ` / seq ${meta.seq}` : ''} · ${meta.hash.slice(0, 8)}` : 'No authored content loaded';
  const stats = kit?.runtime.inspect();
  $('metrics').textContent = stats ? `${stats.objects} objects · ${stats.cachedAssets} shared assets · ${stats.assetLoads} loads` : 'One host renderer · one host render loop';
};
const setSelected = () => {
  selected = kit?.runtime.snapshot().doc.items.find(v => v.id === $('items').value) ?? null;
  if (selected) { ['x', 'y', 'z'].forEach((id, i) => { $(id).value = selected.pos[i]; }); $('yaw').value = selected.rot[1]; $('scale').value = selected.scale; }
  controls();
};
const act = (id, fn) => $(id).addEventListener('click', async () => { busy = true; controls(); try { await fn(); } catch (e) { log(`${e.code ?? 'ERROR'} · ${e.message}`, e.details ?? 'No unapproved edit was committed.'); } finally { busy = false; controls(); } });
const begin = async (label = 'Project edit', history) => { await refresh(); change = await call('change_begin', { rev: project.rev, key: crypto.randomUUID(), label, ...(history ? { history } : {}) }); await refresh(); return change; };
const apply = async ops => { if (!change) await begin(); change = await call('change_apply', { id: change.id, seq: change.seq, key: crypto.randomUUID(), ops }); showChange(); log('Draft updated. Preview and rerun evidence before publication.', change.diff); };
const demoOps = () => [
  ...['arch', 'bench', 'pier', 'crate', 'pallet', 'drum'].map(key => ({ op: 'asset_use', key, ref: `starter.${key}` })),
  { op: 'item_add', id: 'entry', asset: 'arch', name: 'Limestone entrance', pos: [0, .035, 4], scale: 1.3, tags: ['entrance'] },
  { op: 'bind_set', id: 'entry', slot: 'interaction', target: 'gate' },
  { op: 'bind_set', id: 'entry', slot: 'clearance', target: 'route' },
  { op: 'item_add', id: 'bench_w', asset: 'bench', name: 'West oak bench', pos: [-4, .035, .2], rot: [0, 90, 0] },
  { op: 'item_add', id: 'bench_e', asset: 'bench', name: 'East oak bench', pos: [4, .035, .2], rot: [0, -90, 0] },
  { op: 'items_path', asset: 'pier', prefix: 'west', path: [[-6.5, .035, -7], [-6.5, .035, 7]], count: 5, orient: false },
  { op: 'items_path', asset: 'pier', prefix: 'east', path: [[6.5, .035, -7], [6.5, .035, 7]], count: 5, orient: false },
  { op: 'item_add', id: 'pallet', asset: 'pallet', name: 'Loading pallet', pos: [-4, .035, 6.5] },
  { op: 'item_add', id: 'crate', asset: 'crate', name: 'Socket-stacked crate', pos: [0, 0, 0] },
  { op: 'item_snap', id: 'crate', socket: 'origin', to: 'pallet', targetSocket: 'top' },
  { op: 'item_add', id: 'drum', asset: 'drum', name: 'Utility drum', pos: [4.5, .035, 6.5] }
];
act('attach', async () => {
  await refresh();
  kit = await attach(game, { THREE, token, project: project.manifest.id, onStatus: ({ state, detail }) => { $('link-state').textContent = `Toolkit ${state}${detail ? ` · ${detail}` : ''}`; } });
  kit.runtime.subscribe(syncItems);
  await refresh(); log('Attached to the existing game.', 'Seedwork owns one content group. The host retains its renderer, camera, inputs, gate and render loop.');
});
act('detach', async () => { await kit.dispose(); kit = null; selected = null; syncItems(); log('Toolkit detached. Existing game continues.', game.inspect()); });
act('stage', async () => { if (project.doc.items.length) throw new Error('This example is already populated. Use New change or Propose undo instead.'); await begin('Stone courtyard'); await apply(demoOps()); await refresh(); });
act('begin', () => begin());
act('undo', async () => { await begin('Undo previous project revision', 'undo'); log('Undo proposed, not committed.', change.diff); });
act('redo', async () => { await begin('Redo previous project revision', 'redo'); log('Redo proposed, not committed.', change.diff); });
act('preview', async () => { const result = await call('change_preview', { id: change.id, seq: change.seq, host: kit.link.id }); await refresh(); syncItems(); log('Exact draft loaded in the host game.', { meta: result.meta, runtime: result.runtime }); });
act('check', async () => log('Static validation', await call('change_check', { id: change.id })));
act('discard', async () => { await call('change_discard', { id: change.id, seq: change.seq, key: crypto.randomUUID() }); change = null; await refresh(); log('Draft discarded.', 'Any host displaying it will return to the committed scene.'); });
act('apply', async () => { await apply(JSON.parse($('ops').value)); await refresh(); });
act('transform', async () => { const item = selected; if (!item) return; const pos = ['x', 'y', 'z'].map(id => Number($(id).value)), rot = [item.rot[0], Number($('yaw').value), item.rot[2]], scale = Number($('scale').value); await apply([{ op: 'item_set', id: item.id, patch: { pos, rot, scale } }]); await refresh(); });
act('test', async () => {
  const results = [];
  for (const test of project.manifest.requiredTests) results.push(await call('scene_test', { host: kit.link.id, test }));
  await refresh(); log('Host-owned gameplay and integrity checks', results.map(({ test, passed, checks }) => ({ test, passed, checks })));
});
act('capture', async () => { const result = await call('scene_capture', { host: kit.link.id }); $('capture-img').src = `data:image/png;base64,${result.image.data}`; $('capture-img').hidden = false; await refresh(); log('Native host frame retained as evidence.', { hash: result.capture, size: [result.image.width, result.image.height], camera: result.camera.type, conditions: result.conditions }); });
act('profile', async () => log('Measured host counters; not a GPU benchmark', await call('scene_profile', { host: kit.link.id })));
act('approve', async () => { if (!$('ack').checked) return; change = await api('/api/project/approve', { id: change.id, seq: change.seq, rev: project.rev }); await refresh(); log('Exact draft approved for publication.', change.approval); });
act('commit', async () => { const result = await call('change_commit', { id: change.id, seq: change.seq, rev: project.rev, key: crypto.randomUUID() }); change = null; await refresh(); log('Committed as one project revision.', result); });
$('changes').addEventListener('change', async () => { try { change = $('changes').value ? await call('change_read', { id: $('changes').value }) : null; showChange(); } catch (e) { log(e.message, e.details); } });
$('items').addEventListener('change', setSelected); $('ack').addEventListener('change', controls);
$('orbit').addEventListener('click', () => game.setWalk(false)); $('walk').addEventListener('click', () => game.setWalk(true)); $('gate').addEventListener('click', game.toggleGate);
window.seedworkLab = { game, get kit() { return kit; }, get change() { return change; }, get project() { return project; }, call, api, refresh, begin, apply, demoOps, attach: () => $('attach').click(), get ready() { return !busy; } };
controls();
