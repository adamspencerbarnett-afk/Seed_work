import { createRuntime, createGlbLoader } from '/sdk/index.mjs';
import { createObserver, connect } from '/sdk/dev.mjs';

export async function attach(game, { THREE, token, base = '', project = 'courtyard', onStatus = () => {} }) {
  const runtime = createRuntime({ THREE, parent: game.scene, load: createGlbLoader({ Loader: THREE.GLTFLoader, url: hash => `${base}/api/asset/${hash}`, shadows: true }) });
  let collision = [];
  const update = () => {
    const snapshot = runtime.snapshot(); runtime.root.updateWorldMatrix(true, true);
    collision = [];
    for (const item of snapshot.doc.items) {
      const matrix = runtime.get(item.id).matrixWorld;
      for (const box of snapshot.doc.assets[item.asset].boxes) {
        const value = new THREE.Box3(new THREE.Vector3(...box[0]), new THREE.Vector3(...box[1])).applyMatrix4(matrix);
        collision.push({ id: item.id, min: value.min.toArray(), max: value.max.toArray() });
      }
    }
  };
  const unsub = runtime.subscribe(update);
  game.setContent(() => collision);
  const observer = createObserver({ runtime, renderer: game.renderer, camera: game.camera, entities: game.entities, tests: game.tests });
  const off = game.afterFrame(info => observer.afterFrame(info));
  let link;
  try { link = await connect({ runtime, observer, project, name: 'Courtyard host game', base, token, onStatus }); }
  catch (e) { off(); observer.dispose(); unsub(); game.setContent(null); await runtime.dispose(); throw e; }
  let closed = false;
  return { runtime, observer, link, update, dispose: async () => { if (closed) return; closed = true; await link.close(); off(); observer.dispose(); unsub(); game.setContent(null); await runtime.dispose(); } };
}
