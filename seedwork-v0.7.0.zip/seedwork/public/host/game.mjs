export function createGame({ THREE: T, canvas, onHud = () => {}, mats = '../assets/materials/' }) {
  const renderer = new T.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(devicePixelRatio);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = T.PCFSoftShadowMap;
  renderer.toneMapping = T.ACESFilmicToneMapping;
  renderer.toneMappingExposure = .95;
  if ('outputColorSpace' in renderer) renderer.outputColorSpace = T.SRGBColorSpace;
  else renderer.outputEncoding = T.sRGBEncoding;
  const scene = new T.Scene();
  scene.background = new T.Color('#bbc7c8');
  scene.fog = new T.Fog('#bbc7c8', 34, 105);
  const camera = new T.PerspectiveCamera(43, 1, .08, 150);
  const own = new T.Group(); own.name = 'Host game: protected'; scene.add(own);
  const light = new T.DirectionalLight('#fff1db', 1.9); light.position.set(-9, 17, 8); light.castShadow = true;
  light.shadow.mapSize.set(2048, 2048); light.shadow.camera.left = -19; light.shadow.camera.right = 19;
  light.shadow.camera.top = 19; light.shadow.camera.bottom = -19; light.shadow.camera.near = 1; light.shadow.camera.far = 65;
  light.shadow.normalBias = .025; light.shadow.bias = -.00004; own.add(light);
  own.add(new T.HemisphereLight('#c5d6e0', '#645843', 1.1));
  const loads = [], textures = new Set(), loader = new T.TextureLoader();
  const tex = (name, color, repeat) => {
    const value = loader.load(`${mats}${name}.png`); textures.add(value);
    value.wrapS = value.wrapT = T.RepeatWrapping; value.repeat.set(...repeat);
    value.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    if (color) { if ('colorSpace' in value) value.colorSpace = T.SRGBColorSpace; else value.encoding = T.sRGBEncoding; }
    loads.push(new Promise(resolve => { if (value.image?.complete) resolve(); else { const poll = setInterval(() => { if (value.image?.complete) { clearInterval(poll); resolve(); } }, 20); setTimeout(() => { clearInterval(poll); resolve(); }, 5000); } }));
    return value;
  };
  const surface = (name, color, repeat) => new T.MeshStandardMaterial({ color, map: tex(`${name}-color`, true, repeat), normalMap: tex(`${name}-normal`, false, repeat), roughnessMap: tex(`${name}-orm`, false, repeat), roughness: 1, metalness: 0 });
  const stone = surface('masonry', '#d4d0c3', [2, 2]);
  const earth = surface('ground', '#818370', [20, 20]);
  const road = surface('rock', '#808578', [4, 15]);
  const floor = surface('masonry', '#c1bfae', [12, 12]);
  const iron = new T.MeshStandardMaterial({ color: '#333c3e', roughness: .47, metalness: .76 });
  const mesh = (geometry, material, x, y, z, parent = own) => {
    const node = new T.Mesh(geometry, material); node.position.set(x, y, z); node.castShadow = true; node.receiveShadow = true; parent.add(node); return node;
  };
  mesh(new T.BoxGeometry(90, .5, 90), earth, 0, -.29, 0);
  mesh(new T.BoxGeometry(16, .10, 18), floor, 0, -.02, 0);
  mesh(new T.BoxGeometry(2.8, .045, 45), road, 0, .01, 0);
  for (const x of [-8.4, 8.4]) {
    mesh(new T.BoxGeometry(.45, .5, 18), stone, x, .21, 0);
    for (const z of [-9, -4.5, 0, 4.5, 9]) mesh(new T.BoxGeometry(.65, .8, .65), stone, x, .39, z);
  }
  const gate = new T.Group(); gate.position.set(-.91, .035, 4); own.add(gate);
  for (let i = 0; i < 9; i++) mesh(new T.BoxGeometry(.034, 1.85, .045), iron, .055 + i * .213, .95, 0, gate);
  for (const y of [.19, 1.61]) mesh(new T.BoxGeometry(1.82, .058, .064), iron, .91, y, 0, gate);
  for (const x of [-.98, .98]) mesh(new T.CylinderGeometry(.046, .055, 2.08, 12), iron, x, 1.04, 4);
  const state = { player: [0, 1.68, 10], yaw: 0, walk: false, gate: false, frames: 0, testing: false, moved: 0 };
  const keys = new Set(), frames = new Set(), pointer = { active: false, x: 0, y: 0 }, orbit = { yaw: .48, pitch: .65, radius: 32, target: new T.Vector3(0, 1, 0) };
  let source = () => [], raf = null, closed = false, last = null, width = 0, height = 0;
  const ids = { renderer: renderer.domElement, camera, protected: own.uuid, gate: gate.uuid };
  const boxes = () => source();
  const hit = (x, z, radius = .22) => {
    if (Math.abs(x) > 17 || Math.abs(z) > 17) return true;
    if (!state.gate && Math.abs(z - 4) < .075 + radius && x > -1 - radius && x < 1 + radius) return true;
    for (const b of boxes()) {
      if (b.max[1] <= .09 || b.min[1] >= 1.8) continue;
      if (x + radius > b.min[0] && x - radius < b.max[0] && z + radius > b.min[2] && z - radius < b.max[2]) return true;
    }
    return false;
  };
  const move = (dx, dz) => {
    const n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / .04));
    for (let i = 0; i < n; i++) {
      if (!hit(state.player[0] + dx / n, state.player[2])) state.player[0] += dx / n;
      if (!hit(state.player[0], state.player[2] + dz / n)) state.player[2] += dz / n;
    }
  };
  const toggleGate = () => { state.gate = !state.gate; gate.rotation.y = state.gate ? -Math.PI * .52 : 0; onHud(); };
  const setWalk = value => { state.walk = value; canvas.focus(); onHud(); };
  const keydown = e => {
    if (document.activeElement !== canvas || state.testing) return;
    if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyE', 'Escape', 'ShiftLeft'].includes(e.code)) {
      e.preventDefault(); keys.add(e.code);
      if (!e.repeat && e.code === 'KeyE') toggleGate();
      if (e.code === 'Escape') setWalk(false);
    }
  };
  const keyup = e => keys.delete(e.code), blur = () => keys.clear();
  const down = e => { if (e.button !== 0) return; canvas.focus(); pointer.active = true; pointer.x = e.clientX; pointer.y = e.clientY; canvas.setPointerCapture(e.pointerId); };
  const drag = e => {
    if (!pointer.active) return;
    const dx = e.clientX - pointer.x, dy = e.clientY - pointer.y;
    pointer.x = e.clientX; pointer.y = e.clientY;
    if (state.walk) state.yaw -= dx * .006;
    else { orbit.yaw -= dx * .006; orbit.pitch = Math.max(.12, Math.min(1.4, orbit.pitch + dy * .005)); }
  };
  const up = () => { pointer.active = false; };
  const wheel = e => { if (state.walk) return; e.preventDefault(); orbit.radius = Math.max(4, Math.min(50, orbit.radius * Math.exp(e.deltaY * .001))); };
  window.addEventListener('keydown', keydown); window.addEventListener('keyup', keyup); window.addEventListener('blur', blur);
  canvas.addEventListener('pointerdown', down); canvas.addEventListener('pointermove', drag); canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up); canvas.addEventListener('wheel', wheel, { passive: false });
  const step = dt => {
    if (!state.walk || state.testing) return;
    let x = (keys.has('KeyD') ? 1 : 0) - (keys.has('KeyA') ? 1 : 0), z = (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0) - (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0);
    state.yaw += ((keys.has('ArrowLeft') ? 1 : 0) - (keys.has('ArrowRight') ? 1 : 0)) * dt * 1.8;
    const len = Math.hypot(x, z) || 1, speed = keys.has('ShiftLeft') ? 5 : 2.6;
    x *= dt * speed / len; z *= dt * speed / len;
    const before = [...state.player]; move(Math.cos(state.yaw) * x + Math.sin(state.yaw) * z, -Math.sin(state.yaw) * x + Math.cos(state.yaw) * z);
    state.moved += Math.hypot(state.player[0] - before[0], state.player[2] - before[2]);
  };
  const render = time => {
    if (closed) return;
    const start = performance.now(), rect = canvas.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0 && (width !== rect.width || height !== rect.height)) {
      width = rect.width; height = rect.height; renderer.setSize(width, height, false); camera.aspect = width / height; camera.updateProjectionMatrix();
    }
    step(Math.min(.05, last === null ? 0 : (time - last) / 1000)); last = time;
    if (state.walk) { camera.position.fromArray(state.player); camera.rotation.set(0, state.yaw, 0); }
    else { camera.position.set(orbit.target.x + Math.sin(orbit.yaw) * Math.cos(orbit.pitch) * orbit.radius, orbit.target.y + Math.sin(orbit.pitch) * orbit.radius, orbit.target.z + Math.cos(orbit.yaw) * Math.cos(orbit.pitch) * orbit.radius); camera.lookAt(orbit.target); }
    renderer.render(scene, camera); state.frames++;
    const cpuMs = performance.now() - start;
    for (const fn of frames) fn({ time, cpuMs });
    raf = requestAnimationFrame(render);
  };
  raf = requestAnimationFrame(render);
  const withState = fn => {
    const saved = { player: [...state.player], gate: state.gate, rotation: gate.rotation.y, walk: state.walk, yaw: state.yaw };
    state.testing = true;
    try { return fn(); }
    finally { Object.assign(state, { ...saved, testing: false }); gate.rotation.y = saved.rotation; delete state.rotation; onHud(); }
  };
  const result = checks => ({ passed: checks.every(c => c.passed), checks });
  const tests = {
    route: () => withState(() => {
      state.gate = true; state.player = [0, 1.68, 12];
      for (let i = 0; i < 650; i++) move(0, -.04);
      return result([{ name: 'Host movement traverses the north route with the gate open', passed: state.player[2] < -11.9, measuredZ: state.player[2] }]);
    }),
    gate: () => withState(() => {
      state.gate = false; state.player = [0, 1.68, 6];
      for (let i = 0; i < 120; i++) move(0, -.04);
      const closed = state.player[2] > 4.2;
      toggleGate(); for (let i = 0; i < 150; i++) move(0, -.04);
      return result([{ name: 'Existing gate blocks movement when closed', passed: closed }, { name: 'Existing gate interaction opens the route', passed: state.player[2] < 3 }]);
    }),
    host_integrity: () => result([{ name: 'Renderer and canvas remain host-owned', passed: renderer.domElement === ids.renderer }, { name: 'Host camera is unchanged', passed: camera === ids.camera }, { name: 'Protected ground and gate are still attached', passed: own.parent === scene && own.uuid === ids.protected && gate.parent === own && gate.uuid === ids.gate }, { name: 'Host render loop remains active', passed: state.frames > 1 && !closed }])
  };
  return {
    renderer, scene, camera, state, own, ready: Promise.all(loads), tests, move, hit, step, setWalk, toggleGate,
    setContent: fn => { source = fn ?? (() => []); },
    afterFrame: fn => { frames.add(fn); return () => frames.delete(fn); },
    entities: () => [{ id: 'route', type: 'player_route', editable: false, start: [0, 0, 12], end: [0, 0, -12], radius: .22 }, { id: 'gate', type: 'interactive_gate', editable: false, open: state.gate, pos: [0, 0, 4], activation: 'KeyE' }],
    inspect: () => ({ frames: state.frames, renderer: renderer.domElement.id, protected: own.uuid, gate: gate.uuid, player: [...state.player], input: 'host-owned', loop: 'host-owned', collision: 'host compound AABB + gate, not general mesh physics' }),
    view: (yaw, pitch, radius, target = [0, 1, 0]) => { state.walk = false; Object.assign(orbit, { yaw, pitch, radius }); orbit.target.fromArray(target); },
    dispose: () => {
      if (closed) return; closed = true; cancelAnimationFrame(raf); frames.clear();
      window.removeEventListener('keydown', keydown); window.removeEventListener('keyup', keyup); window.removeEventListener('blur', blur);
      canvas.removeEventListener('pointerdown', down); canvas.removeEventListener('pointermove', drag); canvas.removeEventListener('pointerup', up); canvas.removeEventListener('pointercancel', up); canvas.removeEventListener('wheel', wheel);
      const geometries = new Set(), materials = new Set(); own.traverse(n => { if (n.geometry) geometries.add(n.geometry); for (const m of Array.isArray(n.material) ? n.material : n.material ? [n.material] : []) materials.add(m); });
      for (const g of geometries) g.dispose(); for (const m of materials) m.dispose(); for (const t of textures) t.dispose();
      light.shadow.map?.dispose(); renderer.dispose();
    }
  };
}
