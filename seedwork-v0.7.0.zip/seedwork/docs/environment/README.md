# Seedwork Environment 0.7.0

## Release identity

This environment module is integrated in the 0.7 release. Its lineage is the available 0.6 preview built on 0.4; the 0.5 advanced water package was not available. Combined advanced water/weather integration is not claimed.

The release retains World Studio, Model Workshop and Host Lab from the supplied v0.4 source archive. The gallery is `/environment/`. World Studio gains an Environment & seasons panel and three revision-safe tools. The separate embedded-project scene format and its approval flow are unchanged; environment operations are **world-scoped**, not new project draft operations.

## Run the complete preview

With Node.js 22 or newer:

```sh
cd seedwork
node server.mjs
```

Open `http://127.0.0.1:4173/environment/`. World Studio and Model Workshop remain at `/`; Host Lab remains at `/host/`. No npm installation, build step, Python, account or remote assets are needed for the gallery. New supported model recipes compile with the bundled Node compiler; Python is not required.

In the gallery, choose a preset or edit a condition. Drag to orbit, scroll to zoom, use Surface view for the ice specimen, and pause before taking a comparison image. Save climate records the current simulation snapshot. The tool console is under its expandable heading.

In World Studio, choose a condition and Apply conditions. This changes the native world document through the regular revision-aware server tool. Undo, redo, Save JSON and world-with-assets bundles retain the authored configuration. Detach effects removes the optional configuration and restores the base materials and atmosphere. Existing worlds without the environment property keep their normal behavior.

## What the seven presets coordinate

| Preset | Effects |
|---|---|
| Clear summer | Dry surfaces and retained green foliage |
| Rain | Wind-slanted streaks, procedural impact rings, wet darkening/roughness/clearcoat, overcast lighting and fog |
| Snow | Drifting flakes, slope- and shelter-aware surface coating, reduced foliage, colder lighting |
| Freeze | Frost/ice surface response and a separate transmissive cracked-ice specimen in the gallery |
| Autumn | Leaf tint, deterministic foliage retention, falling leaves and ground litter |
| Mist | Exponential distance fog with coordinated lighting/background |
| Thaw | Configured warm conditions evolve snow, ice and wetness amounts over time |

All values remain editable. Presets are authored configurations, not automatic quality levels. No texture resizing, triangle decimation, resolution scaling, automatic LOD or neural asset generation is included.

## Architectural boundaries

`schema.mjs` is a closed, versioned configuration and preset layer. `state.mjs` is renderer-independent climate state, transitions and fixed-step surface evolution. `field.mjs` is the explicitly supplied terrain/shelter cache. `surfaces.mjs` binds opt-in PBR materials. `particles.mjs` owns seeded GPU instanced weather emitters. `index.mjs` coordinates lifecycle and exposes three local tools. None starts an animation loop or creates a renderer, camera or controls.

The host supplies one compatible Three.js namespace, a parent, a camera and elevation callbacks. Three.js r140 is the verified baseline. Other revisions are rejected by default; `allowUnverified` is an explicit opt-in for adapter development, not a compatibility certification. Modern WebGPU/TSL examples cannot simply be copied into this r140 shader adapter.

PBR materials are cloned and shared by source material plus response weights. Source textures and geometry are borrowed, not disposed or edited. Originals are restored on detach unless the host has replaced the material in the meantime. Foliage uses matching depth/distance shadow materials. Prepatched shaders, unsupported material classes and custom foliage shadow pipelines require a deliberate adapter; they are not silently patched twice.

The optional atmospheric binding owns only the fog/background objects it installs and the light intensities it last wrote. Detachment restores these only while they are still owned. It does not replace a sky dome, HDR environment map, post-processing chain, water material, physics engine or game loop. Host code must prevent two systems from independently fighting over the same property.

## Complete host attachment function

This assumes `h` exposes its existing compatible Three.js namespace, scene, camera, lights, material groups and frame registration methods. `h.onFrame` must call the supplied function after camera movement and before rendering, then return an unsubscribe function. `h.onTerrain` should fire for terrain or shelter edits and return another unsubscribe function. These two callbacks are the host adapter contract, not built-in Seedwork host-game methods.

```js
import { createEnvironment, bindAtmosphere, createEnvTools, preset } from './sdk/environment/index.mjs';

export function attachEnv(h) {
  const env = createEnvironment({
    THREE: h.THREE,
    parent: h.scene,
    camera: h.camera,
    config: preset('rain'),
    field: {
      bounds: [-40, -40, 80, 80],
      range: [-10, 70],
      size: 256,
      ground: h.ground,
      roof: h.roof
    }
  });
  let offFrame = () => {};
  let offTerrain = () => {};
  try {
    env.bind(h.groundMesh, { wet: 1, snow: 1, ice: 0.2 });
    env.bind(h.buildings, { wet: 0.8, snow: 1 });
    env.bind(h.leaves, { wet: 0.3, snow: 0.5, foliage: 1 });
    bindAtmosphere(env, {
      scene: h.scene,
      sun: h.sun,
      hemi: h.hemi,
      background: false
    });
    offFrame = h.onFrame(dt => {
      if (!Number.isFinite(dt) || dt < 0 || dt > 5) {
        throw new RangeError('The host must define its policy for long stalls.');
      }
      let left = dt;
      while (left > 0) {
        const step = Math.min(1, left);
        env.update(step);
        left -= step;
      }
      env.sync();
    });
    offTerrain = h.onTerrain(() => env.invalidateField());
    return {
      env,
      tools: createEnvTools(env),
      dispose() {
        offFrame();
        offTerrain();
        env.dispose();
      }
    };
  } catch (error) {
    offFrame();
    offTerrain();
    env.dispose();
    throw error;
  }
}
```

World Studio already supplies its own matching integration. Use the function above for another game; do not run a second animation loop beside the host. `env.update(dt)` accepts finite deltas between zero and one second. Large advances must be subdivided explicitly. The demonstration limits a single post-stall advance to five seconds and then resumes; this is a documented gallery playback policy, not a hidden SDK quality reduction.

`env.set(partial, seconds)` supports validated parameter changes and optional smooth transitions. A weather-only partial change preserves live surface amounts. A partial surface edit changes only those fields. Applying a complete preset intentionally resets its authored surface baseline. Seed changes are immediate-only because blending two discrete seed identities would be ambiguous.

`env.snapshot()` stores current/configured values, surface amounts, clock and blend state. `env.restore(snapshot)` validates before mutation. Use snapshots for live-state continuation; world JSON stores authored configuration and recreates the running state on load. Identical snapshots and updates are deterministic within the tested implementation, not bit-identical across every GPU or engine version. The CPU surface model is a stylized fixed-30-Hz wet/freeze/melt approximation, not physical hydrology.

## Terrain, shelter and sampling contract

`ground(x,z)` returns terrain or another intended receiving-surface height in meters. `roof(x,z)` returns the highest shelter surface, or null. Call `invalidateField` whenever those functions' results change. The grid is deliberately finite and fixed-size (16–512 cells per side). Invalid or out-of-range samples abort a rebuild without altering the existing field.

Each cell stores two 16-bit normalized heights in an RGBA8 texture: ground and the highest receiving/shelter surface. Nearest filtering preserves the packed values. This is an authored approximation, not a lossless representation of arbitrary geometry. Height precision is `(maxHeight-minHeight)/65535`; spatial precision is the domain dimension divided by the grid size. The gallery uses 256² over 70 m with about 0.61 mm height quantization; it does not claim 0.61 mm horizontal detail.

A small normal-dependent slope allowance handles the finite cell footprint without striped self-coverage on roofs. It is bounded at 0.5 m; very close overlapping layers need a higher-resolution or geometry-aware shelter adapter. Precipitation is clipped to the top field, and surface coatings test exposure. This is not individual drop collision or wind-driven rain entering open doorways. Thin eaves, interior boundaries, roof edges and steep structures remain resolution-dependent. The World Studio adapter recognizes built-in house/tower shelters only; imported roofs require a sampler rather than guessed metadata.

Foliage retention acts per mesh/instance origin. The gallery provides separate leaf instances, allowing individual leaf removal. A host grouping an entire canopy in one instance gets canopy-level retention and should supply leaf-level authoring data for finer control. Color and shadow discard thresholds match.

## Water, ice and gameplay

The new system does not touch a water provider or infer that its lake has frozen. The gallery includes a static transmissive ice specimen with original procedural cracks and bubbles. Its thickness/transmission parameters are shading approximations on a surface mesh, not volumetric ice or a structural simulation. No wave coupling, buoyancy, swimming, freezing front, slippery collision or certified walkable ice is included.

A future water adapter may subscribe to the environment's wind/rain/temperature. It must explicitly translate units, distinguish authored from simulated state, manage its own interactions and tests, and register water-surface heights for rain impacts. Do not overwrite water shaders with the PBR surface binder.

The older courtyard exporter still exports the original host template and scene. It does **not** bake or automatically attach environment state. Another game's runtime build must include these environment modules and its validated configuration. Static GLB cannot carry the weather update loop, GPU emitters or live climate state. The preview exporter rejects live environment-patched materials by default. Its UI asks before exporting the original base materials; `env.sourceMaterial(material)` supplies those originals without changing the running scene. This avoids serializing shader-enabling clearcoat flags as if they were the authored visible material. An external host exporter must make the same deliberate distinction.

## Quality and performance contract

The reference and optimized paths use the same geometry, seed arrays, shaders, camera, clock, lighting and viewport. Reference mode submits all allocated particle instances and discards inactive IDs in the vertex/fragment path. Optimized mode submits only the same active prefix. The comparison tests isolate this difference. They are not a comparison with an upstream rain demo, original v0.4 graphics or an imagined higher-detail renderer.

The five fixed-capacity emitters allocate 12,000 rain streaks, 5,000 flakes, 400 falling leaves, 1,400 impact rings and 8,000 litter instances by default. These authored budgets never adapt to frame time. They can be explicitly changed on construction within limits; such a change creates a new quality baseline. Particle uniforms update with time/camera/wind, rather than rebuilding geometry. Heightfield data is rebuilt only on invalidation. Preset changes reuse compatible material programs. Host maps retain their source pixels.

The gallery also batches repeated identical authored primitive geometry by material. That is separate from its weather A/B comparison and is not included in the zero-pixel optimization claim. The source appearance has intentionally changed through improved normal construction and snow coverage. Those authoring fixes become the accepted reference, not alleged lossless conversion from older art.

Physical multilayer shading, particles and ice transmission still add rendering cost. Inspect reports submitted instances, field builds, material counts and actual Three.js counters. GPU time and VRAM are null because they were not measured. This release does not promise an FPS increase, universal zero-pixel identity, hardware certification or free complex shading. Desktop GPU profiling, camera-route tests and water/weather combined tests remain release gates.

## Realism boundaries

The bundled artwork remains procedural, with 512² material maps and a procedural leaf texture. It is visibly less realistic than well-authored scan assets at close range. Rain and snow are analytic instanced quads, impacts are rings, and ground litter is flat geometry. Snow is a material coating without changed silhouette, deep drifts or tracks. Mist is exponential fog, not volumetric shafts. The cloud parameter coordinates ambient/sun intensity and background tint; it does not create cloud geometry or volumetric clouds. The ice map is procedural, not a scan. Wind drives precipitation and falling leaves; tree-branch sway is not implemented. No new sound, lightning, wildfire, sandstorm, river, cave or biome generator was added.

Next passes should prioritize a reviewed scan-quality material/foliage collection, real accumulation geometry and tracks, geometry-aware shelters, a modern renderer adapter, localized weather volumes, coherent sky/cloud lighting and water coupling. Each should have a separate authored visual baseline, regression scenes and target-GPU measurements before optimization.

## Research references

Verified September 24, 2026. These are primary references for renderer capabilities and architectural choices, not claims that their examples were copied into this build.

- Three.js official compute-rain example: https://threejs.org/examples/webgpu_compute_particles_rain.html
- Three.js sprite/snowflake example: https://threejs.org/examples/webgl_points_sprites.html
- Physical material clearcoat, transmission and cost: https://threejs.org/docs/pages/MeshPhysicalMaterial.html
- Standard PBR materials: https://threejs.org/docs/pages/MeshStandardMaterial.html
- Instanced geometry: https://threejs.org/docs/pages/InstancedBufferGeometry.html
- Exponential fog: https://threejs.org/docs/pages/FogExp2.html
- Renderer resource disposal: https://threejs.org/manual/pages/how-to-dispose-of-objects.html
- Modern renderer migration context: https://threejs.org/manual/pages/webgpurenderer
- Screenshot environment constraints: https://playwright.dev/docs/test-snapshots

No Poly Haven textures, HDRIs, stock rain/snow assets or external generative models were downloaded or bundled. Existing Three.js and kit notices are retained. Newly authored environment code uses the SDK license; existing external kit licensing is unchanged.
