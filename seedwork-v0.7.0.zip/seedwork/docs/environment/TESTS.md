# Environment validation

See [the current release test report](../TESTS.md). Older preview counts are not new evidence for this build. The optional harness is `tests/environment-browser.py`; it needs separately installed developer packages and a working software or hardware WebGL implementation.
