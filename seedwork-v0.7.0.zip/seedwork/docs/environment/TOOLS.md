# Environment tools and persistence

The complete preview exposes 42 tools: 27 world/model/environment tools and 15 unchanged project tools. These environment tools are in the world scope. The existing MCP bridge adds required `_rev` and `_key` fields to mutating tool schemas. HTTP world writes use the existing outer `rev` and `key`. Stale revisions fail; valid mutations enter the world's existing undo/redo and change notification flow.

| Tool | Arguments | Semantics |
|---|---|---|
| `environment_inspect` | `{}` | Return authored configuration (or null), never fabricated live GPU measurements |
| `environment_preset` | `{"name":"snow"}` | Apply one of clear/rain/snow/ice/autumn/mist/thaw; `off` removes the optional world environment |
| `environment_set` | `{"config": ...}` | Apply one complete, validated `seedwork.environment/1` configuration |

The gallery and SDK expose a local facade with the same three names. Its inspect operation returns live environment counters, and it has no server revision history. The local facade's preset list does not include `off`; detach by calling `dispose()`. Do not confuse this in-process facade with the revision-safe world service or assume it participates in embedded-project approval.

The supplied `sdk/environment/config.schema.json` is the exact authored configuration schema. Unknown fields, prototype-bearing objects, invalid values and unsupported preset names are rejected. Use `env.set(partial, seconds)` in an explicit host adapter for partial changes and blends. A full world-tool write intentionally creates a new authored preset baseline.

World JSON and portable world bundles retain the configuration. A gallery `seedwork.climate/1` snapshot additionally retains evolved state and clock. These are different persistence boundaries. A static GLB contains neither live particles nor weather behavior. The old courtyard exporter does not attach this new system automatically.

All atmospheric and surface changes are opt-in. The SDK does not call remote services or execute model-generated code. A host should expose only the approved callbacks and keep its existing staging/review semantics. Local preview tools are not a new authentication or authorization boundary.
