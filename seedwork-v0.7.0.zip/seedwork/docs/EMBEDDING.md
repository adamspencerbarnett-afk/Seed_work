# Embed Seedwork in an existing Three.js game

## Contract

The game supplies its Three namespace, parent `Object3D`, compatible `GLTFLoader`, renderer, camera and a subscription that runs after its final render. It explicitly registers entity metadata and trusted gameplay test callbacks. It keeps its own controls, animation loop, renderer configuration and physics.

The SDK has no dependencies and no frontend build requirement. Copy `sdk/` into the host's served source or use the local `@seedwork/runtime` package. A bundler can import the package's main and `./dev` entries separately. A direct browser module can use relative ESM paths as in the complete example below. Do not load a second bundled Three copy just to run Seedwork.

Only r140 was tested in this release. The adapter uses a small injected interface and the default loader uses the host's constructor, but newer or custom engines need their own compatibility test run. This is not a promise of API compatibility with every Three release.

## Complete attach function

Place this file alongside a copied `sdk/` folder. `game.afterFrame(fn)` must subscribe to the host's final-render event and return its unsubscribe function. `game.entities()` returns bounded JSON metadata; `game.tests` contains named callbacks returning `{passed, checks}`. Test callbacks own state restoration and must honor their AbortSignal.

```js
import { createRuntime, createGlbLoader } from './sdk/index.mjs';
import { createObserver, connect } from './sdk/dev.mjs';

export async function mount(game, { THREE, Loader, base, token, project }) {
  const runtime = createRuntime({
    THREE,
    parent: game.scene,
    load: createGlbLoader({
      Loader,
      url: hash => `${base}/api/asset/${hash}`
    })
  });
  const observer = createObserver({
    runtime,
    renderer: game.renderer,
    camera: () => game.camera,
    entities: game.entities,
    tests: game.tests
  });
  const off = game.afterFrame(info => observer.afterFrame(info));
  let link;
  try {
    link = await connect({ runtime, observer, project, base, token });
  } catch (error) {
    off();
    observer.dispose();
    await runtime.dispose();
    throw error;
  }
  let closed = false;
  return {
    runtime,
    observer,
    link,
    async dispose() {
      if (closed) return;
      closed = true;
      await link.close();
      off();
      observer.dispose();
      await runtime.dispose();
    }
  };
}
```

The default loader leaves shadow flags alone. Set `shadows: true` deliberately when the host wants imported models to cast/receive shadows and its renderer supports them. No function above starts a render loop or creates a renderer.

The example is a content/observation bridge, not a universal collision adapter. `public/host/integration.mjs` is the full executable reference for converting native compound boxes into the supplied game's AABBs. A real game should instead bind asset boxes, triggers or mesh shapes through its own physics/navigation system. `bind_set` records approved semantic targets; the host must interpret them. A binding string does not automatically implement a new door controller.

## Resource ownership

For an existing host-managed asset library, pass a custom loader returning `{root}`. These are borrowed resources; Seedwork never disposes them. Return `{root, dispose}` only for assets whose resource lifetime the runtime owns. A hash is the resource identity: two assets using the same hash share source geometry/materials. Do not use the same hash for different bytes or change a shared material in one placement unless that change is intended for every placement using it.

The default `createGlbLoader` checks the exact file SHA-256 before parsing and returns an owned disposer. It rejects animated/skinned/morph content, external file dependencies and unsupported extensions. It accepts bounded self-contained static GLBs, unlit and texture-transform extensions. It does not claim support for every glTF PBR extension. Its resource disposal deduplicates handles; it does not dispose the host renderer or external scene objects.

Use `runtime.get(id)` for a stable wrapper handle. Treat child geometry/material/texture handles as shared. Authoring transforms should go through scene revisions; a game-only animation of a wrapper changes the live pose without automatically editing the authored document. `scene_query` includes actual matrices as well as authoring metadata. An asset revision preserves the wrapper but may replace its model child, so do not retain child references across revisions without a listener.

`runtime.subscribe(fn)` runs after a successful scene application and returns an unsubscribe function. Use it to refresh collision proxies and interaction mappings. Callback failure is reported as a warning, not silently treated as a safe rollback of gameplay effects. The host must make such bindings atomic or recoverable.

## Connecting a different local development origin

Start Seedwork with `SEEDWORK_ORIGINS` listing the exact approved loopback HTTP origin, for example `http://localhost:3000`. Set `base` to `http://127.0.0.1:4173` and supply the local author token deliberately through your development integration. Do not expose it to an AI prompt or a production build. `/api/session` refuses cross-origin token discovery even for an allowlisted origin.

`connect` exchanges that token for a restricted host token and does not retain the author token in the link. Host identity, capabilities and tests appear in `project_inspect`, but secrets do not. A host can receive bounded commands and return evidence, not mutate or approve the authoring document directly.

Use an HTTPS or localhost secure context for native WebCrypto. The test-only opaque-origin crypto facade is not shipped in the SDK and is not a product fallback.

## Observe the actual final frame

Call `observer.afterFrame({time, cpuMs})` only after the game has rendered its final visible framebuffer. Do not call it after an intermediate offscreen pass. With a postprocessing composer, place it after the composer completes. The observer does not force a render, change camera state, resize the canvas or turn down pixel ratio.

Captures wait for the next host frame, are PNGs at native framebuffer size, and include camera matrices, projection, render settings and scene revision/hash. A tainted or oversized canvas is an error, not a fabricated or silently downscaled image. Maximum capture size is 16 megapixels and 12 MiB of base64 payload. The default host command deadline may be reached before a very slow initial load finishes; reconnect/reset rather than publishing unverified output.

Profiles expose actual frame intervals, optional host-supplied CPU work durations and renderer counters. Frame intervals include browser scheduling. GPU time and VRAM bytes are null because no GPU query or byte accountant is installed. Renderer resource counts can include internal caches. This is diagnostic instrumentation, not a target-GPU benchmark.

## Runtime-only use

For a shipped game, import only `sdk/index.mjs`, load the scene JSON and its referenced GLBs, and call `runtime.setScene(doc)`. Do not import `sdk/dev.mjs`, open the authoring broker, or ship credentials. Your game can run with the authoring server stopped.

A complete executable static example is emitted by `scripts/export-host.mjs`. It includes the supplied host's controls and collision mapping, a local-only static server, the scene, immutable assets and a build inventory. It is not a bundler for an arbitrary supplied game. For another project, integrate the SDK with that project's existing production build.

## Cleanup and failure behavior

Close the development connection first, unsubscribe the post-render callback, dispose the observer and integration hooks, then dispose the runtime. Do not dispose the host's renderer or camera. A canceled or superseded asset load does not publish a partial scene. Host test hooks and custom loaders must cooperate with cancellation; JavaScript callbacks are not forcibly terminated or sandboxed.

The example's route test uses compound AABBs and a fixed-height player. It proves that this registered route works in this registered host, not that every possible route is navigable or that arbitrary imported collision meshes are correct.

The default loader snapshots its owned resource handles before exposing a parsed asset. A host texture attached later (for example an environment map) is not adopted and disposed as an imported resource. Disposal attempts all captured resources even when a custom disposer fails, and reports failures. The general `disposeTree` utility instead acts on the tree resources present when it is called; use it only for a wholly owned tree.

Scene positions, policy bounds and authoring queries use the supplied parent's authoring coordinate frame. `scene_query` additionally returns actual `matrixWorld` values. Convert coordinates in the host adapter when the parent is transformed. The query updates the owned subtree and its ancestor chain without traversing unrelated host siblings. Runtime item wrappers use `matrixAutoUpdate = false`; a deliberate game-only pose change must call `updateMatrix()` or explicitly re-enable automatic matrix updates for that wrapper. Such a pose change is not an authored scene revision.
