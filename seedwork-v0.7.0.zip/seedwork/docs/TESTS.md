# Seedwork 0.7.0 — release verification

Date: September 24, 2026. These results were executed for this release; older kit, water or editor counts are not inherited as new evidence.

## Recorded results

| Check | Result |
| --- | --- |
| Dependency-free Node suite, including world/model/service/SDK/API/export/MCP tests | 261 passed, 0 failed |
| Native Workshop browser interactions | 57 passed |
| Environment gallery and World Studio weather integration | 46 passed |
| Embedded Host Lab workflow | 59 passed |
| Exported runtime-only game | 9 passed |
| Clean ZIP → generated project → real editor/workshop | 4 passed |
| Controlled reference/optimized image pairs | 18 pairs, zero differing pixels in every pair |
| Strict TypeScript SDK/environment checks | Exit 0 |

Machine-readable results are in `validation/summary.json` and the per-suite JSON files. `validation/node-tests.txt` is the actual Node run output. Tests used Node 22.16.0 on Linux. No hosted GitHub Actions execution, Windows/macOS execution, Node 24 execution or target-GPU benchmark is claimed.

## What was exercised

The new compiler is tested for all eight primitives, deterministic output, valid static GLB readback, supported legacy envelope, missing/invalid PNG inputs, CRC/hash/dimension validation, explicit height baking, caching, exact attribute welding, source/recipe provenance and native starter integrity. Unknown sculpt/stamp/decal fields, mismatched UV modes and falsy or mistyped transforms/maps fail instead of being silently dropped. Seven authored starters were rebuilt; their appearance is a new baseline, not a claimed match to the excluded kit.

The offline workflow tests actual new project generation, bundled model assets, refusal to overwrite existing output, launch-time bundle import and preservation of a later edit after restarting. Release tests exercise ZIP byte preservation/CRC, deterministic ordering, exclusion of local credentials/state, rejection of source symlinks and changed/unlisted source detection.

Native browser checks open all starters, inspect PBR/clay/wire geometry, publish models, inspect native thumbnails, edit materials and dimensions, compile a new revision, preserve placements, undo/redo and read back exported world GLB with tangents and embedded PBR maps. A stale/unapplied recipe cannot be published as the inspected model.

Environment checks exercise all seven presets, actual emitter/material changes, climate persistence, thaw evolution, roof exposure, stable allocations, detachment, World Studio history and explicit base-material export. The static GLB path rejects live weather materials unless base-material export is deliberately confirmed.

Host checks stage a courtyard, reject an invalid atomic batch, preserve host ownership, validate a passable route and gate, capture the real scene, approve/publish, detect a deliberately blocked route, refuse approval, repair, undo/redo, discard and detach/reattach. The exported runtime loads sixteen placements from six asset sources without any authoring API request and passes its original route/gate/ownership checks.

## Visual comparison boundary

Seven native reference/compacted model pairs each compare 600,542 pixels. The indexed-versus-expanded world comparison contains 956,432 pixels. Seven weather pairs each compare 1,014,740 pixels. Three host-placement pairs each compare 666,168 pixels. All 18 comparisons used zero tolerance and matched exactly.

The host pairs share decoded source assets and independently construct placements/transforms. They isolate incremental placement reuse, not cold decoder/draw-order variation. Cameras, time, authored settings and resolution are controlled. The weather reference submits all allocated instances and rejects inactive IDs; the optimized path submits the identical active prefix. No simplification or reduced image resolution is hidden in those comparisons.

The browser runs use Chromium with SwiftShader software WebGL under Xvfb, device scale 1 and a local HTTP fixture because managed navigation is restricted in this environment. The real renderer and local API run; browser EventSource is mocked where used. The actual server stream and HTTP/MCP boundaries are covered separately by Node tests. This is not an end-to-end ChatGPT account integration or a physical GPU certification. GPU timing and VRAM remain unset where unavailable.

## Clean package and reproducibility

The release ZIP was CRC-checked, extracted into a new directory and verified against every source hash. The extracted CLI generated Autumn Settlement with 152 objects and two native model definitions; the generated source manifest also verified. Starting that new project with an invalid Python executable path successfully bootstrapped its bundle. Browser checks confirmed the planned world/model definitions, a compiled Workshop starter and no uncaught page errors. Two archive builds from identical reviewed source produced identical SHA-256 values. The final ZIP checksum is distributed separately rather than impossibly embedding its own checksum inside itself.

## Issues found and corrected

An initial headless launch failed to create WebGL because no X display was running. Starting Xvfb resolved that test-environment failure. Removing the unsupported legacy detail panel initially removed the Workshop part-field binding as well; the binding was restored and all 57 native browser checks then passed. An initial new-project test polled an incorrect API path; it was corrected to the actual `/api/world` endpoint, then the real startup/restart test passed. Later schema tightening changed the compiler fingerprint but left all seven GLB SHA-256 hashes unchanged; Node tests were rerun after the metadata rebuild.

## Reproduce

```sh
node scripts/test.mjs
node scripts/release.mjs
node seedwork.mjs verify
```

Optional strict type checks require a separately available TypeScript compiler:

```sh
tsc --strict --noEmit --module nodenext --target es2022 tests/types/main.ts tests/types/environment.ts
```

Optional browser harnesses require the developer's Python/Playwright, NumPy/Pillow, Chromium and working WebGL display; they are not application runtime dependencies. Generate native references with `SEEDWORK_REF_DIR=<folder> node scripts/build-starters.mjs`, start a clean local server, and run `tests/native-browser.py --refs <folder>`, `tests/environment-browser.py`, or `tests/host-browser.py --fixture` against it. The fixture option is for constrained test environments, not normal user launch. Runtime-only checks use the generated static example and `--runtime`.

The removed kit's former 207-test suite is not bundled and not counted. Advanced v0.5 water, real hardware frame time, general gameplay reachability, complete physics, neural generation and automatic remote ChatGPT setup are outside this release's verification.
