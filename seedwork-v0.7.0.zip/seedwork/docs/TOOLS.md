> The current 42-tool catalog is generated in `tools.manifest.json`. The environment tool contract is in `environment/TOOLS.md`.

# Tool/API reference — Seedwork 0.7

The catalog contains 39 named tools: 24 World Studio/model tools and 15 embedded-project tools. `tools.manifest.json` contains the complete MCP input schemas. `GET /api/tools` returns HTTP argument schemas; `/api/tools?wire=1` adds world `_rev`/`_key` MCP fields. The custom schema validator implements the closed subset emitted by this catalog, not arbitrary externally supplied JSON Schema dialects.

## Shared HTTP envelope

All calls use authenticated `POST /api/tool` with `{name, args}`. World mutations additionally require top-level `rev` and `key`. Project write preconditions belong in their tool arguments. Missing, stale or invalid input fails explicitly. There is no implicit latest-revision substitution.

```json
{
  "name": "object_add",
  "args": {"type": "crate", "x": 3, "z": 4},
  "rev": 0,
  "key": "add-crate-request-001"
}
```

Read the observed world revision first with `world_inspect`. Do not copy `0` unless it really is the returned revision. A retry must reuse exactly the same key and arguments. A different edit needs a different key. Keys are bounded to 128 characters; receipts are retained up to 512. After receipt eviction, stale revisions/sequences prevent a duplicate mutation rather than guaranteeing indefinite replay results.

World responses contain `scope`, current `world`, current `rev`, and the result. Replays also identify `receiptRev` and `replayed`; current world state is not replaced with old receipt state. Project responses contain `scope: project`, current project `rev` and `result`.

## World/model tools

The previous 23 tools remain: `world_inspect`, `world_make`, `world_recipe`, `terrain_set`, `terrain_brush`, `object_add`, `object_update`, `object_remove`, `object_scatter`, `spawn_set`, `world_validate`, `world_undo`, `world_redo`, `asset_list`, `asset_bind`, `asset_unbind`, `model_list`, `model_template`, `model_build`, `model_status`, `model_publish`, `model_cancel`, `model_remove`.

The new `world_batch` accepts 1–128 ordinary mutating operations and publishes one revision/undo step. Nested batches, history operations and asynchronous model-build work are not accepted inside it.

```json
{
  "name": "world_batch",
  "args": {
    "ops": [
      {"name": "object_add", "args": {"type": "crate", "x": 3, "z": 4}},
      {"name": "object_add", "args": {"type": "lamp", "x": 5, "z": 4}}
    ]
  },
  "rev": 0,
  "key": "courtyard-props-001"
}
```

This intentionally tightens the old API: world writes without revision/key are no longer allowed, including MCP and native-model publication. Read-only tools and model build/status/cancel do not require a world revision. `examples/edit.mjs` and `examples/model.mjs` show complete updated calls.

## Embedded project tools

| Name | Purpose |
|---|---|
| `project_inspect` | Current project, revision, permissions, active changes and connected host capabilities |
| `asset_search` | Focused search across native starters, published models and ready local builds |
| `project_query` | Focused authoring document/draft query, with filters before pagination |
| `change_begin` | Isolated change from observed `rev`; optional exact history proposal |
| `change_apply` | Atomic operations against observed draft `seq` |
| `change_read` | Diff, state, sequence, evidence and approval; optional complete draft document |
| `change_check` | Static schema/bounds/bindings checks and missing evidence |
| `change_preview` | Exact staged snapshot loaded and acknowledged by a selected host |
| `change_commit` | Atomic, revision-checked publication after required evidence and approval |
| `change_discard` | Close draft and reset hosts displaying it to current committed content |
| `scene_query` | Actual loaded host matrices and registered external semantic metadata |
| `scene_capture` | Actual native-resolution PNG after the host's final render |
| `scene_test` | One registered host gameplay/integrity callback |
| `scene_profile` | Measured counters and explicit missing GPU/VRAM measurements |
| `scene_reset` | Explicitly restore committed content in one host without discarding drafts |

There is no `approve` tool. The reviewer endpoint is `POST /api/project/approve` with `{id, seq, rev}`; Host Lab exposes it behind an explicit acknowledgment. It is a local author-token endpoint, not proof of human identity.

## Operations inside a project batch

`asset_use` selects an approved registry reference under a scene asset key. `asset_socket` defines an explicit socket. `item_add`, `item_set` and `item_remove` edit placements. `bind_set` records a manifest-approved semantic target. `item_snap` aligns source and target sockets including orientation and scale. `items_path` creates a bounded deterministic set of placements. Consult the manifest for exact fields and limits.

```json
{
  "name": "change_apply",
  "args": {
    "id": "c_4fe8b93d-18aa-4c54-a4df-c0c802db524f",
    "seq": 0,
    "key": "bench-change-001",
    "ops": [
      {"op": "asset_use", "key": "bench", "ref": "starter.bench"},
      {"op": "items_path", "asset": "bench", "prefix": "seats", "path": [[-5, 0.035, -5], [-5, 0.035, 5]], "count": 3, "orient": false}
    ]
  }
}
```

Use the actual change ID/sequence returned by `change_begin`; the values above illustrate the complete envelope. A path batch emits stable suffix IDs such as `seats_001`. It does not silently skip blocked positions or infer collision validity. A single invalid item causes the whole batch to fail. Static validation is not a reachability proof.

## Evidence conditions

Preview, required tests and capture must match the exact change hash/sequence and connected host. The host must still be displaying that scene at review/commit. The policy controls required tests and evidence age. Editing or new evidence clears approval. Failed new tests replace earlier passing results. A stale change cannot silently rebase onto a newer project revision.

Host callbacks must restore state and honor cancellation. Tests, captures and host commands have bounded deadlines. Invalid, replayed, out-of-order or mismatched host replies cannot create accepted evidence. Captures exceeding size limits fail without resizing. Host offline/disconnected, failed loads and expired commands are explicit failures, not permission to publish without inspection.

## MCP versions and content

`mcp.mjs` supports the `2025-11-25` initialize/initialized flow and the `2026-07-28` per-request tools-only stdio flow. Modern calls include `_meta` with `io.modelcontextprotocol/protocolVersion` and `io.modelcontextprotocol/clientCapabilities`. Client identity is optional. Discovery is `server/discover`; tools results have `resultType: complete`. Unsupported protocol versions are rejected.

World mutating tool arguments require `_rev` and `_key`; the bridge moves them to the HTTP envelope. Project write arguments already contain their normal `rev`/`seq`/`key` fields. No global mutable revision is cached inside the bridge. The bridge reads the local secret file and never sends it to the model in tool results.

`scene_capture` produces an MCP image-content block and structured camera/snapshot metadata. The base64 image is not duplicated into the text summary. Tool errors preserve codes/details with `isError: true`. Cancellation aborts the outstanding request; it does not undo a mutation that already committed. Stable retry keys are still necessary after uncertain outcomes.

The bridge is a focused tools subset, not a full conformance implementation. No HTTP MCP transport, OAuth, elicitation, resources, prompts or commercial-client certification is claimed. Source schemas and MCP version behavior should be retested during future dependency migrations.
