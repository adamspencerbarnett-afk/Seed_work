# Publishing the prepared GitHub release

This archive is a repository-ready source tree, not an already published GitHub release. No Seedwork repository was identified in the connected account during preparation. Choose the destination repository explicitly; do not publish into either upstream water or Three.js repository.

## Repository contents

Extract the ZIP and use the contents of `seedwork/` as the repository root. Review README's commercial permission and `THIRD_PARTY.md`. Keep `notices/`, `sdk/LICENSE`, vendor notices, source manifests, all bundled models/maps and the ChatGPT handoff documents. Do not add `.seedwork/`, private inputs, cached jobs, generated personal projects, credentials or local logs.

There is intentionally no new standard root LICENSE selection. Existing notices remain; adding no license would not itself provide commercial permission. The README contains the requested affirmative grant for controlled original contributions.

## Local release checks

```sh
node seedwork.mjs doctor
node scripts/test.mjs
node scripts/release.mjs
node seedwork.mjs verify
```

The release builder generates the exact tool manifest, attribution inventory, release metadata, checksums and a deterministic source ZIP under `dist/`. The ZIP contains its source, libraries, assets, instructions and tests. Node.js/browser binaries and optional developer test tools are not included.

Review `docs/TESTS.md` for the checks actually run before publishing. The workflow configuration itself is not evidence that hosted CI has executed.

## GitHub Actions

`check.yml` runs the dependency-free Node suite on Node 22 and 24. `release.yml` is manual (`workflow_dispatch`), checks out an explicit release tag, confirms it matches `package.json`, runs tests, builds/verifies the archive, and creates a **draft** GitHub release with its ZIP/checksum. There is no automatic public release on every commit. Actions are pinned to recorded commit IDs.

Create/push the reviewed tag, then dispatch the workflow on that tag. Inspect its draft assets and release notes before publishing. The GitHub token is supplied by Actions at run time; no credential is stored in the project. The release workflow needs `contents: write`, while ordinary checks use read-only permissions.

Alternatively upload the tested ZIP/checksum manually to a new draft release. Do not describe a release as tested on Windows, a target GPU or a browser version merely because a matrix or optional harness exists.
