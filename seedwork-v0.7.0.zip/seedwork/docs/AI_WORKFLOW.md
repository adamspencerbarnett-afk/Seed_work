# File-based AI workflow

This path works without a live connection between ChatGPT and the user's computer. The AI reads the release's capability manifest and exact tool/plan schemas, writes a plan, validates it, then returns either a portable world bundle or a complete new project folder. It is a deterministic tool workflow, not a built-in language model.

## Inspect before editing

```sh
node seedwork.mjs doctor
node seedwork.mjs context
node seedwork.mjs tools
node seedwork.mjs schema
```

Start with an existing plan in `examples/plans/`. A plan contains `format: "seedwork.plan/1"`, a `world` description, optional native `models`, and a bounded list of `{name, args}` world operations. Model definitions use either a supported starter template or an editable recipe. Read the generated schema instead of guessing field names, dimensions or prefab IDs.

```sh
node seedwork.mjs validate --plan examples/plans/autumn-settlement.json
node seedwork.mjs plan --input examples/plans/autumn-settlement.json --out ../portable-world
node seedwork.mjs new --plan examples/plans/autumn-settlement.json --out ../autumn-game
```

`validate` checks input structure. `plan` also builds/reuses model assets, applies operations and validates the resulting world. It writes portable `start.seedpack.json`, world, plan and report files. `new` adds the entire clean application source and places those files in `project/`. Both commands refuse an existing target rather than overwrite a user's project. A failed operation leaves no partly completed output folder.

The report distinguishes validation from unperformed browser or gameplay review. It records actual operation results, including achieved scatter counts. Artifacts are content-addressed and included, not represented by links to missing services.

## Local first run and continuation

Run `node server.mjs` in the generated folder. On the first launch only, the service imports the supplied starter bundle into its local state. Later launches preserve edits. `.seedwork/` contains local credentials, history and user files; exclude it from public releases. Save a world-and-assets bundle for a portable editable backup.

A generated project is an authoring/playable scaffold. The assistant still needs to implement game-specific objectives, UI, movement, tests and rules. Preserve the game owner's renderer, loop and inputs when integrating into an existing game; see `EMBEDDING.md`.

## Iteration contract

Work in small reviewed passes: inspect, plan, build, inspect real images, test actual controls, compare, save. Keep the original project and accepted references. Do not describe an unrun test as passing or substitute an imagined image for the running game. Optimization follows acceptance of a visual baseline, not automatic simplification.

For a local connected client, use the existing tool API and revision keys. For an uploaded ZIP, return complete changed files or a complete new ZIP plus a change/test summary. Do not claim that uploading files automatically installs the stdio MCP server in ChatGPT.
