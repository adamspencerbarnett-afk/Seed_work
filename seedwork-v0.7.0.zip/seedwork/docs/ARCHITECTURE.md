# Architecture decisions — Seedwork 0.7

Date: 2026-09-24. Scope: implemented local prototype, not a production architecture certification.

## 1. Dependency direction and ownership

The SDK depends inward on pure scene/schema/math modules. The optional development bridge depends on the SDK; the SDK does not depend on the editor, server, MCP, Node model compiler or a global Three installation. Server services use the same scene operations and schemas as the runtime. UI and MCP call the same tool service.

```text
World Studio / Model Workshop ── world tools ── native assets and recipes
                                                   │ explicit asset_use
Agent or Host Lab UI ── project tools ── isolated draft ── evidence / approval
                                  │                         │
                                  └── development broker ───┘
                                             │
Existing game ── integration adapter ── runtime content group
    │                  │                      │
    │                  └── post-frame observer│
    └── renderer, camera, loop, physics, inputs┘
```

The host game creates and destroys its own rendering and gameplay systems. The runtime attaches one `Group` and never creates a renderer, installs controls or starts `requestAnimationFrame`. The optional observer reads results after a host frame. The optional bridge has a network polling loop, not a rendering loop.

Three.js documents that removing an object from the scene does not free its geometry/material/texture resources. Therefore resource lifetime is explicit: a loader supplies `{root, dispose}` for owned assets, or `{root}` for borrowed assets. The pool calls an owned disposer once after its final active lease. A host must not dispose shared resources behind the runtime or mutate shared materials unintentionally.

Source: https://threejs.org/manual/pages/how-to-dispose-of-objects.html

## 2. Data model, source and runtime boundaries

`seedwork.scene/1` contains assets and items. Assets carry immutable GLB hashes, meter dimensions, compound collision boxes, tags, explicit sockets and optional editable provenance. Items carry stable IDs, asset references, position, XYZ degree rotation, positive uniform scale, tags and behavior bindings. The runtime scene preserves asset local transforms and source dimensions. It does not recenter or normalize assets while loading.

The compiler's established auto-center/ground behavior still exists before publication. The adapter cannot retroactively infer a semantic hinge from arbitrary geometry. Starter origin/top/left/right sockets are derived from declared bounds; semantic attachment frames must be authored explicitly. `asset_socket` and `item_snap` expose this boundary. Snapping resolves a pose once; no persistent mechanical constraint solver is claimed.

World Studio's terrain-world format remains separate and compatible. Its model assets enter the project registry, but world edits do not silently change a published project. `asset_use` makes an explicit asset revision inside a draft, affecting dependent placements without replacing their IDs. `items_path` performs bounded deterministic placement; it does not infer terrain alignment or automatically avoid gameplay obstacles.

No general file scanner, code indexer, neural model provider, arbitrary repository patcher or behavior synthesis layer was added. The project manifest and host registration are the source of game semantics.

## 3. Atomic and incremental runtime application

`setScene` validates and clones the proposed document. It acquires hash-keyed asset leases before releasing superseded pending plans, preserving shared in-flight loads. Obsolete unshared loads are cooperatively aborted. It waits for all required assets before changing the visible scene. Failed loading leaves the prior document, object groups and content intact.

Once loading succeeds, stable wrapper groups are reused. Only changed transforms are written; unchanged subtrees remain intact. An asset revision replaces that item's model child rather than the wrapper. Repeated placements clone object nodes but share geometry/material/texture resources. This is source resource sharing, not new draw-call instancing.

The newest requested scene wins. Superseded requests fail explicitly rather than claiming they were applied. `dispose` removes the owned group, prevents new work, closes resource leases and waits for outstanding cooperative loads. A custom loader that ignores abort can delay cleanup; resource contracts are not a process sandbox. Subscriber exceptions are returned as warnings after a valid scene apply rather than creating a half-rolled-back graphics scene.

## 4. Revisions, sequences, receipts and persistence

A project publication advances `rev`. A draft edit advances its own `seq`. Both writes require an observed precondition and a stable request `key`. Repeating an identical key/argument combination returns its receipt. Reusing a key for a different operation fails. Replaying a World Studio mutation returns current document state plus the original receipt revision, not an old document that could overwrite newer state in the UI.

A batch clones the target once and validates all operations and the resulting document. Invalid operation N prevents operations 1..N-1 from becoming visible. Project edits remain isolated until commit. `world_batch` provides a parallel bounded transaction for ordinary World Studio operations, but is not a transaction for asynchronous model builds or external providers.

Storage writes a temporary JSON file then renames it before exposing the new in-memory state. A single-writer process lock guards one data directory. The history retains 20 project snapshots; active changes are limited to 8, closed changes to 24, receipts to 512. Revisions and sequences still reject stale retries after receipt eviction. Project undo/redo proposes an exact snapshot, requires normal evidence and approval, and publishes as a new revision. World Studio retains its existing session-local undo history.

This is not a collaborative database, file-watch merge system, fsync/power-loss guarantee or automatic rebase. On startup the service clears live evidence and approvals because the old host session cannot still attest to its current scene. Immutable assets are separate from the JSON journal.

## 5. Evidence and approval

Every host scene response includes project, revision, change ID, sequence and canonical document hash. Preview must receive a successful matching load acknowledgment before tests/captures count. Evidence is bound to that exact scene and connected host. The host must still be displaying the same scene at approval and commit; evidence from draft A cannot approve it while the host shows B.

Required tests, capture requirement, protected IDs, editable bounds, registered binding targets and evidence age are declared in `seedwork.json`. Any draft edit invalidates previous evidence and approval. A new failed test replaces an older pass. Approval is a distinct local endpoint and UI operation, not an MCP tool. Approval does not bypass missing or failed evidence. Commit verifies current project revision, sequence, evidence, connected scene and explicit approval atomically.

This is a trust boundary for a local authoring workflow, not cryptographic proof that a human clicked: the full author token can invoke the approval endpoint. Game tests are trusted registered callbacks, not independently verified gameplay logic. They must restore state and honor cancellation. The host test timeout is 10 seconds, capture waits at most 10 seconds, bridge commands default to 15 seconds, and the GLB loader defaults to 30 seconds. Large assets or slow hardware can exceed the command budget; such attempts fail/reset rather than publishing unverifiable state. The current UI does not automatically retry or silently extend a budget.

MCP supports structured results and image content; the bridge returns real captured PNGs, not generated renderings or an assistant's description of a viewport.

Source: https://modelcontextprotocol.io/specification/2026-07-28/server/tools

## 6. Host transport and security

The broker uses bounded long polling: one active command and one waiting poll per host, a finite queue, idle timeout and separate host tokens. Initial committed sync runs before a queued draft preview. Responses are bound to host, command ID and exact requested snapshot. Out-of-order, forged, replayed or expired responses cannot create accepted evidence. A failed asset load retains the old runtime state and reports failure; command timeout schedules a committed reset.

The server binds loopback. Same-origin authoring token discovery is not made available to other origins. Explicitly allowlisted loopback hosts must receive credentials through deliberate developer integration. A host exchanges an author token for a restricted host token and does not retain the author token in its link. Host tokens can poll and reply, not edit or approve projects. Local access is not a defense against arbitrary same-user code execution or stolen credentials.

MCP exposes no shell/ arbitrary JavaScript execution. Native compilation uses the new Node compiler through a bounded subprocess worker, not a complete sandbox. The development server is not a remotely deployable service. The optional stdio bridge supports two documented protocol versions' tools subsets, not resources, prompts, OAuth, HTTP transport or a full conformance suite.

## 7. Rendering and the quality contract

The default GLB loader verifies exact SHA-256 bytes, rejects external references and unreviewed required/optional extensions, and preserves supported geometry attributes, images and hierarchy. It does not introduce decimation, lower texture resolution or a new material conversion. Custom host loaders are explicit replacements for that policy and must be reviewed separately.

A scene revision intentionally changes the authored output. Optimization is evaluated against the accepted version, not used to conceal an art change. The generic adapter shares resources and avoids redundant transform updates; the existing model compiler retains its exact compaction checks. Measured frame counters are available, but GPU timing and VRAM bytes are null without dedicated instrumentation. Resource counts are not byte measurements. No whole-game speedup is inferred from a smaller operation count.

Controlled screenshot equality is finite evidence. Browser, OS, GPU and configuration can affect rendering, as Playwright's visual-testing documentation notes. The present browser runs use a disclosed software-WebGL fixture, not target hardware certification.

Source: https://playwright.dev/docs/test-snapshots

## 8. Delivery and next architectural gates

Runtime export uses the normal scene plus byte-verified assets, omitting the authoring bridge, credentials, compiler and recipes. It packages the supplied host template only. Other games retain their own build/deployment pipeline and use the SDK/scene as dependencies. Editable backups require the authoring data and referenced assets, not only the exported runtime.

Next gates are a reviewed Three.js migration and test matrix; a real supplied game's adapter; explicit semantic assembly constraints and pivots; a coherent reference-quality material collection; target-hardware profiling; optional reviewed compressed/animated asset adapters; and independently evaluated agent task productivity. Those are not implied to be completed by this release.

The default loader snapshots its owned resource handles before exposing a parsed asset. A host texture attached later (for example an environment map) is not adopted and disposed as an imported resource. Disposal attempts all captured resources even when a custom disposer fails, and reports failures. The general `disposeTree` utility instead acts on the tree resources present when it is called; use it only for a wholly owned tree.

## 9. Offline authoring and release boundaries

The 0.7 Node compiler replaces the excluded uncertain-permission Python kit. Recipes are closed validated data; bundled Three.js constructs standard geometry while original code assembles, textures, audits and publishes it. All native starters are regenerated. Unsupported advanced operations are errors, not ignored parameters.

The offline plan path imports the same world operations and validators used by the editor. A complete plan is compiled into a new temporary directory and atomically renamed only after successful validation. Native artifacts are included by hash. A generated application bootstraps a portable bundle only when local state does not yet exist, preserving subsequent edits. This is not an automatic full-game compiler or a remote ChatGPT connection.

The release filter excludes runtime state, input stores, caches and common secret files, rejects symlinks, and includes an exact source manifest. Deterministic ZIP metadata supports repeated builds with the same toolchain. Checksums establish integrity, not authorship or security certification. See the AI workflow, native modeler and GitHub release guides for executable commands.
