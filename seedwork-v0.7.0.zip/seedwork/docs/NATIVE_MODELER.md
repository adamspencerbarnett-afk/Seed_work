# Native model compiler — 0.7.0

The compiler runs with the same installed Node.js executable as the server. No Python, npm package, neural model or network service is required. The worker accepts validated data, not code. `modeler/compiler.mjs` exposes `doctor()` and `compile(recipe, options)`; the service retains bounded jobs, build cancellation, artifact validation and explicit publication.

Run `node seedwork.mjs doctor`. Copy a recipe from `modeler/catalog.json` or use Model Workshop to edit it. Compile a recipe using:

```sh
node seedwork.mjs model --recipe recipe.json --out ../new-model
```

The new folder includes `model.glb`, `reference.glb`, `recipe.json`, and `audit.json`. Existing output folders are refused. In the editor, building and publishing are separate actions. A revision with the same stable model ID preserves world object IDs and transforms.

## Supported authoring

`seedwork.recipe/1` is the preferred envelope. `ai3d.recipe/1` is accepted for the supported data subset only. Eight primitives are available: box, cylinder, ellipsoid, torus, bowl, lathe, hose and plate. Dimensions, transforms, UV scale, bevels where supported, lathe profiles and hose control points are validated. The authoritative closed field schemas are `modeler/schema.mjs`; unknown options are errors.

Materials support wood, stone, steel, paint, concrete, solid and image families. Color, normal and packed occlusion/roughness/metalness PNG maps can be supplied. Supported PNGs are non-interlaced 8-bit grayscale, RGB or fully opaque RGBA. Full-surface maps must match the selected authoring resolution; no automatic resizing or lossy recompression is applied. Height-to-normal baking is an explicit authoring operation, not byte-preserving conversion.

Standalone recipes reference files as content hashes. Put each uploaded source PNG at `inputs/<sha256>.png` beside the recipe or plan. Existing editor upload controls populate the managed store. CRC, dimensions and source hashes are checked; missing maps fail. Do not write arbitrary filesystem paths or URLs into a recipe.

Limits include 192 parts, 32 materials, 80,000 triangles, 100 m total extent, 24 MiB GLB size and powers-of-two authoring maps from 64 to 2048 pixels. Those limits are guardrails, not performance guarantees.

## Quality contract

The reference and compacted GLBs preserve triangle order/winding and triangle-corner POSITION, NORMAL, TANGENT and UV attributes. Materials, image bytes, samplers, hierarchy and transforms are included in the exact signature. Compaction welds only identical attributes; it does not merge a normal or UV seam just because two positions match. Failure aborts the build.

Procedural maps and all geometry are deterministic for the same recipe/compiler fingerprint. Material caching keys include the source version and input data. Shared geometry and material reuse avoid duplicating identical representations. No automatic mesh simplification, texture resizing or lower-quality fallback is present.

The seven new starters define a **new authored baseline**. The audit does not claim to preserve the old excluded compiler's output. Bitmap equality in a controlled browser is additional evidence, not a cross-GPU promise. Snow, reflections and host lighting are runtime effects, not part of static GLB authoring.

## Explicit exclusions

Legacy stamps, sculpt brushes, decal layers, arbitrary scripts, animation, skeletons, neural generation and unsupported shape parameters are rejected. This is not full feature parity with the removed kit. Old static GLBs may still be imported when they satisfy the editor's format validation and the user has appropriate rights.
