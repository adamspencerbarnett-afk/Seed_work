# Seedwork agent contract

Read `seedwork-capabilities.json` first. It states the actual version, supported compiler subset and missing advanced-water archive. `tools.manifest.json` is generated from the source catalog, not a wish list. Project credit is Adam S. Barnett; third-party ownership and notices remain separate.

Use `node seedwork.mjs context`, `schema`, `tools` and `doctor` to inspect the package. The engine has no embedded LLM, internet model service or automatic remote connection. File-based plan generation is the default handoff; use a live API only when it is actually reachable with explicit authorization.

## Working order

Establish the game type, player camera, setting, core action, target hardware and acceptance criteria. Propose a small first playable milestone. Search existing templates and assets before generating replacements. Edit semantic world/model data through validated tools wherever possible. Keep existing gameplay code and source files unless the requested change requires them to change.

For file-based authoring, create `seedwork.plan/1` using the schema returned by the CLI. Models can name a bundled template or contain a full supported recipe. User PNG inputs must be content-addressed files in an `inputs` directory next to the plan/recipe. Plans cannot run scripts, read arbitrary paths or download assets. `new` copies a clean application and writes the generated project atomically to a new folder. It never overwrites an existing project.

For the live world, inspect the current revision and use `_rev` and a stable `_key` in MCP writes, or `rev` and `key` in HTTP requests. A retry after a timeout keeps the same key. A conflict requires a new inspection, not a blind retry against the latest revision. Ordinary changes can use `world_batch`. Models build separately and publish only after inspection. For embedded projects, use project_inspect, asset_search, change_begin/apply/preview, named scene tests/capture, local human approval, and change_commit. Never fabricate approval evidence.

## Code changes

Keep the reusable core, host adapter, authoring service and UI separate. The host owns its renderer, camera, inputs, clock and physics. Pass dependencies explicitly; dispose only owned resources. Runtime exports must not contain authoring tokens or require the modeling service. Use named functions with simple names and complete replacement files; do not introduce placeholders or silent fallbacks.

Keep model recipes as editable source and GLB as a compiled runtime artifact. The new Node compiler accepts eight static primitives and the documented PBR fields. Reject unsupported legacy sculpt/stamp/decal fields rather than ignoring them. Do not load recipe text as JavaScript or shell commands. Never re-add the excluded user-supplied kit without verified redistribution permission.

## Quality and verification

Treat a visual authoring change as a new candidate, not a lossless optimization. Preserve accepted detail, resolution and maps during optimization. The compiler compares exact rendering-data signatures before publishing compacted assets. Browser equality is a finite test in a controlled environment; frame rates need target-hardware measurements.

Run `node scripts/test.mjs`. Run optional browser/type tests when their tools are actually available. Record commands, results, warnings and unrun checks. Use a freshly extracted release for the final launch test. Verify updated version metadata, tool manifests, dependency notices, source hashes, generated starter provenance and example asset references. Release assembly is `node scripts/release.mjs`; never package `.seedwork`, credentials, caches, virtual environments, node_modules, model inputs belonging to another user, or unrelated files.

## Delivery

Return the complete updated project or a complete portable world-and-assets bundle as requested, plus a short change/test/limitations report. Do not claim the ZIP was published on GitHub unless a real release action succeeded. Do not claim that ChatGPT connected to localhost or that an image was rendered unless the corresponding tool actually ran. Explain that Node.js and a browser are separately installed runtimes, while the application itself has no required package downloads.
