import { Fault, stable, copy } from './core/schema.mjs';
import { sha256 } from './glb.mjs';
export { createObserver, Observer } from './observe.mjs';

export class DevLink {
  constructor({ runtime, observer, project, name = 'Three.js game', base = '', token, fetch: get = globalThis.fetch, onStatus = () => {} }) {
    if (!runtime || !observer || !project || typeof token !== 'string' || !token) throw new Fault('CONTRACT', 'Runtime, observer, project ID and explicit local authoring token are required.');
    this.runtime = runtime; this.observer = observer; this.project = project; this.name = name;
    this.base = base.replace(/\/$/, ''); this.token = token; this.get = (...args) => get(...args); this.onStatus = onStatus;
    this.abort = new AbortController(); this.id = null; this.secret = null; this.running = null; this.closed = false;
  }

  status(state, detail = '') { try { this.onStatus({ state, detail, id: this.id }); } catch {} }

  async api(path, data, secret, signal = this.abort.signal) {
    const response = await this.get(`${this.base}${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${secret}` }, body: JSON.stringify(data), signal });
    const out = await response.json();
    if (!response.ok) throw new Fault(out.code ?? 'HTTP', out.error ?? `Request failed (${response.status}).`, out.details ?? {}, response.status);
    return out;
  }

  async open() {
    if (this.closed || this.id) throw new Fault('STATE', 'Create a new link to reconnect.');
    const out = await this.api('/api/host/open', { project: this.project, name: this.name, three: String(this.runtime.T.REVISION), tests: Object.keys(this.observer.tests), capabilities: ['capture', 'query', 'profile', 'test'] }, this.token);
    this.id = out.id; this.secret = out.token; this.token = null;
    this.status('connected');
    this.running = this.loop();
    return { id: this.id };
  }

  async loop() {
    try {
      while (!this.closed) {
        const command = await this.api('/api/host/next', { id: this.id }, this.secret);
        if (!command) continue;
        let result, error;
        try { result = await this.run(command); }
        catch (e) { error = { code: e.code ?? 'HOST_ERROR', message: e.message }; this.status('command-error', e.message); }
        if (this.closed) break;
        try { await this.api('/api/host/done', { id: this.id, command: command.id, ...(error ? { error } : { result }) }, this.secret); }
        catch (e) { if (e.status !== 410 && e.code !== 'STALE_EVIDENCE') throw e; this.status('command-expired', e.message); }
      }
    } catch (e) { if (!this.closed) { this.status('disconnected', e.message); this.closed = true; } }
  }

  async run(command) {
    this.status('running', command.method);
    let result;
    if (['sync', 'preview', 'reset'].includes(command.method)) {
      const { doc, meta } = command.args;
      const hash = await sha256(new TextEncoder().encode(stable(doc)));
      if (hash !== meta.hash || meta.project !== this.project) throw new Fault('HASH_MISMATCH', 'Scene snapshot does not match its advertised project and hash.');
      await this.runtime.setScene(doc, meta);
      result = { meta: copy(this.runtime.meta), runtime: this.runtime.inspect() };
    } else if (command.method === 'capture') result = await this.observer.capture({ signal: this.abort.signal });
    else if (command.method === 'query') result = this.observer.query(command.args.query ?? {});
    else if (command.method === 'profile') result = this.observer.profile();
    else if (command.method === 'test') result = await this.observer.test(command.args.test, { signal: this.abort.signal });
    else throw new Fault('UNSUPPORTED', `Unsupported host command: ${command.method}.`);
    this.status('connected', command.method);
    return result;
  }

  async close() {
    if (!this.closed) this.closed = true;
    this.abort.abort();
    if (this.id && this.secret) {
      try { await this.api('/api/host/close', { id: this.id }, this.secret, AbortSignal.timeout(2000)); } catch {}
    }
    await this.running;
    this.status('detached'); this.secret = null;
  }
}

export const connect = async options => {
  const link = new DevLink(options);
  await link.open();
  return link;
};
