# @seedwork/runtime 0.7.0

Local zero-dependency ESM toolkit for static content in an existing Three.js game. Pass the host's Three namespace, parent group and asset loader. Seedwork does not create a renderer, camera, input system or animation loop. No Three distribution, model compiler, assets, credentials or fonts are included in this SDK folder.

Main entry: `index.mjs`. Optional authoring connection: `dev.mjs`. TypeScript declarations: `index.d.mts` and `dev.d.mts`. The host owns its own compatible Three/GLTFLoader. Only Three.js r140 was exercised in this release; compatibility with other versions must be tested.

```js
import { createRuntime, createGlbLoader } from './index.mjs';

export async function loadScene({ THREE, Loader, parent, scene, assetUrl }) {
  const runtime = createRuntime({
    THREE,
    parent,
    load: createGlbLoader({ Loader, url: assetUrl })
  });
  try {
    await runtime.setScene(scene);
    return runtime;
  } catch (error) {
    await runtime.dispose();
    throw error;
  }
}
```

`scene` must be a valid `seedwork.scene/1` document, and `assetUrl(hash)` must resolve a self-contained static GLB whose SHA-256 matches the approved hash. The default loader does not resize, normalize, remesh or enable unsupported extensions. It rejects unsupported content instead of silently degrading it. Localhost or HTTPS is required for browser WebCrypto.

A custom loader returns `{root, dispose}` for owned assets or `{root}` for borrowed resources. Repeated placements share source geometry/materials/textures. Do not modify a shared material in one item unless the change is intended for all its users. Resource reuse is not a draw-call instancing claim. Call `runtime.dispose()` when detaching, not the host renderer's dispose method.

The optional development entry requires the full local Seedwork authoring server. It adds registered host commands, after-frame observation and named host tests; it is not an AI provider. The shipped game needs only the runtime entry and its normal host code/assets.

See the full distribution's `docs/EMBEDDING.md` for a complete authoring attach/cleanup function and host semantics/collision contracts. The SDK is MIT licensed under its own `LICENSE`. It does not confer rights to user-supplied models or third-party assets.
