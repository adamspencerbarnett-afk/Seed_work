import { Fault, copy, stable, jsonSafe } from './core/schema.mjs';
import { checkScene, queryScene, sceneDiff, emptyScene } from './core/scene.mjs';

class Pool {
  constructor(load) { this.load = load; this.entries = new Map(); this.loads = 0; this.hits = 0; this.errors = []; }

  acquire(asset) {
    let entry = this.entries.get(asset.hash);
    if (entry) { entry.refs++; this.hits++; return entry; }
    entry = { hash: asset.hash, refs: 1, abort: new AbortController(), value: null, freed: false };
    this.entries.set(asset.hash, entry); this.loads++;
    entry.ready = Promise.resolve().then(() => this.load(copy(asset), { signal: entry.abort.signal })).then(value => {
      entry.value = value;
      if (!value?.root?.isObject3D || (value.dispose !== undefined && typeof value.dispose !== 'function')) { this.free(entry); throw new Fault('ASSET_CONTRACT', 'Asset loader must return {root: Object3D, dispose?: function}.'); }
      entry.value = value;
      let invalid = null;
      value.root.traverse(node => { if (node.isSkinnedMesh || node.morphTargetInfluences?.length) invalid = new Fault('UNSUPPORTED', 'The static runtime does not clone rigs or morph animation.'); });
      if (invalid) { this.free(entry); throw invalid; }
      if (!entry.refs) this.free(entry);
      return value.root;
    }).catch(error => {
      if (this.entries.get(asset.hash) === entry) this.entries.delete(asset.hash);
      throw error;
    });
    return entry;
  }

  release(entry) {
    if (entry.refs <= 0) return;
    entry.refs--;
    if (!entry.refs) {
      if (this.entries.get(entry.hash) === entry) this.entries.delete(entry.hash);
      entry.abort.abort();
      this.free(entry);
    }
  }

  free(entry) {
    if (!entry.value || entry.freed) return;
    entry.freed = true;
    try { if (typeof entry.value.dispose === 'function') entry.value.dispose(); } catch (e) { this.errors.push(String(e.message ?? e)); }
  }

  abort() { for (const entry of this.entries.values()) if (!entry.value) entry.abort.abort(); }
}

export class Runtime {
  constructor({ THREE, parent, load }) {
    if (!THREE?.Group || !parent?.isObject3D || typeof load !== 'function') throw new Fault('CONTRACT', 'Pass the host THREE namespace, parent Object3D and an asset loader.');
    this.T = THREE;
    this.parent = parent;
    this.root = new THREE.Group(); this.root.name = 'Seedwork content';
    this.parent.add(this.root);
    this.pool = new Pool(load);
    this.nodes = new Map(); this.leases = [];
    this.doc = emptyScene(); this.meta = null;
    this.seq = 0; this.closed = false; this.tasks = new Set(); this.plans = new Set(); this.listeners = new Set();
    this.metrics = { applies: 0, created: 0, replaced: 0, transforms: 0, removed: 0 };
  }

  async setScene(doc, meta = null) {
    if (this.closed) throw new Fault('DISPOSED', 'The runtime is detached. Create a new runtime to attach again.');
    checkScene(doc); if (meta !== null) jsonSafe(meta);
    const input = copy(doc), tag = copy(meta), seq = ++this.seq;
    const task = this.apply(input, tag, seq);
    this.tasks.add(task);
    try { return await task; } finally { this.tasks.delete(task); }
  }

  async apply(doc, meta, seq) {
    const assets = [...new Map(doc.items.map(item => [doc.assets[item.asset].hash, doc.assets[item.asset]])).values()];
    const leases = assets.map(asset => this.pool.acquire(asset));
    const plan = { leases, released: false };
    for (const prior of this.plans) if (!prior.released) { for (const entry of prior.leases) this.pool.release(entry); prior.released = true; }
    this.plans.add(plan);
    let committed = false;
    try {
      const loaded = await Promise.allSettled(leases.map(entry => entry.ready));
      if (this.closed || seq !== this.seq) throw new Fault('SUPERSEDED', 'A newer scene load or detach superseded this request.');
      const failed = loaded.find(result => result.status === 'rejected');
      if (failed) throw failed.reason;
      const roots = new Map(leases.map((entry, i) => [entry.hash, loaded[i].value]));
      const prepared = new Map();
      for (const item of doc.items) {
        const previous = this.nodes.get(item.id), hash = doc.assets[item.asset].hash;
        const child = !previous || previous.hash !== hash ? roots.get(hash).clone(true) : null;
        const group = previous?.group ?? new this.T.Group();
        prepared.set(item.id, { group, child, hash, previous, item });
      }
      const diff = sceneDiff(this.doc, doc), counts = { created: 0, replaced: 0, transforms: 0, removed: 0 };
      for (const [id, old] of this.nodes) if (!prepared.has(id)) { this.root.remove(old.group); counts.removed++; }
      const next = new Map();
      for (const [id, p] of prepared) {
        const { group, previous, item, hash } = p;
        if (p.child) {
          if (previous?.child) group.remove(previous.child);
          group.add(p.child);
          counts[previous ? 'replaced' : 'created']++;
        }
        if (!previous) this.root.add(group);
        if (!previous || ['pos', 'rot', 'scale'].some(key => stable(item[key]) !== stable(previous.item[key]))) {
          group.position.fromArray(item.pos);
          group.rotation.set(...item.rot.map(v => v * Math.PI / 180), 'XYZ');
          group.scale.setScalar(item.scale); group.updateMatrix();
          group.matrixAutoUpdate = false; group.matrixWorldNeedsUpdate = true; counts.transforms++;
        }
        group.name = item.name;
        group.userData.seedwork = { id, asset: item.asset, tags: [...item.tags], bindings: copy(item.bindings) };
        next.set(id, { group, child: p.child ?? previous.child, hash, item });
      }
      const old = this.leases;
      this.nodes = next; this.leases = leases; this.doc = doc; this.meta = meta;
      committed = true;
      for (const entry of old) this.pool.release(entry);
      this.metrics.applies++;
      for (const [key, value] of Object.entries(counts)) this.metrics[key] += value;
      const warnings = [];
      for (const fn of this.listeners) { try { fn({ diff: copy(diff), meta: copy(meta) }); } catch (e) { warnings.push(String(e.message ?? e)); } }
      return { diff, counts, warnings, meta: copy(meta) };
    } finally { this.plans.delete(plan); if (!committed && !plan.released) for (const entry of leases) this.pool.release(entry); }
  }

  get(id) { return this.nodes.get(id)?.group ?? null; }
  snapshot() { return { doc: copy(this.doc), meta: copy(this.meta) }; }
  subscribe(fn) { if (this.closed || typeof fn !== 'function') throw new Fault('CONTRACT', 'A live runtime and listener function are required.'); this.listeners.add(fn); return () => this.listeners.delete(fn); }

  query(query = {}) {
    const result = queryScene(this.doc, query);
    this.root.updateWorldMatrix(true, true);
    return { meta: copy(this.meta), ...result, items: result.items.map(item => ({ ...item, matrixWorld: this.get(item.id).matrixWorld.toArray() })) };
  }

  inspect() {
    return { ...this.metrics, objects: this.nodes.size, cachedAssets: this.pool.entries.size, assetLoads: this.pool.loads, assetHits: this.pool.hits, disposalErrors: [...this.pool.errors], three: String(this.T.REVISION), closed: this.closed };
  }

  async dispose() {
    if (!this.closed) {
      this.closed = true; this.seq++; this.parent.remove(this.root); this.listeners.clear();
      for (const entry of this.leases) this.pool.release(entry);
      this.leases = []; this.nodes.clear(); this.root.clear(); this.pool.abort();
    }
    await Promise.allSettled([...this.tasks]);
  }
}

export const createRuntime = options => new Runtime(options);
