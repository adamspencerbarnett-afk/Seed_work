import { Fault, copy, jsonSafe } from './core/schema.mjs';

const stats = values => {
  const list = values.filter(Number.isFinite).sort((a, b) => a - b);
  if (!list.length) return null;
  const at = p => list[Math.min(list.length - 1, Math.floor(p * (list.length - 1)))];
  return { samples: list.length, min: list[0], p50: at(.5), p95: at(.95), max: list.at(-1) };
};

export class Observer {
  constructor({ runtime, renderer, camera, entities = () => [], tests = {}, maxFrames = 240 }) {
    if (!runtime || !renderer?.domElement || !camera) throw new Fault('CONTRACT', 'Observer requires the host runtime, renderer and camera.');
    if (!Number.isInteger(maxFrames) || maxFrames < 2 || maxFrames > 2000) throw new Fault('CONTRACT', 'maxFrames must be 2–2000.');
    this.runtime = runtime; this.renderer = renderer; this.camera = typeof camera === 'function' ? camera : () => camera;
    this.entities = entities; this.tests = tests; this.maxFrames = maxFrames;
    this.frames = []; this.pending = []; this.closed = false; this.last = null;
  }

  afterFrame({ time = performance.now(), cpuMs = null } = {}) {
    if (this.closed) return;
    if (!Number.isFinite(time) || (cpuMs !== null && (!Number.isFinite(cpuMs) || cpuMs < 0))) throw new Fault('INVALID', 'Frame timings must be finite, with nonnegative CPU work.');
    const info = this.renderer.info;
    this.frames.push({ intervalMs: this.last === null ? null : Math.max(0, time - this.last), cpuMs, calls: info?.render?.calls ?? null, triangles: info?.render?.triangles ?? null });
    this.last = time;
    if (this.frames.length > this.maxFrames) this.frames.shift();
    for (const request of this.pending.splice(0)) {
      request.clean();
      try {
        const canvas = this.renderer.domElement;
        if (canvas.width * canvas.height > 16777216) throw new Fault('CAPTURE_LIMIT', 'Canvas exceeds 16 megapixels. Choose a smaller host viewport explicitly; capture never resizes it.');
        const camera = this.camera(); camera.updateMatrixWorld(true);
        const data = canvas.toDataURL('image/png').split(',')[1];
        if (!data || data.length > 12 * 1024 * 1024) throw new Fault('CAPTURE_LIMIT', 'PNG capture exceeds the transfer limit. No downscaling was applied.');
        request.resolve({ meta: copy(this.runtime.meta), image: { data, mimeType: 'image/png', width: canvas.width, height: canvas.height }, camera: { type: camera.type, matrixWorld: camera.matrixWorld.toArray(), projection: camera.projectionMatrix.toArray(), near: camera.near, far: camera.far }, conditions: { three: String(this.runtime.T.REVISION), exposure: this.renderer.toneMappingExposure, toneMapping: this.renderer.toneMapping, output: this.renderer.outputColorSpace ?? this.renderer.outputEncoding, time, pixelRatio: this.renderer.getPixelRatio(), note: 'Captured after the host final render; no extra render or pixel resize.' } });
      } catch (e) { request.reject(e); }
    }
  }

  capture({ signal } = {}) {
    if (this.closed) return Promise.reject(new Fault('DISPOSED', 'Observer is detached.'));
    if (signal?.aborted) return Promise.reject(new Fault('CANCELLED', 'Capture cancelled.'));
    if (this.pending.length >= 2) return Promise.reject(new Fault('BUSY', 'Two captures are already waiting for a host frame.'));
    return new Promise((resolve, reject) => {
      const request = { resolve, reject };
      const fail = error => { request.clean(); this.pending = this.pending.filter(v => v !== request); reject(error); };
      const cancel = () => fail(new Fault('CANCELLED', 'Capture cancelled.'));
      request.clean = () => { clearTimeout(request.timer); signal?.removeEventListener('abort', cancel); };
      request.timer = setTimeout(() => fail(new Fault('NO_FRAME', 'The host did not render within 10 seconds. Call observer.afterFrame after the final render.')), 10000);
      signal?.addEventListener('abort', cancel, { once: true });
      this.pending.push(request);
    });
  }

  query(query = {}) {
    const external = this.entities(); jsonSafe(external);
    if (!Array.isArray(external) || external.length > 200 || JSON.stringify(external).length > 128 * 1024) throw new Fault('HOST_CONTRACT', 'Registered entity metadata must be an array of at most 200 bounded JSON entries.');
    return { ...this.runtime.query(query), external: copy(external) };
  }

  profile() {
    const info = this.renderer.info;
    return { meta: copy(this.runtime.meta), frames: this.frames.length, frameIntervalMs: stats(this.frames.map(f => f.intervalMs)), cpuWorkMs: stats(this.frames.map(f => f.cpuMs)), drawCalls: stats(this.frames.map(f => f.calls)), triangles: stats(this.frames.map(f => f.triangles)), resources: { geometries: info?.memory?.geometries ?? null, textures: info?.memory?.textures ?? null, programs: info?.programs?.length ?? null }, runtime: this.runtime.inspect(), gpuMs: null, vramBytes: null, note: 'Frame interval includes scheduling. CPU work is host-supplied. Draw counts use the host renderer.info reset policy. Resource counts are not bytes. No GPU timer is installed.' };
  }

  async test(name, { signal } = {}) {
    if (!Object.hasOwn(this.tests, name) || typeof this.tests[name] !== 'function') throw new Fault('UNSUPPORTED', `Host test is not registered: ${name}.`);
    if (this.testRun) throw new Fault('BUSY', 'A host test is still running. Test hooks must honor cancellation and restore state.');
    const before = copy(this.runtime.meta);
    const abort = new AbortController();
    const cancel = () => abort.abort();
    if (signal?.aborted) abort.abort();
    signal?.addEventListener('abort', cancel, { once: true });
    let timer;
    const deadline = new Promise((_, reject) => {
      const stop = () => reject(new Fault('CANCELLED', 'Host test was cancelled.'));
      abort.signal.addEventListener('abort', stop, { once: true });
      if (abort.signal.aborted) stop();
      timer = setTimeout(() => { reject(new Fault('TEST_TIMEOUT', 'Host test exceeded 10 seconds. No evidence accepted.')); abort.abort(); }, 10000);
    });
    const run = Promise.resolve().then(() => { if (abort.signal.aborted) throw new Fault('CANCELLED', 'Host test cancelled.'); return this.tests[name]({ runtime: this.runtime, signal: abort.signal }); });
    this.testRun = run;
    run.then(() => { if (this.testRun === run) this.testRun = null; }, () => { if (this.testRun === run) this.testRun = null; });
    let result;
    try { result = await Promise.race([run, deadline]); }
    finally { clearTimeout(timer); signal?.removeEventListener('abort', cancel); }

    jsonSafe(result);
    if (!result || typeof result.passed !== 'boolean' || !Array.isArray(result.checks) || result.checks.length > 100 || JSON.stringify(result).length > 64 * 1024) throw new Fault('HOST_CONTRACT', 'A test returns {passed:boolean, checks:array} under 64 KiB.');
    if (JSON.stringify(before) !== JSON.stringify(this.runtime.meta)) throw new Fault('STALE_EVIDENCE', 'Scene changed while a host test was running.');
    return { ...copy(result), test: name, meta: before };
  }

  dispose() {
    this.closed = true;
    for (const request of this.pending.splice(0)) { request.clean(); request.reject(new Fault('DISPOSED', 'Observer detached before the frame capture.')); }
    this.frames = [];
  }
}

export const createObserver = options => new Observer(options);
