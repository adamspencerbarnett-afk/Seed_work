export type Vec = [number, number, number];
export type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
export interface Socket { pos: Vec; rot: Vec; }
export interface Asset { hash: string; name: string; size: Vec; boxes: [Vec, Vec][]; tags: string[]; sockets: Record<string, Socket>; source?: Record<string, Json>; }
export interface Item { id: string; name: string; asset: string; pos: Vec; rot: Vec; scale: number; tags: string[]; bindings: Record<string, string>; }
export interface Scene { schema: 'seedwork.scene/1'; name: string; assets: Record<string, Asset>; items: Item[]; }
export interface Meta { project: string; rev: number; change: string | null; seq: number | null; hash: string; }
export interface Query { q?: string; ids?: string[]; tags?: string[]; bounds?: [Vec, Vec]; offset?: number; limit?: number; }
export interface QueryResult { total: number; items: Item[]; next: number | null; }
export interface Diff { added: string[]; removed: string[]; changed: { id: string; fields: string[] }[]; assets: string[]; affected: string[]; count: number; }
export type Patch = Partial<Pick<Item, 'name' | 'asset' | 'pos' | 'rot' | 'scale' | 'tags'>>;
export type Op =
  | { op: 'asset_use'; key: string; ref: string }
  | { op: 'asset_socket'; asset: string; name: string; pos: Vec; rot: Vec }
  | ({ op: 'item_add'; id: string; asset: string; pos: Vec } & Partial<Omit<Item, 'id' | 'asset' | 'pos'>>)
  | { op: 'item_set'; id: string; patch: Patch }
  | { op: 'item_remove'; id: string }
  | { op: 'bind_set'; id: string; slot: string; target: string }
  | { op: 'item_snap'; id: string; socket: string; to: string; targetSocket: string }
  | { op: 'items_path'; asset: string; prefix: string; path: Vec[]; count: number; scale?: number; yaw?: number; orient?: boolean; tags?: string[] };
export interface Policy { locked?: string[]; bounds?: [Vec, Vec]; bindings?: string[]; }
export interface Node { readonly isObject3D: boolean; uuid: string; name: string; parent: Node | null; children: Node[]; add(...objects: Node[]): unknown; remove(...objects: Node[]): unknown; traverse(fn: (node: Node) => void): unknown; clone(recursive?: boolean): Node; updateMatrixWorld(force?: boolean): unknown; updateWorldMatrix(updateParents: boolean, updateChildren: boolean): unknown; }
export interface Three { REVISION: string; Group: new () => Node; }
export interface Loaded { root: Node; dispose?: () => void; }
export type Load = (asset: Asset, options: { signal: AbortSignal }) => Promise<Loaded>;
export interface Counts { created: number; replaced: number; transforms: number; removed: number; }
export interface Metrics extends Counts { applies: number; objects: number; cachedAssets: number; assetLoads: number; assetHits: number; disposalErrors: string[]; three: string; closed: boolean; }
export interface Applied { diff: Diff; counts: Counts; warnings: string[]; meta: Meta | null; }
export interface RuntimeOptions { THREE: Three; parent: Node; load: Load; }
export class Runtime {
  constructor(options: RuntimeOptions);
  readonly T: Three;
  readonly root: Node;
  readonly parent: Node;
  readonly closed: boolean;
  readonly meta: Meta | null;
  setScene(scene: Scene, meta?: Meta | null): Promise<Applied>;
  snapshot(): { doc: Scene; meta: Meta | null };
  get(id: string): Node | null;
  query(query?: Query): QueryResult & { meta: Meta | null; items: (Item & { matrixWorld: number[] })[] };
  subscribe(fn: (event: { diff: Diff; meta: Meta | null }) => void): () => void;
  inspect(): Metrics;
  dispose(): Promise<void>;
}
export interface GltfLoader { parse(data: ArrayBuffer, path: string, done: (value: { scene: Node }) => void, error: (error: unknown) => void): unknown; }
export interface GlbOptions { Loader: new () => GltfLoader; url?: (hash: string) => string; fetch?: typeof globalThis.fetch; timeout?: number; shadows?: boolean; }
export function createRuntime(options: RuntimeOptions): Runtime;
export function createGlbLoader(options: GlbOptions): Load;
export function disposeTree(root: Node): void;
export function sha256(bytes: BufferSource): Promise<string>;
export function emptyScene(name?: string): Scene;
export function checkScene(scene: unknown): Scene;
export function applyOps(scene: Scene, ops: Op[], options?: { resolveAsset?: (ref: string) => Asset | undefined; policy?: Policy }): { doc: Scene; results: Record<string, Json>[] };
export function queryScene(scene: Scene, query?: Query): QueryResult;
export function sceneDiff(before: Scene, after: Scene): Diff;
export class Fault extends Error { constructor(code: string, message: string, details?: Record<string, unknown>, status?: number); code: string; details: Record<string, unknown>; status: number; }
