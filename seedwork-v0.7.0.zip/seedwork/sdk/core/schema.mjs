export class Fault extends Error {
  constructor(code, message, details = {}, status = 400) {
    super(message);
    this.name = 'SeedworkError';
    this.code = code;
    this.details = details;
    this.status = status;
  }
}

export const obj = (properties, required = []) => ({ type: 'object', properties, required, additionalProperties: false });
export const str = (maxLength = 80) => ({ type: 'string', minLength: 1, maxLength });
export const num = (minimum = -10000, maximum = 10000) => ({ type: 'number', minimum, maximum });
export const int = (minimum = 0, maximum = 1e9) => ({ type: 'integer', minimum, maximum });
export const arr = (items, minItems = 0, maxItems = 256) => ({ type: 'array', items, minItems, maxItems });
export const choice = values => ({ type: 'string', enum: values });
export const bool = { type: 'boolean' };
export const id = { ...str(64), pattern: '^[a-zA-Z][a-zA-Z0-9_.-]{0,63}$' };
export const hash = { type: 'string', pattern: '^[a-f0-9]{64}$' };
export const vec = (min = -10000, max = 10000) => arr(num(min, max), 3, 3);
export const copy = value => structuredClone(value);
export const stable = value => JSON.stringify(order(value));

function order(value) {
  if (Array.isArray(value)) return value.map(order);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(k => [k, order(value[k])]));
  return value;
}

export function jsonSafe(value, depth = 0) {
  if (depth > 32) throw new Fault('LIMIT', 'JSON nesting exceeds 32 levels.');
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
  if (typeof value === 'number' && Number.isFinite(value)) return;
  if (!value || typeof value !== 'object') throw new Fault('INVALID', 'Expected finite JSON data.');
  if (!Array.isArray(value) && ![Object.prototype, null].includes(Object.getPrototypeOf(value))) throw new Fault('INVALID', 'Expected a plain JSON object.');
  for (const [k, v] of Object.entries(value)) {
    if (['__proto__', 'constructor', 'prototype'].includes(k)) throw new Fault('INVALID', `Reserved JSON key: ${k}.`);
    jsonSafe(v, depth + 1);
  }
}

export function validate(value, rule, path = 'arguments') {
  const fail = message => { throw new Fault('INVALID', `${path} ${message}.`); };
  if (rule.anyOf) {
    const errors = [];
    for (const child of rule.anyOf) {
      try { validate(value, child, path); return value; } catch (e) { errors.push(e.message); }
    }
    throw new Fault('INVALID', `${path} does not match a supported operation.`, { alternatives: errors });
  }
  if (rule.const !== undefined && value !== rule.const) fail(`must equal ${rule.const}`);
  if (rule.enum && !rule.enum.includes(value)) fail('is not a supported value');
  if (rule.type === 'object') {
    if (!value || typeof value !== 'object' || Array.isArray(value)) fail('must be an object');
    if (rule.maxProperties !== undefined && Object.keys(value).length > rule.maxProperties) fail('has too many fields');
    for (const k of rule.required ?? []) if (!Object.hasOwn(value, k)) fail(`requires ${k}`);
    for (const [k, v] of Object.entries(value)) {
      if (['__proto__', 'constructor', 'prototype'].includes(k)) fail('contains a reserved key');
      if (rule.propertyNames) validate(k, rule.propertyNames, `${path} key`);
      if (Object.hasOwn(rule.properties ?? {}, k)) validate(v, rule.properties[k], `${path}.${k}`);
      else if (rule.additionalProperties === false) fail(`contains unknown field ${k}`);
      else if (rule.additionalProperties && typeof rule.additionalProperties === 'object') validate(v, rule.additionalProperties, `${path}.${k}`);
    }
  } else if (rule.type === 'array') {
    if (!Array.isArray(value)) fail('must be an array');
    if (value.length < (rule.minItems ?? 0) || value.length > (rule.maxItems ?? Infinity)) fail('has an invalid length');
    if (rule.uniqueItems && new Set(value.map(stable)).size !== value.length) fail('must have unique entries');
    value.forEach((v, i) => validate(v, rule.items ?? {}, `${path}[${i}]`));
  } else if (rule.type === 'number' || rule.type === 'integer') {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < (rule.minimum ?? -Infinity) || value > (rule.maximum ?? Infinity) || (rule.type === 'integer' && !Number.isInteger(value))) fail('is outside its numeric limits');
  } else if (rule.type === 'string') {
    if (typeof value !== 'string' || value.length < (rule.minLength ?? 0) || value.length > (rule.maxLength ?? Infinity) || (rule.pattern && !new RegExp(rule.pattern).test(value))) fail('is not a supported string value');
  } else if (rule.type === 'boolean' && typeof value !== 'boolean') fail('must be boolean');
  return value;
}
