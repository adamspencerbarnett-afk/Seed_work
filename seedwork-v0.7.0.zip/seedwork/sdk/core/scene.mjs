import { Fault, obj, str, num, int, arr, choice, id, hash, vec, bool, copy, stable, validate, jsonSafe } from './schema.mjs';
import { bounds, snapPose, atPath } from './math.mjs';

const tags = { ...arr(str(40), 0, 24), uniqueItems: true };
const map = (values, maxProperties) => ({ type: 'object', additionalProperties: values, propertyNames: id, maxProperties });
export const SOCKET = obj({ pos: vec(), rot: vec(-36000, 36000) }, ['pos', 'rot']);
export const ASSET = obj({
  hash, name: str(), size: vec(.000001, 1000), boxes: arr(arr(vec(-1000, 1000), 2, 2), 1, 192),
  tags, sockets: map(SOCKET, 32), source: { type: 'object', maxProperties: 8 }
}, ['hash', 'name', 'size', 'boxes', 'tags', 'sockets']);
const fields = { name: str(), asset: id, pos: vec(), rot: vec(-36000, 36000), scale: num(.001, 100), tags };
export const ITEM = obj({ id, ...fields, bindings: map(id, 16) }, ['id', 'asset', 'name', 'pos', 'rot', 'scale', 'tags', 'bindings']);
export const SCENE = obj({ schema: { const: 'seedwork.scene/1' }, name: str(), assets: map(ASSET, 128), items: arr(ITEM, 0, 2000) }, ['schema', 'name', 'assets', 'items']);
const op = (name, properties, required = []) => obj({ op: { const: name }, ...properties }, ['op', ...required]);
export const OP = { anyOf: [
  op('asset_use', { key: id, ref: id }, ['key', 'ref']),
  op('asset_socket', { asset: id, name: id, ...SOCKET.properties }, ['asset', 'name', 'pos', 'rot']),
  op('item_add', { ...ITEM.properties }, ['id', 'asset', 'pos']),
  op('item_set', { id, patch: obj(fields) }, ['id', 'patch']),
  op('item_remove', { id }, ['id']),
  op('bind_set', { id, slot: id, target: id }, ['id', 'slot', 'target']),
  op('item_snap', { id, socket: id, to: id, targetSocket: id }, ['id', 'socket', 'to', 'targetSocket']),
  op('items_path', { asset: id, prefix: { ...id, maxLength: 48 }, path: arr(vec(), 2, 64), count: int(2, 128), scale: num(.001, 100), yaw: num(-36000, 36000), orient: bool, tags }, ['asset', 'prefix', 'path', 'count'])
] };
export const OPS = arr(OP, 1, 128);
export const QUERY = obj({ q: { type: 'string', maxLength: 120 }, ids: arr(id, 0, 100), tags, bounds: arr(vec(), 2, 2), offset: int(0, 100000), limit: int(1, 100) });

export function emptyScene(name = 'Connected scene') {
  return { schema: 'seedwork.scene/1', name, assets: {}, items: [] };
}

export function checkScene(doc) {
  jsonSafe(doc);
  validate(doc, SCENE, 'scene');
  if (stable(doc).length > 4 * 1024 * 1024) throw new Fault('LIMIT', 'Scene exceeds 4 MiB. Split it into smaller authoring regions.');
  const ids = new Set();
  for (const item of doc.items) {
    if (ids.has(item.id)) throw new Fault('DUPLICATE', `Item ID already exists: ${item.id}.`);
    ids.add(item.id);
    if (!Object.hasOwn(doc.assets, item.asset)) throw new Fault('MISSING_ASSET', `Item ${item.id} references missing asset ${item.asset}.`);
  }
  for (const [key, asset] of Object.entries(doc.assets)) for (const box of asset.boxes) {
    if (box[0].some((v, i) => v > box[1][i])) throw new Fault('INVALID', `Inverted collision bounds for ${key}.`);
  }
  return doc;
}

export function makeItem(value) {
  const { op, ...item } = value;
  return { name: item.id, rot: [0, 0, 0], scale: 1, tags: [], bindings: {}, ...copy(item) };
}

export function sceneDiff(before, after) {
  const prior = new Map(before.items.map(o => [o.id, o]));
  const assets = [...new Set([...Object.keys(before.assets), ...Object.keys(after.assets)])].filter(k => stable(before.assets[k]) !== stable(after.assets[k]));
  const added = [], changed = [], removed = [], affected = new Set();
  for (const item of after.items) {
    const old = prior.get(item.id);
    if (!old) added.push(item.id);
    else if (stable(old) !== stable(item)) changed.push({ id: item.id, fields: Object.keys(item).filter(k => stable(old[k]) !== stable(item[k])) });
    if (!old || stable(old) !== stable(item) || assets.includes(item.asset)) affected.add(item.id);
    prior.delete(item.id);
  }
  for (const id of prior.keys()) { removed.push(id); affected.add(id); }
  return { added, changed, removed, assets, affected: [...affected], count: affected.size };
}

export function protect(before, after, policy = {}) {
  const locked = new Set(policy.locked ?? []);
  for (const item of before.items) if (locked.has(item.id)) {
    const next = after.items.find(o => o.id === item.id);
    if (stable(item) !== stable(next) || stable(before.assets[item.asset]) !== stable(after.assets[item.asset])) throw new Fault('PROTECTED', `Item ${item.id} is locked, including its asset and sockets.`);
  }
  const allowed = new Set(policy.bindings ?? []);
  for (const item of after.items) {
    if (policy.bounds) {
      const box = bounds(item, after.assets[item.asset]);
      if (box[0].some((v, i) => v < policy.bounds[0][i] - 1e-8) || box[1].some((v, i) => v > policy.bounds[1][i] + 1e-8)) throw new Fault('OUT_OF_BOUNDS', `Item ${item.id} extends outside the editable region.`, { id: item.id, bounds: box });
    }
    for (const target of Object.values(item.bindings)) if (!allowed.has(target)) throw new Fault('BINDING', `Host binding ${target} is not declared by this project.`);
  }
}

export function applyOps(doc, ops, { resolveAsset, policy = {} } = {}) {
  validate(ops, OPS, 'ops');
  jsonSafe(ops);
  const next = copy(doc);
  const get = id => {
    const item = next.items.find(o => o.id === id);
    if (!item) throw new Fault('NOT_FOUND', `Item not found: ${id}.`);
    return item;
  };
  const asset = key => {
    if (!Object.hasOwn(next.assets, key)) throw new Fault('MISSING_ASSET', `Use asset_use before placing ${key}.`);
    return next.assets[key];
  };
  const results = [];
  for (let index = 0; index < ops.length; index++) {
    const o = ops[index];
    try {
      if (o.op === 'asset_use') {
        const found = resolveAsset?.(o.ref);
        if (!found) throw new Fault('MISSING_ASSET', `Asset reference not found: ${o.ref}. Search the catalog first.`);
        validate(found, ASSET, 'asset');
        next.assets[o.key] = copy(found);
        results.push({ asset: o.key, hash: found.hash });
      } else if (o.op === 'asset_socket') {
        asset(o.asset).sockets[o.name] = { pos: [...o.pos], rot: [...o.rot] };
        results.push({ asset: o.asset, socket: o.name });
      } else if (o.op === 'item_add') {
        asset(o.asset);
        if (next.items.some(item => item.id === o.id)) throw new Fault('DUPLICATE', `Item ID already exists: ${o.id}.`);
        next.items.push(makeItem(o)); results.push({ id: o.id });
      } else if (o.op === 'item_set') {
        Object.assign(get(o.id), copy(o.patch)); results.push({ id: o.id });
      } else if (o.op === 'item_remove') {
        get(o.id); next.items = next.items.filter(item => item.id !== o.id); results.push({ id: o.id });
      } else if (o.op === 'bind_set') {
        get(o.id).bindings[o.slot] = o.target; results.push({ id: o.id, slot: o.slot, target: o.target });
      } else if (o.op === 'item_snap') {
        if (o.id === o.to) throw new Fault('INVALID', 'A part cannot snap to itself.');
        const from = get(o.id), target = get(o.to);
        const socket = asset(from.asset).sockets[o.socket], anchor = asset(target.asset).sockets[o.targetSocket];
        if (!socket || !anchor) throw new Fault('NOT_FOUND', 'Socket not found. Register explicit socket poses before snapping.');
        Object.assign(from, snapPose(from, socket, target, anchor)); results.push({ id: o.id, pos: [...from.pos], rot: [...from.rot] });
      } else if (o.op === 'items_path') {
        asset(o.asset);
        const ids = [];
        for (let i = 0; i < o.count; i++) {
          const id = `${o.prefix}_${String(i + 1).padStart(3, '0')}`;
          if (next.items.some(item => item.id === id)) throw new Fault('DUPLICATE', `Item ID already exists: ${id}.`);
          const pose = atPath(o.path, i / (o.count - 1));
          next.items.push(makeItem({ id, asset: o.asset, pos: pose.pos, rot: [0, (o.orient === false ? 0 : pose.yaw) + (o.yaw ?? 0), 0], scale: o.scale ?? 1, tags: o.tags ?? [] }));
          ids.push(id);
        }
        results.push({ ids, placed: ids.length, note: 'Even path spacing; host collision tests must check clearance.' });
      }
      if (next.items.length > 2000) throw new Fault('LIMIT', 'Scene supports at most 2000 items. Nothing has been committed.');
    } catch (e) {
      throw new Fault(e.code ?? 'INVALID', e.message, { ...e.details, operation: index, op: o.op }, e.status ?? 400);
    }
  }
  checkScene(next);
  protect(doc, next, policy);
  return { doc: next, results, diff: sceneDiff(doc, next) };
}

export function queryScene(doc, query = {}) {
  validate(query, QUERY);
  const q = (query.q ?? '').toLowerCase();
  const items = doc.items.filter(item => {
    if (query.ids?.length && !query.ids.includes(item.id)) return false;
    if (query.tags?.some(t => !item.tags.includes(t))) return false;
    if (q && !`${item.id} ${item.name} ${item.asset} ${item.tags.join(' ')}`.toLowerCase().includes(q)) return false;
    if (query.bounds) {
      const box = bounds(item, doc.assets[item.asset]);
      if (box[0].some((v, i) => v > query.bounds[1][i]) || box[1].some((v, i) => v < query.bounds[0][i])) return false;
    }
    return true;
  }).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  const offset = query.offset ?? 0, limit = query.limit ?? 40;
  return { total: items.length, items: copy(items.slice(offset, offset + limit)), next: offset + limit < items.length ? offset + limit : null };
}
