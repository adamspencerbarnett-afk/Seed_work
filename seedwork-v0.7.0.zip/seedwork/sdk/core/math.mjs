const rad = Math.PI / 180;
export const add3 = (a, b) => a.map((v, i) => v + b[i]);
export const sub3 = (a, b) => a.map((v, i) => v - b[i]);
export const mul3 = (a, s) => a.map(v => v * s);

export function quat(rot) {
  const [x, y, z] = rot.map(v => v * rad / 2);
  const a = Math.cos(x), b = Math.cos(y), c = Math.cos(z), d = Math.sin(x), e = Math.sin(y), f = Math.sin(z);
  return [d * b * c + a * e * f, a * e * c - d * b * f, a * b * f + d * e * c, a * b * c - d * e * f];
}

export function qmul(a, b) {
  const [x, y, z, w] = a, [X, Y, Z, W] = b;
  return [x * W + w * X + y * Z - z * Y, y * W + w * Y + z * X - x * Z, z * W + w * Z + x * Y - y * X, w * W - x * X - y * Y - z * Z];
}

export const inv = q => [-q[0], -q[1], -q[2], q[3]];
export const rotate = (q, v) => qmul(qmul(q, [...v, 0]), inv(q)).slice(0, 3);
export const point = (item, p) => add3(item.pos, rotate(quat(item.rot), mul3(p, item.scale)));

export function euler(q) {
  const [x, y, z, w] = q;
  const m11 = 1 - 2 * (y * y + z * z), m12 = 2 * (x * y - z * w), m13 = 2 * (x * z + y * w);
  const m22 = 1 - 2 * (x * x + z * z), m23 = 2 * (y * z - x * w), m32 = 2 * (y * z + x * w), m33 = 1 - 2 * (x * x + y * y);
  const Y = Math.asin(Math.max(-1, Math.min(1, m13)));
  const X = Math.abs(m13) < .9999999 ? Math.atan2(-m23, m33) : Math.atan2(m32, m22);
  const Z = Math.abs(m13) < .9999999 ? Math.atan2(-m12, m11) : 0;
  return [X, Y, Z].map(v => v / rad);
}

export function snapPose(item, socket, target, anchor) {
  const q = qmul(qmul(quat(target.rot), quat(anchor.rot)), inv(quat(socket.rot)));
  return { pos: sub3(point(target, anchor.pos), rotate(q, mul3(socket.pos, item.scale))), rot: euler(q) };
}

export function bounds(item, asset) {
  const out = [[Infinity, Infinity, Infinity], [-Infinity, -Infinity, -Infinity]];
  for (const box of asset.boxes) for (let mask = 0; mask < 8; mask++) {
    const p = point(item, [0, 1, 2].map(i => box[(mask >> i) & 1][i]));
    for (let i = 0; i < 3; i++) { out[0][i] = Math.min(out[0][i], p[i]); out[1][i] = Math.max(out[1][i], p[i]); }
  }
  return out;
}

export function atPath(path, t) {
  const lengths = path.slice(1).map((p, i) => Math.hypot(...sub3(p, path[i])));
  const total = lengths.reduce((a, b) => a + b, 0);
  if (total < 1e-9) throw new Error('A path needs nonzero length.');
  let distance = Math.max(0, Math.min(1, t)) * total;
  for (let i = 0; i < lengths.length; i++) {
    const length = lengths[i];
    if (length < 1e-9) continue;
    if (distance <= length || i === lengths.length - 1) {
      const d = sub3(path[i + 1], path[i]);
      return { pos: add3(path[i], mul3(d, Math.min(1, distance / length))), yaw: Math.atan2(d[0], d[2]) / rad };
    }
    distance -= length;
  }
  return { pos: [...path.at(-1)], yaw: 0 };
}
