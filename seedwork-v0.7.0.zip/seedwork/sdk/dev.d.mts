import type { Runtime, Meta, Json, Query, QueryResult, Item } from './index.mjs';
export interface Camera { type: string; near: number; far: number; matrixWorld: { toArray(): number[] }; projectionMatrix: { toArray(): number[] }; updateMatrixWorld(force?: boolean): unknown; }
export interface Renderer { domElement: HTMLCanvasElement; toneMappingExposure: number; toneMapping: number; outputEncoding?: number; outputColorSpace?: string; getPixelRatio(): number; info?: { render?: { calls?: number; triangles?: number }; memory?: { geometries?: number; textures?: number }; programs?: unknown[] | null }; }
export interface TestResult { passed: boolean; checks: ({ name: string; passed: boolean } & Record<string, Json>)[]; }
export interface ObserverOptions { runtime: Runtime; renderer: Renderer; camera: Camera | (() => Camera); entities?: () => Json[]; tests?: Record<string, (context: { runtime: Runtime; signal: AbortSignal }) => TestResult | Promise<TestResult>>; maxFrames?: number; }
export interface Capture { meta: Meta | null; image: { data: string; mimeType: 'image/png'; width: number; height: number }; camera: { type: string; matrixWorld: number[]; projection: number[]; near: number; far: number }; conditions: Record<string, Json>; }
export class Observer {
  constructor(options: ObserverOptions);
  readonly closed: boolean;
  readonly tests: NonNullable<ObserverOptions['tests']>;
  afterFrame(info?: { time?: number; cpuMs?: number | null }): void;
  capture(options?: { signal?: AbortSignal }): Promise<Capture>;
  query(query?: Query): QueryResult & { meta: Meta | null; external: Json[]; items: (Item & { matrixWorld: number[] })[] };
  profile(): Record<string, unknown>;
  test(name: string, options?: { signal?: AbortSignal }): Promise<TestResult & { test: string; meta: Meta | null }>;
  dispose(): void;
}
export interface Status { state: string; detail: string; id: string | null; }
export interface ConnectOptions { runtime: Runtime; observer: Observer; project: string; name?: string; base?: string; token: string; fetch?: typeof globalThis.fetch; onStatus?: (status: Status) => void; }
export class DevLink {
  constructor(options: ConnectOptions);
  readonly id: string | null;
  readonly closed: boolean;
  open(): Promise<{ id: string }>;
  close(): Promise<void>;
}
export function createObserver(options: ObserverOptions): Observer;
export function connect(options: ConnectOptions): Promise<DevLink>;
