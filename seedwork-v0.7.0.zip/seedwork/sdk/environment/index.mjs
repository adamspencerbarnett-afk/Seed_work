import { EnvError, preset, validate, patchEnv, PRESET_NAMES, ENV_SCHEMA, copy } from './schema.mjs';
import { Climate } from './state.mjs';
import { Exposure } from './field.mjs';
import { Surfaces } from './surfaces.mjs';
import { Emitter } from './particles.mjs';
export { EnvError, preset, validate, patchEnv, PRESET_NAMES, ENV_SCHEMA, Climate, Exposure };
export const VERSION = '0.7.0';
export class Environment {
  constructor({ THREE: T, parent, camera, config = preset(), field = {}, radius = 22, capacity = {}, allowUnverified = false }) {
    if (!T?.Group || !parent?.isObject3D || !camera?.isCamera) throw new EnvError('CONTRACT', 'Pass the host THREE namespace, parent and camera.');
    if (String(T.REVISION) !== '140' && !allowUnverified) throw new EnvError('VERSION', `Three.js r${T.REVISION} has not been verified. Use an explicit compatibility adapter; this build targets r140.`);
    if (!Number.isFinite(radius) || radius < 4 || radius > 100) throw new EnvError('INVALID', 'Particle radius must be in [4, 100] meters.');
    const limits = { rain: 12000, snow: 5000, leaves: 400, impacts: 1400, litter: 8000 };
    for (const [k, v] of Object.entries(capacity)) if (!Object.hasOwn(limits, k) || !Number.isInteger(v) || v < 0 || v > 50000) throw new EnvError('INVALID', 'Capacity fields require integers in [0, 50000].');
    this.capacity = { ...limits, ...capacity };
    if (Object.values(this.capacity).reduce((a, b) => a + b, 0) > 100000) throw new EnvError('LIMIT', 'Particle allocation is limited to 100000 instances.');
    this.T = T; this.camera = camera; this.parent = parent; this.closed = false; this.reference = false; this.frames = 0; this.listeners = new Set(); this.cleanups = new Set(); this.notices = [];
    this.climate = new Climate(validate(config));
    this.field = new Exposure({ THREE: T, ...field });
    this.root = new T.Group(); this.root.name = 'Seedwork environment';
    this.uniforms = { ...this.field.uniforms, envTime: { value: 0 }, envSurface: { value: new T.Vector3() }, envFoliage: { value: new T.Vector3() }, envWind: { value: new T.Vector2() }, envCamera: { value: new T.Vector3() }, envRight: { value: new T.Vector3(1, 0, 0) }, envCamUp: { value: new T.Vector3(0, 1, 0) }, envRadius: { value: radius }, envFog: { value: config.atmosphere.fog }, envFogColor: { value: new T.Color(.49, .55, .59) }, envLight: { value: 1 }, envSnowCover: { value: 0 } };
    this.surfaces = new Surfaces(T, this.uniforms);
    this.emitters = Object.entries(this.capacity).map(([key, max], i) => { const emitter = new Emitter(T, i, max, this.uniforms, config.seed); this.root.add(emitter.mesh); return emitter; });
    parent.add(this.root); this.sync();
  }
  guard() { if (this.closed) throw new EnvError('DISPOSED', 'The environment is detached.'); }
  set(patch, seconds = 0) {
    this.guard(); const old = this.climate.config.seed;
    const result = this.climate.set(patch, seconds);
    if (old !== this.climate.config.seed) this.emitters.forEach(e => e.reseed(this.climate.config.seed));
    this.sync(); return result;
  }
  preset(name, seconds = 0) { return this.set(preset(name), seconds); }
  update(dt) { this.guard(); this.climate.update(dt); this.frames++; this.sync(); }
  sync() {
    const c = this.climate.current, s = this.climate.surface, u = this.uniforms;
    u.envTime.value = this.climate.time; u.envSurface.value.set(s.wet, s.snow, s.ice); u.envFoliage.value.set(c.foliage.autumn, c.foliage.retention, c.foliage.litter);
    u.envWind.value.fromArray(c.weather.wind); u.envFog.value = c.atmosphere.fog; u.envLight.value = c.atmosphere.light; u.envSnowCover.value = s.snow;
    this.camera.updateWorldMatrix(true, false); this.camera.getWorldPosition(u.envCamera.value);
    u.envRight.value.setFromMatrixColumn(this.camera.matrixWorld, 0).normalize(); u.envCamUp.value.setFromMatrixColumn(this.camera.matrixWorld, 1).normalize();
    const values = [c.weather.rain, c.weather.snow, c.foliage.autumn * c.foliage.retention, c.weather.rain, c.foliage.litter];
    this.emitters.forEach((e, i) => e.set(values[i], this.reference));
    for (const fn of this.listeners) { try { fn({ config: c, surface: s, time: this.climate.time }); } catch (e) { if (this.notices.length < 16) this.notices.push(String(e.message ?? e)); } }
  }
  setReference(enabled) { this.guard(); if (typeof enabled !== 'boolean') throw new EnvError('INVALID', 'Reference mode is boolean.'); this.reference = enabled; this.sync(); }
  bind(root, options) { this.guard(); return this.surfaces.bind(root, options); }
  sourceMaterial(material) { this.guard(); return this.surfaces.original(material); }
  subscribe(fn) { this.guard(); if (typeof fn !== 'function') throw new EnvError('INVALID', 'Expected a listener function.'); this.listeners.add(fn); return () => this.listeners.delete(fn); }
  invalidateField(samplers) { this.guard(); this.field.rebuild(samplers); }
  snapshot() { this.guard(); return this.climate.snapshot(); }
  restore(snapshot) { this.guard(); this.climate.restore(snapshot); this.emitters.forEach(e => e.reseed(this.climate.config.seed)); this.sync(); }
  inspect() {
    return { version: VERSION, three: String(this.T.REVISION), closed: this.closed, frameUpdates: this.frames, config: copy(this.climate.config), surface: copy(this.climate.surface), clock: this.climate.time, reference: this.reference, field: { size: this.field.size, builds: this.field.builds, bounds: [...this.field.bounds], heightPrecision: (this.field.range[1] - this.field.range[0]) / 65535 }, materials: this.surfaces.pool.size, boundMeshes: this.surfaces.bindings.size, shaderCompiles: this.surfaces.compiles, emitters: this.emitters.map(e => ({ name: e.mesh.name, visible: e.count, allocated: e.max, submitted: e.mesh.visible ? e.geometry.instanceCount : 0 })), notices: [...this.notices], gpuTimeMs: null, vramBytes: null };
  }
  dispose() { if (this.closed) return; for (const fn of [...this.cleanups]) fn(); this.cleanups.clear(); this.surfaces.dispose(); this.emitters.forEach(e => e.dispose()); this.field.dispose(); this.root.removeFromParent(); this.root.clear(); this.listeners.clear(); this.closed = true; }
}
export const createEnvironment = options => new Environment(options);
export function bindAtmosphere(env, { scene, sun = null, hemi = null, background = false, invalidate = () => {} }) {
  env.guard();
  if (!scene?.isScene) throw new EnvError('CONTRACT', 'Pass the host scene to opt into atmospheric changes.');
  const T = env.T;
  const previous = { fog: scene.fog, background: scene.background, sun: sun?.intensity, hemi: hemi?.intensity };
  const fog = new T.FogExp2('#b5c0c7', .005), bg = new T.Color(), color = new T.Color(), overcast = new T.Color('#9aabb7');
  scene.fog = fog; if (background) scene.background = bg;
  let lastSun = null, lastHemi = null;
  const apply = ({ config: c }) => {
    const cloud = c.atmosphere.cloud;
    color.set('#b5c8d7').lerp(overcast, cloud).convertSRGBToLinear();
    fog.color.copy(color); fog.density = c.atmosphere.fog;
    env.uniforms.envFogColor.value.copy(color);
    if (background) bg.copy(color);
    if (sun) { lastSun = previous.sun * c.atmosphere.light * (1 - cloud * .82); sun.intensity = lastSun; }
    if (hemi) { lastHemi = previous.hemi * c.atmosphere.light * (.9 + cloud * .25); hemi.intensity = lastHemi; }
  };
  const off = env.subscribe(apply); apply({ config: env.climate.current }); invalidate();
  let closed = false;
  const detach = () => { if (closed) return; closed = true; env.cleanups.delete(detach); off(); if (scene.fog === fog) scene.fog = previous.fog; if (background && scene.background === bg) scene.background = previous.background; if (sun && sun.intensity === lastSun) sun.intensity = previous.sun; if (hemi && hemi.intensity === lastHemi) hemi.intensity = previous.hemi; invalidate(); };
  env.cleanups.add(detach); return detach;
}
export function createEnvTools(env) {
  const catalog = [
    { name: 'environment_inspect', description: 'Inspect configured weather, surface states, exposure resolution and submitted particle counts. Does not report invented GPU timing.', inputSchema: { type: 'object', properties: {}, additionalProperties: false } },
    { name: 'environment_set', description: 'Apply a complete validated environment configuration. Visual state only; no changes to physics or water providers.', inputSchema: { type: 'object', properties: { config: ENV_SCHEMA }, required: ['config'], additionalProperties: false } },
    { name: 'environment_preset', description: 'Select one declared environment preset. No neural generation or arbitrary code execution.', inputSchema: { type: 'object', properties: { name: { type: 'string', enum: PRESET_NAMES } }, required: ['name'], additionalProperties: false } }
  ];
  return { catalog: () => copy(catalog), call(name, args = {}) {
    if (!args || ![Object.prototype, null].includes(Object.getPrototypeOf(args))) throw new EnvError('INVALID', 'Tool arguments must be a plain object.');
    if (name === 'environment_inspect' && Object.keys(args).length === 0) return env.inspect();
    if (name === 'environment_set' && Object.keys(args).join() === 'config') { validate(args.config); env.set(args.config); return env.inspect(); }
    if (name === 'environment_preset' && Object.keys(args).join() === 'name') { env.preset(args.name); return env.inspect(); }
    throw new EnvError('TOOL', 'Unknown tool or unsupported arguments.');
  } };
}
