import { EnvError, clamp } from './schema.mjs';
export const FIELD_GLSL = `
uniform sampler2D envField;
uniform vec4 envBounds;
uniform vec2 envRange;
uniform float envBias;
uniform vec2 envCell;
float envDecode(vec2 v) { return dot(v, vec2(65280.0, 255.0)) / 65535.0 * envRange.y + envRange.x; }
vec3 envHeights(vec2 p) {
  vec2 uv = (p - envBounds.xy) / envBounds.zw;
  vec4 v = texture2D(envField, clamp(uv, 0.0, 1.0));
  float valid = step(0.0, uv.x) * step(uv.x, 1.0) * step(0.0, uv.y) * step(uv.y, 1.0);
  return vec3(envDecode(v.rg), envDecode(v.ba), valid);
}
`;
export class Exposure {
  constructor({ THREE: T, bounds = [-30, -30, 60, 60], range = [-32, 96], size = 128, ground = () => 0, roof = () => null }) {
    if (!Array.isArray(bounds) || bounds.length !== 4 || !bounds.every(Number.isFinite) || bounds[2] <= 0 || bounds[3] <= 0 || !Array.isArray(range) || range.length !== 2 || !range.every(Number.isFinite) || range[1] <= range[0] || !Number.isInteger(size) || size < 16 || size > 512 || typeof ground !== 'function' || typeof roof !== 'function') throw new EnvError('INVALID', 'Invalid exposure field dimensions or samplers.');
    this.T = T; this.bounds = [...bounds]; this.range = [...range]; this.size = size; this.ground = ground; this.roof = roof; this.builds = 0; this.closed = false;
    this.data = new Uint8Array(size * size * 4);
    this.texture = new T.DataTexture(this.data, size, size, T.RGBAFormat, T.UnsignedByteType);
    this.texture.minFilter = this.texture.magFilter = T.NearestFilter; this.texture.generateMipmaps = false; this.texture.flipY = false;
    this.uniforms = { envField: { value: this.texture }, envBounds: { value: new T.Vector4(...bounds) }, envRange: { value: new T.Vector2(range[0], range[1] - range[0]) }, envCell: { value: new T.Vector2(bounds[2] / size, bounds[3] / size) }, envBias: { value: (range[1] - range[0]) / 65535 * 2 + .015 } };
    try { this.rebuild(); } catch (e) { this.texture.dispose(); throw e; }
  }
  rebuild({ ground = this.ground, roof = this.roof } = {}) {
    if (this.closed) throw new EnvError('DISPOSED', 'Exposure field is detached.');
    const next = new Uint8Array(this.data.length), [min, max] = this.range, b = this.bounds;
    const encode = (v, i) => { if (!Number.isFinite(v) || v < min || v > max) throw new EnvError('FIELD_RANGE', `Sample ${v} is outside the configured elevation range [${min}, ${max}].`); const n = Math.round((v - min) / (max - min) * 65535); next[i] = n >>> 8; next[i + 1] = n & 255; };
    for (let z = 0; z < this.size; z++) for (let x = 0; x < this.size; x++) {
      const px = b[0] + (x + .5) / this.size * b[2], pz = b[1] + (z + .5) / this.size * b[3], g = ground(px, pz), r = roof(px, pz), i = (z * this.size + x) * 4;
      encode(g, i); encode(r === null || r === undefined ? g : Math.max(g, r), i + 2);
    }
    this.data.set(next); this.ground = ground; this.roof = roof; this.texture.needsUpdate = true; this.builds++;
  }
  sample(x, z) {
    if (!Number.isFinite(x) || !Number.isFinite(z)) throw new EnvError('INVALID', 'Sample coordinates must be finite.');
    const b = this.bounds, u = (x - b[0]) / b[2], v = (z - b[1]) / b[3], px = Math.min(this.size - 1, Math.floor(clamp(u) * this.size)), pz = Math.min(this.size - 1, Math.floor(clamp(v) * this.size)), i = (pz * this.size + px) * 4;
    const decode = at => (this.data[at] * 256 + this.data[at + 1]) / 65535 * (this.range[1] - this.range[0]) + this.range[0];
    return { ground: decode(i), roof: decode(i + 2), inside: u >= 0 && u <= 1 && v >= 0 && v <= 1 };
  }
  dispose() { if (!this.closed) { this.texture.dispose(); this.closed = true; } }
}
