export type Vec2 = [number, number];
export type Bounds = [number, number, number, number];
export type PresetName = 'clear' | 'rain' | 'snow' | 'ice' | 'autumn' | 'mist' | 'thaw';
export interface Config {
  schema: 'seedwork.environment/1';
  name: string;
  seed: number;
  weather: { rain: number; snow: number; wind: Vec2; temperature: number };
  surface: Surface;
  foliage: { autumn: number; retention: number; litter: number };
  atmosphere: { fog: number; cloud: number; light: number };
  simulation: { enabled: boolean; rate: number };
}
export interface Surface { wet: number; snow: number; ice: number; }
export type Patch = Partial<Omit<Config, 'weather' | 'surface' | 'foliage' | 'atmosphere' | 'simulation'>> & { weather?: Partial<Config['weather']>; surface?: Partial<Surface>; foliage?: Partial<Config['foliage']>; atmosphere?: Partial<Config['atmosphere']>; simulation?: Partial<Config['simulation']> };
export interface Snapshot { schema: 'seedwork.climate/1'; config: Config; current: Config; surface: Surface; time: number; ticks: number; remainder: number; transition: null | { from: Config; elapsed: number; seconds: number }; }
export interface Node { readonly isObject3D: boolean; }
export interface Camera extends Node { readonly isCamera: boolean; }
export interface Scene extends Node { readonly isScene: boolean; }
export interface Three { REVISION: string; Group: new () => Node; }
export interface Field { bounds?: Bounds; range?: Vec2; size?: number; ground?: (x: number, z: number) => number; roof?: (x: number, z: number) => number | null; }
export interface Roles { wet?: number; snow?: number; foliage?: number; ice?: number; }
export interface Options { THREE: Three; parent: Node; camera: Camera; config?: Config; field?: Field; radius?: number; capacity?: Partial<Record<'rain' | 'snow' | 'leaves' | 'impacts' | 'litter', number>>; allowUnverified?: boolean; }
export interface Metrics { version: string; three: string; closed: boolean; frameUpdates: number; config: Config; surface: Surface; clock: number; reference: boolean; field: { size: number; builds: number; bounds: Bounds; heightPrecision: number }; materials: number; boundMeshes: number; shaderCompiles: number; emitters: { name: string; visible: number; allocated: number; submitted: number }[]; notices: string[]; gpuTimeMs: null; vramBytes: null; }
export interface Frame { readonly config: Readonly<Config>; readonly surface: Readonly<Surface>; readonly time: number; }
export class EnvError extends Error { constructor(code: string, message: string); code: string; }
export const VERSION: string;
export const PRESET_NAMES: readonly PresetName[];
export const ENV_SCHEMA: Readonly<Record<string, unknown>>;
export function preset(name?: PresetName): Config;
export function validate(value: unknown): Config;
export function validate<T>(value: T, schema: Record<string, unknown>): T;
export function patchEnv(config: Config, patch: Patch): Config;
export class Climate { constructor(config?: Config); config: Config; current: Config; surface: Surface; time: number; ticks: number; remainder: number; transition: Snapshot['transition']; set(patch: Patch, seconds?: number): Snapshot; update(dt: number): Surface; snapshot(): Snapshot; restore(snapshot: unknown): void; }
export class Exposure { constructor(options: Field & { THREE: Three }); readonly size: number; readonly bounds: Bounds; readonly range: Vec2; readonly data: Uint8Array; readonly builds: number; sample(x: number, z: number): { ground: number; roof: number; inside: boolean }; rebuild(samplers?: Pick<Field, 'ground' | 'roof'>): void; dispose(): void; }
export class Environment {
  constructor(options: Options);
  readonly root: Node;
  readonly parent: Node;
  readonly camera: Camera;
  readonly climate: Climate;
  readonly field: Exposure;
  readonly closed: boolean;
  set(patch: Patch, seconds?: number): Snapshot;
  preset(name: PresetName, seconds?: number): Snapshot;
  update(dt: number): void;
  sync(): void;
  setReference(enabled: boolean): void;
  bind(root: Node, roles?: Roles): () => void;
  sourceMaterial<T>(material: T): T;
  subscribe(fn: (frame: Frame) => void): () => void;
  invalidateField(samplers?: Pick<Field, 'ground' | 'roof'>): void;
  snapshot(): Snapshot;
  restore(snapshot: unknown): void;
  inspect(): Metrics;
  dispose(): void;
}
export function createEnvironment(options: Options): Environment;
export function bindAtmosphere(env: Environment, options: { scene: Scene; sun?: { intensity: number } | null; hemi?: { intensity: number } | null; background?: boolean; invalidate?: () => void }): () => void;
export function createEnvTools(env: Environment): { catalog(): { name: string; description: string; inputSchema: Record<string, unknown> }[]; call(name: 'environment_inspect', args?: Record<string, never>): Metrics; call(name: 'environment_set', args: { config: Config }): Metrics; call(name: 'environment_preset', args: { name: PresetName }): Metrics; };
