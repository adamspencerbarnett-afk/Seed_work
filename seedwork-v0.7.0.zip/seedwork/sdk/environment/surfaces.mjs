import { EnvError } from './schema.mjs';
import { FIELD_GLSL } from './field.mjs';
const HEAD = `
varying vec3 envPos;
varying vec3 envNormal;
varying float envLeaf;
uniform vec3 envSurface;
uniform vec3 envFoliage;
uniform vec4 envRole;
uniform float envCoat;
float envHash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float envNoise(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(envHash(i), envHash(i + vec2(1.0, 0.0)), f.x), mix(envHash(i + vec2(0.0, 1.0)), envHash(i + 1.0), f.x), f.y); }
${FIELD_GLSL}
`;
const COLOR = `
vec3 envH = envHeights(envPos.xz);
vec3 envFaceNormal = normalize(envNormal);
float envSlopeBias = min(.5, dot(abs(envFaceNormal.xz), envCell) * .5 / max(abs(envFaceNormal.y), .08));
float envOpen = step(envH.y - envBias - envSlopeBias, envPos.y) * envH.z;
float envUp = smoothstep(0.26, 0.84, normalize(envNormal).y);
float envGrain = envNoise(envPos.xz * 2.7 + envPos.y * 1.7) * .65 + envNoise(envPos.xz * 13.0) * .35;
float envSnow = smoothstep(envGrain * .85 - .12, envGrain * .85 + .16, envSurface.y) * envUp * envOpen * envRole.y * step(.001, envSurface.y);
float envWet = envSurface.x * envOpen * envRole.x * (1.0 - envSnow);
float envIce = envSurface.z * envUp * envOpen * envRole.w * (1.0 - envSnow);
if (envRole.z > .5 && envLeaf > envFoliage.y) discard;
vec3 envAmber = mix(vec3(.52, .135, .019), vec3(.29, .066, .012), envLeaf);
float envLuma = dot(diffuseColor.rgb, vec3(.2126, .7152, .0722));
diffuseColor.rgb = mix(diffuseColor.rgb, envAmber * (.38 + envLuma * 2.4), envFoliage.x * envRole.z);
diffuseColor.rgb *= 1.0 - envWet * .28;
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(.79, .83, .87) * (.93 + envGrain * .07), envSnow);
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(.31, .42, .47), envIce * .28);
`;
export class Surfaces {
  constructor(T, uniforms) { this.T = T; this.uniforms = uniforms; this.bindings = new Map(); this.pool = new Map(); this.closed = false; this.compiles = 0; }
  bind(root, options = {}) {
    if (this.closed) throw new EnvError('DISPOSED', 'Surface controller is detached.');
    if (!options || Object.keys(options).some(k => !['wet', 'snow', 'foliage', 'ice'].includes(k))) throw new EnvError('INVALID', 'Unknown surface response field.');
    const role = { wet: options.wet ?? 1, snow: options.snow ?? 1, foliage: options.foliage ?? 0, ice: options.ice ?? 0 };
    for (const v of Object.values(role)) if (!Number.isFinite(v) || v < 0 || v > 1) throw new EnvError('INVALID', 'Surface responses must be in [0, 1].');
    if (!root?.isObject3D) throw new EnvError('INVALID', 'A surface root Object3D is required.');
    const meshes = [];
    root.traverse(node => {
      if (!node.isMesh) return;
      if (this.bindings.has(node)) throw new EnvError('BOUND', 'A mesh is already registered with this environment.');
      const values = Array.isArray(node.material) ? node.material : [node.material];
      if (!values.length) throw new EnvError('MATERIAL', 'A mesh needs at least one supported material.');
      if (role.foliage && (values.length > 1 || node.customDepthMaterial || node.customDistanceMaterial)) throw new EnvError('SHADOW_ADAPTER', 'Foliage with custom shadow materials or multiple material slots requires an explicit adapter.');
      for (const m of values) {
        if (!m?.isMeshStandardMaterial) throw new EnvError('MATERIAL', 'Register standard or physical materials only; custom materials need an explicit adapter.');
        if (m.onBeforeCompile !== this.T.Material.prototype.onBeforeCompile) throw new EnvError('CUSTOM_SHADER', 'A prepatched material needs an explicit environment adapter.');
      }
      meshes.push([node, values]);
    });
    const owned = [];
    try {
      for (const [node, values] of meshes) {
        const leases = values.map(m => this.acquire(m, role));
        const material = Array.isArray(node.material) ? leases.map(l => l.material) : leases[0].material;
        const binding = { node, original: node.material, material, leases, depth: node.customDepthMaterial, distance: node.customDistanceMaterial };
        if (role.foliage) { node.customDepthMaterial = leases[0].depth; node.customDistanceMaterial = leases[0].distance; }
        this.bindings.set(node, binding); node.material = material; owned.push(binding);
      }
    } catch (e) { for (const binding of owned) this.release(binding); throw e; }
    let closed = false;
    return () => { if (closed) return; closed = true; for (const b of owned) this.release(b); };
  }
  acquire(source, role) {
    const key = `${source.uuid}:${Object.values(role).join(',')}`;
    let entry = this.pool.get(key);
    if (entry) { entry.refs++; return entry; }
    const T = this.T;
    const material = source.isMeshPhysicalMaterial ? source.clone() : new T.MeshPhysicalMaterial();
    if (!source.isMeshPhysicalMaterial) T.MeshStandardMaterial.prototype.copy.call(material, source);
    const coat = source.clearcoat ?? 0;
    material.clearcoat = 1; material.clearcoatRoughness = source.clearcoatRoughness ?? .08;
    material.name = `${source.name || 'surface'} · environment`;
    material.userData.seedworkEnvironment = true;
    material.onBeforeCompile = shader => {
      this.compiles++;
      for (const tag of ['#include <project_vertex>']) if (!shader.vertexShader.includes(tag)) throw new EnvError('SHADER', `Missing vertex extension point ${tag}`);
      for (const tag of ['#include <color_fragment>', '#include <lights_physical_fragment>']) if (!shader.fragmentShader.includes(tag)) throw new EnvError('SHADER', `Missing fragment extension point ${tag}`);
      Object.assign(shader.uniforms, this.uniforms, { envRole: { value: new T.Vector4(role.wet, role.snow, role.foliage, role.ice) }, envCoat: { value: coat } });
      shader.vertexShader = `varying vec3 envPos; varying vec3 envNormal; varying float envLeaf;\n` + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace('#include <project_vertex>', `#include <project_vertex>
vec4 envPoint = vec4(transformed, 1.0);
vec4 envOrigin = vec4(0.0, 0.0, 0.0, 1.0);
#ifdef USE_INSTANCING
  envPoint = instanceMatrix * envPoint;
  envOrigin = instanceMatrix * envOrigin;
#endif
envPos = (modelMatrix * envPoint).xyz;
envNormal = inverseTransformDirection(transformedNormal, viewMatrix);
vec3 envSeedPos = (modelMatrix * envOrigin).xyz;
envLeaf = fract(sin(dot(envSeedPos, vec3(127.1, 52.7, 311.7))) * 43758.5453);
`);
      shader.fragmentShader = HEAD + shader.fragmentShader;
      shader.fragmentShader = shader.fragmentShader.replace('#include <color_fragment>', '#include <color_fragment>\n' + COLOR);
      shader.fragmentShader = shader.fragmentShader.replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
roughnessFactor = mix(roughnessFactor, max(.055, roughnessFactor * .34), max(envWet, envIce));
roughnessFactor = mix(roughnessFactor, .84, envSnow);
`);
      shader.fragmentShader = shader.fragmentShader.replace('#include <metalnessmap_fragment>', '#include <metalnessmap_fragment>\nmetalnessFactor *= 1.0 - envSnow;');
      shader.fragmentShader = shader.fragmentShader.replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
normal = normalize(mix(normal, geometryNormal, envSnow * .86));
`);
      shader.fragmentShader = shader.fragmentShader.replace('#include <lights_physical_fragment>', `#include <lights_physical_fragment>
#ifdef USE_CLEARCOAT
material.clearcoat = max(envCoat, max(envWet * .83, envIce * .95)) * (1.0 - envSnow);
material.clearcoatRoughness = mix(material.clearcoatRoughness, .075, max(envWet, envIce));
material.clearcoatF0 = mix(vec3(.04), vec3(.021), envWet);
#endif
`);
    };
    material.customProgramCacheKey = () => 'seedwork-environment-r140-v1';
    const depth = role.foliage ? this.shadow(source, false) : null, distance = role.foliage ? this.shadow(source, true) : null;
    entry = { key, source, material, depth, distance, refs: 1 }; this.pool.set(key, entry); return entry;
  }
  shadow(source, distance) {
    const T = this.T;
    const m = distance ? new T.MeshDistanceMaterial() : new T.MeshDepthMaterial({ depthPacking: T.RGBADepthPacking });
    m.map = source.map; m.alphaMap = source.alphaMap; m.alphaTest = source.alphaTest; m.side = source.side;
    m.onBeforeCompile = shader => {
      shader.uniforms.envFoliage = this.uniforms.envFoliage;
      shader.vertexShader = 'varying float envLeaf;\n' + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace('#include <project_vertex>', `#include <project_vertex>
vec4 envOrigin = vec4(0.0, 0.0, 0.0, 1.0);
#ifdef USE_INSTANCING
  envOrigin = instanceMatrix * envOrigin;
#endif
vec3 envSeedPos = (modelMatrix * envOrigin).xyz;
envLeaf = fract(sin(dot(envSeedPos, vec3(127.1, 52.7, 311.7))) * 43758.5453);
`);
      shader.fragmentShader = 'varying float envLeaf; uniform vec3 envFoliage;\n' + shader.fragmentShader;
      shader.fragmentShader = shader.fragmentShader.replace('void main() {', 'void main() { if (envLeaf > envFoliage.y) discard;');
    };
    m.customProgramCacheKey = () => 'seedwork-environment-shadow-v1';
    return m;
  }
  original(material) { for (const entry of this.pool.values()) if (entry.material === material) return entry.source; return material; }
  release(binding) {
    if (this.bindings.get(binding.node) !== binding) return;
    if (binding.node.material === binding.material) binding.node.material = binding.original;
    if (binding.node.customDepthMaterial === binding.leases[0].depth) binding.node.customDepthMaterial = binding.depth;
    if (binding.node.customDistanceMaterial === binding.leases[0].distance) binding.node.customDistanceMaterial = binding.distance;
    for (const entry of binding.leases) if (--entry.refs === 0) { entry.material.dispose(); entry.depth?.dispose(); entry.distance?.dispose(); this.pool.delete(entry.key); }
    this.bindings.delete(binding.node);
  }
  dispose() { if (this.closed) return; for (const b of [...this.bindings.values()]) this.release(b); this.closed = true; }
}
