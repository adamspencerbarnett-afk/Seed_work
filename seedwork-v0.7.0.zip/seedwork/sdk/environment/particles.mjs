import { rng } from './schema.mjs';
import { FIELD_GLSL } from './field.mjs';
const VERT = `
attribute vec4 envSeed;
attribute float envId;
uniform float envTime;
uniform float envCount;
uniform vec2 envWind;
uniform vec3 envCamera;
uniform vec3 envRight;
uniform vec3 envCamUp;
uniform float envRadius;
varying vec2 vUv;
varying float vFade;
varying float vLife;
varying float vSeed;
varying float vDist;
${FIELD_GLSL}
void main() {
  vUv = uv; vSeed = envSeed.w; vFade = step(envId + .5, envCount);
  vec3 p;
  float speed = KIND == 0 ? 18.0 + envSeed.z * 4.0 : (KIND == 1 ? .58 + envSeed.z * .52 : .42 + envSeed.z * .28);
  float t = envTime;
  vec2 drift = envWind * t * (KIND == 0 ? .2 : .38);
  p.xz = mod(envSeed.xy * envRadius * 2.0 + drift - envCamera.xz + envRadius, envRadius * 2.0) + envCamera.xz - envRadius;
  if (KIND == 1 || KIND == 2) p.xz += vec2(sin(t * .65 + envSeed.z * 60.0), cos(t * .5 + envSeed.z * 80.0)) * .3;
  vec3 h = envHeights(p.xz);
  float span = KIND == 0 ? 24.0 : 16.0;
  float cycle = fract(envSeed.z + t * speed / span);
  vLife = cycle;
  p.y = envCamera.y + span * .7 - cycle * span;
  vec3 right = envRight, up = envCamUp;
  float width = .012, len = .23 + envSeed.w * .25;
  if (KIND == 0) {
    up = normalize(vec3(envWind * .2, 0.0).xzy + vec3(0.0, -speed, 0.0));
    vec3 view = normalize(envCamera - p);
    right = normalize(cross(up, view));
  }
  if (KIND == 1) { width = .025 + envSeed.w * .025; len = width; }
  if (KIND == 2) { width = .07 + envSeed.w * .055; len = width * 1.55; float a = t * 1.6 + envSeed.z * 42.0; vec3 r = right * cos(a) + up * sin(a); up = up * cos(a) - right * sin(a); right = r; }
  if (KIND == 3) {
    p.y = h.y + .014;
    cycle = fract(envSeed.z + t * (1.5 + envSeed.w)); vLife = cycle;
    width = .06 + cycle * .18; len = width;
    right = vec3(1.0, 0.0, 0.0); up = vec3(0.0, 0.0, 1.0);
  }
  if (KIND == 4) {
    p.xz = envBounds.xy + envSeed.xy * envBounds.zw;
    h = envHeights(p.xz); p.y = h.x + .017;
    width = .07 + envSeed.w * .07; len = width * 1.4;
    float a = envSeed.z * 6.283185;
    right = vec3(cos(a), .03, sin(a)); up = vec3(-sin(a), .08, cos(a));
    vFade *= step(h.y - .04, h.x);
  }
  if (KIND < 3) vFade *= smoothstep(h.y + .02, h.y + .12, p.y);
  vFade *= h.z;
  float dist = length(p.xz - envCamera.xz);
  if (KIND != 4) vFade *= 1.0 - smoothstep(envRadius * .76, envRadius, dist);
  p += right * position.x * width + up * position.y * len;
  vec4 mv = viewMatrix * vec4(p, 1.0); vDist = max(0.0, -mv.z);
  vFade *= smoothstep(.25, .8, vDist);
  gl_Position = projectionMatrix * mv;
}
`;
const FRAG = `
uniform vec3 envFogColor;
uniform float envFog;
uniform float envLight;
uniform float envSnowCover;
varying vec2 vUv;
varying float vFade;
varying float vLife;
varying float vSeed;
varying float vDist;
void main() {
  if (vFade < .001) discard;
  float alpha = 1.0;
  vec3 color = vec3(.68, .73, .77);
  if (KIND == 0) alpha = pow(max(0.0, 1.0 - abs(vUv.x * 2.0 - 1.0)), 1.7) * smoothstep(0.0, .13, vUv.y) * (1.0 - smoothstep(.65, 1.0, vUv.y)) * .3;
  if (KIND == 1) { alpha = 1.0 - smoothstep(.38, .5, length(vUv - .5)); color = vec3(.88, .9, .94); }
  if (KIND == 2 || KIND == 4) {
    float shape = pow(max(0.0, sin(vUv.y * 3.141593)), .7) * .42;
    alpha = 1.0 - smoothstep(shape - .025, shape + .005, abs(vUv.x - .5));
    color = mix(vec3(.23, .065, .008), vec3(.42, .19, .018), vSeed);
    color *= .73 + .27 * sin(vUv.y * 70.0 + abs(vUv.x - .5) * 36.0);
    color *= 1.0 - .35 * (1.0 - smoothstep(.005, .027, abs(vUv.x - .5)));
    if (KIND == 4) alpha *= 1.0 - envSnowCover;
  }
  if (KIND == 3) { float r = length(vUv - .5); alpha = (1.0 - smoothstep(.025, .055, abs(r - .37))) * pow(1.0 - vLife, 2.0) * .5; color = vec3(.6, .65, .69); }
  alpha *= vFade;
  if (alpha < .004) discard;
  color *= envLight;
  float fog = 1.0 - exp(-envFog * envFog * vDist * vDist);
  gl_FragColor = vec4(mix(color, envFogColor, fog), alpha);
  #include <tonemapping_fragment>
  #include <encodings_fragment>
}
`;
export class Emitter {
  constructor(T, kind, max, uniforms, seed) {
    this.T = T; this.kind = kind; this.max = max; this.count = 0;
    this.geometry = new T.InstancedBufferGeometry();
    this.geometry.setIndex([0, 1, 2, 0, 2, 3]);
    this.geometry.setAttribute('position', new T.Float32BufferAttribute([-.5, -.5, 0, .5, -.5, 0, .5, .5, 0, -.5, .5, 0], 3));
    this.geometry.setAttribute('uv', new T.Float32BufferAttribute([0, 0, 1, 0, 1, 1, 0, 1], 2));
    this.seeds = new Float32Array(max * 4); this.ids = Float32Array.from({ length: max }, (_, i) => i);
    this.geometry.setAttribute('envSeed', new T.InstancedBufferAttribute(this.seeds, 4));
    this.geometry.setAttribute('envId', new T.InstancedBufferAttribute(this.ids, 1));
    this.uniforms = { ...uniforms, envCount: { value: 0 } };
    this.material = new T.ShaderMaterial({ defines: { KIND: kind }, uniforms: this.uniforms, vertexShader: VERT, fragmentShader: FRAG, transparent: true, depthWrite: false, depthTest: true, side: T.DoubleSide, toneMapped: true });
    this.mesh = new T.Mesh(this.geometry, this.material); this.mesh.frustumCulled = false; this.mesh.renderOrder = kind === 4 ? 1 : 8; this.mesh.name = ['Rain', 'Snow', 'Falling leaves', 'Rain impacts', 'Leaf litter'][kind];
    this.reseed(seed); this.geometry.instanceCount = 0;
  }
  reseed(seed) { const random = rng((seed + this.kind * 2939) >>> 0); for (let i = 0; i < this.seeds.length; i++) this.seeds[i] = random(); this.geometry.attributes.envSeed.needsUpdate = true; }
  set(value, reference = false) { this.count = Math.round(this.max * value); this.uniforms.envCount.value = this.count; this.geometry.instanceCount = reference ? this.max : this.count; this.mesh.visible = reference || this.count > 0; }
  dispose() { this.geometry.dispose(); this.material.dispose(); this.mesh.removeFromParent(); }
}
