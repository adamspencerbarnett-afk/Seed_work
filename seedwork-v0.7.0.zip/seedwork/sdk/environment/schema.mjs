export class EnvError extends Error {
  constructor(code, message) { super(message); this.name = 'EnvironmentError'; this.code = code; }
}
const n = (min, max) => ({ type: 'number', minimum: min, maximum: max });
const o = properties => ({ type: 'object', properties, required: Object.keys(properties), additionalProperties: false });
export const ENV_SCHEMA = o({
  schema: { const: 'seedwork.environment/1' },
  name: { type: 'string', minLength: 1, maxLength: 80 },
  seed: { type: 'integer', minimum: 0, maximum: 4294967295 },
  weather: o({ rain: n(0, 1), snow: n(0, 1), wind: { type: 'array', items: n(-25, 25), minItems: 2, maxItems: 2 }, temperature: n(-60, 60) }),
  surface: o({ wet: n(0, 1), snow: n(0, 1), ice: n(0, 1) }),
  foliage: o({ autumn: n(0, 1), retention: n(0, 1), litter: n(0, 1) }),
  atmosphere: o({ fog: n(0, .12), cloud: n(0, 1), light: n(.05, 3) }),
  simulation: o({ enabled: { type: 'boolean' }, rate: n(.01, 60) })
});
export const copy = value => structuredClone(value);
export const clamp = (v, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));
export function validate(value, rule = ENV_SCHEMA, path = 'environment') {
  const fail = text => { throw new EnvError('INVALID', `${path}: ${text}`); };
  if (rule.const !== undefined) { if (value !== rule.const) fail(`expected ${rule.const}`); return value; }
  if (rule.type === 'object') {
    if (!value || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) fail('expected a plain object');
    for (const key of rule.required ?? []) if (!Object.hasOwn(value, key)) fail(`missing ${key}`);
    for (const [key, item] of Object.entries(value)) {
      if (['__proto__', 'constructor', 'prototype'].includes(key) || !Object.hasOwn(rule.properties, key)) fail(`unknown field ${key}`);
      validate(item, rule.properties[key], `${path}.${key}`);
    }
  } else if (rule.type === 'array') {
    if (!Array.isArray(value) || value.length < rule.minItems || value.length > rule.maxItems) fail('invalid array length');
    value.forEach((item, i) => validate(item, rule.items, `${path}[${i}]`));
  } else if (rule.type === 'number' || rule.type === 'integer') {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < rule.minimum || value > rule.maximum || (rule.type === 'integer' && !Number.isInteger(value))) fail(`expected ${rule.type} in [${rule.minimum}, ${rule.maximum}]`);
  } else if (rule.type === 'string') {
    if (typeof value !== 'string' || value.length < rule.minLength || value.length > rule.maxLength || /[\x00-\x1f]/.test(value)) fail('invalid text');
  } else if (rule.type === 'boolean' && typeof value !== 'boolean') fail('expected boolean');
  return value;
}
export function patchEnv(config, patch) {
  validate(config);
  const partial = rule => rule.type === 'object' ? { ...rule, required: [], properties: Object.fromEntries(Object.entries(rule.properties).map(([k, r]) => [k, partial(r)])) } : rule;
  validate(patch, partial(ENV_SCHEMA), 'patch');
  const merge = (a, b) => Object.fromEntries(Object.entries(a).map(([key, val]) => [key, Object.hasOwn(b, key) ? (val && typeof val === 'object' && !Array.isArray(val) ? merge(val, b[key]) : copy(b[key])) : copy(val)]));
  return validate(merge(config, patch));
}
const BASE = { schema: 'seedwork.environment/1', name: 'Clear summer', seed: 732, weather: { rain: 0, snow: 0, wind: [1.2, .3], temperature: 19 }, surface: { wet: 0, snow: 0, ice: 0 }, foliage: { autumn: 0, retention: 1, litter: .03 }, atmosphere: { fog: .003, cloud: .12, light: 1 }, simulation: { enabled: false, rate: 1 } };
const PRESETS = {
  clear: {},
  rain: { name: 'Rain after dusk', weather: { rain: .72, wind: [2.6, -.7], temperature: 11 }, surface: { wet: .87 }, atmosphere: { cloud: .93, fog: .018, light: .65 } },
  snow: { name: 'Fresh snowfall', weather: { snow: .65, wind: [1.1, .35], temperature: -6 }, surface: { wet: .04, snow: .84, ice: .12 }, foliage: { autumn: .42, retention: .08, litter: .02 }, atmosphere: { cloud: .82, fog: .019, light: .84 } },
  ice: { name: 'Winter freeze', weather: { wind: [.35, .2], temperature: -12 }, surface: { wet: .05, snow: .22, ice: .96 }, foliage: { autumn: .65, retention: .07, litter: .09 }, atmosphere: { cloud: .18, fog: .005, light: .96 } },
  autumn: { name: 'Late autumn', weather: { wind: [1.5, .6], temperature: 8 }, surface: { wet: .16 }, foliage: { autumn: .87, retention: .68, litter: .95 }, atmosphere: { cloud: .28, fog: .007, light: 1.06 } },
  mist: { name: 'Woodland mist', weather: { wind: [.15, 0], temperature: 7 }, surface: { wet: .48 }, atmosphere: { cloud: .78, fog: .058, light: .8 } },
  thaw: { name: 'Spring thaw', weather: { rain: .22, wind: [.6, .3], temperature: 7 }, surface: { wet: .9, snow: .46, ice: .62 }, foliage: { autumn: .2, retention: .15, litter: .25 }, atmosphere: { cloud: .72, fog: .014, light: .86 }, simulation: { enabled: true, rate: 6 } }
};
export const PRESET_NAMES = Object.freeze(Object.keys(PRESETS));
export function preset(name = 'clear') {
  if (!Object.hasOwn(PRESETS, name)) throw new EnvError('INVALID', `Unknown environment preset: ${name}`);
  return patchEnv(BASE, PRESETS[name]);
}
export function rng(seed) {
  let x = seed >>> 0;
  return () => { x += 0x6D2B79F5; let t = Math.imul(x ^ x >>> 15, 1 | x); t ^= t + Math.imul(t ^ t >>> 7, 61 | t); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
