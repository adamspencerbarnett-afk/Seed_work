import { EnvError, validate, preset, patchEnv, copy, clamp, ENV_SCHEMA } from './schema.mjs';
const STEP = 1 / 30;
function mix(a, b, t) {
  if (typeof a === 'number') return a + (b - a) * t;
  if (Array.isArray(a)) return a.map((v, i) => mix(v, b[i], t));
  if (a && typeof a === 'object') return Object.fromEntries(Object.keys(a).map(k => [k, mix(a[k], b[k], t)]));
  return t < 1 ? a : b;
}
export class Climate {
  constructor(config = preset()) { this.config = copy(validate(config)); this.current = copy(config); this.time = 0; this.ticks = 0; this.remainder = 0; this.transition = null; this.surface = copy(config.surface); }
  set(patch, seconds = 0) {
    if (!Number.isFinite(seconds) || seconds < 0 || seconds > 3600) throw new EnvError('INVALID', 'Transition must be in [0, 3600] seconds.');
    const next = patchEnv(this.config, patch);
    if (!Object.hasOwn(patch, 'surface')) next.surface = copy(this.surface);
    else next.surface = { ...this.surface, ...patch.surface };
    const from = { ...copy(this.current), surface: copy(this.surface) };
    if (seconds && next.seed !== this.current.seed) throw new EnvError('INVALID', 'Seed changes require an immediate transition.');
    this.transition = seconds ? { from, elapsed: 0, seconds } : null;
    this.config = next;
    if (!seconds) { this.current = copy(next); this.surface = copy(next.surface); }
    return this.snapshot();
  }
  update(dt) {
    if (!Number.isFinite(dt) || dt < 0 || dt > 1) throw new EnvError('INVALID', 'Frame delta must be a finite value in [0, 1] seconds. Subdivide larger advances explicitly.');
    this.time += dt;
    if (this.transition) {
      const t = this.transition; t.elapsed = Math.min(t.seconds, t.elapsed + dt);
      const p = t.elapsed / t.seconds, eased = p * p * (3 - 2 * p);
      this.current = mix(t.from, this.config, eased); this.current.seed = this.config.seed;
      this.current.simulation = copy(this.config.simulation); this.current.name = this.config.name;
      this.surface = copy(this.current.surface);
      if (p === 1) this.transition = null;
    }
    this.remainder += dt;
    while (this.remainder + 1e-12 >= STEP) {
      if (this.current.simulation.enabled && !this.transition) this.step(STEP * this.current.simulation.rate);
      this.ticks++; this.remainder = Math.max(0, this.remainder - STEP);
    }
    return this.surface;
  }
  step(dt) {
    const w = this.current.weather, s = this.surface, cold = clamp(-w.temperature / 8), warm = clamp(w.temperature / 12);
    const melt = Math.min(s.snow, dt * warm * .0018), thaw = Math.min(s.ice, dt * warm * .0015);
    const freeze = Math.min(s.wet, dt * cold * .0014);
    s.wet = clamp(s.wet + dt * w.rain * .002 + melt * .7 + thaw * .8 - freeze - dt * (.00008 + warm * .0004));
    s.snow = clamp(s.snow + dt * w.snow * cold * .0009 - melt);
    s.ice = clamp(s.ice + freeze - thaw);
  }
  snapshot() { return { schema: 'seedwork.climate/1', config: copy(this.config), current: copy(this.current), surface: copy(this.surface), time: this.time, ticks: this.ticks, remainder: this.remainder, transition: copy(this.transition) }; }
  restore(snap) {
    if (!snap || Object.keys(snap).some(k => !['schema', 'config', 'current', 'surface', 'time', 'ticks', 'remainder', 'transition'].includes(k)) || snap.schema !== 'seedwork.climate/1') throw new EnvError('INVALID', 'Unsupported climate snapshot.');
    validate(snap.config); validate(snap.current); validate(snap.surface, ENV_SCHEMA.properties.surface);
    if (![snap.time, snap.ticks, snap.remainder].every(Number.isFinite) || snap.time < 0 || snap.time > 1e9 || !Number.isInteger(snap.ticks) || snap.ticks < 0 || snap.remainder < 0 || snap.remainder >= STEP + 1e-9) throw new EnvError('INVALID', 'Invalid climate clock.');
    if (snap.transition !== null) {
      const t = snap.transition;
      if (!t || Object.keys(t).sort().join() !== 'elapsed,from,seconds' || !Number.isFinite(t.seconds) || t.seconds <= 0 || t.seconds > 3600 || !Number.isFinite(t.elapsed) || t.elapsed < 0 || t.elapsed > t.seconds) throw new EnvError('INVALID', 'Invalid transition snapshot.');
      validate(t.from);
    }
    this.config = copy(snap.config); this.current = copy(snap.current); this.surface = copy(snap.surface); this.time = snap.time; this.ticks = snap.ticks; this.remainder = snap.remainder; this.transition = copy(snap.transition);
  }
}
