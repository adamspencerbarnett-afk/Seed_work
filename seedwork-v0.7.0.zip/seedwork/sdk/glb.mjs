import { Fault } from './core/schema.mjs';

function releaseTree(root) {
  const geometries = new Set(), materials = new Set(), textures = new Set(), images = new Set();
  root.traverse(node => {
    if (node.geometry) geometries.add(node.geometry);
    for (const material of Array.isArray(node.material) ? node.material : node.material ? [node.material] : []) {
      materials.add(material);
      for (const value of Object.values(material)) if (value?.isTexture) { textures.add(value); if (value.image?.close) images.add(value.image); }
    }
  });
  let disposed = false;
  return () => {
    if (disposed) return;
    disposed = true;
    const errors = [];
    for (const value of [...geometries, ...materials, ...textures]) { try { value.dispose(); } catch (e) { errors.push(e); } }
    for (const value of images) { try { value.close(); } catch (e) { errors.push(e); } }
    if (errors.length) throw new AggregateError(errors, 'Some owned asset resources failed to dispose.');
  };
}

export function disposeTree(root) { releaseTree(root)(); }

export async function sha256(bytes) {
  if (!globalThis.crypto?.subtle) throw new Fault('CRYPTO_REQUIRED', 'Verified asset loading requires a secure context such as localhost or HTTPS.');
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(v => v.toString(16).padStart(2, '0')).join('');
}

function inspect(bytes) {
  if (bytes.byteLength < 28 || bytes.byteLength > 24 * 1024 * 1024) throw new Fault('ASSET_LIMIT', 'Expected a GLB of at most 24 MiB.');
  const view = new DataView(bytes);
  if (view.getUint32(0, true) !== 0x46546c67 || view.getUint32(4, true) !== 2 || view.getUint32(8, true) !== bytes.byteLength || view.getUint32(16, true) !== 0x4e4f534a) throw new Fault('INVALID_GLB', 'Invalid GLB header.');
  const length = view.getUint32(12, true);
  if (length + 20 > bytes.byteLength) throw new Fault('INVALID_GLB', 'Invalid GLB JSON length.');
  const doc = JSON.parse(new TextDecoder().decode(new Uint8Array(bytes, 20, length)));
  if (doc.animations?.length || doc.skins?.length || doc.meshes?.some(mesh => mesh.primitives.some(p => p.targets?.length))) throw new Fault('UNSUPPORTED', 'Use the host animation pipeline for animated or skinned assets.');
  if ([...(doc.buffers ?? []), ...(doc.images ?? [])].some(v => v.uri !== undefined)) throw new Fault('EXTERNAL_ASSET', 'Use self-contained GLB files; remote or data URI dependencies are not loaded.');
  const supported = new Set(['KHR_materials_unlit', 'KHR_texture_transform']);
  if ([...(doc.extensionsRequired ?? []), ...(doc.extensionsUsed ?? [])].some(name => !supported.has(name))) throw new Fault('UNSUPPORTED', 'This loader does not approve the required GLB extensions. Supply a reviewed host loader.');
  return doc;
}

export function createGlbLoader({ Loader, url = hash => `/api/asset/${hash}`, fetch: get = globalThis.fetch, timeout = 30000, shadows = false }) {
  if (typeof Loader !== 'function' || typeof url !== 'function' || typeof get !== 'function') throw new Fault('CONTRACT', 'Pass the host GLTFLoader constructor, URL resolver, and fetch function.');
  return async (asset, { signal } = {}) => {
    const abort = new AbortController();
    const cancel = () => abort.abort(signal?.reason);
    signal?.addEventListener('abort', cancel, { once: true });
    if (signal?.aborted) cancel();
    const timer = setTimeout(() => abort.abort(new Error('Asset load timed out.')), timeout);
    let gltf;
    try {
      const res = await get(url(asset.hash), { signal: abort.signal });
      if (!res.ok) throw new Fault('ASSET_FETCH', `Asset request failed (${res.status}).`, { hash: asset.hash });
      if (Number(res.headers.get('content-length') ?? 0) > 24 * 1024 * 1024) throw new Fault('ASSET_LIMIT', 'GLB exceeds 24 MiB.');
      const chunks = []; let length = 0;
      const reader = res.body.getReader();
      try {
        for (;;) {
          const { done, value } = await reader.read(); if (done) break;
          length += value.byteLength;
          if (length > 24 * 1024 * 1024) throw new Fault('ASSET_LIMIT', 'GLB exceeds 24 MiB.');
          chunks.push(value);
        }
      } catch (e) { await reader.cancel().catch(() => {}); throw e; }
      finally { reader.releaseLock(); }
      const joined = new Uint8Array(length); let offset = 0;
      for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.length; }
      const bytes = joined.buffer;
      if (await sha256(bytes) !== asset.hash) throw new Fault('HASH_MISMATCH', 'Asset bytes do not match the approved SHA-256 hash.', { hash: asset.hash });
      inspect(bytes);
      abort.signal.throwIfAborted();
      gltf = await new Promise((resolve, reject) => new Loader().parse(bytes, '', resolve, reject));
      abort.signal.throwIfAborted();
      if (shadows) gltf.scene.traverse(node => { if (node.isMesh) { node.castShadow = true; node.receiveShadow = true; } });
      return { root: gltf.scene, dispose: releaseTree(gltf.scene) };
    } catch (e) { if (gltf?.scene) disposeTree(gltf.scene); throw e; }
    finally { clearTimeout(timer); signal?.removeEventListener('abort', cancel); }
  };
}
