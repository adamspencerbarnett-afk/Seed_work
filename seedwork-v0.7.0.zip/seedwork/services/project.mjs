import { randomUUID } from 'node:crypto';
import { Journal, digest, needRev, receipt } from './store.mjs';
import { Fault, obj, str, int, arr, id, vec, bool, copy, stable, validate, jsonSafe } from '../sdk/core/schema.mjs';
import { emptyScene, checkScene, applyOps, sceneDiff, queryScene, protect } from '../sdk/core/scene.mjs';

export const MANIFEST = obj({
  schema: { const: 'seedwork.project/1' }, id, name: str(), units: { const: 'm' }, up: { const: 'Y' },
  bounds: arr(vec(), 2, 2), locked: arr(id, 0, 2000), bindings: arr(id, 0, 128), requiredTests: arr(id, 0, 32),
  review: bool, requireCapture: bool, evidenceMaxAge: int(30, 3600)
}, ['schema', 'id', 'name', 'units', 'up', 'bounds', 'locked', 'bindings', 'requiredTests', 'review', 'requireCapture', 'evidenceMaxAge']);

export function assetFrom(model, ref, tags = []) {
  const width = model.width, height = model.height, depth = model.depth;
  return {
    hash: model.hash, name: model.name, size: [width, height, depth], boxes: copy(model.boxes), tags: [...new Set(tags)].slice(0, 24),
    sockets: { origin: { pos: [0, 0, 0], rot: [0, 0, 0] }, top: { pos: [0, height, 0], rot: [0, 0, 0] }, left: { pos: [-width / 2, 0, 0], rot: [0, 0, 0] }, right: { pos: [width / 2, 0, 0], rot: [0, 0, 0] } },
    source: { kind: 'native', ref, recipe: copy(model.recipe), build: copy(model.build ?? {}) }
  };
}

export class Projects {
  constructor(file, manifest, getAssets, checkAssets, notify = () => {}) {
    jsonSafe(manifest); validate(manifest, MANIFEST, 'project');
    if (manifest.bounds[0].some((v, i) => v >= manifest.bounds[1][i])) throw new Fault('INVALID', 'Project bounds must have positive dimensions.');
    this.manifest = copy(manifest); this.getAssets = getAssets; this.checkAssets = checkAssets; this.notify = notify;
    this.db = new Journal(file, { format: 1, project: manifest.id, rev: 0, doc: emptyScene(manifest.name), undo: [], redo: [], changes: {}, receipts: [] }, state => {
      if (state.format !== 1 || state.project !== manifest.id) throw new Error('Saved project does not match seedwork.json. Use a separate SEEDWORK_DIR for another project.');
      if (!Number.isSafeInteger(state.rev) || state.rev < 0) throw new Error('Invalid project revision.');
      checkScene(state.doc); this.checkAssets(state.doc);
      for (const c of Object.values(state.changes)) { checkScene(c.doc); checkScene(c.baseDoc); c.approval = null; c.evidence = []; c.preview = null; }
      for (const doc of [...state.undo, ...state.redo]) checkScene(doc);
    });
  }

  state(document = true) {
    const s = this.db.state;
    return { project: this.manifest.id, rev: s.rev, hash: digest(s.doc), name: s.doc.name, items: s.doc.items.length, assets: Object.keys(s.doc.assets).length, undo: s.undo.length, redo: s.redo.length, ...(document ? { doc: copy(s.doc) } : {}) };
  }

  inspect(hosts = []) {
    return { ...this.state(false), manifest: copy(this.manifest), changes: Object.values(this.db.state.changes).filter(c => c.state === 'open').map(c => this.view(c)), hosts };
  }

  view(c, document = false) {
    return { id: c.id, label: c.label, state: c.state, base: c.base, seq: c.seq, hash: c.hash, history: c.history ?? null, stale: c.base !== this.db.state.rev, diff: sceneDiff(c.baseDoc, c.doc), evidence: copy(c.evidence), approval: copy(c.approval), preview: copy(c.preview), ...(document ? { doc: copy(c.doc) } : {}) };
  }

  change(id, state = this.db.state, open = true) {
    const c = state.changes[id];
    if (!c) throw new Fault('NOT_FOUND', 'Change not found.', { id }, 404);
    if (open && c.state !== 'open') throw new Fault('CLOSED', `Change is ${c.state}.`, { id }, 409);
    return c;
  }

  stage(id, seq) {
    const c = this.change(id);
    needRev(seq, c.seq); needRev(c.base, this.db.state.rev);
    return { doc: copy(c.doc), meta: { project: this.manifest.id, rev: c.base, change: c.id, seq: c.seq, hash: c.hash } };
  }

  live() {
    const s = this.state();
    return { doc: s.doc, meta: { project: s.project, rev: s.rev, change: null, seq: null, hash: s.hash } };
  }

  begin(args) {
    return this.db.atomic(s => receipt(s, args.key, { name: 'change_begin', ...args }, () => {
      needRev(args.rev, s.rev);
      if (Object.values(s.changes).filter(c => c.state === 'open').length >= 8) throw new Fault('LIMIT', 'Eight changes are already open. Commit or discard one.');
      const history = args.history;
      if (history && !s[history].length) throw new Fault('NO_HISTORY', `No ${history} history is available.`);
      const doc = copy(history ? s[history].at(-1) : s.doc), id = `c_${randomUUID()}`;
      const c = { id, label: args.label, state: 'open', base: s.rev, seq: 0, baseDoc: copy(s.doc), doc, hash: digest(doc), history: history ?? null, evidence: [], approval: null, preview: null };
      s.changes[id] = c;
      const closed = Object.values(s.changes).filter(v => v.state !== 'open');
      for (const old of closed.slice(0, Math.max(0, closed.length - 24))) delete s.changes[old.id];
      return this.view(c);
    }));
  }

  apply(args) {
    const catalog = this.getAssets();
    return this.db.atomic(s => receipt(s, args.key, { name: 'change_apply', ...args }, () => {
      const c = this.change(args.id, s); needRev(args.seq, c.seq); needRev(c.base, s.rev);
      if (c.history) throw new Fault('HISTORY_LOCK', 'History proposals are exact snapshots and cannot be edited. Begin a normal change instead.');
      const result = applyOps(c.doc, args.ops, { resolveAsset: ref => catalog[ref], policy: this.manifest });
      this.checkAssets(result.doc);
      c.doc = result.doc; c.seq++; c.hash = digest(c.doc); c.evidence = []; c.preview = null; c.approval = null;
      return { ...this.view(c), results: result.results };
    }));
  }

  check(id) {
    const c = this.change(id);
    checkScene(c.doc); protect(this.db.state.doc, c.doc, this.manifest); this.checkAssets(c.doc);
    const missing = this.missing(c);
    return { valid: true, id, seq: c.seq, hash: c.hash, stale: c.base !== this.db.state.rev, changed: sceneDiff(c.baseDoc, c.doc).count, missing, note: 'Schema/bounds checks are not physics, visual approval, or global reachability proofs.' };
  }

  missing(c) {
    const fresh = e => e.hash === c.hash && e.seq === c.seq && e.host === c.preview?.host && Date.now() - e.at <= this.manifest.evidenceMaxAge * 1000;
    const missing = [];
    if (!c.preview || c.preview.hash !== c.hash || c.preview.seq !== c.seq) missing.push('preview');
    if (this.manifest.requireCapture && !c.evidence.some(e => e.type === 'capture' && fresh(e))) missing.push('capture');
    for (const name of this.manifest.requiredTests) {
      const latest = c.evidence.filter(e => e.type === 'test' && e.test === name && fresh(e)).at(-1);
      if (!latest?.passed) missing.push(`test:${name}`);
    }
    return missing;
  }

  evidence(host, kind, result) {
    const meta = result.meta;
    if (!meta || meta.project !== this.manifest.id || !meta.change) return;
    const c = this.change(meta.change);
    needRev(meta.seq, c.seq); needRev(meta.rev, this.db.state.rev);
    if (meta.hash !== c.hash) throw new Fault('STALE_EVIDENCE', 'Host evidence belongs to a different scene snapshot.', {}, 409);
    this.db.atomic(s => {
      const next = this.change(meta.change, s);
      const stamp = { host, seq: c.seq, hash: c.hash, at: Date.now() };
      if (kind === 'preview') { next.preview = stamp; next.approval = null; }
      else {
        next.evidence = next.evidence.filter(e => !(e.host === host && e.type === kind && e.test === result.test));
        next.evidence.push({ ...stamp, type: kind, ...(kind === 'test' ? { test: result.test, passed: result.passed === true, checks: copy(result.checks ?? []) } : { capture: result.capture }) });
        if (next.evidence.length > 64) next.evidence.shift();
        next.approval = null;
      }
    });
  }

  hostMatches(c, hosts) {
    const host = hosts.find(h => h.id === c.preview?.host);
    return Boolean(host?.scene && host.scene.project === this.manifest.id && host.scene.rev === c.base && host.scene.change === c.id && host.scene.seq === c.seq && host.scene.hash === c.hash);
  }

  approve(args, liveHosts) {
    return this.db.atomic(s => {
      needRev(args.rev, s.rev);
      const c = this.change(args.id, s); needRev(args.seq, c.seq); needRev(c.base, s.rev);
      const missing = this.missing(c);
      if (!this.hostMatches(c, liveHosts)) missing.push('host currently displaying this exact preview');
      if (missing.length) throw new Fault('EVIDENCE_REQUIRED', 'Review requires fresh evidence for this exact draft.', { missing }, 409);
      c.approval = { hash: c.hash, seq: c.seq, base: c.base, host: c.preview.host, at: Date.now() };
      return this.view(c);
    });
  }

  commit(args, liveHosts) {
    const result = this.db.atomic(s => receipt(s, args.key, { name: 'change_commit', ...args }, () => {
      needRev(args.rev, s.rev);
      const c = this.change(args.id, s); needRev(args.seq, c.seq); needRev(c.base, s.rev);
      const missing = this.missing(c);
      if (!this.hostMatches(c, liveHosts)) missing.push('host currently displaying this exact preview');
      if (missing.length) throw new Fault('EVIDENCE_REQUIRED', 'Required live evidence is missing or expired.', { missing }, 409);
      if (this.manifest.review && (!c.approval || c.approval.hash !== c.hash || c.approval.seq !== c.seq || c.approval.base !== s.rev || c.approval.host !== c.preview.host)) throw new Fault('APPROVAL_REQUIRED', 'A human must review and approve this exact draft in the local project UI.', {}, 403);
      checkScene(c.doc); protect(s.doc, c.doc, this.manifest); this.checkAssets(c.doc);
      if (stable(s.doc) === stable(c.doc)) throw new Fault('NO_CHANGE', 'This draft contains no changes.');
      const before = copy(s.doc);
      if (c.history) { s[c.history].pop(); s[c.history === 'undo' ? 'redo' : 'undo'].push(before); }
      else { s.undo.push(before); if (s.undo.length > 20) s.undo.shift(); s.redo = []; }
      s.doc = copy(c.doc); s.rev++; c.state = 'committed';
      return { id: c.id, seq: c.seq, rev: s.rev, hash: c.hash, diff: sceneDiff(before, s.doc), message: 'Committed as one revision.' };
    }));
    if (!result.replayed) this.notify({ type: 'commit', change: args.id, ...this.live() });
    return result;
  }

  discard(args) {
    const result = this.db.atomic(s => receipt(s, args.key, { name: 'change_discard', ...args }, () => {
      const c = this.change(args.id, s); needRev(args.seq, c.seq); c.state = 'discarded'; c.approval = null;
      return { id: c.id, state: c.state };
    }));
    if (!result.replayed) this.notify({ type: 'discard', change: args.id, ...this.live() });
    return result;
  }

  search(query = {}) {
    const q = (query.q ?? '').toLowerCase();
    const all = Object.entries(this.getAssets()).filter(([ref, asset]) =>
      (!q || `${ref} ${asset.name} ${asset.tags.join(' ')}`.toLowerCase().includes(q)) &&
      !(query.tags ?? []).some(t => !asset.tags.includes(t)) &&
      !query.maxSize?.some((n, i) => asset.size[i] > n)
    ).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    const start = query.offset ?? 0, limit = query.limit ?? 30;
    return { total: all.length, assets: all.slice(start, start + limit).map(([ref, { source, boxes, ...asset }]) => ({ ref, ...copy(asset), boxCount: boxes.length, source: { kind: source.kind, ref: source.ref } })), next: start + limit < all.length ? start + limit : null };
  }

  query(args) {
    const { change, ...q } = args;
    const c = change ? this.change(change) : null;
    return { rev: c?.base ?? this.db.state.rev, change: c?.id ?? null, seq: c?.seq ?? null, hash: c?.hash ?? digest(this.db.state.doc), ...queryScene(c?.doc ?? this.db.state.doc, q) };
  }
}
