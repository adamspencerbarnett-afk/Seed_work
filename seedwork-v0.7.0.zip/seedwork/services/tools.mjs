import { TOOLS, WORLD_WRITES } from '../core/tools.mjs';
import { PROJECT_TOOLS } from './project-tools.mjs';
import { validate, jsonSafe, obj, str, int, copy, Fault } from '../sdk/core/schema.mjs';
import { inspectPng } from '../modeler/service.mjs';
import { writeFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

export const definitions = [...TOOLS.map(t => ({ ...t, scope: 'world' })), ...PROJECT_TOOLS];

export function toolCatalog(wire = false) {
  return definitions.map(({ readOnly, scope, ...tool }) => {
    const def = copy(tool);
    if (wire && scope === 'world' && WORLD_WRITES.has(tool.name)) {
      def.inputSchema.properties._rev = { ...int(0, Number.MAX_SAFE_INTEGER), description: 'Observed world revision from world_inspect. Never replace a stale revision without reviewing the change.' };
      def.inputSchema.properties._key = { ...str(128), description: 'Stable retry key. Reuse with identical arguments after a network failure.' };
      def.inputSchema.required = [...(def.inputSchema.required ?? []), '_rev', '_key'];
    }
    return { ...def, description: `[${scope}] ${def.description}`, annotations: { readOnlyHint: Boolean(readOnly), destructiveHint: !readOnly, idempotentHint: Boolean(readOnly) || WORLD_WRITES.has(tool.name), openWorldHint: false } };
  });
}

export class ToolService {
  constructor(worlds, project, bridge, captures) { this.worlds = worlds; this.project = project; this.bridge = bridge; this.captures = captures; }

  async call(data) {
    jsonSafe(data);
    validate(data, obj({ name: str(64), args: { type: 'object' }, rev: int(0, Number.MAX_SAFE_INTEGER), key: str(128) }, ['name']));
    const def = definitions.find(t => t.name === data.name);
    if (!def) throw new Fault('NOT_FOUND', 'Unknown tool.', {}, 404);
    validate(data.args ?? {}, def.inputSchema);
    if (def.scope === 'world') return this.worlds.call(data.name, data.args ?? {}, data.rev, data.key);
    const result = await this.projectCall(data.name, data.args ?? {});
    return { scope: 'project', rev: this.project.db.state.rev, result };
  }

  async projectCall(name, args) {
    const p = this.project, b = this.bridge;
    if (name === 'project_inspect') return p.inspect(b.list());
    if (name === 'asset_search') return p.search(args);
    if (name === 'project_query') return p.query(args);
    if (name === 'change_begin') return p.begin(args);
    if (name === 'change_apply') return p.apply(args);
    if (name === 'change_read') return p.view(p.change(args.id, p.db.state, false), args.document);
    if (name === 'change_check') return p.check(args.id);
    if (name === 'change_commit') return p.commit(args, b.list());
    if (name === 'change_discard') return p.discard(args);
    if (name === 'change_preview') {
      const snapshot = p.stage(args.id, args.seq);
      const result = await b.request(args.host, 'preview', snapshot);
      p.evidence(args.host, 'preview', result);
      return result;
    }
    if (name === 'scene_reset') return b.request(args.host, 'reset', p.live());
    if (name === 'scene_query') return b.request(args.host, 'query', { query: args.query ?? {} });
    if (name === 'scene_profile') return b.request(args.host, 'profile');
    if (name === 'scene_test') {
      const result = await b.request(args.host, 'test', { test: args.test });
      if (result.test !== args.test || typeof result.passed !== 'boolean' || !Array.isArray(result.checks) || !result.checks.length || result.checks.length > 100 || result.checks.some(c => typeof c?.passed !== 'boolean' || typeof c?.name !== 'string') || result.passed !== result.checks.every(c => c.passed)) throw new Fault('HOST_CONTRACT', 'Test summary must agree with its named, boolean checks.');
      p.evidence(args.host, 'test', result);
      return result;
    }
    if (name === 'scene_capture') {
      const result = await b.request(args.host, 'capture');
      if (result.image?.mimeType !== 'image/png' || typeof result.image.data !== 'string' || !/^[A-Za-z0-9+/]*={0,2}$/.test(result.image.data)) throw new Fault('HOST_CONTRACT', 'Capture must be a base64 PNG image.');
      const bytes = Buffer.from(result.image.data, 'base64'), info = inspectPng(bytes);
      if (info.width !== result.image.width || info.height !== result.image.height) throw new Fault('HOST_CONTRACT', 'Capture dimensions do not match the PNG.');
      const file = resolve(this.captures, `${info.hash}.png`);
      if (!existsSync(file)) writeFileSync(file, bytes, { mode: 0o600 });
      result.capture = info.hash;
      p.evidence(args.host, 'capture', result);
      return result;
    }
    throw new Fault('NOT_FOUND', 'Unknown project tool.');
  }
}
