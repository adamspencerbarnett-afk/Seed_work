import { make, check, clone } from '../core/world.mjs';
import { TOOLS, tool, validate, WORLD_WRITES } from '../core/tools.mjs';
import { MODEL_KEY } from '../core/models.mjs';
import { Journal, receipt, needRev } from './store.mjs';
import { Fault, jsonSafe } from '../sdk/core/schema.mjs';

export class Worlds {
  constructor(file, modeler, checkAssets, notify = () => {}) {
    this.modeler = modeler;
    this.checkAssets = checkAssets;
    this.notify = notify;
    this.db = new Journal(file, { world: make(), rev: 0, receipts: [] }, state => {
      check(state.world);
      if (!Number.isSafeInteger(state.rev) || state.rev < 0) throw new Error('Invalid saved world revision.');
    });
    this.undo = [];
    this.redo = [];
  }

  state() {
    const { world, rev } = this.db.state;
    return { world, rev, undo: this.undo.length, redo: this.redo.length };
  }

  flush() { this.db.persist(this.db.state); }

  mutate(name, args, rev, key, reduce) {
    let history;
    const out = this.db.atomic(state => receipt(state, key, { name, args, rev }, () => {
      needRev(rev, state.rev);
      const before = clone(state.world);
      const result = reduce(state.world);
      check(result.world); this.checkAssets(result.world);
      state.world = result.world; state.rev++;
      history = { before, name };
      return { rev: state.rev, result: result.result ?? {} };
    }));
    if (history) {
      if (name === 'world_undo') { this.undo.pop(); this.redo.push(history.before); }
      else if (name === 'world_redo') { this.redo.pop(); this.undo.push(history.before); }
      else { this.undo.push(history.before); if (this.undo.length > 40) this.undo.shift(); this.redo.length = 0; }
      this.notify({ rev: out.rev, source: name });
    }
    return { ...this.state(), result: out.result, replayed: Boolean(out.replayed), receiptRev: out.rev };
  }

  replace(world, rev, key, source = 'import') {
    return this.mutate(source, { world }, rev, key, () => ({ world: check(world) }));
  }

  async call(name, args = {}, rev, key) {
    const def = TOOLS.find(t => t.name === name);
    if (!def) throw new Fault('NOT_FOUND', 'Unknown world tool.', {}, 404);
    jsonSafe(args); validate(args, def.inputSchema);
    if (WORLD_WRITES.has(name)) {
      return this.mutate(name, args, rev, key, world => {
        if (name === 'world_undo' || name === 'world_redo') {
          const from = name === 'world_undo' ? this.undo : this.redo;
          if (!from.length) throw new Fault('NO_HISTORY', 'No history available in this session.');
          return { world: clone(from.at(-1)), result: { message: name === 'world_undo' ? 'Undone.' : 'Redone.' } };
        }
        if (name === 'model_publish' || name === 'model_remove') return this.publish(world, name, args);
        if (name === 'world_batch') {
          let next = clone(world); const results = [];
          for (let i = 0; i < args.ops.length; i++) {
            const op = args.ops[i];
            if (!WORLD_WRITES.has(op.name) || op.name.startsWith('model_') || ['world_batch', 'world_undo', 'world_redo'].includes(op.name)) throw new Fault('INVALID', 'Only ordinary world mutations are allowed in a batch.', { operation: i });
            try { const out = tool(next, op.name, op.args ?? {}, { copy: false }); next = out.world; results.push(out.result); }
            catch (e) { throw new Fault(e.code ?? 'INVALID', e.message, { operation: i }); }
          }
          return { world: next, result: { results, operations: results.length } };
        }
        return tool(world, name, args);
      });
    }
    let result;
    if (name === 'model_list') result = { models: clone(this.db.state.world.models ?? {}), health: await this.modeler.health };
    else if (name === 'model_template') result = { recipe: clone(this.modeler.catalog.templates.find(t => t.id === args.template).recipe) };
    else if (name === 'model_build') result = { job: await this.modeler.start(args.recipe) };
    else if (name === 'model_status') result = { job: this.modeler.get(args.job) };
    else if (name === 'model_cancel') result = { job: this.modeler.cancel(args.job) };
    else result = tool(this.db.state.world, name, args).result;
    return { ...this.state(), result };
  }

  publish(world, name, args) {
    const next = clone(world);
    if (name === 'model_publish') {
      if (!MODEL_KEY.test(args.key)) throw new Fault('INVALID', 'Use m_ followed by 1–28 lowercase letters, numbers or underscores.');
      const job = this.modeler.get(args.job);
      if (job.state !== 'ready') throw new Fault('NOT_READY', 'Model build is not ready for review/publication.');
      const { report, ...model } = job.result;
      if (args.name) model.name = args.name;
      next.models ??= {}; next.models[args.key] = clone(model);
      return { world: next, result: { key: args.key, model: clone(model), message: 'Model published. Existing placements retain IDs and transforms.' } };
    }
    if (!next.models || !Object.hasOwn(next.models, args.key)) throw new Fault('NOT_FOUND', 'Native model not found.');
    if (next.objects.some(o => o.type === args.key) && !args.removeObjects) throw new Fault('IN_USE', 'Model is placed in the world. Remove placements first, or explicitly set removeObjects:true.');
    next.objects = next.objects.filter(o => o.type !== args.key); delete next.models[args.key];
    if (!Object.keys(next.models).length) delete next.models;
    return { world: next, result: { removed: args.key } };
  }
}
