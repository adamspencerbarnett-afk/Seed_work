import { obj, str, num, int, arr, choice, id, vec, bool } from '../sdk/core/schema.mjs';
import { OPS, QUERY } from '../sdk/core/scene.mjs';
const rev = int(0, Number.MAX_SAFE_INTEGER), key = str(128), seq = int(0, Number.MAX_SAFE_INTEGER);
const def = (name, description, properties = {}, required = [], readOnly = true) => ({ name, description, inputSchema: obj(properties, required), readOnly, scope: 'project' });
export const PROJECT_TOOLS = [
  def('project_inspect', 'Read the embedded project revision, permissions, active changes and connected host capabilities. Host-game semantics must be explicitly registered.'),
  def('asset_search', 'Search approved native starters, published world models and ready local builds. Filters precede bounded pagination; no downloads or paid generation.', { q: { type: 'string', maxLength: 120 }, tags: arr(str(40), 0, 24), maxSize: vec(.001, 1000), offset: int(0, 100000), limit: int(1, 100) }),
  def('project_query', 'Read a focused portion of the committed scene or a staged draft. Results are authoring data, not a capture of the live host.', { ...QUERY.properties, change: id }),
  def('change_begin', 'Start an isolated change from the observed project revision. Optional history creates an exact undo/redo proposal; it still requires review.', { rev, key, label: str(120), history: choice(['undo', 'redo']) }, ['rev', 'key', 'label'], false),
  def('change_apply', 'Apply up to 128 validated operations atomically to a draft. Use the observed change seq and a stable retry key. Asset use, sockets, path assembly and bindings are supported. Invalidates prior tests/approval.', { id, seq, key, ops: OPS }, ['id', 'seq', 'key', 'ops'], false),
  def('change_read', 'Read draft status, sequence, exact diff, approval and test evidence. document:true includes the entire draft for export or debugging.', { id, document: bool }, ['id']),
  def('change_check', 'Validate the draft, locked items, editable bounds and declared bindings. Reports missing live evidence; does not invent gameplay validation.', { id }, ['id']),
  def('change_preview', 'Load this exact draft in a connected development host without publishing it. The host owns rendering and game logic. Wait for loaded acknowledgement before testing.', { id, seq, host: id }, ['id', 'seq', 'host'], false),
  def('change_commit', 'Publish one atomic, undoable project revision. Requires current rev, change seq, passing required live tests and human approval when review is enabled. Never silently rebases.', { id, seq, rev, key }, ['id', 'seq', 'rev', 'key'], false),
  def('change_discard', 'Close a draft without committing. Connected hosts viewing it return to the current committed scene.', { id, seq, key }, ['id', 'seq', 'key'], false),
  def('scene_query', 'Query the actual scene loaded in a named host, including explicitly registered external entity metadata. Returns loaded revision/hash, which may be a preview.', { host: id, query: QUERY }, ['host']),
  def('scene_capture', 'Capture the host canvas immediately after its own final render, at native resolution. No generated image, forced render, resize, or quality downgrade. Includes camera and snapshot metadata.', { host: id }, ['host']),
  def('scene_test', 'Run one explicitly registered host test. The host owns gameplay simulation and state restoration. Evidence is tied to the loaded draft hash, sequence and host session.', { host: id, test: id }, ['host', 'test']),
  def('scene_profile', 'Read recent instrumented host frame intervals, optional CPU work durations and renderer counters. GPU timings and VRAM bytes are not inferred.', { host: id }, ['host']),
  def('scene_reset', 'Return one host to the current committed scene. Does not discard a draft or modify the game input system.', { host: id }, ['host'], false)
];
