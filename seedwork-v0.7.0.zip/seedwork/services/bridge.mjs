import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { Fault, obj, str, arr, id, validate, jsonSafe, copy, stable } from '../sdk/core/schema.mjs';

const HOST = obj({ project: id, name: str(), three: str(20), tests: arr(id, 0, 64), capabilities: arr({ type: 'string', enum: ['capture', 'query', 'profile', 'test'] }, 0, 4) }, ['project', 'name', 'three', 'tests', 'capabilities']);
const sameSecret = (value, expected) => {
  const a = Buffer.from(String(value ?? '')), b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
};

export class Bridge {
  constructor(project, { timeout = 15000, idle = 45000 } = {}) {
    this.project = project; this.timeout = timeout; this.idle = idle;
    this.peers = new Map(); this.commands = new Map(); this.closed = false;
    this.pulse = setInterval(() => { for (const peer of this.peers.values()) if (Date.now() - peer.last > this.idle) this.disconnect(peer.id); }, Math.min(idle, 5000));
    this.pulse.unref();
  }

  connect(data) {
    jsonSafe(data); validate(data, HOST, 'host');
    if (this.closed) throw new Fault('CLOSED', 'Host bridge is closed.');
    if (data.project !== this.project.manifest.id) throw new Fault('PROJECT_MISMATCH', 'Host project ID must match seedwork.json.');
    for (const peer of this.peers.values()) if (Date.now() - peer.last > this.idle) this.disconnect(peer.id);
    if (this.peers.size >= 8) throw new Fault('LIMIT', 'At most eight development hosts may be connected.');
    const peer = { ...copy(data), id: `h_${randomUUID()}`, token: randomBytes(32).toString('hex'), queue: [], active: null, waiting: null, last: Date.now(), scene: null, desired: this.project.live() };
    this.peers.set(peer.id, peer);
    return { id: peer.id, token: peer.token, project: data.project, instructions: 'Development bridge only. Call afterFrame after the host final render. No renderer, controls, camera or input loop is owned by this bridge.' };
  }

  list() {
    return [...this.peers.values()].filter(p => Date.now() - p.last <= this.idle).map(p => ({ id: p.id, name: p.name, project: p.project, three: p.three, tests: [...p.tests], capabilities: [...p.capabilities], scene: copy(p.scene), busy: Boolean(p.active), lastSeen: p.last }));
  }

  peer(id) {
    const peer = this.peers.get(id);
    if (!peer || Date.now() - peer.last > this.idle) throw new Fault('HOST_OFFLINE', 'The requested development host is not connected.', { host: id }, 409);
    return peer;
  }

  auth(id, token) {
    const peer = this.peer(id);
    if (!sameSecret(token, peer.token)) throw new Fault('UNAUTHORIZED', 'A host-scoped connection token is required.', {}, 401);
    peer.last = Date.now();
    return peer;
  }

  request(id, method, args = {}) {
    const peer = this.peer(id);
    if (!['preview', 'reset', 'sync'].includes(method) && !peer.capabilities.includes(method === 'test' ? 'test' : method)) throw new Fault('UNSUPPORTED', `Host capability not registered: ${method}.`);
    if (method === 'test' && !peer.tests.includes(args.test)) throw new Fault('UNSUPPORTED', `Host test not registered: ${args.test}.`);
    if (peer.queue.length >= 16) throw new Fault('BUSY', 'Host command queue is full. Wait for existing work.');
    return new Promise((resolve, reject) => {
      this.enqueue(peer, method, args, resolve, reject);
      this.wake(peer);
    });
  }

  enqueue(peer, method, args, resolve = () => {}, reject = () => {}) {
    const id = `r_${randomUUID()}`, command = { id, method, args: copy(args) };
    const record = { peer: peer.id, command, resolve, reject, started: false };
    record.timer = setTimeout(() => {
      this.commands.delete(id);
      peer.queue = peer.queue.filter(v => v !== id);
      if (peer.active === id) { peer.active = null; peer.scene = null; peer.desired = this.project.live(); }
      reject(new Fault('HOST_TIMEOUT', 'Host command timed out. No evidence or project commit was accepted.', { host: peer.id, method }, 504));
      this.wake(peer);
    }, this.timeout);
    record.timer.unref();
    this.commands.set(id, record); peer.queue.push(id);
    return command;
  }

  take(peer) {
    if (peer.active) return null;
    if (peer.desired) {
      const desired = peer.desired; peer.desired = null;
      const command = this.enqueue(peer, 'sync', desired);
      peer.queue = [command.id, ...peer.queue.filter(id => id !== command.id)];
    }
    while (peer.queue.length) {
      const id = peer.queue.shift(), record = this.commands.get(id);
      if (!record) continue;
      peer.active = id; record.started = true;
      return record.command;
    }
    return null;
  }

  wake(peer) {
    if (!peer.waiting) return;
    const command = this.take(peer);
    if (command) peer.waiting.finish(command);
  }

  next(id, token, signal) {
    const peer = this.auth(id, token);
    if (peer.waiting) throw new Fault('CONCURRENT_POLL', 'One host poll is allowed per connection.', {}, 409);
    const command = this.take(peer);
    if (command) return Promise.resolve(command);
    if (signal?.aborted) return Promise.resolve(null);
    return new Promise(resolve => {
      const cancel = () => finish(null);
      const timer = setTimeout(() => finish(null), Math.min(12000, this.idle / 3));
      const finish = value => { clearTimeout(timer); signal?.removeEventListener('abort', cancel); if (peer.waiting?.finish === finish) peer.waiting = null; resolve(value); };
      peer.waiting = { finish };
      signal?.addEventListener('abort', cancel, { once: true });
    });
  }

  complete(id, token, commandId, result, error) {
    const peer = this.auth(id, token), record = this.commands.get(commandId);
    if (!record || record.peer !== id || peer.active !== commandId || !record.started) throw new Fault('EXPIRED', 'Command is not active for this host.', {}, 410);
    this.commands.delete(commandId); clearTimeout(record.timer); peer.active = null;
    try {
      if (error) throw new Fault('HOST_ERROR', String(error.message ?? error).slice(0, 2000), { hostCode: error.code ?? null });
      jsonSafe(result);
      if (!result || typeof result !== 'object' || Array.isArray(result)) throw new Fault('HOST_CONTRACT', 'A host command must return structured JSON.');
      const expected = ['preview', 'reset', 'sync'].includes(record.command.method) ? record.command.args.meta : peer.scene;
      if (!expected || stable(result.meta) !== stable(expected)) throw new Fault('STALE_EVIDENCE', 'Host result does not match the expected loaded snapshot.', { expected, actual: result.meta }, 409);
      if (['preview', 'reset', 'sync'].includes(record.command.method)) {
        peer.scene = copy(result.meta);
        if (peer.desired && stable(peer.desired.meta) === stable(result.meta)) peer.desired = null;
      }
      record.resolve(copy(result));
    } catch (e) {
      record.reject(e);
      if (['preview', 'reset', 'sync'].includes(record.command.method)) { peer.scene = null; }
      this.wake(peer);
      return { accepted: false, error: { code: e.code ?? 'HOST_ERROR', message: e.message } };
    }
    this.wake(peer);
    return { accepted: true };
  }

  sync(event) {
    for (const peer of this.peers.values()) {
      if (!peer.scene?.change || peer.scene.change === event.change) {
        peer.desired = { doc: copy(event.doc), meta: copy(event.meta) };
        this.wake(peer);
      }
    }
  }

  disconnect(id) {
    const peer = this.peers.get(id);
    if (!peer) return;
    this.peers.delete(id);
    peer.waiting?.finish(null);
    for (const [key, record] of this.commands) if (record.peer === id) {
      clearTimeout(record.timer); this.commands.delete(key);
      record.reject(new Fault('HOST_OFFLINE', 'Host disconnected before completing the command.', { host: id }, 409));
    }
  }

  close() {
    this.closed = true; clearInterval(this.pulse);
    for (const id of [...this.peers.keys()]) this.disconnect(id);
  }
}
