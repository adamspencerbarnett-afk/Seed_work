import { readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { Fault, copy, stable, validate, str } from '../sdk/core/schema.mjs';

export const digest = value => createHash('sha256').update(stable(value)).digest('hex');
export const needRev = (expected, actual) => {
  if (!Number.isSafeInteger(expected) || expected < 0) throw new Fault('PRECONDITION', 'A nonnegative observed revision is required. Inspect before editing.', { actual }, 428);
  if (expected !== actual) throw new Fault('CONFLICT', 'Revision conflict. Inspect the new state; do not blindly retry an edit against a newer revision.', { expected, actual }, 409);
};

export class Journal {
  constructor(file, initial, check = () => {}, persist) {
    this.file = file;
    this.persist = persist ?? (state => {
      writeFileSync(`${file}.tmp`, JSON.stringify(state), { mode: 0o600 });
      renameSync(`${file}.tmp`, file);
    });
    this.state = file && existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : copy(initial);
    check(this.state);
  }

  atomic(fn) {
    const next = copy(this.state);
    const result = fn(next);
    if (result && typeof result.then === 'function') throw new Fault('ASYNC_TRANSACTION', 'Transactions must complete synchronously; prepare asynchronous work before entering.');
    this.persist(next);
    this.state = next;
    return copy(result);
  }
}

export function receipt(state, key, input, run) {
  validate(key, str(128), 'key');
  const signature = digest(input);
  state.receipts ??= [];
  const old = state.receipts.find(r => r.key === key);
  if (old) {
    if (old.signature !== signature) throw new Fault('KEY_REUSED', 'This request key was already used for different arguments.', {}, 409);
    return { ...copy(old.result), replayed: true };
  }
  const result = run();
  state.receipts.push({ key, signature, result: copy(result) });
  if (state.receipts.length > 512) state.receipts.shift();
  return result;
}
