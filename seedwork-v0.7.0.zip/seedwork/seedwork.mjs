import { readFileSync, writeFileSync, mkdirSync, existsSync, renameSync, rmSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { randomUUID } from 'node:crypto';
import { doctor, compile } from './modeler/compiler.mjs';
import { toolCatalog } from './services/tools.mjs';
import { PLAN_SCHEMA, validatePlan, writePlan } from './scripts/plan.mjs';

const root = import.meta.dirname, pkg = JSON.parse(readFileSync(resolve(root, 'package.json')));
const [cmd = 'help', ...args] = process.argv.slice(2), read = p => JSON.parse(readFileSync(resolve(p), 'utf8'));
const output = v => process.stdout.write(JSON.stringify(v, null, 2) + '\n');
function options(allowed) {
  const out = {};
  for (let i = 0; i < args.length; i += 2) {
    const name = args[i], value = args[i + 1];
    if (!allowed.includes(name) || value === undefined || value.startsWith('--') || Object.hasOwn(out, name)) throw new Error(`Expected option ${allowed.join(', ')} followed by its value.`);
    out[name] = value;
  }
  return out;
}
try {
  if (Number(process.versions.node.split('.')[0]) < 22) throw new Error('Node.js 22 or newer is required.');
  if (cmd === 'help') output({ version: pkg.version, commands: ['node seedwork.mjs doctor', 'node seedwork.mjs context', 'node seedwork.mjs tools', 'node seedwork.mjs schema', 'node seedwork.mjs validate --plan plan.json', 'node seedwork.mjs plan --input plan.json --out new-folder', 'node seedwork.mjs new --plan plan.json --out new-game', 'node seedwork.mjs model --recipe recipe.json --out new-model', 'node seedwork.mjs verify'], note: 'File-based commands run offline. They do not connect ChatGPT to a local browser or create a complete game from a prompt.' });
  else if (cmd === 'doctor') output({ version: pkg.version, compiler: doctor(), runtime: { node: process.version, renderer: 'Three.js r140, bundled', browser: 'WebGL-capable desktop browser, tested separately', dependenciesToDownload: [] }, transport: 'Local HTTP and optional stdio MCP; no hosted ChatGPT app is included.' });
  else if (cmd === 'context') output(read(resolve(root, 'seedwork-capabilities.json')));
  else if (cmd === 'tools') output({ version: pkg.version, tools: toolCatalog(true) });
  else if (cmd === 'schema') output(PLAN_SCHEMA);
  else if (cmd === 'validate') { const o = options(['--plan']); validatePlan(read(o['--plan'])); output({ valid: true, validation: 'Plan structure and operation schemas only; use plan/new for complete generation validation.' }); }
  else if (cmd === 'plan' || cmd === 'new') {
    const key = cmd === 'new' ? '--plan' : '--input', o = options([key, '--out']);
    if (!o[key] || !o['--out']) throw new Error(`${key} and --out are required.`);
    output(writePlan(read(o[key]), o['--out'], { inputs: resolve(dirname(resolve(o[key])), 'inputs'), standalone: cmd === 'new' }));
  } else if (cmd === 'model') {
    const o = options(['--recipe', '--out']);
    if (!o['--recipe'] || !o['--out']) throw new Error('--recipe and --out are required.');
    const target = resolve(o['--out']); if (existsSync(target)) throw new Error('Output exists. Choose a new model folder.');
    const temp = `${target}.seedwork-${randomUUID()}`; mkdirSync(temp, { recursive: true });
    try {
      const built = compile(read(o['--recipe']), { inputs: resolve(dirname(resolve(o['--recipe'])), 'inputs') });
      writeFileSync(resolve(temp, 'model.glb'), built.bytes); writeFileSync(resolve(temp, 'reference.glb'), built.reference);
      writeFileSync(resolve(temp, 'recipe.json'), JSON.stringify(built.result.recipe, null, 2)); writeFileSync(resolve(temp, 'audit.json'), JSON.stringify(built.result, null, 2));
      renameSync(temp, target); output({ path: target, hash: built.result.hash, ...built.result.report.packed, exact: built.result.report.exact.passed });
    } catch (e) { rmSync(temp, { recursive: true, force: true }); throw e; }
  } else if (cmd === 'verify') output((await import('./scripts/verify.mjs')).verify());
  else throw new Error(`Unknown command: ${cmd}. Run node seedwork.mjs help.`);
} catch (e) { output({ error: e.message }); process.exitCode = 1; }
