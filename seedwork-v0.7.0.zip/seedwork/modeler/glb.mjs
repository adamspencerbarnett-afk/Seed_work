import { createHash } from 'node:crypto';

export function packGlb(parts, materials, offset) {
  const doc = { asset: { version: '2.0', generator: 'Seedwork 0.7 native compiler' }, scene: 0, scenes: [{ nodes: [0] }], nodes: [{ name: 'Seedwork_meter_origin', translation: offset, children: [] }], meshes: [], materials: [], accessors: [], bufferViews: [], buffers: [], images: [], textures: [], samplers: [{ wrapS: 10497, wrapT: 10497, minFilter: 9987, magFilter: 9729 }] };
  const chunks = [], meshes = new Map(), geos = new Map(), textures = new Map(), mats = new Map(); let length = 0;
  function data(bytes, target) {
    const src = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength), padded = Buffer.alloc(Math.ceil(src.length / 4) * 4); src.copy(padded);
    const id = doc.bufferViews.length; doc.bufferViews.push({ buffer: 0, byteOffset: length, byteLength: src.length, ...(target ? { target } : {}) }); chunks.push(padded); length += padded.length; return id;
  }
  function accessor(a, size, target, bounds = false) {
    const entry = { bufferView: data(a, target), componentType: a instanceof Uint32Array ? 5125 : a instanceof Uint16Array ? 5123 : 5126, count: a.length / size, type: { 1: 'SCALAR', 2: 'VEC2', 3: 'VEC3', 4: 'VEC4' }[size] };
    if (bounds) {
      entry.min = Array(size).fill(Infinity); entry.max = Array(size).fill(-Infinity);
      for (let i = 0; i < a.length; i++) { const k = i % size; entry.min[k] = Math.min(entry.min[k], a[i]); entry.max[k] = Math.max(entry.max[k], a[i]); }
    }
    doc.accessors.push(entry); return doc.accessors.length - 1;
  }
  function texture(bytes, name) {
    const key = createHash('sha256').update(bytes).digest('hex');
    if (textures.has(key)) return textures.get(key);
    const image = doc.images.length; doc.images.push({ name, mimeType: 'image/png', bufferView: data(bytes) });
    const id = doc.textures.length; doc.textures.push({ source: image, sampler: 0 }); textures.set(key, id); return id;
  }
  for (const [name, m] of Object.entries(materials)) {
    const map = texture(m.maps.color, `${name} color`), normal = texture(m.maps.normal, `${name} normal`), orm = texture(m.maps.orm, `${name} orm`);
    mats.set(name, doc.materials.length);
    doc.materials.push({ name, pbrMetallicRoughness: { baseColorFactor: [1, 1, 1, 1], metallicFactor: 1, roughnessFactor: 1, baseColorTexture: { index: map }, metallicRoughnessTexture: { index: orm } }, normalTexture: { index: normal, scale: m.normalStrength }, occlusionTexture: { index: orm, texCoord: 1, strength: 1 }, doubleSided: false });
  }
  for (const part of parts) {
    const g = part.geometry;
    let primitive = geos.get(g);
    if (!primitive) {
      primitive = { attributes: {} };
      for (const [key, semantic] of [['position', 'POSITION'], ['normal', 'NORMAL'], ['tangent', 'TANGENT'], ['uv', 'TEXCOORD_0'], ['uv2', 'TEXCOORD_1']]) if (g.attributes[key]) {
        const a = g.attributes[key]; primitive.attributes[semantic] = accessor(new Float32Array(a.array), a.itemSize, 34962, key === 'position');
      }
      if (g.index) { const a = g.index.array, n = g.attributes.position.count; primitive.indices = accessor(n <= 65535 ? new Uint16Array(a) : new Uint32Array(a), 1, 34963); }
      geos.set(g, primitive);
    }
    const mat = mats.get(part.mat), meshKey = `${part.geoKey}:${mat}`;
    let mesh = meshes.get(meshKey);
    if (mesh === undefined) { mesh = doc.meshes.length; doc.meshes.push({ primitives: [{ ...primitive, material: mat }] }); meshes.set(meshKey, mesh); }
    doc.nodes[0].children.push(doc.nodes.length); doc.nodes.push({ name: part.name, mesh, matrix: part.matrix });
  }
  doc.buffers.push({ byteLength: length });
  const json = Buffer.from(JSON.stringify(doc)), jsonPad = Buffer.alloc(Math.ceil(json.length / 4) * 4, 32); json.copy(jsonPad);
  const header = Buffer.alloc(20); header.writeUInt32LE(0x46546c67, 0); header.writeUInt32LE(2, 4); header.writeUInt32LE(28 + jsonPad.length + length, 8); header.writeUInt32LE(jsonPad.length, 12); header.writeUInt32LE(0x4e4f534a, 16);
  const bin = Buffer.alloc(8); bin.writeUInt32LE(length, 0); bin.writeUInt32LE(0x004e4942, 4);
  return Buffer.concat([header, jsonPad, bin, ...chunks]);
}
export function readGlb(bytes) {
  const b = Buffer.from(bytes), n = b.readUInt32LE(12), doc = JSON.parse(b.subarray(20, 20 + n).toString('utf8')), bin = b.subarray(28 + n);
  function accessor(id) {
    const a = doc.accessors[id], view = doc.bufferViews[a.bufferView], size = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 }[a.type], width = a.componentType === 5123 ? 2 : 4;
    const data = bin.subarray((view.byteOffset ?? 0) + (a.byteOffset ?? 0), (view.byteOffset ?? 0) + (a.byteOffset ?? 0) + a.count * size * width);
    const get = i => a.componentType === 5123 ? data.readUInt16LE(i * 2) : a.componentType === 5125 ? data.readUInt32LE(i * 4) : data.readFloatLE(i * 4);
    return { a, size, width, data, get };
  }
  return { doc, bin, accessor };
}
export function signature(bytes) {
  const { doc, bin, accessor } = readGlb(bytes), hash = createHash('sha256');
  hash.update(JSON.stringify({ scene: doc.scene, scenes: doc.scenes, nodes: doc.nodes.map(({ mesh, ...n }) => n), materials: doc.materials, samplers: doc.samplers, textures: doc.textures }));
  for (const image of doc.images) { const v = doc.bufferViews[image.bufferView]; hash.update(image.name); hash.update(image.mimeType); hash.update(bin.subarray(v.byteOffset ?? 0, (v.byteOffset ?? 0) + v.byteLength)); }
  for (const node of doc.nodes) {
    if (node.mesh === undefined) continue;
    for (const primitive of doc.meshes[node.mesh].primitives) {
      const indices = primitive.indices !== undefined ? accessor(primitive.indices) : null;
      hash.update(JSON.stringify({ name: node.name, material: primitive.material, mode: primitive.mode ?? 4 }));
      for (const name of Object.keys(primitive.attributes).sort()) {
        const a = accessor(primitive.attributes[name]), count = indices?.a.count ?? a.a.count, corner = Buffer.alloc(count * a.size * a.width);
        for (let i = 0; i < count; i++) { const index = indices ? indices.get(i) : i; a.data.copy(corner, i * a.size * a.width, index * a.size * a.width, (index + 1) * a.size * a.width); }
        hash.update(JSON.stringify({ name, type: a.a.type, componentType: a.a.componentType, count })); hash.update(corner);
      }
    }
  }
  return hash.digest('hex');
}
export function stats(bytes) {
  const { doc } = readGlb(bytes), seen = new Set(); let uniqueVertices = 0, triangles = 0;
  for (const node of doc.nodes) if (node.mesh !== undefined) for (const p of doc.meshes[node.mesh].primitives) triangles += doc.accessors[p.indices ?? p.attributes.POSITION].count / 3;
  for (const mesh of doc.meshes) for (const p of mesh.primitives) { const id = p.attributes.POSITION; if (!seen.has(id)) { seen.add(id); uniqueVertices += doc.accessors[id].count; } }
  return { bytes: bytes.length, unique_vertices: uniqueVertices, drawn_triangles: triangles, meshes: doc.meshes.length, images: doc.images.length, image_bytes: doc.images.reduce((n, i) => n + doc.bufferViews[i.bufferView].byteLength, 0) };
}
