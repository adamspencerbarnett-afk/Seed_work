import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { compile, doctor } from './compiler.mjs';

const emit = value => process.stdout.write(JSON.stringify(value) + '\n');
try {
  if (process.argv[2] === '--doctor') emit(doctor());
  else {
    const [folder, inputs, cache] = process.argv.slice(2);
    if (!folder || !inputs || !cache) throw new Error('Expected job, input and cache directories.');
    const data = JSON.parse(readFileSync(resolve(folder, 'recipe.json'), 'utf8'));
    const built = compile(data, { inputs, cache, phase: text => emit({ event: 'phase', phase: text }) });
    mkdirSync(resolve(folder, 'compiled'), { recursive: true });
    writeFileSync(resolve(folder, 'compiled/model.glb'), built.bytes);
    writeFileSync(resolve(folder, 'reference.glb'), built.reference);
    writeFileSync(resolve(folder, 'result.json'), JSON.stringify(built.result, null, 2));
    emit({ event: 'done', result: built.result });
  }
} catch (e) { emit({ event: 'error', error: e.message }); process.exitCode = 1; }
