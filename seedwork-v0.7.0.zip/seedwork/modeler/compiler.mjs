import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { validateRecipe, capabilities } from './schema.mjs';
import { geometry, matrix, bounds, exactWeld } from './geometry.mjs';
import { material } from './materials.mjs';
import { packGlb, signature, stats } from './glb.mjs';

const stable = v => Array.isArray(v) ? v.map(stable) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map(k => [k, stable(v[k])])) : v;
export const digest = v => createHash('sha256').update(Buffer.isBuffer(v) ? v : JSON.stringify(stable(v))).digest('hex');
export function doctor() {
  const h = createHash('sha256');
  for (const name of ['compiler.mjs', 'worker.mjs', 'schema.mjs', 'geometry.mjs', 'materials.mjs', 'glb.mjs', 'png.mjs', '../core/models.mjs', '../public/vendor/three-r140.min.js']) {
    h.update(name); h.update(readFileSync(new URL(name, import.meta.url)));
  }
  return { ok: true, node: process.versions.node, source: h.digest('hex'), engine: '0.7.0', network: false, capabilities };
}
export function compile(data, { inputs = '', cache = '', phase = () => {} } = {}) {
  const started = performance.now(); validateRecipe(data);
  const code = doctor(), geos = new Map(), parts = [], boxes = [];
  let triangles = 0;
  phase('Building dimensioned geometry');
  for (const part of data.parts) {
    const { name, mat, pos, rot, scale, ...geoSpec } = part, key = digest(geoSpec);
    let g = geos.get(key);
    if (!g) { g = geometry(part); geos.set(key, g); }
    triangles += (g.index?.count ?? g.attributes.position.count) / 3;
    if (triangles > (data.max_triangles ?? 80000)) throw new Error('Authored geometry exceeds the triangle limit. Split the assembly or explicitly edit its settings; detail was not removed.');
    const m = matrix(part); boxes.push(bounds(g, m)); parts.push({ name, mat, geometry: g, matrix: m.toArray(), geoKey: key });
  }
  const lo = [0, 1, 2].map(i => Math.min(...boxes.map(b => b[0][i]))), hi = [0, 1, 2].map(i => Math.max(...boxes.map(b => b[1][i]))), dims = hi.map((v, i) => v - lo[i]);
  if (dims.some(v => !Number.isFinite(v) || v < .00001 || v > 100)) throw new Error('Model dimensions must be finite, nonzero and at most 100 meters.');
  const offset = [-(lo[0] + hi[0]) / 2, -lo[1], -(lo[2] + hi[2]) / 2];
  phase('Creating PBR maps at the authored resolution');
  const materials = {}; let hits = 0, misses = 0;
  for (const key of [...new Set(parts.map(p => p.mat))]) {
    const m = data.materials[key], size = m.tex_size ?? data.texture_size ?? 512;
    const built = material(m, { size, seed: data.seed ?? 42, inputs, cache, source: code.source });
    built.hit ? hits++ : misses++;
    materials[key] = { ...built, normalStrength: m.normal_strength ?? 1 };
  }
  phase('Packing and checking exact rendering data');
  const raw = packGlb(parts, materials, offset), packed = new Map();
  for (const [key, g] of geos) packed.set(key, exactWeld(g));
  const bytes = packGlb(parts.map(p => ({ ...p, geometry: packed.get(p.geoKey) })), materials, offset);
  if (bytes.length > 24 * 1024 * 1024) throw new Error('Model exceeds 24 MiB. Split the model or explicitly change authoring settings; no texture was resized.');
  const before = signature(raw), after = signature(bytes);
  if (before !== after) throw new Error('Exact rendering-data verification failed. Nothing was published.');
  const result = {
    hash: digest(bytes), name: data.name.replaceAll('_', ' '), width: dims[0], height: dims[1], depth: dims[2], radius: Math.hypot(dims[0], dims[2]) / 2,
    boxes: boxes.map(box => box.map(v => v.map((n, i) => n + offset[i]))), recipe: structuredClone(data),
    build: { source: code.source, recipeHash: digest(data), version: '0.7.0' },
    report: { seconds: Math.round((performance.now() - started) / 10) / 100, runtime: code, materials: { hits, misses }, raw: stats(raw), packed: stats(bytes), exact: { passed: true, before, after, checks: ['Triangle-corner bytes and winding', 'Normals and both UV channels', 'PNG bytes and texture samplers', 'Material values', 'Node graph and transforms'] }, geometry: { parts: parts.length, unique: geos.size }, limits: ['Independent compiler; appearance differs from the unlicensed legacy modeling backend.', 'Static procedural geometry; no automatic LOD, texture resizing, or decimation.', 'Advanced legacy sculpt/stamp/decal fields are rejected, never ignored.', 'Compound boxes are conservative collision proxies, not mesh-accurate physics.'] }
  };
  for (const g of [...geos.values(), ...packed.values()]) g.dispose();
  return { bytes, reference: raw, result };
}
