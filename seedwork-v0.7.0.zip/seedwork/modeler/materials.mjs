import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { encodePng, decodePng } from './png.mjs';

const clamp = n => Math.max(0, Math.min(1, n));
const byte = n => Math.round(clamp(n) * 255);
const hash = b => createHash('sha256').update(b).digest('hex');
const stable = v => Array.isArray(v) ? v.map(stable) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map(k => [k, stable(v[k])])) : v;
function rand(x, y, seed) {
  let n = Math.imul(x ^ seed, 374761393) ^ Math.imul(y + 1, 668265263);
  n = Math.imul(n ^ n >>> 13, 1274126177); return ((n ^ n >>> 16) >>> 0) / 4294967296;
}
function noise(x, y, seed) {
  const ix = Math.floor(x), iy = Math.floor(y), a = x - ix, b = y - iy, u = a * a * (3 - 2 * a), v = b * b * (3 - 2 * b);
  const p = rand(ix, iy, seed), q = rand(ix + 1, iy, seed), r = rand(ix, iy + 1, seed), s = rand(ix + 1, iy + 1, seed);
  return p * (1 - u) * (1 - v) + q * u * (1 - v) + r * (1 - u) * v + s * u * v;
}
function defaultColor(kind) {
  return ({ wood: [.48, .36, .24], stone: [.58, .56, .51], concrete: [.51, .50, .48], steel: [.45, .46, .47], paint: [.29, .38, .40], solid: [.6, .6, .6], image: [1, 1, 1] })[kind];
}
function readMap(ref, inputs, size) {
  const name = ref.split('/').at(-1), bytes = readFileSync(resolve(inputs, name));
  if (hash(bytes) !== name.slice(0, -4)) throw new Error('Input PNG content hash changed.');
  const image = decodePng(bytes);
  if (image.width !== size || image.height !== size) throw new Error(`Source map must be ${size} × ${size}. Automatic resizing is disabled.`);
  return { bytes, ...image };
}
export function material(m, { size, seed, inputs, cache, source }) {
  const key = hash(JSON.stringify(stable({ m, size, seed, source }))), dir = cache ? resolve(cache, key) : null;
  if (dir && existsSync(resolve(dir, 'entry.json'))) {
    try {
      const entry = JSON.parse(readFileSync(resolve(dir, 'entry.json'))), maps = {};
      for (const name of ['color', 'normal', 'orm']) {
        const b = readFileSync(resolve(dir, `${name}.png`)); if (hash(b) !== entry.hashes[name]) throw new Error('Bad cached map.'); maps[name] = b;
      }
      return { maps, hit: true, size };
    } catch {}
  }
  const supplied = {};
  for (const name of ['image', 'normal', 'orm', 'height']) if (m[name]) supplied[name] = readMap(m[name], inputs, size);
  const count = size * size, color = Buffer.alloc(count * 3), normal = Buffer.alloc(count * 3), orm = Buffer.alloc(count * 3), heights = new Float32Array(count);
  const rgb = m.color ?? defaultColor(m.kind), rough = m.rough ?? .75, metal = m.metal ?? (m.kind === 'steel' ? 1 : 0), wear = m.wear ?? .1;
  const tau = Math.PI * 2;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const u = x / size, v = y / size, i = y * size + x, low = noise(u * 8, v * 8, seed), fine = noise(u * 120, v * 120, seed + 3);
    let detail = .5, tone = 1, relief = .5;
    if (m.kind === 'wood') {
      const warp = noise(u * 4, v * 12, seed) * .10 + .025 * Math.sin(u * tau * 2 + seed);
      const line = Math.sin((v + warp) * tau * 55 + noise(u * 12, v * 30, seed + 9));
      detail = .5 + .5 * line; relief = .25 * detail + .55 * fine + .20 * low; tone = .83 + .12 * detail + .17 * low;
    } else if (m.kind === 'stone' || m.kind === 'concrete') {
      detail = noise(u * 35, v * 35, seed + 6); relief = .40 * detail + .35 * fine + .25 * low; tone = .85 + .14 * low + .12 * detail;
    } else if (m.kind === 'paint' || m.kind === 'steel') {
      detail = noise(u * 64, v * 140, seed + 5); relief = .5 * fine + .5 * detail; tone = .94 + .06 * low + .015 * detail;
    }
    if (supplied.height) {
      const h = supplied.height, off = i * h.channels;
      relief = h.channels === 1 ? h.pixels[off] / 255 : (.2126 * h.pixels[off] + .7152 * h.pixels[off + 1] + .0722 * h.pixels[off + 2]) / 255;
    }
    heights[i] = relief;
    for (let c = 0; c < 3; c++) color[i * 3 + c] = byte(rgb[c] * tone);
    orm[i * 3] = 255; orm[i * 3 + 1] = byte(rough + (detail - .5) * wear * .22); orm[i * 3 + 2] = byte(metal);
  }
  const bump = m.bump ?? .0002;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const left = heights[y * size + Math.max(0, x - 1)], right = heights[y * size + Math.min(size - 1, x + 1)], down = heights[Math.max(0, y - 1) * size + x], up = heights[Math.min(size - 1, y + 1) * size + x];
    const dx = -(right - left) * size * bump * .5, dy = -(up - down) * size * bump * .5, len = Math.hypot(dx, dy, 1), off = (y * size + x) * 3;
    normal[off] = byte(.5 + .5 * dx / len); normal[off + 1] = byte(.5 + .5 * dy / len); normal[off + 2] = byte(.5 + .5 / len);
  }
  const maps = { color: supplied.image?.bytes ?? encodePng(size, size, color), normal: supplied.normal?.bytes ?? encodePng(size, size, normal), orm: supplied.orm?.bytes ?? encodePng(size, size, orm) };
  if (dir) {
    mkdirSync(dir, { recursive: true });
    for (const [name, bytes] of Object.entries(maps)) writeFileSync(resolve(dir, `${name}.png`), bytes);
    writeFileSync(resolve(dir, 'entry.json'), JSON.stringify({ hashes: Object.fromEntries(Object.entries(maps).map(([k, v]) => [k, hash(v)])) }));
  }
  return { maps, hit: false, size };
}
