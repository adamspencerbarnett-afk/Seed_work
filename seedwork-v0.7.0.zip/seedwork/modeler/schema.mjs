import { checkRecipe } from '../core/models.mjs';

const kinds = ['wood', 'stone', 'steel', 'paint', 'concrete', 'solid', 'image'];
const shapes = ['box', 'cylinder', 'ellipsoid', 'torus', 'bowl', 'lathe', 'hose', 'plate'];
const sizes = [64, 128, 256, 512, 1024, 2048];
function keys(v, allowed, label) {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error(`${label} must be an object.`);
  for (const k of Object.keys(v)) if (!allowed.includes(k)) throw new Error(`${label}.${k} is not supported by the self-contained compiler. It was not ignored.`);
}
function num(n, lo, hi, label, integer = false) {
  if (!Number.isFinite(n) || n < lo || n > hi || integer && !Number.isInteger(n)) throw new Error(`${label} must be ${integer ? 'an integer ' : ''}from ${lo} to ${hi}.`);
}
function vec(v, n, lo, hi, label) {
  if (!Array.isArray(v) || v.length !== n) throw new Error(`${label} needs ${n} values.`);
  v.forEach(x => num(x, lo, hi, label));
}
export function validateRecipe(data) {
  checkRecipe(data);
  keys(data, ['schema', 'name', 'brief', 'seed', 'texture_size', 'max_triangles', 'lods', 'materials', 'parts'], 'recipe');
  if (typeof data.name !== 'string' || !data.name.trim() || data.name.length > 64) throw new Error('Model name must contain 1–64 characters.');
  if (data.brief !== undefined && (typeof data.brief !== 'string' || data.brief.length > 2048)) throw new Error('Brief exceeds 2048 characters.');
  num(data.seed ?? 42, 0, 2147483647, 'seed', true);
  num(data.max_triangles ?? 80000, 1, 80000, 'max_triangles', true);
  if (!sizes.includes(data.texture_size ?? 512)) throw new Error('Choose an explicit supported texture size (64–2048).');
  if (!data.materials || typeof data.materials !== 'object' || Array.isArray(data.materials) || !Object.keys(data.materials).length || Object.keys(data.materials).length > 32) throw new Error('Use 1–32 materials.');
  for (const [key, m] of Object.entries(data.materials)) {
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(key)) throw new Error('Material IDs use letters, digits, underscores or hyphens.');
    keys(m, ['kind', 'color', 'rough', 'metal', 'bump', 'normal_strength', 'wear', 'tex_size', 'image', 'normal', 'orm', 'height'], `material ${key}`);
    if (!kinds.includes(m.kind)) throw new Error(`Unknown material kind ${m.kind}.`);
    if (m.color !== undefined) vec(m.color, 3, 0, 1, 'material color');
    for (const p of ['rough', 'metal', 'wear']) if (m[p] !== undefined) num(m[p], 0, 1, p);
    if (m.bump !== undefined) num(m.bump, 0, .1, 'bump');
    if (m.normal_strength !== undefined) num(m.normal_strength, 0, 10, 'normal_strength');
    if (m.tex_size !== undefined && !sizes.includes(m.tex_size)) throw new Error('Unsupported material texture size.');
    for (const field of ['image', 'normal', 'orm', 'height']) if (m[field] !== undefined && (typeof m[field] !== 'string' || !/^inputs\/[a-f0-9]{64}\.png$/.test(m[field]))) throw new Error('Surface inputs must use uploaded inputs/<sha256>.png references.');
    if (m.kind === 'image' && !m.image) throw new Error('Image materials require an uploaded base color PNG.');
    if (m.height && m.normal) throw new Error('Choose height baking or a supplied normal map, not both.');
  }
  const names = new Set();
  for (const p of data.parts) {
    const common = ['name', 'shape', 'mat', 'pos', 'rot', 'scale', 'tile', 'uv'];
    const byShape = { box: ['size', 'bevel'], cylinder: ['radius', 'length', 'steps', 'top', 'inner'], ellipsoid: ['size', 'steps', 'rings'], torus: ['radius', 'tube', 'steps', 'rings'], bowl: ['size', 'depth', 'steps', 'rings'], lathe: ['profile', 'steps'], hose: ['points', 'radius', 'steps', 'samples'], plate: ['points', 'depth'] };
    if (!shapes.includes(p.shape)) throw new Error(`Unsupported primitive ${p.shape}.`);
    keys(p, [...common, ...byShape[p.shape]], `part ${p.name}`);
    if (typeof p.name !== 'string' || !p.name.trim() || p.name.length > 64 || names.has(p.name)) throw new Error('Part names must be unique and contain 1–64 characters.');
    names.add(p.name);
    if (!Object.hasOwn(data.materials, p.mat)) throw new Error(`Part ${p.name} references a missing material.`);
    if (p.pos !== undefined) vec(p.pos, 3, -100, 100, 'position');
    if (p.rot !== undefined) vec(p.rot, 3, -36000, 36000, 'rotation');
    if (p.scale !== undefined) vec(p.scale, 3, .0001, 100, 'scale');
    if (p.tile !== undefined) vec(p.tile, 2, .0001, 1000, 'UV tiling');
    if (p.uv !== undefined && !['box', 'grain', 'cylinder', 'default'].includes(p.uv)) throw new Error('Unsupported UV mode.');
    if (p.uv === 'box' && p.shape !== 'box' || p.uv === 'cylinder' && p.shape !== 'cylinder') throw new Error('UV mode must match its primitive; alternate projection modes are not silently substituted.');
    if (p.uv === 'grain' && p.shape !== 'box') throw new Error('Grain UVs are supported for boxes only.');
    if (p.size !== undefined) vec(p.size, 3, .00001, 100, 'size');
    for (const k of ['radius', 'length', 'tube', 'depth']) if (p[k] !== undefined) num(p[k], .00001, 100, k);
    for (const k of ['top', 'inner', 'bevel']) if (p[k] !== undefined) num(p[k], 0, 100, k);
    if (p.steps !== undefined) num(p.steps, 3, 256, 'steps', true);
    if (p.rings !== undefined) num(p.rings, 3, 128, 'rings', true);
    if (p.samples !== undefined) num(p.samples, 2, 256, 'samples', true);
    if (['box', 'ellipsoid', 'bowl'].includes(p.shape) && !p.size) throw new Error(`${p.shape} requires size.`);
    if (p.shape === 'box' && (p.bevel ?? 0) >= Math.min(...p.size) / 2) throw new Error('Box bevel must be smaller than half the smallest dimension.');
    if (['cylinder', 'torus', 'hose'].includes(p.shape) && !p.radius) throw new Error(`${p.shape} requires radius.`);
    if (p.shape === 'cylinder' && (!p.length || (p.inner ?? 0) >= Math.min(p.radius, p.top ?? p.radius))) throw new Error('Cylinder needs length and an inner radius smaller than both outer radii.');
    if (p.shape === 'torus' && (!p.tube || p.tube >= p.radius)) throw new Error('Torus tube must be smaller than its major radius.');
    if (p.shape === 'bowl' && (!p.depth || p.depth >= Math.min(p.size[0], p.size[2]) / 4 || p.depth >= p.size[1] / 2)) throw new Error('Bowl wall depth is too large for its dimensions.');
    if (['plate', 'hose', 'lathe'].includes(p.shape)) {
      const points = p.shape === 'lathe' ? p.profile : p.points;
      const min = p.shape === 'plate' ? 3 : 2;
      if (!Array.isArray(points) || points.length < min || points.length > 128) throw new Error(`${p.shape} needs ${min}–128 control points.`);
      points.forEach(v => vec(v, p.shape === 'hose' ? 3 : 2, -100, 100, 'control point'));
      if (p.shape === 'lathe' && points.some(v => v[0] < 0)) throw new Error('Lathe radii cannot be negative.');
      if (p.shape === 'plate' && !p.depth) throw new Error('Plate requires depth.');
    }
  }
  return data;
}
export const capabilities = Object.freeze({ compiler: 'seedwork-native', shapes, materials: kinds, textureSizes: sizes, advancedSculpt: false, stamps: false, staticOnly: true, automaticLod: false, dependencies: ['Node.js 22+', 'bundled Three.js r140'] });
