import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';

const scope = { console, performance };
runInNewContext(readFileSync(new URL('../public/vendor/three-r140.min.js', import.meta.url), 'utf8'), scope, { filename: 'three-r140.min.js', timeout: 10000 });
export const THREE = scope.THREE;
const T = THREE;

function box(p) {
  const size = p.size, b = p.bevel ?? 0, pos = [], norm = [], uv = [], idx = [];
  for (let axis = 0; axis < 3; axis++) for (const sign of [-1, 1]) {
    const u = (axis + 1) % 3, v = (axis + 2) % 3;
    const grid = a => b ? [-size[a] / 2, -size[a] / 2 + b / 2, -size[a] / 2 + b, size[a] / 2 - b, size[a] / 2 - b / 2, size[a] / 2] : [-size[a] / 2, size[a] / 2];
    const xs = grid(u), ys = grid(v), start = pos.length / 3;
    const grain = p.uv === 'grain', gu = grain && size[v] > size[u] ? v : u, gv = gu === u ? v : u;
    for (const y of ys) for (const x of xs) {
      const q = [0, 0, 0]; q[axis] = sign * size[axis] / 2; q[u] = x; q[v] = y;
      const center = q.map((n, i) => Math.max(-size[i] / 2 + b, Math.min(size[i] / 2 - b, n)));
      let n = q.map((a, i) => a - center[i]);
      const length = Math.hypot(...n);
      n = b ? n.map(a => a / length) : [0, 0, 0];
      if (!b) n[axis] = sign;
      const point = b ? center.map((a, i) => a + b * n[i]) : q;
      pos.push(...point); norm.push(...n); uv.push(point[gu] / size[gu] + .5, point[gv] / size[gv] + .5);
    }
    for (let y = 0; y < ys.length - 1; y++) for (let x = 0; x < xs.length - 1; x++) {
      const a = start + y * xs.length + x, c = a + xs.length, d = c + 1;
      idx.push(...(sign > 0 ? [a, a + 1, d, a, d, c] : [a, d, a + 1, a, c, d]));
    }
  }
  const g = new T.BufferGeometry();
  g.setAttribute('position', new T.Float32BufferAttribute(pos, 3));
  g.setAttribute('normal', new T.Float32BufferAttribute(norm, 3));
  g.setAttribute('uv', new T.Float32BufferAttribute(uv, 2)); g.setIndex(idx);
  return g;
}
function plate(p) {
  let area = 0;
  for (let i = 0; i < p.points.length; i++) { const a = p.points[i], b = p.points[(i + 1) % p.points.length]; area += a[0] * b[1] - b[0] * a[1]; }
  if (Math.abs(area) < 1e-10) throw new Error('Plate polygon has zero area.');
  const points = area < 0 ? [...p.points].reverse() : p.points;
  const side = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  for (let i = 0; i < points.length; i++) for (let j = i + 2; j < points.length; j++) {
    if (i === 0 && j === points.length - 1) continue;
    const a = points[i], b = points[(i + 1) % points.length], c = points[j], d = points[(j + 1) % points.length];
    if (side(a, b, c) * side(a, b, d) <= 0 && side(c, d, a) * side(c, d, b) <= 0) throw new Error('Plate polygon intersects itself.');
  }
  const shape = new T.Shape(points.map(v => new T.Vector2(...v)));
  const g = new T.ExtrudeGeometry(shape, { depth: p.depth, steps: 1, bevelEnabled: false });
  g.translate(0, 0, -p.depth / 2); return g;
}
function bowl(p) {
  const [w, h, d] = p.size, thick = p.depth, rings = p.rings ?? 24, points = [];
  for (let i = 0; i <= rings; i++) { const a = i / rings * Math.PI / 2; points.push(new T.Vector2(w / 2 * Math.sin(a), h * (1 - Math.cos(a)))); }
  for (let i = rings; i >= 0; i--) { const a = i / rings * Math.PI / 2; points.push(new T.Vector2((w / 2 - thick) * Math.sin(a), thick + (h - thick) * (1 - Math.cos(a)))); }
  points.push(points[0].clone());
  const g = new T.LatheGeometry(points, p.steps ?? 96); g.scale(1, 1, d / w); return g;
}
export function geometry(p) {
  let g;
  if (p.shape === 'box') g = box(p);
  if (p.shape === 'cylinder') {
    if (p.inner) {
      const r = p.radius, top = p.top ?? r, h = p.length / 2, ri = p.inner;
      g = new T.LatheGeometry([[ri, -h], [r, -h], [r, -h], [top, h], [top, h], [ri, h], [ri, h], [ri, -h]].map(v => new T.Vector2(...v)), p.steps ?? 96);
    } else g = new T.CylinderGeometry(p.top ?? p.radius, p.radius, p.length, p.steps ?? 96, 1, false);
  }
  if (p.shape === 'ellipsoid') { g = new T.SphereGeometry(.5, p.steps ?? 96, p.rings ?? 48); g.scale(...p.size); }
  if (p.shape === 'torus') { g = new T.TorusGeometry(p.radius, p.tube, p.rings ?? 24, p.steps ?? 96); g.rotateX(Math.PI / 2); }
  if (p.shape === 'lathe') g = new T.LatheGeometry(p.profile.map(v => new T.Vector2(...v)), p.steps ?? 96);
  if (p.shape === 'hose') {
    const points = p.points.map(v => new T.Vector3(...v));
    if (points.some((v, i) => i && v.distanceTo(points[i - 1]) < 1e-6)) throw new Error('Hose control points must be distinct.');
    g = new T.TubeGeometry(new T.CatmullRomCurve3(points, false, 'centripetal'), p.samples ?? 64, p.radius, p.steps ?? 16, false);
  }
  if (p.shape === 'plate') g = plate(p);
  if (p.shape === 'bowl') g = bowl(p);
  if (!g) throw new Error(`Unsupported geometry ${p.shape}.`);
  if (p.tile) {
    const uv = g.getAttribute('uv');
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * p.tile[0], uv.getY(i) * p.tile[1]);
  }
  g.clearGroups();
  if (g.getAttribute('uv')) g.setAttribute('uv2', g.getAttribute('uv').clone());
  for (const attr of Object.values(g.attributes)) for (const n of attr.array) if (!Number.isFinite(n)) throw new Error(`Nonfinite geometry in ${p.name}.`);
  if (!g.index) g.setIndex(Array.from({ length: g.attributes.position.count }, (_, i) => i));
  g.computeTangents();
  g.computeBoundingBox(); return g;
}
export function matrix(p) {
  const rot = (p.rot ?? [0, 0, 0]).map(n => n * Math.PI / 180);
  return new T.Matrix4().compose(new T.Vector3(...(p.pos ?? [0, 0, 0])), new T.Quaternion().setFromEuler(new T.Euler(...rot, 'XYZ')), new T.Vector3(...(p.scale ?? [1, 1, 1])));
}
export function bounds(g, mat) {
  const box = new T.Box3(), v = new T.Vector3(), pos = g.getAttribute('position');
  for (let i = 0; i < pos.count; i++) box.expandByPoint(v.fromBufferAttribute(pos, i).applyMatrix4(mat));
  return [box.min.toArray(), box.max.toArray()];
}
export function exactWeld(g) {
  const names = Object.keys(g.attributes).sort(), arrays = Object.fromEntries(names.map(k => [k, []]));
  const index = [], seen = new Map(), count = g.index?.count ?? g.attributes.position.count;
  for (let i = 0; i < count; i++) {
    const src = g.index ? g.index.getX(i) : i, chunks = [];
    for (const name of names) {
      const a = g.attributes[name]; chunks.push(Buffer.from(a.array.buffer, a.array.byteOffset + src * a.itemSize * 4, a.itemSize * 4));
    }
    const key = Buffer.concat(chunks).toString('base64');
    let dst = seen.get(key);
    if (dst === undefined) {
      dst = seen.size; seen.set(key, dst);
      for (const name of names) { const a = g.attributes[name]; for (let j = 0; j < a.itemSize; j++) arrays[name].push(a.array[src * a.itemSize + j]); }
    }
    index.push(dst);
  }
  const out = new T.BufferGeometry();
  for (const name of names) out.setAttribute(name, new T.Float32BufferAttribute(arrays[name], g.attributes[name].itemSize));
  out.setIndex(index); out.computeBoundingBox(); return out;
}
