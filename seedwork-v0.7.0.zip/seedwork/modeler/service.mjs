import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, existsSync, rmSync, renameSync } from 'node:fs';
import { resolve } from 'node:path';
import { assetHash, inspectGlb } from '../core/asset.mjs';
import { inputRefs } from '../core/models.mjs';
import { validateRecipe } from './schema.mjs';
import { decodePng } from './png.mjs';

const stable = v => Array.isArray(v) ? v.map(stable) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map(k => [k, stable(v[k])])) : v;
const hash = v => createHash('sha256').update(typeof v === 'string' ? v : JSON.stringify(stable(v))).digest('hex');

export function inspectPng(bytes) {
  const b = Buffer.from(bytes), { width, height } = decodePng(b);
  return { hash: assetHash(b), width, height, bytes: b.length };
}

export class Modeler {
  constructor(root, dir, assetFile) {
    this.root = root; this.dir = resolve(dir, 'model-builds'); this.inputs = resolve(dir, 'model-inputs'); this.cache = resolve(dir, 'material-cache'); this.assetFile = assetFile;
    for (const p of [this.dir, this.inputs, this.cache]) mkdirSync(p, { recursive: true, mode: 0o700 });
    this.jobs = new Map(); this.queue = []; this.active = null;
    this.catalog = JSON.parse(readFileSync(resolve(root, 'modeler/catalog.json'), 'utf8'));
    this.seed();
    this.health = this.exec(['--doctor'], 20000).then(lines => lines.at(-1)).catch(e => ({ ok: false, error: e.message, setup: 'Run node seedwork.mjs doctor and check the complete package.' }));
  }

  seed() {
    const folder = resolve(this.root, 'modeler/starter'), index = resolve(folder, 'index.json');
    if (!existsSync(index)) return;
    for (const entry of JSON.parse(readFileSync(index, 'utf8')).models) {
      const t = this.catalog.templates.find(t => t.id === entry.template);
      if (!t || hash(entry.result.recipe) !== hash(t.recipe)) continue;
      const bytes = readFileSync(resolve(folder, `${entry.result.hash}.glb`));
      if (inspectGlb(bytes).hash !== entry.result.hash || !entry.result.report.exact.passed) throw new Error('Bundled starter verification failed.');
      const dest = this.assetFile(entry.result.hash);
      if (!existsSync(dest) || assetHash(readFileSync(dest)) !== entry.result.hash) writeFileSync(dest, bytes, { mode: 0o600 });
      const id = hash(['bundled-starter', entry.result.hash, entry.result.recipe]);
      t.starter = id;
      this.jobs.set(id, { id, state: 'ready', phase: 'Verified bundled starter', created: 0, cached: true, result: entry.result });
    }
  }

  exec(args, timeout = 120000, event = () => {}, attach = () => {}) {
    return new Promise((done, fail) => {
      const child = spawn(process.execPath, ['--max-old-space-size=768', resolve(this.root, 'modeler/worker.mjs'), ...args], { shell: false, windowsHide: true, env: { ...process.env, NODE_OPTIONS: '' }, stdio: ['ignore', 'pipe', 'pipe'] });
      let text = '', err = '', bytes = 0, settled = false; const lines = [];
      const timer = setTimeout(() => { child.kill('SIGKILL'); finish(new Error('Model build exceeded its time limit. No detail was removed.')); }, timeout);
      const finish = e => { if (settled) return; settled = true; clearTimeout(timer); e ? fail(e) : done(lines); };
      attach(child);
      child.stdout.on('data', chunk => {
        bytes += chunk.length;
        if (bytes > 8 * 1024 * 1024) { child.kill('SIGKILL'); finish(new Error('Worker output exceeded its limit.')); return; }
        text += chunk;
        for (;;) { const at = text.indexOf('\n'); if (at < 0) break; const line = text.slice(0, at); text = text.slice(at + 1); try { const v = JSON.parse(line); lines.push(v); event(v); } catch {} }
      });
      child.stderr.on('data', c => { err = (err + c).slice(-8000); });
      child.on('error', e => finish(new Error(`Native modeler could not start: ${e.message}`)));
      child.on('close', code => finish(code === 0 ? null : new Error(lines.findLast(v => v.event === 'error')?.error || err || `Modeler exited with status ${code}.`)));
    });
  }

  public(job) {
    return { id: job.id, state: job.state, phase: job.phase, created: job.created, cached: Boolean(job.cached), ...(job.error ? { error: job.error } : {}), ...(job.result ? { result: job.result } : {}) };
  }

  async start(recipe) {
    validateRecipe(recipe);
    const health = await this.health;
    if (!health.ok) throw new Error('Native compiler is unavailable. Run node seedwork.mjs doctor; no Python or package download is needed.');
    for (const h of inputRefs(recipe)) {
      const p = resolve(this.inputs, `${h}.png`);
      if (!existsSync(p) || assetHash(readFileSync(p)) !== h) throw new Error('Recipe input is missing or corrupted. Upload the PNG first.');
    }
    const id = hash([recipe, health]), folder = resolve(this.dir, id);
    const prior = this.jobs.get(id);
    if (prior && ['queued', 'running'].includes(prior.state)) return this.public(prior);
    const resultFile = resolve(folder, 'result.json');
    if (existsSync(resultFile)) {
      try {
        const result = JSON.parse(readFileSync(resultFile, 'utf8')), bytes = readFileSync(resolve(folder, 'compiled/model.glb'));
        if (inspectGlb(bytes).hash === result.hash && hash(result.recipe) === hash(recipe) && result.build.source === health.source && result.report.exact.passed) {
          if (!existsSync(this.assetFile(result.hash)) || assetHash(readFileSync(this.assetFile(result.hash))) !== result.hash) writeFileSync(this.assetFile(result.hash), bytes, { mode: 0o600 });
          const job = { id, state: 'ready', phase: 'Verified cached build', created: Date.now(), result, cached: true };
          this.jobs.set(id, job); return this.public(job);
        }
      } catch {}
      rmSync(folder, { recursive: true, force: true });
    }
    if (this.queue.length >= 4) throw new Error('The modeling queue is full (one active build and four queued).');
    mkdirSync(folder, { recursive: true, mode: 0o700 });
    writeFileSync(resolve(folder, 'recipe.json'), JSON.stringify(recipe), { mode: 0o600 });
    const job = { id, folder, state: 'queued', phase: 'Queued', created: Date.now() };
    this.jobs.set(id, job); this.queue.push(job); this.pump(); return this.public(job);
  }

  get(id) {
    if (!/^[a-f0-9]{64}$/.test(id)) throw new Error('Invalid model build ID.');
    let job = this.jobs.get(id);
    if (!job) {
      const p = resolve(this.dir, id, 'result.json');
      if (!existsSync(p)) throw new Error('Model job not found.');
      const result = JSON.parse(readFileSync(p, 'utf8'));
      if (!existsSync(this.assetFile(result.hash)) || assetHash(readFileSync(this.assetFile(result.hash))) !== result.hash) throw new Error('Cached model asset is missing or corrupted; rebuild the recipe.');
      job = { id, state: 'ready', phase: 'Saved build', created: 0, result }; this.jobs.set(id, job);
    }
    if (job.state === 'ready' && (!existsSync(this.assetFile(job.result.hash)) || assetHash(readFileSync(this.assetFile(job.result.hash))) !== job.result.hash)) throw new Error('Model asset is missing or corrupted; rebuild the recipe.');
    return this.public(job);
  }

  cancel(id) {
    const job = this.jobs.get(id);
    if (!job || !['queued', 'running'].includes(job.state)) throw new Error('Only queued or running jobs can be cancelled.');
    job.state = 'cancelled'; job.phase = 'Cancelled'; this.queue = this.queue.filter(v => v !== job); job.child?.kill('SIGKILL'); return this.public(job);
  }

  async pump() {
    if (this.active || !this.queue.length) return;
    const job = this.queue.shift(); this.active = job; job.state = 'running'; job.phase = 'Validating recipe';
    try {
      const lines = await this.exec([job.folder, this.inputs, this.cache], 120000, v => { if (v.event === 'phase' && job.state !== 'cancelled') job.phase = v.phase; }, child => { job.child = child; });
      if (job.state === 'cancelled') return;
      const result = lines.findLast(v => v.event === 'done')?.result;
      if (!result) throw new Error('Model worker returned no artifact.');
      const bytes = readFileSync(resolve(job.folder, 'compiled/model.glb')), info = inspectGlb(bytes);
      if (info.hash !== result.hash) throw new Error('Compiled asset hash mismatch.');
      if (!existsSync(this.assetFile(info.hash)) || assetHash(readFileSync(this.assetFile(info.hash))) !== info.hash) { writeFileSync(`${this.assetFile(info.hash)}.tmp`, bytes, { mode: 0o600 }); renameSync(`${this.assetFile(info.hash)}.tmp`, this.assetFile(info.hash)); }
      job.result = result; job.state = 'ready'; job.phase = 'Ready for review';
    } catch (e) { if (job.state !== 'cancelled') { job.state = 'failed'; job.error = e.message; job.phase = 'Build rejected'; } }
    finally { job.child = null; this.active = null; this.pump(); }
  }

  stop() {
    this.queue.length = 0;
    this.active?.child?.kill('SIGKILL');
  }
}
