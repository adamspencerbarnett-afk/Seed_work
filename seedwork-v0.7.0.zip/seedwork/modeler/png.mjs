import { deflateSync, inflateSync } from 'node:zlib';

const sig = Buffer.from('89504e470d0a1a0a', 'hex');
const table = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let n = i;
  for (let j = 0; j < 8; j++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1;
  table[i] = n >>> 0;
}
export function crc32(bytes) {
  let n = 0xffffffff;
  for (const b of bytes) n = table[(n ^ b) & 255] ^ (n >>> 8);
  return (n ^ 0xffffffff) >>> 0;
}
function chunk(name, bytes) {
  const type = Buffer.from(name), out = Buffer.alloc(12 + bytes.length);
  out.writeUInt32BE(bytes.length, 0); type.copy(out, 4); bytes.copy(out, 8);
  out.writeUInt32BE(crc32(out.subarray(4, 8 + bytes.length)), 8 + bytes.length);
  return out;
}
export function encodePng(width, height, rgb) {
  if (rgb.length !== width * height * 3) throw new Error('RGB buffer size does not match the image.');
  const head = Buffer.alloc(13); head.writeUInt32BE(width, 0); head.writeUInt32BE(height, 4); head[8] = 8; head[9] = 2;
  const rows = Buffer.alloc(height * (width * 3 + 1));
  for (let y = 0; y < height; y++) {
    const at = y * (width * 3 + 1); rows[at] = 1;
    for (let x = 0; x < width * 3; x++) rows[at + 1 + x] = (rgb[y * width * 3 + x] - (x < 3 ? 0 : rgb[y * width * 3 + x - 3])) & 255;
  }
  return Buffer.concat([sig, chunk('IHDR', head), chunk('IDAT', deflateSync(rows, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}
function paeth(a, b, c) {
  const p = a + b - c, x = Math.abs(p - a), y = Math.abs(p - b), z = Math.abs(p - c);
  return x <= y && x <= z ? a : y <= z ? b : c;
}
export function decodePng(bytes) {
  const b = Buffer.from(bytes);
  if (b.length < 45 || b.length > 16 * 1024 * 1024 || !b.subarray(0, 8).equals(sig)) throw new Error('Expected a PNG under 16 MiB.');
  let at = 8, width, height, channels, ended = false, dataStarted = false, dataEnded = false;
  const data = [];
  while (at + 12 <= b.length) {
    const n = b.readUInt32BE(at), name = b.toString('ascii', at + 4, at + 8);
    if (at + 12 + n > b.length) throw new Error('Truncated PNG chunk.');
    if (crc32(b.subarray(at + 4, at + 8 + n)) !== b.readUInt32BE(at + 8 + n)) throw new Error('PNG checksum mismatch.');
    const value = b.subarray(at + 8, at + 8 + n);
    if (name === 'IHDR') {
      if (at !== 8 || n !== 13) throw new Error('Invalid PNG header.');
      width = value.readUInt32BE(0); height = value.readUInt32BE(4); channels = { 0: 1, 2: 3, 6: 4 }[value[9]];
      if (width < 2 || height < 2 || width > 4096 || height > 4096 || width * height > 16777216) throw new Error('PNG dimensions must be 2–4096 pixels.');
      if (value[8] !== 8 || !channels || value[10] || value[11] || value[12]) throw new Error('Use non-interlaced 8-bit grayscale, RGB, or opaque RGBA PNG; no automatic conversion.');
    } else if (name === 'IDAT') {
      if (!width || dataEnded) throw new Error('Invalid PNG image-data order.');
      dataStarted = true; data.push(value);
    } else if (name === 'IEND') {
      if (n || !data.length) throw new Error('Invalid PNG end marker.');
      ended = true; at += 12; break;
    } else {
      if (!width) throw new Error('PNG header must be first.');
      if (dataStarted) dataEnded = true;
      if (['eXIf', 'tRNS', 'acTL', 'fcTL', 'fdAT'].includes(name)) throw new Error('Apply orientation, flatten transparency, and use a static PNG before upload.');
      if (name[0] === name[0].toUpperCase() && name !== 'PLTE') throw new Error(`Unsupported critical PNG chunk: ${name}.`);
    }
    at += 12 + n;
  }
  if (!ended || at !== b.length) throw new Error('PNG is incomplete or has trailing data.');
  const stride = width * channels, expected = height * (stride + 1);
  const raw = inflateSync(Buffer.concat(data), { maxOutputLength: expected });
  if (raw.length !== expected) throw new Error('PNG pixel data has the wrong length.');
  const pixels = Buffer.alloc(width * height * channels);
  for (let y = 0; y < height; y++) {
    const row = y * (stride + 1), filter = raw[row];
    if (filter > 4) throw new Error('Invalid PNG filter.');
    for (let x = 0; x < stride; x++) {
      const i = y * stride + x, a = x < channels ? 0 : pixels[i - channels], up = y ? pixels[i - stride] : 0, c = y && x >= channels ? pixels[i - stride - channels] : 0;
      const add = [0, a, up, Math.floor((a + up) / 2), paeth(a, up, c)][filter];
      pixels[i] = (raw[row + 1 + x] + add) & 255;
    }
  }
  if (channels === 4) for (let i = 3; i < pixels.length; i += 4) if (pixels[i] !== 255) throw new Error('Material inputs must be opaque. Alpha is never discarded.');
  return { width, height, channels, pixels };
}
