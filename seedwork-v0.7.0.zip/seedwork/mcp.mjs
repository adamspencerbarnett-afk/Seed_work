import { createInterface } from 'node:readline';
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { toolCatalog, definitions } from './services/tools.mjs';
import { WORLD_WRITES } from './core/tools.mjs';
import { jsonSafe, validate } from './sdk/core/schema.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const dir = resolve(process.env.SEEDWORK_DIR ?? resolve(root, '.seedwork'));
const port = Number(process.env.PORT ?? 4173);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid PORT.');
const url = `http://127.0.0.1:${port}`;
const modern = '2026-07-28', legacy = '2025-11-25', prefix = 'io.modelcontextprotocol/';
const info = { name: 'seedwork', version: '0.7.0' };
const instructions = 'Local Seedwork world and host-game authoring tools. Inspect before editing. World writes require _rev and a stable _key. Project changes use explicit rev, seq and key fields. Never retry a stale edit using a newer revision without reviewing it. Use project_inspect, asset_search, change_begin/apply/preview, scene_capture/test, human review, then change_commit. The game owns its renderer, camera, controls and simulation. No arbitrary code execution, cloud generation or paid provider is enabled. See AGENTS.md.';
const all = toolCatalog(true), active = new Map();
let initialized = false, ready = false;
const send = message => process.stdout.write(`${JSON.stringify(message)}\n`);
const fail = (id, code, message, data) => send({ jsonrpc: '2.0', ...(id === undefined ? {} : { id }), error: { code, message, ...(data ? { data } : {}) } });

async function handle(msg, abort) {
  const meta = msg.params?._meta, version = meta?.[`${prefix}protocolVersion`];
  const isModern = version !== undefined;
  const reply = result => send({ jsonrpc: '2.0', id: msg.id, result: isModern ? { ...result, resultType: 'complete', _meta: { [`${prefix}serverInfo`]: info } } : result });
  if (isModern) {
    if (version !== modern) return fail(msg.id, -32022, 'Unsupported protocol version', { supported: [modern, legacy], requested: version });
    const caps = meta[`${prefix}clientCapabilities`];
    if (!caps || typeof caps !== 'object' || Array.isArray(caps)) return fail(msg.id, -32602, 'Per-request clientCapabilities is required.');
  }
  if (msg.method === 'initialize' && !isModern) {
    if (initialized) return fail(msg.id, -32600, 'Already initialized');
    if (!msg.params || typeof msg.params.protocolVersion !== 'string' || !msg.params.clientInfo || !msg.params.capabilities) return fail(msg.id, -32602, 'Invalid initialize parameters');
    initialized = true;
    return reply({ protocolVersion: legacy, capabilities: { tools: { listChanged: false } }, serverInfo: info, instructions });
  }
  if (msg.method === 'server/discover') {
    if (!isModern) return fail(msg.id, -32602, 'server/discover requires per-request protocolVersion and clientCapabilities metadata.');
    return reply({ supportedVersions: [modern, legacy], capabilities: { tools: { listChanged: false } }, instructions });
  }
  if (!isModern && msg.method === 'ping') return reply({});
  if (!isModern && !ready) return fail(msg.id, -32002, 'Initialize and send notifications/initialized, or send modern per-request metadata.');
  if (msg.method === 'ping') return reply({});
  if (msg.method === 'tools/list') {
    if (msg.params?.cursor !== undefined) return fail(msg.id, -32602, 'This catalog fits one page; no cursor is valid.');
    return reply({ tools: all });
  }
  if (msg.method !== 'tools/call') return fail(msg.id, -32601, 'Method not found');
  if (!msg.params || typeof msg.params.name !== 'string') return fail(msg.id, -32602, 'A tool name is required');
  const def = all.find(t => t.name === msg.params.name);
  if (!def) return fail(msg.id, -32602, 'Unknown tool');
  try {
    const args = msg.params.arguments ?? {};
    jsonSafe(args); validate(args, def.inputSchema);
    const { _rev, _key, ...plain } = args;
    const payload = { name: def.name, args: plain, ...(WORLD_WRITES.has(def.name) ? { rev: _rev, key: _key } : {}) };
    const token = readFileSync(resolve(dir, 'token'), 'utf8').trim();
    const res = await fetch(`${url}/api/tool`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify(payload), signal: AbortSignal.any([abort.signal, AbortSignal.timeout(25000)]) });
    const out = await res.json();
    if (!res.ok) throw Object.assign(new Error(out.error ?? `HTTP ${res.status}`), { code: out.code, details: out.details });
    const { image, ...result } = out.result;
    const data = { scope: out.scope ?? definitions.find(t => t.name === def.name).scope, rev: out.rev, ...(out.receiptRev === undefined ? {} : { receiptRev: out.receiptRev, replayed: out.replayed }), ...result };
    const content = [{ type: 'text', text: JSON.stringify(data) }];
    if (image) content.push({ type: 'image', data: image.data, mimeType: image.mimeType });
    reply({ content, structuredContent: data, isError: false });
  } catch (e) {
    const data = { error: { code: e.code ?? 'CONNECTION', message: e.message, details: e.details ?? {} } };
    reply({ content: [{ type: 'text', text: JSON.stringify(data) }], structuredContent: data, isError: true });
  }
}

const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
input.on('line', line => {
  if (!line.trim()) return;
  if (Buffer.byteLength(line) > 1024 * 1024) return fail(undefined, -32600, 'Message exceeds 1 MiB');
  let msg;
  try { msg = JSON.parse(line); } catch { return fail(undefined, -32700, 'Parse error'); }
  if (!msg || Array.isArray(msg) || msg.jsonrpc !== '2.0' || typeof msg.method !== 'string') return fail(msg?.id, -32600, 'Invalid request');
  if (msg.id === undefined) {
    if (msg.method === 'notifications/initialized' && initialized) ready = true;
    if (msg.method === 'notifications/cancelled') active.get(msg.params?.requestId)?.abort();
    return;
  }
  if (!(typeof msg.id === 'string' || Number.isSafeInteger(msg.id))) return fail(undefined, -32600, 'Request ID must be a string or integer.');
  if (active.has(msg.id)) return fail(msg.id, -32600, 'Request ID is already active.');
  if (active.size >= 8) return fail(msg.id, -32603, 'At most eight simultaneous requests are supported.');
  const abort = new AbortController(); active.set(msg.id, abort);
  handle(msg, abort).catch(e => fail(msg.id, -32603, e.message)).finally(() => active.delete(msg.id));
});
input.on('close', () => { for (const abort of active.values()) abort.abort(); });
