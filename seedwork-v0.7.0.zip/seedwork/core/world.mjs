import { validate as checkEnvironment } from '../sdk/environment/schema.mjs';
import { checkModels } from './models.mjs';
export const VER = 1;
export const SEG = 96;
export const MAX = 1500;
export const BIOMES = ['forest', 'desert', 'snow', 'fantasy'];
export const TIMES = ['day', 'sunset', 'night'];
export const TYPES = ['pine', 'oak', 'rock', 'house', 'tower', 'crystal', 'mushroom', 'arch', 'cactus', 'lamp', 'crate'];
export const META = {
  pine: { name: 'Alpine pine', cat: 'Nature', radius: 0.55, height: 7, width: 4.2 },
  oak: { name: 'Canopy tree', cat: 'Nature', radius: 0.7, height: 6.2, width: 6 },
  rock: { name: 'Boulder', cat: 'Nature', radius: 1.2, height: 2.5, width: 3.2 },
  house: { name: 'Timber cottage', cat: 'Structures', radius: 3, height: 6.3, width: 6.2 },
  tower: { name: 'Watchtower', cat: 'Structures', radius: 2.2, height: 9.2, width: 5 },
  crystal: { name: 'Quartz specimen', cat: 'Props', radius: 0, height: 1, width: 0.9 },
  mushroom: { name: 'Woodland mushrooms', cat: 'Nature', radius: 0.35, height: 0.55, width: 0.9 },
  arch: { name: 'Ancient gate', cat: 'Structures', radius: 0, height: 6.8, width: 7.5 },
  cactus: { name: 'Desert cactus', cat: 'Nature', radius: 0.6, height: 4.7, width: 3.3 },
  lamp: { name: 'Wayfinder lamp', cat: 'Props', radius: 0.3, height: 3.1, width: 1.4 },
  crate: { name: 'Supply crate', cat: 'Props', radius: 0.85, height: 1.6, width: 1.7 }
};
export const types = w => [...TYPES, ...Object.keys(w?.models ?? {})];
export const meta = (w, type) => w?.models && Object.hasOwn(w.models, type) ? { ...w.models[type], cat: 'Models' } : META[type];
export const clone = value => structuredClone(value);
export const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
export const mix = (a, b, t) => a + (b - a) * t;
export const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

export function hash(value) {
  let n = 2166136261;
  for (const c of String(value)) n = Math.imul(n ^ c.charCodeAt(0), 16777619);
  return n >>> 0;
}

export function rand(seed) {
  let n = hash(seed);
  return () => {
    n += 0x6D2B79F5;
    let t = Math.imul(n ^ n >>> 15, n | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function cell(x, z, seed) {
  let n = Math.imul(x, 374761393) ^ Math.imul(z, 668265263) ^ seed;
  n = Math.imul(n ^ n >>> 13, 1274126177);
  return ((n ^ n >>> 16) >>> 0) / 4294967295;
}

export function noise(x, z, seed) {
  const ix = Math.floor(x), iz = Math.floor(z);
  const u = smooth(0, 1, x - ix), v = smooth(0, 1, z - iz);
  return mix(mix(cell(ix, iz, seed), cell(ix + 1, iz, seed), u), mix(cell(ix, iz + 1, seed), cell(ix + 1, iz + 1, seed), u), v);
}

export function pathZ(x, size) {
  return (Math.sin(x / size * 7.5 + 0.4) * 0.072 + 0.065) * size;
}

export function rawHeight(w, x, z, stamps = true) {
  const t = w.terrain, s = t.size;
  const nx = x / s * 6.5, nz = z / s * 6.5;
  const n = noise(nx, nz, w.seed) * 0.68 + noise(nx * 2.1, nz * 2.1, w.seed + 37) * 0.23 + noise(nx * 4.2, nz * 4.2, w.seed + 81) * 0.09;
  let h = 3 + t.relief * (0.12 + n * 0.82);
  const clearing = 1 - smooth(s * 0.08, s * 0.19, Math.hypot(x, z));
  h = mix(h, 3.6 + t.relief * 0.12, clearing * 0.94);
  const path = 1 - smooth(1.5, 4.8, Math.abs(z - pathZ(x, s)));
  h = mix(h, 3.9 + t.relief * 0.11, path * 0.65);
  const r = Math.hypot(x / (s * 0.47), z / (s * 0.45));
  if (t.shape === 'island') h -= smooth(0.57, 1.03, r) * (t.relief + 12);
  if (stamps) for (const b of t.stamps) {
    const d = Math.hypot(x - b.x, z - b.z);
    if (d >= b.radius) continue;
    const f = 1 - smooth(0, b.radius, d);
    h = b.mode === 'flatten' ? mix(h, b.level, f * b.power) : h + f * b.power * (b.mode === 'lower' ? -1 : 1);
  }
  return h;
}

export function height(w, x, z) {
  const s = w.terrain.size, step = s / SEG;
  const ux = clamp((x + s / 2) / step, 0, SEG - 0.000001);
  const uz = clamp((z + s / 2) / step, 0, SEG - 0.000001);
  const ix = Math.floor(ux), iz = Math.floor(uz), fx = ux - ix, fz = uz - iz;
  const xx = ix * step - s / 2, zz = iz * step - s / 2;
  const a = rawHeight(w, xx, zz), b = rawHeight(w, xx + step, zz);
  const c = rawHeight(w, xx, zz + step), d = rawHeight(w, xx + step, zz + step);
  return fx + fz <= 1 ? a + (b - a) * fx + (c - a) * fz : d + (c - d) * (1 - fx) + (b - d) * (1 - fz);
}

function num(n, name, lo, hi) {
  if (typeof n !== 'number' || !Number.isFinite(n) || n < lo || n > hi) throw new Error(`${name} must be a finite number from ${lo} to ${hi}.`);
}

function text(s, name, max = 80) {
  if (typeof s !== 'string' || !s.trim() || s.length > max || /[\u0000-\u001f]/.test(s)) throw new Error(`${name} must be 1–${max} printable characters.`);
}

function obj(o, name) {
  if (!o || typeof o !== 'object' || Array.isArray(o)) throw new Error(`${name} must be an object.`);
}

function fields(o, keys, name) {
  obj(o, name);
  for (const k of Object.keys(o)) if (!keys.includes(k)) throw new Error(`Unknown ${name} field: ${k}.`);
}

export function check(w) {
  fields(w, ['version', 'name', 'seed', 'biome', 'terrain', 'sky', 'spawn', 'objects', 'assets', 'models', 'environment'], 'world');
  if (w.environment !== undefined) checkEnvironment(w.environment);
  if (w.version !== VER) throw new Error(`Unsupported world version. Expected ${VER}.`);
  text(w.name, 'World name');
  num(w.seed, 'Seed', 0, 4294967295);
  if (!Number.isInteger(w.seed)) throw new Error('Seed must be an integer.');
  if (!BIOMES.includes(w.biome)) throw new Error('Unknown biome.');
  fields(w.terrain, ['size', 'relief', 'water', 'density', 'shape', 'stamps'], 'terrain');
  const t = w.terrain;
  num(t.size, 'Terrain size', 64, 200);
  num(t.relief, 'Relief', 0, 24);
  num(t.water, 'Water level', -5, 8);
  num(t.density, 'Density', 0, 1);
  if (!['island', 'valley'].includes(t.shape)) throw new Error('Unknown terrain shape.');
  if (!Array.isArray(t.stamps) || t.stamps.length > 96) throw new Error('Terrain supports at most 96 brush strokes.');
  for (const b of t.stamps) {
    fields(b, ['x', 'z', 'radius', 'mode', 'power', 'level'], 'brush');
    num(b.x, 'Brush X', -100, 100); num(b.z, 'Brush Z', -100, 100);
    num(b.radius, 'Brush radius', 1, 30); num(b.power, 'Brush power', 0.05, b.mode === 'flatten' ? 1 : 8);
    if (!['raise', 'lower', 'flatten'].includes(b.mode)) throw new Error('Unknown brush mode.');
    num(b.level, 'Brush level', -30, 100);
  }
  fields(w.sky, ['time', 'fog'], 'sky');
  if (!TIMES.includes(w.sky.time)) throw new Error('Unknown time of day.');
  num(w.sky.fog, 'Fog', 0, 1);
  fields(w.spawn, ['x', 'z'], 'spawn');
  num(w.spawn.x, 'Spawn X', -t.size / 2, t.size / 2); num(w.spawn.z, 'Spawn Z', -t.size / 2, t.size / 2);
  if (!Array.isArray(w.objects) || w.objects.length > MAX) throw new Error(`Worlds support at most ${MAX} objects.`);
  checkModels(w.models);
  const ids = new Set();
  for (const o of w.objects) {
    fields(o, ['id', 'type', 'x', 'y', 'z', 'rot', 'scale', 'solid'], 'object');
    text(o.id, 'Object ID', 48);
    if (!/^[a-zA-Z0-9_-]+$/.test(o.id) || ids.has(o.id)) throw new Error('Object IDs must be unique letters, digits, dashes or underscores.');
    ids.add(o.id);
    if (!types(w).includes(o.type)) throw new Error(`Unknown asset: ${o.type}.`);
    num(o.x, 'Object X', -t.size / 2, t.size / 2); num(o.z, 'Object Z', -t.size / 2, t.size / 2);
    num(o.y, 'Object Y offset', -30, 100); num(o.rot, 'Rotation', -36000, 36000); num(o.scale, 'Scale', 0.1, 8);
    if (typeof o.solid !== 'boolean') throw new Error('Solid must be a boolean.');
  }
  if (w.assets !== undefined) {
    fields(w.assets, TYPES, 'asset bindings');
    for (const value of Object.values(w.assets)) if (typeof value !== 'string' || !/^[a-f0-9]{64}$/.test(value)) throw new Error('Asset bindings must contain SHA-256 hashes.');
  }
  return w;
}

export function id(w, type) {
  const ids = new Set(w.objects.map(o => o.id));
  let n = w.objects.length + 1;
  while (ids.has(`${type}_${n}`)) n++;
  return `${type}_${n}`;
}

export function add(w, type, x, z, opts = {}) {
  if (!types(w).includes(type)) throw new Error(`Unknown asset: ${type}.`);
  if (w.objects.length >= MAX) throw new Error(`Object limit reached (${MAX}).`);
  const o = { id: id(w, type), type, x, y: 0, z, rot: 0, scale: 1, solid: meta(w, type).radius > 0, ...opts };
  w.objects.push(o);
  return o;
}

export function scatter(w, args = {}) {
  fields(args, ['type', 'count', 'x', 'z', 'radius', 'seed', 'avoidPath'], 'scatter');
  const type = args.type ?? 'pine', count = args.count ?? 20;
  if (!types(w).includes(type)) throw new Error('Unknown scatter asset.');
  num(count, 'Count', 1, 500);
  if (!Number.isInteger(count)) throw new Error('Count must be an integer.');
  if (w.objects.length + count > MAX) throw new Error(`Scatter exceeds ${MAX} objects.`);
  const r = args.radius ?? w.terrain.size * 0.36, x = args.x ?? 0, z = args.z ?? 0;
  num(r, 'Radius', 1, 100); num(x, 'Center X', -100, 100); num(z, 'Center Z', -100, 100);
  if (args.seed !== undefined) num(args.seed, 'Scatter seed', 0, 4294967295);
  if (args.avoidPath !== undefined && typeof args.avoidPath !== 'boolean') throw new Error('avoidPath must be boolean.');
  const rng = rand(args.seed ?? `${w.seed}-${w.objects.length}-${type}`), made = [];
  for (let tries = 0; made.length < count && tries < count * 65; tries++) {
    const angle = rng() * Math.PI * 2, dist = Math.sqrt(rng()) * r;
    const xx = x + Math.cos(angle) * dist, zz = z + Math.sin(angle) * dist, size = w.terrain.size;
    if (Math.abs(xx) > size * 0.47 || Math.abs(zz) > size * 0.47 || height(w, xx, zz) < w.terrain.water + 0.7) continue;
    if (args.avoidPath !== false && Math.abs(zz - pathZ(xx, size)) < 2.7) continue;
    if (Math.hypot(xx - w.spawn.x, zz - w.spawn.z) < 3) continue;
    const rad = Math.max(1, meta(w, type).radius);
    if (w.objects.some(o => Math.hypot(xx - o.x, zz - o.z) < rad + Math.max(0.8, meta(w, o.type).radius * o.scale))) continue;
    const o = add(w, type, +xx.toFixed(3), +zz.toFixed(3), { rot: +(rng() * 360).toFixed(2), scale: +(0.65 + rng() * 0.7).toFixed(3) });
    made.push(o.id);
  }
  return made;
}

export function make(opts = {}) {
  fields(opts, ['name', 'seed', 'biome', 'size', 'relief', 'water', 'density', 'shape', 'time', 'village', 'ruins', 'crystals'], 'generation');
  const biome = opts.biome ?? 'forest';
  const names = { forest: 'Verdant Reach', desert: 'Amber Expanse', snow: 'Frostfall Basin', fantasy: 'The Aetherwild' };
  const w = {
    version: VER, name: opts.name ?? names[biome] ?? 'Untitled World', seed: opts.seed ?? 1847, biome,
    terrain: { size: opts.size ?? 120, relief: opts.relief ?? 10, water: opts.water ?? 1.4, density: opts.density ?? 0.6, shape: opts.shape ?? 'island', stamps: [] },
    sky: { time: opts.time ?? 'day', fog: 0.28 }, spawn: { x: 0, z: 13 }, objects: []
  };
  for (const k of ['village', 'ruins', 'crystals']) if (opts[k] !== undefined && typeof opts[k] !== 'boolean') throw new Error(`${k} must be boolean.`);
  check(w);
  const s = w.terrain.size / 120;
  const place = (type, x, z, extra = {}) => add(w, type, x * s, z * s, extra);
  if (opts.crystals !== false) place('crystal', 0, 0, { scale: 1.7 });
  if (opts.village !== false) {
    const plots = [[16, 12, -15], [24, 8, -60], [20, 20, 25], [9, 22, 10]];
    for (const [x, z, rot] of plots) {
      const xx = x * s, zz = z * s, level = Math.max(w.terrain.water + 0.9, rawHeight(w, xx, zz));
      w.terrain.stamps.push({ x: xx, z: zz, radius: 5.6, power: 1, mode: 'flatten', level });
      place('house', x, z, { rot, scale: 0.85 });
    }
    place('crate', 11, 18, { rot: 12 }); place('lamp', 12, 12); place('lamp', 23, 16);
  }
  if (opts.ruins !== false) {
    place('tower', -22, -10, { rot: 14 }); place('arch', 17, -20, { rot: -20 });
    place('rock', -18, -15, { scale: 1.7 });
  }
  const n = Math.round(w.terrain.density * 210);
  const tree = biome === 'desert' ? 'cactus' : biome === 'fantasy' ? 'mushroom' : 'pine';
  if (n > 0) scatter(w, { type: tree, count: Math.max(1, Math.round(n * 0.72)), seed: w.seed });
  if (n > 0) scatter(w, { type: biome === 'desert' ? 'rock' : 'oak', count: Math.max(1, Math.round(n * 0.28)), seed: (w.seed + 10) >>> 0 });
  scatter(w, { type: 'rock', count: Math.max(8, Math.round(n * 0.25)), seed: (w.seed + 2) >>> 0 });
  if (biome !== 'desert' && n > 0) scatter(w, { type: 'mushroom', count: Math.max(1, Math.round(n * 0.14)), seed: (w.seed + 3) >>> 0 });
  if (opts.crystals !== false) scatter(w, { type: 'crystal', count: 7, radius: w.terrain.size * 0.25, seed: (w.seed + 4) >>> 0 });
  return check(w);
}

export function recipe(prompt, base = {}) {
  if (typeof prompt !== 'string' || prompt.length > 1500) throw new Error('Recipe must be text, at most 1,500 characters.');
  const p = prompt.toLowerCase();
  const o = { ...base }, notes = [];
  const set = (key, value, label) => { o[key] = value; notes.push(label); };
  if (/\b(desert|dunes?|arid|cactus)\b/.test(p)) set('biome', 'desert', 'Desert biome');
  else if (/\b(snow|snowy|winter|frozen|tundra|ice)\b/.test(p)) set('biome', 'snow', 'Snow biome');
  else if (/\b(fantasy|alien|magical|enchanted|mushrooms?)\b/.test(p)) set('biome', 'fantasy', 'Fantasy biome');
  else if (/\b(forest|woodland|lush|pine|trees?)\b/.test(p)) set('biome', 'forest', 'Forest biome');
  if (/\b(night|moonlit|dark)\b/.test(p)) set('time', 'night', 'Moonlit lighting');
  else if (/\b(sunset|dusk|golden|evening)\b/.test(p)) set('time', 'sunset', 'Sunset lighting');
  else if (/\b(day|daylight|sunny)\b/.test(p)) set('time', 'day', 'Daylight');
  if (/\b(valley|mainland)\b/.test(p)) set('shape', 'valley', 'Valley terrain');
  else if (/\b(island|isles?)\b/.test(p)) set('shape', 'island', 'Island terrain');
  if (/\b(mountains?|mountainous|rugged|steep)\b/.test(p)) set('relief', 19, 'High relief');
  else if (/\b(flat|plains?|gentle)\b/.test(p)) set('relief', 3, 'Gentle relief');
  if (/\b(dense|thick|overgrown)\b/.test(p)) set('density', 0.9, 'Dense foliage');
  else if (/\b(sparse|barren|empty)\b/.test(p)) set('density', 0.15, 'Sparse foliage');
  for (const [key, rx] of [['village', 'village|houses?|cottages?'], ['ruins', 'ruins?|towers?|gates?'], ['crystals', 'crystals?']]) {
    if (new RegExp(`\\b(?:no|without)\\s+(?:a\\s+)?(?:${rx})\\b`).test(p)) set(key, false, `No ${key}`);
    else if (new RegExp(`\\b(?:${rx})\\b`).test(p)) set(key, true, `Include ${key}`);
  }
  const seed = p.match(/\bseed\s*[:=]?\s*(\d+)\b/);
  if (seed) set('seed', Number(seed[1]), `Seed ${seed[1]}`);
  if (!notes.length && p.trim()) notes.push('No supported keywords found; current settings will be used.');
  return { options: o, notes, limitation: 'Local keyword recipes, not an AI model. Unsupported requests are not implemented.' };
}

export function summary(w) {
  const counts = Object.fromEntries(types(w).map(t => [t, w.objects.filter(o => o.type === t).length]));
  return { name: w.name, seed: w.seed, biome: w.biome, size: w.terrain.size, count: w.objects.length, counts, strokes: w.terrain.stamps.length, spawn: w.spawn };
}

export function blocked(w, o, x, z, ground, bottom) {
  if (!o.solid) return false;
  const m = meta(w, o.type);
  if (!m?.radius || ground + 1.7 < bottom || ground > bottom + m.height * o.scale) return false;
  if (!m.boxes) return Math.hypot(x - o.x, z - o.z) < m.radius * o.scale + 0.42;
  const a = o.rot * Math.PI / 180, c = Math.cos(a), s = Math.sin(a), dx = (x - o.x) / o.scale, dz = (z - o.z) / o.scale;
  const xx = c * dx - s * dz, zz = s * dx + c * dz, y = (ground - bottom) / o.scale, r = .42 / o.scale;
  for (const [lo, hi] of m.boxes) {
    if (y + 1.7 / o.scale < lo[1] || y + .06 / o.scale > hi[1]) continue;
    const qx = clamp(xx, lo[0], hi[0]), qz = clamp(zz, lo[2], hi[2]);
    if ((xx - qx) ** 2 + (zz - qz) ** 2 < r * r) return true;
  }
  return false;
}

export function canWalk(w, x, z) {
  if (Math.abs(x) > w.terrain.size * 0.48 || Math.abs(z) > w.terrain.size * 0.48) return false;
  const ground = height(w, x, z);
  if (ground < w.terrain.water + 0.18) return false;
  for (const o of w.objects) if (blocked(w, o, x, z, ground, height(w, o.x, o.z) + o.y)) return false;
  return true;
}

export function findSpawn(w) {
  if (canWalk(w, w.spawn.x, w.spawn.z)) return { ...w.spawn };
  for (let r = 1; r < w.terrain.size * 0.75; r += 1.5) for (let a = 0; a < Math.PI * 2; a += 0.25) {
    const x = w.spawn.x + Math.cos(a) * r, z = w.spawn.z + Math.sin(a) * r;
    if (canWalk(w, x, z)) return { x, z };
  }
  throw new Error('No dry, unobstructed player spawn exists. Lower the water or raise the terrain.');
}
