import { ENV_SCHEMA, PRESET_NAMES, preset } from '../sdk/environment/schema.mjs';
import { validate } from '../sdk/core/schema.mjs';
export { validate } from '../sdk/core/schema.mjs';

import { make, check, clone, add, scatter, recipe, summary, height, META, TYPES, types, BIOMES, TIMES, findSpawn } from './world.mjs';

const n = (min, max, description) => ({ type: 'number', minimum: min, maximum: max, description });
const s = (maxLength = 80) => ({ type: 'string', minLength: 1, maxLength });
const e = values => ({ type: 'string', enum: values });
const b = { type: 'boolean' };
const schema = (properties, required = []) => ({ type: 'object', properties, required, additionalProperties: false });
const gen = {
  name: s(), seed: { type: 'integer', minimum: 0, maximum: 4294967295 }, biome: e(BIOMES),
  size: n(64, 200), relief: n(0, 24), water: n(-5, 8), density: n(0, 1), shape: e(['island', 'valley']),
  time: e(TIMES), village: b, ruins: b, crystals: b
};
const pos = { x: n(-100, 100), z: n(-100, 100) };
const props = { ...pos, y: n(-30, 100), rot: n(-36000, 36000), scale: n(0.1, 8), solid: b };

export const TOOLS = [
  { name: 'environment_inspect', description: 'Read authored world weather and seasonal settings. This is not live GPU, physics or climate-state telemetry.', inputSchema: schema({}), readOnly: true },
  { name: 'environment_set', description: 'Set a complete validated weather and season configuration. Undoable. Does not modify water, physics or gameplay rules.', inputSchema: schema({ config: ENV_SCHEMA }, ['config']) },
  { name: 'environment_preset', description: 'Set a declared environment preset, or off to detach effects and restore base materials. Undoable. Original world geometry and textures remain unchanged.', inputSchema: schema({ name: e(['off', ...PRESET_NAMES]) }, ['name']) },
  { name: 'world_inspect', description: 'Read the current world, revision, counts and optionally all editable objects.', inputSchema: schema({ objects: b }), readOnly: true },
  { name: 'world_make', description: 'Replace the world with a deterministic procedural recipe. This is undoable. Units are meters; rotation is degrees.', inputSchema: schema(gen) },
  { name: 'world_recipe', description: 'Generate a replacement world using a bounded, local keyword parser. Not an LLM. Returns the settings it recognized.', inputSchema: schema({ prompt: s(1500), options: schema(gen) }, ['prompt']) },
  { name: 'terrain_set', description: 'Change terrain, biome, sky or name without scattering new objects. Objects remain grounded. Size cannot be reduced around out-of-bounds objects.', inputSchema: schema({ name: s(), biome: e(BIOMES), size: n(64, 200), relief: n(0, 24), water: n(-5, 8), density: n(0, 1), shape: e(['island', 'valley']), time: e(TIMES), fog: n(0, 1) }) },
  { name: 'terrain_brush', description: 'Apply one soft circular raise, lower or flatten stroke. Maximum 96 strokes including village foundations. Flatten power is at most 1.', inputSchema: schema({ ...pos, mode: e(['raise', 'lower', 'flatten']), radius: n(1, 30), power: n(0.05, 8), level: n(-30, 100) }, ['x', 'z', 'mode', 'radius', 'power']) },
  { name: 'object_add', description: 'Place one procedural asset. Y is an offset above terrain, not absolute elevation.', inputSchema: schema({ type: s(32), ...props }, ['type', 'x', 'z']) },
  { name: 'object_update', description: 'Update an object by stable ID. Omitted properties remain unchanged.', inputSchema: schema({ id: s(48), ...props }, ['id']) },
  { name: 'object_remove', description: 'Remove one object by stable ID. Undoable.', inputSchema: schema({ id: s(48) }, ['id']) },
  { name: 'object_scatter', description: 'Scatter objects on dry land, respecting spacing, spawn and paths. Returns actual placed IDs; a crowded area may fit fewer than requested.', inputSchema: schema({ type: s(32), count: { type: 'integer', minimum: 1, maximum: 500 }, ...pos, radius: n(1, 100), seed: { type: 'integer', minimum: 0, maximum: 4294967295 }, avoidPath: b }, ['type', 'count']) },
  { name: 'spawn_set', description: 'Set the preferred player spawn. Preview searches nearby if the point is obstructed.', inputSchema: schema(pos, ['x', 'z']) },
  { name: 'world_validate', description: 'Check document validity, walkable spawn, underwater object count and collectible count. Does not prove all objects are reachable.', inputSchema: schema({}), readOnly: true },
  { name: 'asset_list', description: 'List content-addressed GLB bindings for the eleven prefab slots. Upload bytes through the authenticated local asset API before binding.', inputSchema: schema({}), readOnly: true },
  { name: 'asset_bind', description: 'Bind a previously uploaded self-contained static GLB SHA-256 hash to a prefab type. Undoable; every instance keeps its ID and transform.', inputSchema: schema({ type: e(TYPES), hash: s(64) }, ['type', 'hash']) },
  { name: 'asset_unbind', description: 'Restore the authored procedural prefab for one type. Undoable.', inputSchema: schema({ type: e(TYPES) }, ['type']) },
  { name: 'model_list', description: 'List native models and local modeling capability. Recipes stay editable; geometry is an immutable content-addressed artifact.', inputSchema: schema({}), readOnly: true },
  { name: 'model_template', description: 'Read a complete dimensioned starter recipe; edit its parts before building. No world mutation.', inputSchema: schema({ template: e(['drum', 'crate', 'arch', 'bench', 'pallet', 'pier', 'part']) }, ['template']), readOnly: true },
  { name: 'model_build', description: 'Queue a static model build. Returns a job ID immediately; poll model_status. Does not publish or place the result. Quality lock requires lods:[1].', inputSchema: schema({ recipe: { type: 'object', additionalProperties: true } }, ['recipe']) },
  { name: 'model_status', description: 'Read build progress, failure or the completed artifact and exact-compaction audit.', inputSchema: schema({ job: s(64) }, ['job']), readOnly: true },
  { name: 'model_cancel', description: 'Cancel a queued/running build. Does not modify an existing world model.', inputSchema: schema({ job: s(64) }, ['job']) },
  { name: 'model_publish', description: 'Publish a reviewed ready build as a native model type, or update that type in place. Existing placements keep IDs/transforms. Undoable. Key begins m_.', inputSchema: schema({ job: s(64), key: s(30), name: s() }, ['job', 'key']) },
  { name: 'model_remove', description: 'Remove a native model type. Refuses removal while placed unless removeObjects is explicitly true. Undoable.', inputSchema: schema({ key: s(30), removeObjects: b }, ['key']) },
  { name: 'world_batch', description: 'Apply up to 128 world operations atomically in one undoable revision. No history or model worker operations inside the batch.', inputSchema: schema({ ops: { type: 'array', minItems: 1, maxItems: 128, items: schema({ name: s(64), args: { type: 'object' } }, ['name']) } }, ['ops']) },
  { name: 'world_undo', description: 'Undo the latest document mutation, whether it came from the editor or an agent.', inputSchema: schema({}) },
  { name: 'world_redo', description: 'Redo the latest undone mutation.', inputSchema: schema({}) }
];

export function tool(w, name, args = {}, options = {}) {
  const def = TOOLS.find(t => t.name === name);
  if (!def) throw new Error(`Unknown tool: ${name}.`);
  validate(args, def.inputSchema);
  if (name === 'environment_inspect') return { world: w, changed: false, result: { enabled: Boolean(w.environment), config: clone(w.environment ?? null), presets: [...PRESET_NAMES], note: 'Authored configuration only; live surface evolution stays in the runtime.' } };
  if (name === 'asset_list') return { world: w, changed: false, result: { assets: clone(w.assets ?? {}), types: types(w) } };
  if (name === 'world_inspect') return { world: w, changed: false, result: { version: w.version, ...summary(w), terrain: clone(w.terrain), sky: clone(w.sky), ...(args.objects ? { objects: clone(w.objects) } : {}) } };
  if (name === 'world_validate') {
    check(w);
    const warnings = [];
    let spawn = null;
    try { spawn = findSpawn(w); } catch (e) { warnings.push(e.message); }
    const wet = w.objects.filter(o => height(w, o.x, o.z) + o.y < w.terrain.water).length;
    if (wet) warnings.push(`${wet} objects have origins below water.`);
    if (w.objects.length > 900) warnings.push('High object count; profile your target device.');
    return { world: w, changed: false, result: { valid: true, playableSpawn: Boolean(spawn), spawn, warnings, crystals: w.objects.filter(o => o.type === 'crystal').length, note: 'Reachability and complex collision are not validated.' } };
  }
  let next = options.copy === false ? w : clone(w), result = {};
  if (name === 'environment_set') next.environment = clone(args.config);
  else if (name === 'environment_preset') { if (args.name === 'off') delete next.environment; else next.environment = preset(args.name); }
  else if (name === 'world_make') { next = make(args); if (w.assets) next.assets = clone(w.assets); if (w.models) next.models = clone(w.models); if (w.environment) next.environment = clone(w.environment); }
  else if (name === 'world_recipe') {
    const plan = recipe(args.prompt, args.options ?? {});
    next = make(plan.options); if (w.assets) next.assets = clone(w.assets); if (w.models) next.models = clone(w.models); if (w.environment) next.environment = clone(w.environment); result = plan;
  } else if (name === 'asset_bind') {
    if (!/^[a-f0-9]{64}$/.test(args.hash)) throw new Error('Asset hash must be a lowercase SHA-256 digest.');
    next.assets ??= {}; next.assets[args.type] = args.hash;
  } else if (name === 'asset_unbind') {
    if (next.assets) { delete next.assets[args.type]; if (!Object.keys(next.assets).length) delete next.assets; }
  } else if (name === 'terrain_set') {
    for (const [k, v] of Object.entries(args)) {
      if (['name', 'biome'].includes(k)) next[k] = v;
      else if (['time', 'fog'].includes(k)) next.sky[k] = v;
      else next.terrain[k] = v;
    }
  } else if (name === 'terrain_brush') {
    const stroke = { ...args, level: args.level ?? height(next, args.x, args.z) };
    next.terrain.stamps.push(stroke);
    result = { strokes: next.terrain.stamps.length };
  } else if (name === 'object_add') {
    const { type, x, z, ...rest } = args;
    result = { object: add(next, type, x, z, rest) };
  } else if (name === 'object_update') {
    const o = next.objects.find(o => o.id === args.id);
    if (!o) throw new Error(`Object not found: ${args.id}.`);
    Object.assign(o, args); result = { object: o };
  } else if (name === 'object_remove') {
    if (!next.objects.some(o => o.id === args.id)) throw new Error(`Object not found: ${args.id}.`);
    next.objects = next.objects.filter(o => o.id !== args.id);
  } else if (name === 'object_scatter') {
    const ids = scatter(next, args);
    result = { ids, placed: ids.length, requested: args.count };
  } else if (name === 'spawn_set') next.spawn = { ...args };
  else throw new Error(`${name} requires the history store.`);
  check(next);
  return { world: next, changed: true, result: { ...summary(next), ...result } };
}

export function catalog() {
  return TOOLS.map(({ readOnly, ...t }) => ({ ...t, annotations: { readOnlyHint: Boolean(readOnly), destructiveHint: !readOnly, idempotentHint: Boolean(readOnly), openWorldHint: false } }));
}

export const WORLD_WRITES = new Set(TOOLS.filter(t => !t.readOnly && !['model_build', 'model_cancel'].includes(t.name)).map(t => t.name));
