import { createHash } from 'node:crypto';
export const ASSET_MAX = 24 * 1024 * 1024;
export const assetHash = bytes => createHash('sha256').update(bytes).digest('hex');

export function inspectGlb(bytes) {
  const b = Buffer.from(bytes);
  if (b.length < 28 || b.length > ASSET_MAX) throw new Error('GLB must be between 28 bytes and 24 MiB.');
  if (b.readUInt32LE(0) !== 0x46546c67 || b.readUInt32LE(4) !== 2 || b.readUInt32LE(8) !== b.length) throw new Error('Expected a complete glTF 2.0 binary file.');
  const len = b.readUInt32LE(12);
  if (b.readUInt32LE(16) !== 0x4e4f534a || len % 4 || 20 + len + 8 > b.length) throw new Error('Invalid GLB JSON chunk.');
  const doc = JSON.parse(b.subarray(20, 20 + len).toString('utf8').trim());
  const at = 20 + len, binLen = b.readUInt32LE(at);
  if (b.readUInt32LE(at + 4) !== 0x004e4942 || at + 8 + binLen !== b.length) throw new Error('Expected one embedded GLB binary chunk.');
  if (doc.asset?.version !== '2.0' || !doc.meshes?.length || !doc.nodes?.length || !doc.scenes?.length) throw new Error('GLB needs a glTF 2.0 scene containing meshes.');
  if (doc.buffers?.length !== 1 || doc.buffers.some(v => v.uri || v.byteLength > binLen || v.byteLength < binLen - 3)) throw new Error('Only one embedded binary buffer is supported.');
  if ((doc.images ?? []).some(v => v.uri || !Number.isInteger(v.bufferView) || !['image/png', 'image/jpeg'].includes(v.mimeType))) throw new Error('Textures must be embedded PNG or JPEG images; external URLs are not allowed.');
  const allowed = new Set(['KHR_materials_unlit', 'KHR_materials_clearcoat', 'KHR_texture_transform', 'KHR_materials_emissive_strength']);
  for (const ext of [...doc.extensionsRequired ?? [], ...doc.extensionsUsed ?? []]) if (!allowed.has(ext)) throw new Error(`Unsupported GLB extension: ${ext}. Export an uncompressed static GLB with PNG/JPEG textures.`);
  for (const m of doc.materials ?? []) {
    if (m.alphaMode === 'BLEND') throw new Error('Static instanced slots support OPAQUE or MASK, not alpha blending.');
    for (const ext of Object.keys(m.extensions ?? {})) if (!allowed.has(ext)) throw new Error(`Unsupported material extension: ${ext}.`);
    const maps = {...m.pbrMetallicRoughness,...m,...m.extensions?.KHR_materials_clearcoat};
    for (const [key,info] of Object.entries(maps)) if (key.endsWith('Texture') && info) {
      const coord=info.extensions?.KHR_texture_transform?.texCoord ?? info.texCoord ?? 0;
      if (coord!==0 && !(key==='occlusionTexture' && coord===1)) throw new Error('Use UV0 for surface maps and UV0 or UV1 for AO.');
      if (Object.keys(info.extensions ?? {}).some(e=>e!=='KHR_texture_transform')) throw new Error('Unsupported texture extension.');
    }
  }
  if (doc.skins?.length || doc.animations?.length || doc.meshes.some(m => m.primitives.some(p => p.targets?.length || p.mode !== undefined && p.mode !== 4))) throw new Error('Asset slots currently support static triangle meshes, not skins, animations, morph targets or lines.');
  for (const v of doc.bufferViews ?? []) if (v.buffer !== 0 || !Number.isSafeInteger(v.byteLength) || !Number.isSafeInteger(v.byteOffset ?? 0) || v.byteLength < 0 || (v.byteOffset ?? 0) < 0 || (v.byteOffset ?? 0) + v.byteLength > binLen) throw new Error('Invalid embedded buffer range.');
  let vertices = 0;
  for (const a of doc.accessors ?? []) { if (!Number.isSafeInteger(a.count) || a.count < 0 || a.count > 3000000) throw new Error('Invalid or oversized accessor.'); vertices += a.type === 'VEC3' ? a.count : 0; }
  if (vertices > 9000000 || doc.nodes.length > 5000 || doc.materials?.length > 128) throw new Error('Asset exceeds the static slot complexity limits.');
  if (doc.nodes.some(n => n.matrix?.some(v => !Number.isFinite(v)) || n.scale?.some(v => !Number.isFinite(v) || v <= 0))) throw new Error('Asset transforms must be finite with positive scales.');
  const visiting = new Set(), done = new Set();
  const visit = id => {
    if (!Number.isInteger(id) || !doc.nodes[id]) throw new Error('Invalid scene node reference.');
    if (visiting.has(id)) throw new Error('Cyclic scene graph is not allowed.');
    if (done.has(id)) return;
    visiting.add(id); for (const child of doc.nodes[id].children ?? []) visit(child); visiting.delete(id); done.add(id);
  };
  for (let i = 0; i < doc.nodes.length; i++) visit(i);
  return { hash: assetHash(b), bytes: b.length, meshes: doc.meshes.length, nodes: doc.nodes.length, materials: doc.materials?.length ?? 0, images: doc.images?.length ?? 0 };
}
