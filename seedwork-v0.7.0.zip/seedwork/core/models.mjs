export const MODEL_KEY = /^m_[a-z0-9_]{1,28}$/;
export const HASH = /^[a-f0-9]{64}$/;

export function inputRefs(data) {
  const refs = new Set();
  const visit = (v, depth = 0) => {
    if (depth > 24) throw new Error('Recipe nesting exceeds 24 levels.');
    if (Array.isArray(v)) { for (const x of v) visit(x, depth + 1); }
    else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) {
      if (['__proto__', 'constructor', 'prototype'].includes(k)) throw new Error('Reserved recipe key.');
      if (['image', 'normal', 'height', 'orm', 'mask', 'asset'].includes(k) && typeof x === 'string') {
        if (!/^inputs\/[a-f0-9]{64}\.png$/.test(x)) throw new Error('Use uploaded inputs/<sha256>.png references, not local paths or URLs.');
        refs.add(x.slice(7, -4));
      }
      visit(x, depth + 1);
    }
    else if (typeof v === 'number' && !Number.isFinite(v)) throw new Error('Recipe numbers must be finite.');
  };
  visit(data);
  return [...refs].sort();
}

export function checkRecipe(recipe) {
  if (!recipe || !['seedwork.recipe/1', 'ai3d.recipe/1'].includes(recipe.schema) || !Array.isArray(recipe.parts) || !recipe.parts.length || recipe.parts.length > 192) throw new Error('Expected a Seedwork or compatible legacy recipe with 1–192 parts.');
  if (JSON.stringify(recipe).length > 160 * 1024) throw new Error('Recipe exceeds 160 KiB. Split large assemblies into separate models.');
  if (JSON.stringify(recipe.lods) !== '[1]') throw new Error('Native quality-locked recipes require lods:[1].');
  inputRefs(recipe);
  return recipe;
}

export function checkModels(models = {}) {
  if (!models || typeof models !== 'object' || Array.isArray(models) || Object.keys(models).length > 32) throw new Error('A world supports at most 32 native model types.');
  for (const [key, m] of Object.entries(models)) {
    if (!MODEL_KEY.test(key)) throw new Error('Model IDs use m_ followed by 1–28 lowercase letters, numbers or underscores.');
    if (!m || typeof m !== 'object' || Object.keys(m).some(k => !['name', 'hash', 'width', 'height', 'depth', 'radius', 'boxes', 'recipe', 'build'].includes(k))) throw new Error('Invalid native model descriptor.');
    if (!HASH.test(m.hash) || typeof m.name !== 'string' || !m.name.trim() || m.name.length > 80) throw new Error('Invalid model name or asset hash.');
    for (const k of ['width', 'height', 'depth', 'radius']) if (!Number.isFinite(m[k]) || m[k] <= 0 || m[k] > 150) throw new Error(`Invalid native model ${k}.`);
    if (!Array.isArray(m.boxes) || !m.boxes.length || m.boxes.length > 192) throw new Error('Expected 1–192 compound collision boxes.');
    for (const b of m.boxes) {
      if (!Array.isArray(b) || b.length !== 2 || b.some(v => !Array.isArray(v) || v.length !== 3 || v.some(n => !Number.isFinite(n) || Math.abs(n) > 150)) || b[0].some((v, i) => v > b[1][i])) throw new Error('Invalid model collision box.');
    }
    checkRecipe(m.recipe);
    if (!m.build || typeof m.build !== 'object' || Object.keys(m.build).some(k => !['source', 'recipeHash', 'version'].includes(k)) || !HASH.test(m.build.source) || !HASH.test(m.build.recipeHash) || !['0.3.0', '0.7.0'].includes(m.build.version)) throw new Error('Invalid model build provenance.');
  }
  return models;
}

export function bindings(w) {
  return { ...w.assets, ...Object.fromEntries(Object.entries(w.models ?? {}).map(([key, m]) => [key, m.hash])) };
}

export function worldInputs(w) {
  return [...new Set(Object.values(w.models ?? {}).flatMap(m => inputRefs(m.recipe)))];
}
