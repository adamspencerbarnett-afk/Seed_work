import { SEG, META, meta, blocked, rawHeight, clamp } from './world.mjs';

export class Index {
  constructor(size = 12) { this.size = size; this.cells = new Map(); }
  key(x, z) { return `${Math.floor(x / this.size)}:${Math.floor(z / this.size)}`; }
  add(o, radius = 0) {
    for (let z = Math.floor((o.z - radius) / this.size); z <= Math.floor((o.z + radius) / this.size); z++) {
      for (let x = Math.floor((o.x - radius) / this.size); x <= Math.floor((o.x + radius) / this.size); x++) {
        const key = `${x}:${z}`;
        if (!this.cells.has(key)) this.cells.set(key, []);
        this.cells.get(key).push(o);
      }
    }
  }
  at(x, z) { return this.cells.get(this.key(x, z)) ?? []; }
}

export function sample(w) {
  const size = w.terrain.size, step = size / SEG, data = new Float64Array((SEG + 1) ** 2);
  for (let z = 0; z <= SEG; z++) for (let x = 0; x <= SEG; x++) data[z * (SEG + 1) + x] = rawHeight(w, x * step - size / 2, z * step - size / 2);
  const get = (x, z) => {
    const ux = clamp((x + size / 2) / step, 0, SEG - 0.000001), uz = clamp((z + size / 2) / step, 0, SEG - 0.000001);
    const ix = Math.floor(ux), iz = Math.floor(uz), fx = ux - ix, fz = uz - iz, i = iz * (SEG + 1) + ix;
    const a = data[i], b = data[i + 1], c = data[i + SEG + 1], d = data[i + SEG + 2];
    return fx + fz <= 1 ? a + (b - a) * fx + (c - a) * fz : d + (c - d) * (1 - fx) + (b - d) * (1 - fz);
  };
  return { get, data, step };
}

export function collider(w, field = sample(w)) {
  const index = new Index();
  for (const o of w.objects) if (o.solid && meta(w, o.type).radius) {
    const r = meta(w, o.type).radius * o.scale + 0.42;
    index.add({ ...o, r, bottom: field.get(o.x, o.z) + o.y }, r);
  }
  const walk = (x, z) => {
    if (Math.abs(x) > w.terrain.size * 0.48 || Math.abs(z) > w.terrain.size * 0.48) return false;
    const ground = field.get(x, z);
    if (ground < w.terrain.water + 0.18) return false;
    for (const o of index.at(x, z)) if (blocked(w, o, x, z, ground, o.bottom)) return false;
    return true;
  };
  return { walk, index, field };
}

export function groundKey(w) {
  return JSON.stringify([w.seed, w.biome, w.terrain.size, w.terrain.relief, w.terrain.water, w.terrain.shape, w.terrain.stamps]);
}
