import { createRuntime, createGlbLoader, emptyScene, applyOps, type Node, type Three, type GltfLoader, type Op } from '../../sdk/index.mjs';
import { createObserver, connect, type Renderer, type Camera } from '../../sdk/dev.mjs';
declare const THREE: Three;
declare const scene: Node;
declare const GLTFLoader: new () => GltfLoader;
declare const renderer: Renderer;
declare const camera: Camera;
const runtime = createRuntime({ THREE, parent: scene, load: createGlbLoader({ Loader: GLTFLoader }) });
const ops: Op[] = [{ op: 'item_set', id: 'door', patch: { pos: [1, 0, 2] } }];
const doc = emptyScene('Typed host');
const observer = createObserver({ runtime, renderer, camera, tests: { route: async ({ signal }) => ({ passed: !signal.aborted, checks: [{ name: 'Route', passed: !signal.aborted }] }) } });
async function boot() {
  await runtime.setScene(doc);
  const link = await connect({ runtime, observer, project: 'test', token: 'explicit-token' });
  observer.afterFrame({ time: 123, cpuMs: 3 });
  const update = applyOps(doc, ops);
  await runtime.setScene(update.doc);
  await link.close(); observer.dispose(); await runtime.dispose();
}
void boot;
