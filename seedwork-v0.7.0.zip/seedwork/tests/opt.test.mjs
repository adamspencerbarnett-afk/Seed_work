import test from 'node:test';
import assert from 'node:assert/strict';
import { make, height, canWalk, check, rand } from '../core/world.mjs';
import { sample, collider, groundKey, Index } from '../core/spatial.mjs';
import { inspectGlb, assetHash } from '../core/asset.mjs';
import { tool } from '../core/tools.mjs';

import { fixture } from './fixture.mjs';

for (const biome of ['forest','desert','snow','fantasy']) {
  test(`${biome}: cached height preserves the reference surface at 5000 points`,()=>{
    const w=make({biome}),f=sample(w),rng=rand(525);
    let max=0;
    for(let i=0;i<5000;i++){const x=(rng()-.5)*240,z=(rng()-.5)*240;max=Math.max(max,Math.abs(f.get(x,z)-height(w,x,z)));}
    assert.ok(max<1e-10,`${max}`);
  });
  test(`${biome}: indexed collision matches the reference at 2500 points`,()=>{
    const w=make({biome}),c=collider(w),rng=rand(626);
    for(let i=0;i<2500;i++){const x=(rng()-.5)*160,z=(rng()-.5)*160;assert.equal(c.walk(x,z),canWalk(w,x,z));}
  });
}

test('terrain cache key ignores name, density, sky and objects',()=>{const a=make(),b=structuredClone(a);b.name='Changed';b.sky.time='night';b.terrain.density=.1;b.objects.pop();assert.equal(groundKey(a),groundKey(b));});
test('terrain cache key includes brush changes',()=>{const a=make(),b=tool(a,'terrain_brush',{x:0,z:0,mode:'raise',radius:5,power:1}).world;assert.notEqual(groundKey(a),groundKey(b));});
test('spatial index handles negative coordinates and objects spanning cells',()=>{const idx=new Index(8),o={x:-.1,z:-.2};idx.add(o,10);assert.equal(idx.at(8,0)[0],o);assert.equal(idx.at(-8,-8)[0],o);assert.equal(idx.at(40,0).length,0);});
test('GLB inspection returns reproducible content hashes',()=>{const b=fixture(),a=inspectGlb(b);assert.equal(a.hash,assetHash(b));assert.equal(a.meshes,1);assert.equal(a.bytes,b.length);});
test('truncated GLB is rejected',()=>assert.throws(()=>inspectGlb(fixture().subarray(0,100))));
test('external buffer URLs are rejected',()=>assert.throws(()=>inspectGlb(fixture(d=>d.buffers[0].uri='https://example.test/mesh.bin')),/embedded/));
test('external image URLs are rejected',()=>assert.throws(()=>inspectGlb(fixture(d=>d.images=[{uri:'https://example.test/a.png'}])),/embedded/));
test('compressed extensions are rejected with a specific message',()=>assert.throws(()=>inspectGlb(fixture(d=>d.extensionsRequired=['KHR_draco_mesh_compression'])),/Unsupported/));
test('animated assets are rejected',()=>assert.throws(()=>inspectGlb(fixture(d=>d.animations=[{}])),/static/));
test('cyclic scene graphs are rejected',()=>assert.throws(()=>inspectGlb(fixture(d=>d.nodes[0].children=[0])),/Cyclic/));
test('invalid node references are rejected',()=>assert.throws(()=>inspectGlb(fixture(d=>d.nodes[0].children=[900])),/reference/));
test('out-of-range buffer views are rejected',()=>assert.throws(()=>inspectGlb(fixture(d=>d.bufferViews[0].byteOffset=100000)),/range/));
test('negative scales are rejected',()=>assert.throws(()=>inspectGlb(fixture(d=>d.nodes[0].scale=[-1,1,1])),/positive/));
test('valid binding preserves object IDs and native document validity',()=>{const w=make(),hash=assetHash(fixture()),next=tool(w,'asset_bind',{type:'rock',hash}).world;assert.equal(next.assets.rock,hash);assert.deepEqual(next.objects,w.objects);check(next);});
test('generation preserves active asset bindings',()=>{const w=make();w.assets={rock:assetHash(fixture())};assert.deepEqual(tool(w,'world_make',{biome:'snow'}).world.assets,w.assets);});
test('unbinding restores the procedural slot without deleting instances',()=>{const w=make();w.assets={rock:assetHash(fixture())};const next=tool(w,'asset_unbind',{type:'rock'}).world;assert.equal(next.assets,undefined);assert.deepEqual(next.objects,w.objects);});
test('malformed binding hashes and slot names are rejected',()=>{const w=make();assert.throws(()=>tool(w,'asset_bind',{type:'rock',hash:'a'}));assert.throws(()=>check({...w,assets:{evil:'a'.repeat(64)}}));});
test('asset listing is read-only',()=>{const w=make(),r=tool(w,'asset_list',{});assert.equal(r.changed,false);assert.equal(r.world,w);assert.equal(r.result.types.length,11);});

test('alpha blending is rejected instead of silently sorted incorrectly',()=>assert.throws(()=>inspectGlb(fixture(d=>d.materials=[{alphaMode:'BLEND'}])),/alpha blending/));
test('unsupported advanced materials are rejected rather than lost on export',()=>assert.throws(()=>inspectGlb(fixture(d=>d.materials=[{extensions:{KHR_materials_transmission:{transmissionFactor:1}}}])),/Unsupported/));
test('surface UV1 is rejected explicitly on the pinned renderer',()=>assert.throws(()=>inspectGlb(fixture(d=>d.materials=[{normalTexture:{index:0,texCoord:1}}])),/UV0/));
