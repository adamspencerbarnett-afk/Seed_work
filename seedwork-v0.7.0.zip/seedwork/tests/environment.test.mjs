import test from 'node:test';
import assert from 'node:assert/strict';
import '../public/vendor/three-r140.min.js';
import { createEnvironment, bindAtmosphere, createEnvTools, preset, patchEnv, validate, ENV_SCHEMA, PRESET_NAMES, Climate, Exposure } from '../sdk/environment/index.mjs';
import { tool, catalog } from '../core/tools.mjs';
import { make, check } from '../core/world.mjs';
import { toolCatalog } from '../services/tools.mjs';
const T = globalThis.THREE;
const host = () => ({ THREE: T, parent: new T.Scene(), camera: new T.PerspectiveCamera() });
const close = (a, b, eps = 1e-10) => assert.ok(Math.abs(a - b) < eps, `${a} != ${b}`);

test('all seven environment presets validate and are independent copies', () => {
  assert.equal(PRESET_NAMES.length, 7);
  for (const n of PRESET_NAMES) { const a = preset(n); assert.equal(validate(a), a); a.weather.rain = .0123; assert.notEqual(a.weather.rain, preset(n).weather.rain); }
});
test('closed environment schema rejects unknown fields and prototype payloads', () => {
  assert.throws(() => validate({ ...preset(), wind: 2 }));
  assert.throws(() => patchEnv(preset(), JSON.parse('{"__proto__":{"poison":1}}')));
  assert.throws(() => preset('__proto__'));
  assert.throws(() => validate(Object.assign(Object.create({ hidden: 1 }), preset())));
});
test('invalid numeric settings cannot contaminate a valid climate state', () => {
  const c = new Climate(), saved = c.snapshot();
  for (const v of [NaN, Infinity, -.1, 1.01, '0.5', null]) assert.throws(() => c.set({ weather: { rain: v } }));
  assert.deepEqual(c.snapshot(), saved);
});
test('config patching preserves omitted nested settings and does not mutate inputs', () => {
  const a = preset('snow'), b = patchEnv(a, { weather: { wind: [3, -2] } });
  assert.equal(b.weather.snow, a.weather.snow); assert.deepEqual(b.weather.wind, [3, -2]); assert.notDeepEqual(a.weather.wind, b.weather.wind);
});
test('transition endpoints, intermediate values and snapshots are deterministic', () => {
  const a = new Climate(), b = new Climate(); a.set(preset('rain'), 2); b.restore(a.snapshot());
  for (let i = 0; i < 30; i++) { a.update(1 / 30); b.update(1 / 30); }
  close(a.current.weather.rain, .36); assert.deepEqual(a.snapshot(), b.snapshot());
  a.update(1); close(a.current.weather.rain, .72); assert.equal(a.transition, null);
});
test('changing the seed during a blended transition fails atomically', () => {
  const c = new Climate(), before = c.snapshot(); assert.throws(() => c.set({ seed: 2 }, 1)); assert.deepEqual(c.snapshot(), before);
});
test('fixed-step surface evolution agrees across frame partitions', () => {
  const a = new Climate(preset('thaw')), b = new Climate(preset('thaw'));
  for (let i = 0; i < 300; i++) a.update(1 / 30);
  for (let i = 0; i < 600; i++) b.update(1 / 60);
  assert.deepEqual(a.surface, b.surface); assert.equal(a.ticks, b.ticks); close(a.time, b.time);
});
test('cold precipitation accumulates snow; warm conditions melt rather than add it', () => {
  const c = new Climate(preset('snow')); c.set({ simulation: { enabled: true, rate: 60 }, surface: { snow: .1 } });
  for (let i = 0; i < 30; i++) c.update(1); assert.ok(c.surface.snow > .1);
  const t = new Climate(preset('thaw')); for (let i = 0; i < 30; i++) t.update(1); assert.ok(t.surface.snow < preset('thaw').surface.snow); assert.ok(t.surface.ice < preset('thaw').surface.ice);
});
test('disabled surface simulation preserves the authored baseline', () => {
  const c = new Climate(preset('rain')); for (let i = 0; i < 60; i++) c.update(1); assert.deepEqual(c.surface, preset('rain').surface);
});
test('climate rejects large or invalid frame deltas without silently dropping time', () => {
  const c = new Climate(); for (const dt of [-1, NaN, Infinity, 1.01]) assert.throws(() => c.update(dt)); assert.equal(c.time, 0);
});
test('live climate snapshots roundtrip and reject malformed restoration atomically', () => {
  const a = new Climate(preset('thaw')); a.update(.123); const snap = JSON.parse(JSON.stringify(a.snapshot())), b = new Climate(); b.restore(snap); assert.deepEqual(b.snapshot(), snap);
  for (const patch of [{ extra: 1 }, { time: NaN }, { remainder: 10 }, { transition: { seconds: NaN } }]) { assert.throws(() => b.restore({ ...snap, ...patch })); assert.deepEqual(b.snapshot(), snap); }
});
test('exposure samples preserve ground and a registered roof within quantization tolerance', () => {
  const f = new Exposure({ THREE: T, bounds: [-8, -8, 16, 16], range: [-5, 12], size: 64, ground: () => -.2, roof: (x, z) => Math.abs(x) < 2 && Math.abs(z) < 2 ? 3 : null });
  close(f.sample(0, 0).ground, -.2, 17 / 65535); close(f.sample(0, 0).roof, 3, 17 / 65535); close(f.sample(5, 5).roof, -.2, 17 / 65535); assert.equal(f.sample(50, 0).inside, false); f.dispose();
});
test('exposure rebuild is atomic and does not resize or replace its GPU texture', () => {
  const f = new Exposure({ THREE: T }), tex = f.texture, saved = f.data.slice();
  assert.throws(() => f.rebuild({ ground: x => x > 0 ? NaN : 2 })); assert.deepEqual(f.data, saved); assert.equal(f.builds, 1); assert.equal(f.texture, tex);
  f.rebuild({ ground: () => 1 }); assert.equal(f.texture, tex); assert.equal(f.builds, 2); f.dispose();
});
test('out-of-range heights are rejected instead of being silently clamped', () => {
  assert.throws(() => new Exposure({ THREE: T, range: [0, 1], ground: () => 2 }), /outside/);
  assert.throws(() => new Exposure({ THREE: T, size: 1024 }));
});
test('environment does not allocate another renderer, camera, input handler or animation loop', () => {
  const h = host(), e = createEnvironment(h); assert.equal(e.camera, h.camera); assert.equal(h.parent.children.length, 1); assert.equal(e.renderer, undefined); assert.equal(e.raf, undefined); e.dispose(); assert.equal(h.parent.children.length, 0);
});
test('unverified renderer versions and invalid resource budgets require explicit handling', () => {
  assert.throws(() => createEnvironment({ ...host(), THREE: { ...T, REVISION: '999' } }), /not been verified/);
  assert.throws(() => createEnvironment({ ...host(), capacity: { rain: 50001 } }));
  assert.throws(() => createEnvironment({ ...host(), radius: 0 }));
});
test('emitter motion keeps seeded attributes static and field cached between updates', () => {
  const e = createEnvironment({ ...host(), config: preset('rain') }), buffers = e.emitters.map(x => [x.geometry, x.geometry.attributes.envSeed.version, x.seeds.slice()]);
  for (let i = 0; i < 120; i++) e.update(1 / 60);
  assert.equal(e.field.builds, 1);
  buffers.forEach(([g, version, values], i) => { assert.equal(e.emitters[i].geometry, g); assert.equal(e.emitters[i].geometry.attributes.envSeed.version, version); assert.deepEqual(e.emitters[i].seeds, values); }); e.dispose();
});
test('reference and optimized paths keep every active seed in the same order', () => {
  const e = createEnvironment({ ...host(), config: preset('rain') }), active = e.emitters.map(x => x.seeds.slice(0, x.count * 4));
  const submitted = e.inspect().emitters.reduce((n, x) => n + x.submitted, 0); e.setReference(true);
  assert.ok(e.inspect().emitters.reduce((n, x) => n + x.submitted, 0) > submitted);
  e.emitters.forEach((x, i) => { assert.equal(x.geometry.instanceCount, x.max); assert.deepEqual(x.seeds.slice(0, x.count * 4), active[i]); }); e.dispose();
});
test('changing weather updates uniforms without rebuilding particle geometry', () => {
  const e = createEnvironment(host()), old = e.emitters.map(x => x.geometry); e.preset('snow'); assert.equal(e.uniforms.envSurface.value.y, .84); e.emitters.forEach((x, i) => assert.equal(x.geometry, old[i])); e.dispose();
});
test('weather material bindings share clones while preserving host geometry and texture ownership', () => {
  const h = host(), e = createEnvironment(h), texture = new T.Texture(), material = new T.MeshStandardMaterial({ map: texture }), geometry = new T.BoxGeometry(), group = new T.Group();
  const a = new T.Mesh(geometry, material), b = new T.Mesh(geometry, material); group.add(a, b); h.parent.add(group);
  let texDisposed = 0, geoDisposed = 0; texture.addEventListener('dispose', () => texDisposed++); geometry.addEventListener('dispose', () => geoDisposed++);
  const off = e.bind(group); assert.equal(a.material, b.material); assert.notEqual(a.material, material); assert.equal(a.material.map, texture); assert.equal(a.geometry, geometry); assert.equal(e.surfaces.pool.size, 1);
  off(); assert.equal(a.material, material); assert.equal(b.material, material); assert.equal(e.surfaces.pool.size, 0); e.dispose(); assert.equal(texDisposed, 0); assert.equal(geoDisposed, 0); assert.equal(group.parent, h.parent);
});
test('detach does not overwrite a material replaced by the host after binding', () => {
  const e = createEnvironment(host()), m = new T.Mesh(new T.BoxGeometry(), new T.MeshStandardMaterial()), next = new T.MeshStandardMaterial(); e.bind(m); m.material = next; e.dispose(); assert.equal(m.material, next);
});
test('custom shaders and duplicate registrations fail rather than being silently altered', () => {
  const e = createEnvironment(host()), a = new T.Mesh(new T.BoxGeometry(), new T.ShaderMaterial()); assert.throws(() => e.bind(a));
  const b = new T.Mesh(new T.BoxGeometry(), new T.MeshStandardMaterial()); b.material.onBeforeCompile = () => {}; assert.throws(() => e.bind(b), /adapter/);
  const c = new T.Mesh(new T.BoxGeometry(), new T.MeshStandardMaterial()); e.bind(c); assert.throws(() => e.bind(c), /already/); e.dispose();
});
test('material registration preflights a whole group before mutation', () => {
  const e = createEnvironment(host()), g = new T.Group(), m = new T.Mesh(new T.BoxGeometry(), new T.MeshStandardMaterial()), original = m.material; g.add(m, new T.Mesh(new T.BoxGeometry(), new T.ShaderMaterial())); assert.throws(() => e.bind(g)); assert.equal(m.material, original); assert.equal(e.surfaces.pool.size, 0); e.dispose();
});
test('seasonal foliage uses the same retention threshold in color and shadow passes', () => {
  const e = createEnvironment(host()), m = new T.InstancedMesh(new T.PlaneGeometry(), new T.MeshStandardMaterial(), 1), old = m.customDepthMaterial;
  e.bind(m, { foliage: 1 }); assert.ok(m.customDepthMaterial?.isMeshDepthMaterial); assert.ok(m.customDistanceMaterial?.isMeshDistanceMaterial);
  const shader = { uniforms: {}, vertexShader: T.ShaderLib.depth.vertexShader, fragmentShader: T.ShaderLib.depth.fragmentShader }; m.customDepthMaterial.onBeforeCompile(shader); assert.ok(shader.fragmentShader.includes('envLeaf > envFoliage.y')); assert.equal(shader.uniforms.envFoliage, e.uniforms.envFoliage); e.dispose(); assert.equal(m.customDepthMaterial, old);
});
test('surface response handles wetness, nonmetallic snow and slope exposure in the PBR shader', () => {
  const e = createEnvironment(host()), m = new T.Mesh(new T.BoxGeometry(), new T.MeshStandardMaterial()); e.bind(m);
  const shader = { uniforms: {}, vertexShader: T.ShaderLib.physical.vertexShader, fragmentShader: T.ShaderLib.physical.fragmentShader }; m.material.onBeforeCompile(shader);
  assert.ok(shader.fragmentShader.includes('metalnessFactor *= 1.0 - envSnow')); assert.ok(shader.fragmentShader.includes('material.clearcoatF0')); assert.ok(shader.fragmentShader.includes('envHeights(envPos.xz)')); e.dispose();
});
test('atmosphere ownership is opt-in and restores only resources still owned', () => {
  const h = host(), e = createEnvironment(h), scene = h.parent, old = new T.Fog('#aaa', 2, 20), bg = new T.Color('#fff'), sun = new T.DirectionalLight('#fff', 2); scene.fog = old; scene.background = bg;
  const off = bindAtmosphere(e, { scene, sun, background: true }); e.preset('rain'); assert.notEqual(scene.fog, old); assert.ok(sun.intensity < 2); off(); assert.equal(scene.fog, old); assert.equal(scene.background, bg); assert.equal(sun.intensity, 2);
  const off2 = bindAtmosphere(e, { scene }); const next = new T.Fog(); scene.fog = next; off2(); assert.equal(scene.fog, next); e.dispose();
});
test('runtime tools are closed, validated and do not execute arbitrary scripts', () => {
  const e = createEnvironment(host()), t = createEnvTools(e); assert.equal(t.catalog().length, 3); t.call('environment_preset', { name: 'snow' }); assert.equal(t.call('environment_inspect').config.weather.snow, .65);
  assert.throws(() => t.call('environment_set', { config: preset(), eval: 'x' })); assert.throws(() => t.call('environment_preset', { name: 'magic' })); e.dispose();
});
test('world environment tools preserve geometry and are included in revision-checked MCP writes', () => {
  const w = make(), a = tool(w, 'environment_preset', { name: 'snow' }).world; assert.deepEqual(a.objects, w.objects); assert.deepEqual(a.terrain, w.terrain); check(a);
  const d = tool(a, 'environment_inspect').result; d.config.surface.snow = 0; assert.equal(a.environment.surface.snow, .84);
  const wires = toolCatalog(true); for (const name of ['environment_set', 'environment_preset']) { const def = wires.find(v => v.name === name); assert.ok(def.inputSchema.required.includes('_rev')); assert.ok(def.inputSchema.required.includes('_key')); }
  assert.equal(catalog().length, 27);
});
test('world JSON roundtrip, regenerate, detachment and invalid weather behave predictably', () => {
  const a = tool(make(), 'environment_preset', { name: 'autumn' }).world; assert.deepEqual(check(JSON.parse(JSON.stringify(a))).environment, a.environment);
  const b = tool(a, 'world_make', { seed: 123 }).world; assert.deepEqual(b.environment, a.environment);
  const c = tool(b, 'environment_preset', { name: 'off' }).world; assert.equal(c.environment, undefined);
  assert.throws(() => check({ ...a, environment: { ...a.environment, bad: true } }));
});
test('environment disposal is idempotent and mutating a detached runtime fails', () => {
  const e = createEnvironment(host()); e.dispose(); e.dispose(); assert.equal(e.inspect().closed, true); assert.throws(() => e.update(.01)); assert.throws(() => e.set({})); assert.throws(() => e.invalidateField());
});

test('weather-only changes preserve evolved surface state and blends start from the live surface', () => {
  const c = new Climate(preset('thaw')); for (let i = 0; i < 60; i++) c.update(1);
  const before = { ...c.surface }; c.set({ weather: { rain: .4 } }); assert.deepEqual(c.surface, before);
  c.set({ surface: { wet: .8 } }); assert.equal(c.surface.snow, before.snow); assert.equal(c.surface.ice, before.ice);
  c.set(preset('snow'), 2); assert.equal(c.transition.from.surface.snow, before.snow);
});
test('detaching environment restores its optional atmosphere adapter automatically', () => {
  const h = host(), sun = new T.DirectionalLight(0xffffff, 2), fog = new T.Fog(0x777777, 5, 40); h.parent.fog = fog;
  const e = createEnvironment(h); const off = bindAtmosphere(e, { scene: h.parent, sun, background: true }); e.preset('rain');
  assert.notEqual(h.parent.fog, fog); e.dispose(); assert.equal(h.parent.fog, fog); assert.equal(sun.intensity, 2); off();
});

test('base material resolution preserves source identity without mutating it', () => {
  const h = host(), e = createEnvironment(h), m = new T.MeshStandardMaterial(), mesh = new T.Mesh(new T.BoxGeometry(), m);
  const off = e.bind(mesh); assert.equal(e.sourceMaterial(mesh.material), m); assert.equal(m.userData.seedworkEnvironment, undefined); assert.equal(mesh.material.userData.seedworkEnvironment, true); off(); e.dispose();
});
test('static export rejects live shaders and explicit base export is byte-identical', async () => {
  globalThis.window = { THREE: T };
  const { glb } = await import('../public/src/glb.js');
  const h = host(), e = createEnvironment(h), m = new T.MeshStandardMaterial({ color: 0x765432, roughness: .73 }), root = new T.Group(); root.add(new T.Mesh(new T.BoxGeometry(), m));
  const before = new Uint8Array(glb(root)); e.bind(root); e.preset('snow'); assert.throws(() => glb(root), /cannot be serialized/);
  const after = new Uint8Array(glb(root, { material: m => e.sourceMaterial(m) })); assert.deepEqual(after, before); e.dispose();
});
