import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { compile, doctor } from '../modeler/compiler.mjs';
import { validateRecipe } from '../modeler/schema.mjs';
import { geometry, exactWeld } from '../modeler/geometry.mjs';
import { packGlb, signature, readGlb } from '../modeler/glb.mjs';
import { encodePng, decodePng } from '../modeler/png.mjs';
import { inspectGlb } from '../core/asset.mjs';
import { validatePlan, buildPlan, writePlan } from '../scripts/plan.mjs';

const root = resolve(import.meta.dirname, '..');
const catalog = JSON.parse(readFileSync(resolve(root, 'modeler/catalog.json')));
const recipe = () => ({ schema: 'seedwork.recipe/1', name: 'Test_Part', seed: 7, texture_size: 64, max_triangles: 80000, lods: [1], materials: { mat: { kind: 'wood', rough: .72, bump: .0003 } }, parts: [{ name: 'body', shape: 'box', mat: 'mat', size: [.5, .3, .2], bevel: .004 }] });
const variants = [
  { shape: 'box', size: [.5, .3, .2], bevel: .004 },
  { shape: 'cylinder', radius: .2, top: .16, inner: .1, length: .4, steps: 48 },
  { shape: 'ellipsoid', size: [.3, .6, .4], steps: 48, rings: 24 },
  { shape: 'torus', radius: .3, tube: .04, steps: 48, rings: 16 },
  { shape: 'bowl', size: [.6, .2, .7], depth: .01, steps: 48, rings: 12 },
  { shape: 'lathe', profile: [[0, 0], [.2, 0], [.2, .4], [0, .4]], steps: 48 },
  { shape: 'hose', points: [[0, 0, 0], [.2, .2, 0], [.3, .2, .2]], radius: .01, steps: 12, samples: 32 },
  { shape: 'plate', points: [[0, 0], [.4, 0], [.4, .2], [.2, .1], [0, .2]], depth: .05 }
];
for (const shape of variants) test(`independent ${shape.shape} compilation is deterministic, bounded and exact`, () => {
  const d = recipe(); d.parts = [{ name: 'shape', mat: 'mat', ...shape, pos: [.1, .2, .3], rot: [10, 25, 5] }];
  const a = compile(d), b = compile(d);
  assert.equal(a.result.hash, b.result.hash); assert.deepEqual(a.bytes, b.bytes); assert.equal(inspectGlb(a.bytes).hash, a.result.hash);
  assert.equal(signature(a.bytes), signature(a.reference)); assert.equal(a.result.report.raw.drawn_triangles, a.result.report.packed.drawn_triangles);
  assert.ok(a.result.width > 0 && a.result.height > 0 && a.result.depth > 0);
});
test('compiler is Node-only and no legacy implementation is bundled', () => {
  const d = doctor(); assert.ok(d.ok && !d.network); assert.equal(d.engine, '0.7.0'); assert.ok(d.capabilities.shapes.length === 8); assert.equal(existsSync(resolve(root, 'modeler/kit')), false);
});
test('legacy recipe envelope is accepted without running legacy source', () => { const d = recipe(); d.schema = 'ai3d.recipe/1'; assert.ok(compile(d).result.report.exact.passed); });
for (const field of ['stamps', 'sculpt', 'decals', 'unknown']) test(`unsupported ${field} is rejected instead of dropping authored detail`, () => {
  const d = recipe(); d.parts[0][field] = []; assert.throws(() => compile(d), /not supported/);
});
test('material/geometry unsupported fields and duplicate names fail closed', () => {
  const d = recipe(); d.materials.mat.url = 'https://example.invalid'; assert.throws(() => compile(d)); delete d.materials.mat.url;
  d.parts.push(structuredClone(d.parts[0])); assert.throws(() => compile(d), /unique/);
});
test('quality limits never decimate or downscale', () => {
  const d = recipe(); d.max_triangles = 1; assert.throws(() => compile(d), /detail was not removed/);
  d.max_triangles = 80000; d.texture_size = 65; assert.throws(() => compile(d), /texture size/);
  d.texture_size = 64; d.lods = [1, .5]; assert.throws(() => compile(d), /lods/);
});
test('invalid dimensions, crossed plates and collapsed hoses are rejected', () => {
  const d = recipe(); d.parts[0].bevel = .2; assert.throws(() => compile(d), /bevel/);
  d.parts = [{ name: 'cross', mat: 'mat', shape: 'plate', depth: .1, points: [[0, 0], [1, 1], [1, 0], [0, 1]] }]; assert.throws(() => compile(d));
  d.parts = [{ name: 'flat', mat: 'mat', shape: 'hose', radius: .02, points: [[0, 0, 0], [0, 0, 0]] }]; assert.throws(() => compile(d));
});
test('native PNG encoder/decoder preserves RGB bytes and rejects corruption', () => {
  const rgb = Buffer.from(Array.from({ length: 17 * 19 * 3 }, (_, i) => i * 29 & 255));
  const bytes = encodePng(17, 19, rgb), decoded = decodePng(bytes); assert.deepEqual(decoded.pixels, rgb);
  const broken = Buffer.from(bytes); broken[40] ^= 1; assert.throws(() => decodePng(broken), /checksum/);
  assert.throws(() => decodePng(Buffer.concat([bytes, Buffer.from([1])])), /trailing/);
});
test('uploaded maps are embedded byte-for-byte and never resized', t => {
  const dir = mkdtempSync(resolve(tmpdir(), 'seedwork-input-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const png = encodePng(64, 64, Buffer.alloc(64 * 64 * 3, 110)), hash = createHash('sha256').update(png).digest('hex'); writeFileSync(resolve(dir, hash + '.png'), png);
  const d = recipe(); d.materials.mat = { kind: 'image', image: `inputs/${hash}.png`, tex_size: 64 };
  const built = compile(d, { inputs: dir }), parsed = readGlb(built.bytes), view = parsed.doc.bufferViews[parsed.doc.images[0].bufferView];
  assert.deepEqual(parsed.bin.subarray(view.byteOffset, view.byteOffset + view.byteLength), png);
  d.materials.mat.tex_size = 128; assert.throws(() => compile(d, { inputs: dir }), /resizing is disabled/);
});
test('height-derived normal baking is explicit and source sizes must match', t => {
  const dir = mkdtempSync(resolve(tmpdir(), 'seedwork-height-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const png = encodePng(64, 64, Buffer.from(Array.from({ length: 64 * 64 * 3 }, (_, i) => Math.floor(i / 3) % 64 * 4))), hash = createHash('sha256').update(png).digest('hex'); writeFileSync(resolve(dir, `${hash}.png`), png);
  const d = recipe(); d.materials.mat.height = `inputs/${hash}.png`; assert.ok(compile(d, { inputs: dir }).result.report.exact.passed);
  d.materials.mat.normal = d.materials.mat.height; assert.throws(() => compile(d, { inputs: dir }), /not both/);
});
test('dimension edits reuse verified material cache without changing maps', t => {
  const cache = mkdtempSync(resolve(tmpdir(), 'seedwork-mat-cache-')); t.after(() => rmSync(cache, { recursive: true, force: true }));
  const d = recipe(), a = compile(d, { cache }); d.parts[0].size[0] = .8; const b = compile(d, { cache });
  assert.equal(a.result.report.materials.misses, 1); assert.equal(b.result.report.materials.hits, 1); assert.equal(a.result.report.packed.image_bytes, b.result.report.packed.image_bytes);
});
test('welding keeps normals and UV seams and the audit detects changed transforms', () => {
  const d = recipe(), built = compile(d), g = geometry(d.parts[0]), packed = exactWeld(g);
  assert.ok(packed.attributes.position.count > 8);
  const bytes = Buffer.from(built.bytes), len = bytes.readUInt32LE(12), doc = JSON.parse(bytes.subarray(20, 20 + len).toString());
  const raw = JSON.stringify(doc), changed = raw.replace('Seedwork_meter_origin', 'Seedwork_meter_Origin');
  Buffer.from(changed).copy(bytes, 20); assert.notEqual(signature(bytes), signature(built.bytes));
});
test('all seven rebuilt starters have current provenance and exact reports', () => {
  const index = JSON.parse(readFileSync(resolve(root, 'modeler/starter/index.json')));
  assert.equal(index.models.length, 7);
  for (const { result } of index.models) { assert.equal(result.build.version, '0.7.0'); assert.equal(result.build.source, doctor().source); assert.equal(result.report.exact.before, result.report.exact.after); }
});
test('all example plans validate and build portable worlds', () => {
  for (const name of ['autumn-settlement', 'alpine-outpost', 'rainy-workshop']) {
    const p = JSON.parse(readFileSync(resolve(root, 'examples/plans', name + '.json'))); validatePlan(p);
    const out = buildPlan(p); assert.ok(out.report.validation.valid); assert.ok(out.pack.world.environment); assert.equal(out.report.externalNetwork, false);
  }
});
test('plan errors are atomic and may not invoke arbitrary programs or paths', t => {
  const dir = mkdtempSync(resolve(tmpdir(), 'seedwork-plan-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const p = { format: 'seedwork.plan/1', world: { seed: 42 }, ops: [{ name: 'world_undo', args: {} }] };
  assert.throws(() => writePlan(p, resolve(dir, 'out')), /not allowed/); assert.equal(existsSync(resolve(dir, 'out')), false);
  p.ops = [{ name: 'object_add', args: { type: 'missing', x: 0, z: 0 } }]; assert.throws(() => buildPlan(p), /operation 0/);
});
test('plan output is portable and refuses to overwrite an existing folder', t => {
  const dir = mkdtempSync(resolve(tmpdir(), 'seedwork-out-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const p = { format: 'seedwork.plan/1', world: { name: 'Clean Plan', seed: 42 }, models: [{ key: 'm_part', template: 'part' }] }, target = resolve(dir, 'out');
  const result = writePlan(p, target); assert.ok(result.validation.valid); assert.ok(readFileSync(resolve(target, 'start.seedpack.json')).length > 0);
  assert.throws(() => writePlan(p, target), /not overwritten/);
});

test('falsy transforms and numerical source-map references are rejected explicitly', () => {
  for (const field of ['pos', 'rot', 'scale', 'tile']) { const d = recipe(); d.parts[0][field] = 0; assert.throws(() => validateRecipe(d)); }
  for (const field of ['image', 'normal', 'orm', 'height']) { const d = recipe(); d.materials.mat[field] = 0; assert.throws(() => validateRecipe(d), /Surface inputs/); }
});
test('mismatched UV projection requests are rejected rather than ignored', () => {
  const d = recipe(); d.parts[0].uv = 'cylinder'; assert.throws(() => validateRecipe(d), /UV mode/);
});
