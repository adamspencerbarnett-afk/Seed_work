from pathlib import Path
from playwright.sync_api import sync_playwright
import argparse, base64, json, os, urllib.request, urllib.error
import numpy as np
from PIL import Image
from io import BytesIO

parser=argparse.ArgumentParser()
parser.add_argument('--url',default='http://127.0.0.1:4173')
parser.add_argument('--out',default='visual-report')
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
checks=[];errors=[];pairs=[]
def record(name,ok,detail=None):
    checks.append({'name':name,'passed':bool(ok),'detail':detail});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    if not ok:raise AssertionError(str(detail))

def decode(data):return base64.b64decode(data.split(',')[1])

def compare(name,a,b):
    aa=np.array(Image.open(BytesIO(decode(a['image'])))).astype(np.int16)
    bb=np.array(Image.open(BytesIO(decode(b['image'])))).astype(np.int16)
    delta=np.abs(aa-bb)
    result={'name':name,'pixels':int(aa.shape[0]*aa.shape[1]),'changedPixels':int(np.any(delta,axis=2).sum()),'maxChannelDifference':int(delta.max()),'reference':a['audit'],'optimized':b['audit']}
    pairs.append(result)
    (out/(name+'-reference.png')).write_bytes(decode(a['image']))
    (out/(name+'-optimized.png')).write_bytes(decode(b['image']))
    record(name+' fixed-camera pixel equality',result['changedPixels']==0,result)

try:
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader','--use-angle=swiftshader'])
        p=browser.new_page(viewport={'width':1200,'height':800},device_scale_factor=1)
        p.set_default_timeout(90000)
        p.on('pageerror',lambda e:errors.append(str(e)))
        def route(r):
            if r.request.method == 'OPTIONS':
                r.fulfill(status=204, headers={'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*'})
                return
            req=urllib.request.Request(args.url+r.request.url.split('http://seedwork.test',1)[-1],data=r.request.post_data_buffer,method=r.request.method)
            for key in ('content-type','authorization'):
                if key in r.request.headers:req.add_header(key,r.request.headers[key])
            try:
                with urllib.request.urlopen(req,timeout=60) as res:data,status,typ=res.read(),res.status,res.headers['Content-Type']
            except urllib.error.HTTPError as e:data,status,typ=e.read(),e.code,'application/json'
            r.fulfill(status=status,body=data,headers={'Content-Type':typ,'Access-Control-Allow-Origin':'*'})
        p.route('http://seedwork.test/**',route)
        p.evaluate('''()=>{window.EventSource=class{constructor(){} close(){}};Object.defineProperty(crypto,'randomUUID',{value:()=>{const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const s=[...b].map(v=>v.toString(16).padStart(2,"0")).join("");return `${s.slice(0,8)}-${s.slice(8,12)}-${s.slice(12,16)}-${s.slice(16,20)}-${s.slice(20)}`;}});}''')
        p.set_content((root/'public/index.html').read_text().replace('<head>','<head><base href="http://seedwork.test/">'),wait_until='load')
        p.wait_for_function('window.seedwork?.ready===true',timeout=120000)
        p.evaluate('async()=>{const e=seedwork.engine;e.freeze=true;e.elapsed=0;window.core=await import("/core/world.mjs");e.load(core.make({name:"Verdant Reach",seed:1847}),true);e.select(null);e.grid.visible=false;e.brush.visible=false;}')
        record('Native rendering and 4096 shadow map remain enabled',p.evaluate('seedwork.engine.renderer.getPixelRatio()===devicePixelRatio && seedwork.engine.sun.shadow.mapSize.x===4096'))
        def shot(optimized):
            return p.evaluate('opt=>{const e=seedwork.engine;e.cull=opt;e.cacheShadows=opt;e.render();e.render();return {image:e.screenshot(),audit:e.audit()}}',optimized)
        for name,x,y,z,dist,yaw,tilt in [('overview',0,4,0,135,.88,.48),('village',16,4,13,31,.75,.3),('edge',-18,5,-5,26,3.7,.3)]:
            p.evaluate('v=>{const e=seedwork.engine;e.target.set(v[0],v[1],v[2]);e.dist=v[3];e.yaw=v[4];e.tilt=v[5];e.render();}',[x,y,z,dist,yaw,tilt])
            compare(name,shot(False),shot(True))
        info=p.evaluate('()=>{const e=seedwork.engine;window.saved=structuredClone(e.world);const old=e.terrain.geometry.uuid,build=e.metrics.terrainBuilds,batches=e.metrics.batchBuilds,shared=e.batches[0].geometry.uuid,w=structuredClone(e.world),o=w.objects.find(o=>o.type==="crystal");o.rot+=17;o.scale*=1.05;e.load(w);return {terrainSame:e.terrain.geometry.uuid===old,terrainBuilds:e.metrics.terrainBuilds-build,batchBuilds:e.metrics.batchBuilds-batches,shared:e.batches[0].geometry.uuid===shared,updates:e.metrics.matrixUpdates};}')
        record('Single transform reuses terrain, geometry and existing instance batches',info['terrainSame'] and info['shared'] and info['terrainBuilds']==0 and info['batchBuilds']==0 and info['updates']>0,info)
        a=shot(True)
        p.evaluate('()=>{const e=seedwork.engine,w=structuredClone(e.world);e.groundKey=null;e.load(w);}')
        compare('incremental-vs-rebuild',a,shot(True))
        for biome in ('snow','desert','fantasy'):
            p.evaluate('biome=>{const e=seedwork.engine;e.load(core.make({biome,seed:1847}),true);e.target.set(10,4,8);e.dist=55;e.yaw=1.3;e.tilt=.3;}',biome)
            compare(biome,shot(False),shot(True))
        p.evaluate('()=>{seedwork.engine.load(core.make({seed:1847}),true);seedwork.engine.render();}')
        memory=p.evaluate('()=>{const e=seedwork.engine,rows=[];for(let i=0;i<12;i++){const w=structuredClone(e.world);w.terrain.relief=i%2?9:10;e.load(w);e.render();rows.push({g:e.renderer.info.memory.geometries,t:e.renderer.info.memory.textures,p:e.renderer.info.programs.length});}return rows;}')
        record('Repeated terrain rebuilds have stable tracked GPU resource counts',len({json.dumps(x,sort_keys=True) for x in memory[2:]})==1,memory)
        idle=p.evaluate('()=>{const e=seedwork.engine;e.render();const n=e.metrics.shadowUpdates;e.render();return e.metrics.shadowUpdates-n;}')
        record('An unchanged camera redraw does not regenerate static shadows',idle==0,idle)
        play=p.evaluate('()=>{const e=seedwork.engine;e.load(core.make({seed:1847}),true);e.start();e.keys.add("KeyW");const start={...e.player};for(let i=0;i<10;i++)e.updatePlay(.03);const distance=Math.hypot(e.player.x-start.x,e.player.z-start.z);e.keys.clear();e.stop();return {distance,steps:10,stepSeconds:.03};}')
        record('First-person traversal advances against the indexed collision surface',play['distance']>0.1,play)
        export_info=p.evaluate('async()=>{const e=seedwork.engine;e.cull=true;e.target.set(16,4,13);e.dist=20;e.yaw=.7;e.tilt=.3;e.render();window.full=seedwork.glb(e.root);const g=await new Promise((res,rej)=>new THREE.GLTFLoader().parse(full,"",res,rej));const d=g.parser.json;let nodes=0;g.scene.traverse(o=>{if(o.isMesh)nodes++});return {bytes:full.byteLength,nodes,images:d.images.length,normal:d.materials.filter(m=>m.normalTexture).length,orm:d.materials.filter(m=>m.pbrMetallicRoughness?.metallicRoughnessTexture).length,masked:d.materials.filter(m=>m.alphaMode==="MASK").length,ids:e.world.objects.every(o=>d.nodes.some(n=>n.name===o.id)),culled:e.audit().culled};}')
        record('Static GLB readback contains PBR maps, foliage cutouts and off-camera objects',export_info['images']>=25 and export_info['normal']>0 and export_info['orm']>0 and export_info['masked']>0 and export_info['ids'],export_info)
        data=p.evaluate('()=>{let s="",a=new Uint8Array(full);for(let i=0;i<a.length;i+=32768)s+=String.fromCharCode(...a.subarray(i,i+32768));return btoa(s)}')
        (out/'world.glb').write_bytes(base64.b64decode(data))
        slot=p.evaluate('()=>{const e=seedwork.engine,p=e.assets.recipes.rock,group=new THREE.Group();for(const part of p)group.add(new THREE.Mesh(e.assets.geo[part.g],e.assets.mat[part.m]));const data=new Uint8Array(seedwork.glb(group));let s="";for(let i=0;i<data.length;i+=32768)s+=String.fromCharCode(...data.subarray(i,i+32768));return btoa(s)}')
        slot=base64.b64decode(slot);(out/'stone-slot.glb').write_bytes(slot)
        p.locator('[data-tab="assets"]').click()
        p.locator('[data-cat="All"]').click()
        p.locator('[data-asset="rock"]').click()
        rev=p.evaluate('seedwork.rev')
        p.locator('#asset-file').set_input_files({'name':'stone-slot.glb','mimeType':'model/gltf-binary','buffer':slot})
        p.wait_for_function('v=>seedwork.rev>v',arg=rev)
        p.wait_for_function('!document.body.classList.contains("busy")')
        record('Real Assets UI imports and binds a textured local GLB',p.evaluate('Boolean(seedwork.world.assets?.rock) && seedwork.engine.assets.recipes.rock[0].g.startsWith("import-")'))
        bound=p.evaluate('seedwork.world.assets.rock')
        for name in ('world_undo','world_redo'):
            p.evaluate('async name=>await seedwork.run(name,{})',name)
        record('Imported asset undo/redo reloads GPU resources correctly',p.evaluate('seedwork.world.assets.rock')==bound)
        p.locator('#reset-asset').click();p.wait_for_function('!seedwork.world.assets?.rock')
        record('Restore prefab removes the binding without deleting objects',p.evaluate('!seedwork.engine.assets.recipes.rock[0].g.startsWith("import-")'))
        p.evaluate('async()=>await seedwork.run("world_make",{name:"Verdant Reach",biome:"forest",seed:1847})')
        p.set_viewport_size({'width':1600,'height':1000})
        p.evaluate('()=>{const e=seedwork.engine;e.freeze=true;e.select(null);e.target.set(16,4,13);e.dist=31;e.yaw=.75;e.tilt=.3;e.render();}')
        p.wait_for_timeout(400);p.screenshot(path=str(out/'editor-close.png'))
        p.evaluate('seedwork.engine.home();seedwork.engine.render()')
        p.wait_for_timeout(300);p.screenshot(path=str(out/'editor-overview.png'))
        record('No uncaught JavaScript errors during the visual and asset audit',not errors,errors)
        browser.close()
finally:
    (out/'visual.json').write_text(json.dumps({'environment':'Chromium / SwiftShader / native DPR1 / about:blank HTTP fixture / SSE mocked','checks':checks,'pairs':pairs,'errors':errors,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)},indent=2))
