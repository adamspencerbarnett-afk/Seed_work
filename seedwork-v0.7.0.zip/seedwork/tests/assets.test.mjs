import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { fixture } from './fixture.mjs';
import { assetHash } from '../core/asset.mjs';
const delay=n=>new Promise(r=>setTimeout(r,n));

test('asset storage and portable bundles across two clean servers',async t=>{
  const procs=[],dirs=[],port=21500+Math.floor(Math.random()*2000);
  t.after(async()=>{for(const p of procs)p.kill();await delay(120);for(const dir of dirs)await rm(dir,{recursive:true,force:true});});
  async function start(port){
    const dir=await mkdtemp(resolve(tmpdir(),'seedwork-assets-'));dirs.push(dir);
    const p=spawn(process.execPath,['server.mjs'],{cwd:resolve(import.meta.dirname,'..'),env:{...process.env,PORT:String(port),SEEDWORK_DIR:dir},stdio:'ignore'});procs.push(p);
    const url=`http://127.0.0.1:${port}`;let session;
    for(let i=0;i<90;i++){try{session=await (await fetch(url+'/api/session')).json();break;}catch{await delay(50);}}
    assert.ok(session?.token);
    const send=async(path,data,method='POST',binary=false)=>{
      if(data&&!binary&&method!=='GET') { data={...data,key:data.key??crypto.randomUUID()}; if(path==='/api/tool'&&data.rev===undefined) data.rev=(await(await fetch(url+'/api/world')).json()).rev; }
      const res=await fetch(url+path,{method,headers:{Authorization:`Bearer ${session.token}`,'Content-Type':binary?'model/gltf-binary':'application/json'},...(data===undefined?{}:{body:binary?data:JSON.stringify(data)})});
      return {status:res.status,data:await res.json()};
    };
    return {url,send,world:async()=>(await send('/api/world',undefined,'GET')).data};
  }
  const a=await start(port),b=await start(port+1),bytes=fixture(),hash=assetHash(bytes);let pack;
  await t.test('upload requires local session authorization',async()=>assert.equal((await fetch(a.url+'/api/asset',{method:'POST',body:bytes})).status,401));
  await t.test('invalid GLB does not alter the world revision',async()=>{const before=await a.world();assert.equal((await a.send('/api/asset',Buffer.from('bad'),'POST',true)).status,400);assert.equal((await a.world()).rev,before.rev);});
  await t.test('content-addressed upload preserves bytes and world revision',async()=>{const before=await a.world(),res=await a.send('/api/asset',bytes,'POST',true);assert.equal(res.status,200);assert.equal(res.data.hash,hash);assert.deepEqual(Buffer.from(await (await fetch(a.url+'/api/asset/'+hash)).arrayBuffer()),bytes);assert.equal((await a.world()).rev,before.rev);});
  await t.test('missing asset binding is rejected',async()=>assert.equal((await a.send('/api/tool',{name:'asset_bind',args:{type:'rock',hash:'f'.repeat(64)}})).status,400));
  await t.test('asset binding preserves instances and is undoable',async()=>{const before=await a.world(),bound=await a.send('/api/tool',{name:'asset_bind',args:{type:'rock',hash}});assert.equal(bound.status,200);assert.equal(bound.data.world.assets.rock,hash);assert.deepEqual(bound.data.world.objects,before.world.objects);const undo=await a.send('/api/tool',{name:'world_undo'});assert.deepEqual(undo.data.world,before.world);const redo=await a.send('/api/tool',{name:'world_redo'});assert.equal(redo.data.world.assets.rock,hash);});
  await t.test('native JSON rejects missing dependencies on another machine',async()=>{const aw=await a.world(),bw=await b.world();assert.equal((await b.send('/api/world',{rev:bw.rev,world:aw.world},'PUT')).status,400);assert.equal((await b.world()).rev,bw.rev);});
  await t.test('portable bundle contains the exact world and GLB bytes',async()=>{const res=await a.send('/api/bundle',undefined,'GET');assert.equal(res.status,200);pack=res.data;assert.equal(pack.seedworkPack,1);assert.deepEqual(Buffer.from(pack.assets[hash],'base64'),bytes);assert.deepEqual(pack.world,(await a.world()).world);});
  await t.test('bundle imports on a clean server with identical world and assets',async()=>{const bw=await b.world(),res=await b.send('/api/bundle',{rev:bw.rev,pack},'PUT');assert.equal(res.status,200);assert.deepEqual(res.data.world,pack.world);assert.deepEqual(Buffer.from(await (await fetch(b.url+'/api/asset/'+hash)).arrayBuffer()),bytes);});
  await t.test('stale bundle import is rejected without changes',async()=>{const bw=await b.world();assert.equal((await b.send('/api/bundle',{rev:bw.rev-1,pack},'PUT')).status,409);assert.deepEqual((await b.world()).world,bw.world);});
  await t.test('tampered bundle content hash is rejected',async()=>{const bw=await b.world(),bad=structuredClone(pack);bad.assets[hash]=fixture(d=>d.asset.generator='tampered').toString('base64');assert.equal((await b.send('/api/bundle',{rev:bw.rev,pack:bad},'PUT')).status,400);assert.equal((await b.world()).rev,bw.rev);});
  await t.test('unknown bundle payload is rejected',async()=>{const bw=await b.world();assert.equal((await b.send('/api/bundle',{rev:bw.rev,pack:{seedworkPack:99}},'PUT')).status,400);});
});
