from pathlib import Path
from playwright.sync_api import sync_playwright
import argparse
import base64
import io
import json
import os
import urllib.request
import urllib.error
import numpy as np
from PIL import Image

parser = argparse.ArgumentParser()
parser.add_argument('--url', default='http://127.0.0.1:4173')
parser.add_argument('--out', default='native-browser-report')
parser.add_argument('--refs', required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
refs = Path(args.refs).resolve()
checks, pairs, errors = [], [], []


def record(name, ok, detail=None):
    checks.append({'name': name, 'passed': bool(ok), 'detail': detail})
    print(('PASS ' if ok else 'FAIL ') + name, flush=True)
    if not ok:
        raise AssertionError(str(detail))


def compare(name, a, b):
    def pixels(data):
        return np.asarray(Image.open(io.BytesIO(base64.b64decode(data.split(',')[1])))).astype(np.int16)
    aa, bb = pixels(a), pixels(b)
    d = np.abs(aa - bb)
    info = {'name': name, 'pixels': int(aa.shape[0] * aa.shape[1]), 'changedPixels': int(np.any(d, axis=2).sum()), 'maxChannelDifference': int(d.max())}
    pairs.append(info)
    for suffix, data in [('reference', a), ('optimized', b)]:
        (out / f'{name}-{suffix}.png').write_bytes(base64.b64decode(data.split(',')[1]))
    checks.append({'name': name + ' exact pixel equality', 'passed': info['changedPixels'] == 0, 'detail': info})
    print(('PASS ' if info['changedPixels'] == 0 else 'FAIL ') + name + ' raster comparison ' + str(info), flush=True)


try:
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=os.environ.get('CHROMIUM', '/usr/bin/chromium'), headless=True, args=['--no-sandbox', '--disable-dev-shm-usage', '--enable-unsafe-swiftshader', '--use-angle=swiftshader'])
        p = browser.new_page(viewport={'width': 1600, 'height': 1000}, device_scale_factor=1)
        p.set_default_timeout(120000)
        p.on('pageerror', lambda e: errors.append(str(e)))
        p.on('console', lambda m: print('CONSOLE', m.type, m.text[:350], flush=True) if m.type == 'error' else None)

        def route(r):
            path = r.request.url.split('http://seedwork.test', 1)[-1]
            if r.request.method == 'OPTIONS':
                r.fulfill(status=204, headers={'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*'})
                return
            if path.startswith('/test-reference/'):
                name = path.split('/')[-1].removesuffix('.glb')
                r.fulfill(status=200, body=(refs / name / 'reference.glb').read_bytes(), headers={'Content-Type': 'model/gltf-binary', 'Access-Control-Allow-Origin': '*'})
                return
            req = urllib.request.Request(args.url + path, data=r.request.post_data_buffer, method=r.request.method)
            for key in ('content-type', 'authorization'):
                if key in r.request.headers:
                    req.add_header(key, r.request.headers[key])
            try:
                with urllib.request.urlopen(req, timeout=90) as res:
                    data, status, typ = res.read(), res.status, res.headers['Content-Type']
            except urllib.error.HTTPError as e:
                data, status, typ = e.read(), e.code, 'application/json'
            r.fulfill(status=status, body=data, headers={'Content-Type': typ, 'Access-Control-Allow-Origin': '*'})

        p.route('http://seedwork.test/**', route)
        p.evaluate('''() => { window.EventSource = class { constructor() {} close() {} }; Object.defineProperty(crypto, 'randomUUID', {value: () => {const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const s=[...b].map(v=>v.toString(16).padStart(2,"0")).join("");return `${s.slice(0,8)}-${s.slice(8,12)}-${s.slice(12,16)}-${s.slice(16,20)}-${s.slice(20)}`;}}); }''')
        p.set_content((root / 'public/index.html').read_text().replace('<head>', '<head><base href="http://seedwork.test/">'), wait_until='load')
        p.wait_for_function('window.seedwork?.ready === true')
        p.evaluate('seedwork.engine.freeze = true')
        p.locator('#open-modeler').click()
        p.wait_for_function('seedwork.workshop.result?.hash && seedwork.workshop.model')
        record('Native workshop opens and loads an audited starter without a build', p.evaluate('seedwork.workshop.result.report.exact.passed'))
        record('Seven recipes are offered in the native UI', p.locator('#wk-template option').count() == 7)
        record('PBR preview reuses the world WebGL renderer', p.evaluate('seedwork.workshop.e.renderer === seedwork.engine.renderer'))
        models = {}
        for i, name in enumerate(['drum', 'crate', 'arch', 'bench', 'pallet', 'pier', 'part']):
            p.evaluate('async name => await seedwork.workshop.template(name)', name)
            p.evaluate('seedwork.workshop.draw()')
            record(name + ' full source parts and meter dimensions loaded', p.evaluate('seedwork.workshop.model.children.length > 0 && seedwork.workshop.measures.height > 0 && seedwork.workshop.draft.parts.length > 0'))
            if name in ['drum', 'crate', 'arch', 'bench']:
                p.screenshot(path=str(out / f'workshop-{name}.png'))
            packed = p.evaluate('seedwork.workshop.canvas.toDataURL("image/png")')
            raw = p.evaluate('async name => { const w=seedwork.workshop, bytes=await (await fetch(`/test-reference/${name}.glb`)).arrayBuffer(); await w.loadModel(bytes,w.result); w.draw(); return w.canvas.toDataURL("image/png"); }', name)
            compare('compact-' + name, raw, packed)
            p.locator('[data-look="clay"]').click()
            p.evaluate('seedwork.workshop.draw()')
            record(name + ' clay mode displays geometry without color maps', p.evaluate('seedwork.workshop.look === "clay" && [...seedwork.workshop.model.children].length > 0'))
            p.locator('[data-look="wire"]').click()
            record(name + ' wire view is available', p.evaluate('seedwork.workshop.look === "wire"'))
            p.locator('[data-look="pbr"]').click()
            key = p.locator('#wk-key').input_value()
            models[name] = key
            p.locator('#wk-publish').click()
            p.wait_for_function('key => !!seedwork.world.models?.[key] && !seedwork.workshop.open', arg=key)
            record(name + ' publication creates a native world type with its source recipe', p.evaluate('key => seedwork.world.models[key].recipe.schema === "seedwork.recipe/1"', key))
            p.evaluate('async v => { await seedwork.run("object_add", {type:v.key,x:(v.i%3-1)*4,z:8+Math.floor(v.i/3)*4}); }', {'key': key, 'i': i})
            if i < 6:
                p.locator('#open-modeler').click()
        p.locator('[data-tab="assets"]').click()
        p.locator('[data-cat="Models"]').click()
        record('Published models appear as rendered native asset thumbnails', p.locator('.asset-card img').count() == 7 and p.evaluate('[...document.querySelectorAll(".asset-card img")].every(i=>i.naturalWidth>0)'))
        record('Native instance colors do not tint the source artwork', p.evaluate('seedwork.engine.batches.filter(b=>b.userData.ids?.some(id=>seedwork.world.objects.find(o=>o.id===id)?.type.startsWith("m_"))).every(b=>!b.instanceColor || [...b.instanceColor.array].every(v=>v===1))'))
        p.evaluate('async () => await seedwork.workshop.show("m_machined_part")')
        n = p.evaluate('seedwork.workshop.draft.parts.length')
        p.locator('#wk-copy').click()
        record('Duplicate part preserves an independently editable component', p.evaluate('seedwork.workshop.draft.parts.length') == n + 1)
        p.locator('#wk-delete').click()
        record('Delete part restores the assembly component count', p.evaluate('seedwork.workshop.draft.parts.length') == n)
        p.locator('#wk-shape').select_option('torus')
        p.locator('#wk-add').click()
        record('Primitive creation adds an editable torus', p.evaluate('seedwork.workshop.draft.parts.at(-1).shape === "torus"'))
        p.locator('#wk-delete').click()
        record('Unsupported legacy detail controls are not advertised', p.locator('#wk-detail-add').count() == 0)
        p.get_by_text('Material & source maps', exact=True).click()
        p.locator('#wk-mat-add').click()
        record('New material is created and assigned to the selected part', p.evaluate('seedwork.workshop.draft.parts[0].mat === "wood_1"'))
        p.evaluate('async()=>await seedwork.workshop.edit("m_machined_part")')
        p.locator('details.wk-json').evaluate('(el)=>el.open=true') if p.locator('details.wk-json').count() else p.locator('#wk-json').evaluate('(el)=>el.closest("details").open=true')
        text = p.locator('#wk-json').input_value()
        p.locator('#wk-json').fill(text + ' ')
        p.locator('#wk-build').click()
        record('Unapplied JSON cannot trigger a stale build', p.evaluate('!seedwork.workshop.building && seedwork.workshop.sourceDirty') and 'Apply source edits' in p.locator('#wk-phase').inner_text())
        p.locator('#wk-json-apply').click()
        p.locator('#wk-json').evaluate('(el)=>el.closest("details").open=false')
        p.locator('[aria-label="size X"]').fill('0.45')
        p.locator('[aria-label="size X"]').press('Tab')
        record('Changing dimensions locks publication until rebuilt', p.locator('#wk-publish').is_disabled())
        before = p.evaluate('seedwork.world.objects.filter(o=>o.type==="m_machined_part")')
        p.locator('#wk-build').click()
        p.wait_for_function('seedwork.workshop.result?.hash && !seedwork.workshop.building')
        record('Edited recipe compiles with exact verification', p.evaluate('Math.abs(seedwork.workshop.result.width-.45)<1e-6 && seedwork.workshop.result.report.exact.passed'))
        p.locator('#wk-publish').click()
        p.wait_for_function('!seedwork.workshop.open')
        record('Republishing preserves existing object IDs and transforms', p.evaluate('seedwork.world.objects.filter(o=>o.type==="m_machined_part")') == before)
        record('Native dimensions are not normalized to a legacy slot', p.evaluate('Math.abs(seedwork.world.models.m_machined_part.width-.45)<1e-6'))
        p.evaluate('async()=>await seedwork.run("world_undo",{})')
        record('Undo restores the earlier model revision', p.evaluate('Math.abs(seedwork.world.models.m_machined_part.width-.30)<1e-6'))
        p.evaluate('async()=>await seedwork.run("world_redo",{})')
        record('Redo restores the rebuilt model revision', p.evaluate('Math.abs(seedwork.world.models.m_machined_part.width-.45)<1e-6'))
        p.evaluate('()=>{ const e=seedwork.engine;e.select(null);e.grid.visible=false;e.target.set(0,5,12);e.dist=26;e.yaw=.3;e.tilt=.35;e.render(); }')
        p.screenshot(path=str(out/'world-models.png'))
        a = p.evaluate('()=>{const e=seedwork.engine;e.render();return e.screenshot()}')
        b = p.evaluate('()=>{const e=seedwork.engine;window.keep=[];e.root.traverse(o=>{if(o.isMesh && o.geometry.index){keep.push([o,o.geometry]);o.geometry=o.geometry.toNonIndexed();}});e.shadowDirty();e.render();return e.screenshot();}')
        compare('indexed-world-batches', b, a)
        p.evaluate('()=>{for(const [o,g] of keep){o.geometry.dispose();o.geometry=g;}seedwork.engine.shadowDirty();seedwork.engine.render();}')
        info = p.evaluate('async()=>{const bytes=seedwork.glb(seedwork.engine.root),g=await new Promise((done,fail)=>new THREE.GLTFLoader().parse(bytes,"",done,fail));return {bytes:bytes.byteLength,ids:seedwork.world.objects.filter(o=>o.type.startsWith("m_")).every(o=>g.parser.json.nodes.some(n=>n.name===o.id)),tangent:g.parser.json.meshes.some(m=>m.primitives.some(p=>p.attributes.TANGENT!==undefined)),maps:g.parser.json.materials.filter(m=>m.normalTexture).length}}')
        record('World GLB export contains native objects, tangents and PBR maps', info['ids'] and info['tangent'] and info['maps'] > 10, info)
        p.locator('#open-modeler').click()
        count = p.evaluate('seedwork.world.objects.length')
        p.locator('#wk-canvas').focus()
        p.keyboard.press('Delete')
        record('Modeling shortcuts cannot delete world objects behind the dialog', p.evaluate('seedwork.world.objects.length') == count)
        p.keyboard.press('Escape')
        record('Escape closes the workshop and restores the world viewport', p.evaluate('!seedwork.workshop.open'))
        record('No uncaught JavaScript errors', not errors, errors)
        browser.close()
finally:
    (out/'results.json').write_text(json.dumps({'environment':'Chromium SwiftShader, DPR 1, HTTP fixture, SSE mocked; real renderer and local API', 'checks':checks,'pairs':pairs,'errors':errors,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)},indent=2))

if any(not c['passed'] for c in checks):
    raise SystemExit(1)
