import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { createInterface } from 'node:readline';
import { once } from 'node:events';
const sleep = n => new Promise(r => setTimeout(r, n));

test('real HTTP boundaries, project workflow and modern MCP requests', async t => {
  const dir = mkdtempSync(resolve(tmpdir(), 'seedwork-v04-api-')), port = 25300 + Math.floor(Math.random() * 800), url = `http://127.0.0.1:${port}`, env = { ...process.env, PORT: String(port), SEEDWORK_DIR: dir, SEEDWORK_ORIGINS: 'http://localhost:3000' };
  const server = spawn(process.execPath, ['server.mjs'], { cwd: resolve(import.meta.dirname, '..'), env, stdio: ['ignore', 'pipe', 'pipe'] });
  let error = ''; server.stderr.on('data', c => error += c);
  t.after(async () => { server.kill('SIGTERM'); await sleep(200); rmSync(dir, { recursive: true, force: true }); });
  let token;
  for (let i = 0; i < 100; i++) { try { token = (await (await fetch(url + '/api/session')).json()).token; if (token) break; } catch {} await sleep(50); }
  assert.ok(token, error);
  const req = async (path, data, headers = {}, method = data === undefined ? 'GET' : 'POST') => { const res = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, ...headers }, ...(data === undefined ? {} : { body: JSON.stringify(data) }) }); return { status: res.status, headers: res.headers, data: await res.json() }; };
  const call = (name, args = {}, extra = {}) => req('/api/tool', { name, args, ...extra });
  await t.test('all 42 closed tool schemas are exposed, with project/world scope', async () => {
    const out = await req('/api/tools?wire=1'); assert.equal(out.data.tools.length, 42);
    const world = out.data.tools.find(v => v.name === 'world_batch'); assert.ok(world.inputSchema.required.includes('_rev')); assert.ok(world.inputSchema.required.includes('_key'));
    assert.equal(out.data.tools.some(v => /approve/.test(v.name)), false);
  });
  await t.test('world mutations require explicit revision and stable request key', async () => {
    assert.equal((await call('terrain_set', { relief: 8 }, { key: crypto.randomUUID() })).status, 428);
    assert.equal((await call('terrain_set', { relief: 8 }, { rev: 0 })).status, 400);
    assert.equal((await req('/api/world')).data.rev, 0);
  });
  await t.test('batch retry is one committed revision and stale edits return scoped state', async () => {
    const extra = { key: crypto.randomUUID(), rev: 0 }, args = { ops: [{ name: 'terrain_set', args: { relief: 8 } }, { name: 'terrain_set', args: { water: -4 } }] };
    const a = await call('world_batch', args, extra), b = await call('world_batch', args, extra); assert.equal(a.status, 200); assert.equal(b.data.replayed, true); assert.equal(b.data.rev, 1);
    const stale = await call('terrain_set', { relief: 12 }, { rev: 0, key: crypto.randomUUID() }); assert.equal(stale.status, 409); assert.equal(stale.data.world.terrain.relief, 8);
    const conflict = await call('change_begin', { label: 'stale', rev: 999, key: crypto.randomUUID() }); assert.equal(conflict.status, 409); assert.equal(conflict.data.world, undefined);
  });
  await t.test('approved loopback origins still need an explicitly supplied authoring token', async () => {
    assert.equal((await req('/api/session', undefined, { Origin: 'http://localhost:3000' })).status, 403);
    const project = await req('/api/project', undefined, { Origin: 'http://localhost:3000' }); assert.equal(project.status, 200); assert.equal(project.headers.get('access-control-allow-origin'), 'http://localhost:3000');
    assert.equal((await req('/api/project', undefined, { Origin: 'https://untrusted.example' })).status, 403);
    assert.equal((await req('/api/project', undefined, { Origin: 'http://localhost:3000', Authorization: 'Bearer bad' })).status, 401);
  });
  await t.test('host-scoped tokens cannot mutate or inspect authoring state', async () => {
    const h = (await req('/api/host/open', { project: 'courtyard', name: 'Test host', three: '140', tests: ['route'], capabilities: ['query', 'test'] })).data;
    assert.equal((await req('/api/project', undefined, { Authorization: `Bearer ${h.token}` })).status, 401);
    assert.equal((await call('project_inspect')).data.result.hosts[0].token, undefined);
    const cmd = (await req('/api/host/next', { id: h.id }, { Authorization: `Bearer ${h.token}` })).data;
    assert.equal(cmd.method, 'sync'); assert.ok(cmd.args.meta.hash);
    assert.equal((await req('/api/host/done', { id: h.id, command: cmd.id, result: { meta: cmd.args.meta } }, { Authorization: `Bearer ${h.token}` })).data.accepted, true);
    await req('/api/host/close', { id: h.id }, { Authorization: `Bearer ${h.token}` });
  });
  await t.test('AI project operations stage real assets without publishing or touching the old world', async () => {
    const found = (await call('asset_search', { q: 'bench', limit: 2 })).data.result; assert.equal(found.total, 1); assert.equal(found.assets[0].ref, 'starter.bench');
    const c = (await call('change_begin', { rev: 0, key: crypto.randomUUID(), label: 'A bench' })).data.result;
    const edit = (await call('change_apply', { id: c.id, seq: 0, key: crypto.randomUUID(), ops: [{ op: 'asset_use', key: 'bench', ref: 'starter.bench' }, { op: 'item_add', id: 'seat', asset: 'bench', pos: [3, .035, 0] }] })).data.result;
    assert.equal(edit.diff.count, 1); assert.equal((await req('/api/project')).data.doc.items.length, 0); assert.equal((await req('/api/world')).data.rev, 1);
    assert.equal((await req('/api/project/approve', { id: c.id, seq: 1, rev: 0 })).status, 409);
    const check = (await call('change_check', { id: c.id })).data.result; assert.equal(check.valid, true); assert.ok(check.missing.includes('preview'));
    await call('change_discard', { id: c.id, seq: 1, key: crypto.randomUUID() });
  });
  await t.test('two servers cannot own the same data directory', async () => {
    const second = spawn(process.execPath, ['server.mjs'], { cwd: resolve(import.meta.dirname, '..'), env: { ...env, PORT: String(port + 1) }, stdio: ['ignore', 'ignore', 'pipe'] }); let log = ''; second.stderr.on('data', c => log += c);
    const [code] = await once(second, 'exit'); assert.notEqual(code, 0); assert.match(log, /already owned/);
  });
  await t.test('modern stateless MCP requests work without initialize and enforce world edit preconditions', async () => {
    const proc = spawn(process.execPath, ['mcp.mjs'], { cwd: resolve(import.meta.dirname, '..'), env, stdio: ['pipe', 'pipe', 'pipe'] });
    const lines = createInterface({ input: proc.stdout }), waiting = new Map(); let seq = 0;
    lines.on('line', line => { const msg = JSON.parse(line); waiting.get(msg.id)?.(msg); waiting.delete(msg.id); });
    const meta = { 'io.modelcontextprotocol/protocolVersion': '2026-07-28', 'io.modelcontextprotocol/clientCapabilities': {} };
    const rpc = (method, params = {}, m = meta) => new Promise((resolve, reject) => { const id = ++seq, timer = setTimeout(() => reject(Error('RPC timeout')), 5000); waiting.set(id, result => { clearTimeout(timer); resolve(result); }); proc.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params: { ...params, _meta: m } }) + '\n'); });
    try {
      const discovery = await rpc('server/discover'); assert.equal(discovery.result.resultType, 'complete'); assert.ok(discovery.result.supportedVersions.includes('2026-07-28'));
      const tools = await rpc('tools/list'); assert.equal(tools.result.tools.length, 42);
      const inspected = await rpc('tools/call', { name: 'project_inspect', arguments: {} }); assert.equal(inspected.result.isError, false); assert.equal(inspected.result.structuredContent.scope, 'project');
      const unsafe = await rpc('tools/call', { name: 'terrain_set', arguments: { relief: 10 } }); assert.equal(unsafe.result.isError, true);
      const invalid = await rpc('tools/list', {}, { 'io.modelcontextprotocol/protocolVersion': '2026-07-28' }); assert.equal(invalid.error.code, -32602);
      const unknown = await rpc('tools/list', {}, { ...meta, 'io.modelcontextprotocol/protocolVersion': '2099-01-01' }); assert.equal(unknown.error.code, -32022);
      const state = (await req('/api/world')).data;
      const edit = await rpc('tools/call', { name: 'terrain_set', arguments: { relief: 10, _rev: state.rev, _key: crypto.randomUUID() } }); assert.equal(edit.result.isError, false); assert.equal((await req('/api/world')).data.rev, state.rev + 1);
    } finally { proc.stdin.end(); await once(proc, 'exit'); lines.close(); }
  });
});
