import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { checkScene } from '../sdk/core/scene.mjs';

const root = resolve(import.meta.dirname, '..');
const sample = join(root, 'examples/courtyard.scene.json');
const run = args => spawnSync(process.execPath, ['scripts/export-host.mjs', ...args], { cwd: root, encoding: 'utf8', timeout: 20000 });
const files = dir => readdirSync(dir, { withFileTypes: true }).flatMap(e => e.isDirectory() ? files(join(dir, e.name)) : [join(dir, e.name)]);

test('runtime-only export preserves approved GLB bytes and omits development resources', () => {
  const dir = mkdtempSync(join(tmpdir(), 'seedwork-export-'));
  try {
    const out = join(dir, 'game');
    const result = run(['--scene', sample, '--out', out, '--data', join(dir, 'absent')]);
    assert.equal(result.status, 0, result.stderr);
    const doc = JSON.parse(readFileSync(join(out, 'scene.json'))), build = JSON.parse(readFileSync(join(out, 'build.json')));
    checkScene(doc); assert.equal(doc.items.length, 16); assert.equal(build.assets.length, 6);
    assert.ok(Object.values(doc.assets).every(a => a.source === undefined));
    for (const asset of build.assets) {
      const bytes = readFileSync(join(out, 'assets', `${asset.hash}.glb`));
      assert.equal(createHash('sha256').update(bytes).digest('hex'), asset.hash);
      assert.deepEqual(bytes, readFileSync(join(root, 'modeler/starter', `${asset.hash}.glb`)));
      assert.equal(bytes.length, asset.bytes);
    }
    const paths = files(out).map(f => f.slice(out.length+1));
    for (const denied of ['dev.mjs', 'observe.mjs', 'token', 'server.mjs', 'mcp.mjs', 'project.json', '.py']) assert.ok(paths.every(p => !p.includes(denied)), denied);
    assert.ok(paths.includes('serve.mjs')); assert.ok(paths.includes('sdk/three.mjs'));
    assert.doesNotMatch(readFileSync(join(out, 'app.mjs'), 'utf8'), /\/api\//);
    assert.equal(JSON.parse(result.stdout).objects, 16);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('export refuses existing directories and never overwrites their contents', () => {
  const dir = mkdtempSync(join(tmpdir(), 'seedwork-export-'));
  try {
    const sentinel = join(dir, 'keep.txt'); writeFileSync(sentinel, 'keep');
    const result = run(['--scene', sample, '--out', dir]);
    assert.notEqual(result.status, 0); assert.match(result.stderr, /must not exist/); assert.equal(readFileSync(sentinel,'utf8'), 'keep');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('tampered content-addressed asset is rejected instead of falling back or converting it', () => {
  const dir = mkdtempSync(join(tmpdir(), 'seedwork-export-'));
  try {
    const hash = Object.values(JSON.parse(readFileSync(sample)).assets)[0].hash;
    mkdirSync(join(dir, 'assets')); writeFileSync(join(dir, 'assets', `${hash}.glb`), 'tampered');
    const out = join(dir, 'game'), result = run(['--scene', sample, '--data', dir, '--out', out]);
    assert.notEqual(result.status, 0); assert.match(result.stderr, /integrity failure/); assert.equal(existsSync(out), false); assert.equal(existsSync(`${out}.tmp`), false);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('host game source has no Seedwork dependency and SDK runtime has no authoring import', () => {
  assert.doesNotMatch(readFileSync(join(root, 'public/host/game.mjs'), 'utf8'), /import |\/api\//);
  for (const name of ['index.mjs','three.mjs','glb.mjs']) assert.doesNotMatch(readFileSync(join(root, 'sdk', name), 'utf8'), /from ['"].*(?:dev|observe|services|modeler)/);
});
