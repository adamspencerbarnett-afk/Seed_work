import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync, mkdirSync, rmSync, existsSync, cpSync, symlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve, dirname } from 'node:path';
import { inflateRawSync } from 'node:zlib';
import { spawnSync, spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { once } from 'node:events';
import { setTimeout as delay } from 'node:timers/promises';
import { releaseFiles } from '../scripts/files.mjs';
import { zip } from '../scripts/zip.mjs';
import { prepare } from '../scripts/release.mjs';
import { verify } from '../scripts/verify.mjs';
import { writePlan } from '../scripts/plan.mjs';
import { crc32 } from '../modeler/png.mjs';

const root = resolve(import.meta.dirname, '..');
const temp = () => mkdtempSync(resolve(tmpdir(), 'seedwork-release-'));
const read = p => JSON.parse(readFileSync(p));
const plan = () => read(resolve(root, 'examples/plans/autumn-settlement.json'));
const clean = p => rmSync(p, { recursive: true, force: true });
function copySource(out) {
  for (const name of releaseFiles(root)) { const target = resolve(out, name); mkdirSync(dirname(target), { recursive: true }); cpSync(resolve(root, name), target); }
}
function unzip(bytes) {
  const files = new Map(); let at = 0;
  while (bytes.readUInt32LE(at) === 0x04034b50) {
    const len = bytes.readUInt32LE(at + 18), raw = bytes.readUInt32LE(at + 22), n = bytes.readUInt16LE(at + 26), e = bytes.readUInt16LE(at + 28), start = at + 30 + n + e;
    const name = bytes.subarray(at + 30, at + 30 + n).toString(), data = inflateRawSync(bytes.subarray(start, start + len));
    assert.equal(data.length, raw); assert.equal(crc32(data), bytes.readUInt32LE(at + 14)); files.set(name, data); at = start + len;
  }
  assert.equal(bytes.readUInt32LE(at), 0x02014b50); assert.equal(bytes.readUInt32LE(bytes.length - 22), 0x06054b50); return files;
}

test('release excludes local state, credentials, environments and caches', () => {
  const dir = temp(); try {
    for (const name of ['.seedwork/token', '.env', '.env.local', 'private.pem', '.cache/foo', 'node_modules/x', 'reports/log.json', 'project/private.json', 'work.log', 'README.md', '.github/workflows/check.yml']) {
      const file = resolve(dir, name); mkdirSync(dirname(file), { recursive: true }); writeFileSync(file, 'x');
    }
    assert.deepEqual(releaseFiles(dir), ['.github/workflows/check.yml', 'README.md']);
  } finally { clean(dir); }
});

test('release traversal rejects source symlinks', { skip: process.platform === 'win32' }, () => {
  const dir = temp(); try { writeFileSync(resolve(dir, 'file'), 'x'); symlinkSync(resolve(dir, 'file'), resolve(dir, 'link')); assert.throws(() => releaseFiles(dir), /Symlinks/); } finally { clean(dir); }
});

test('ZIP preserves all bytes and produces deterministic ordered output', () => {
  const dir = temp(); try {
    writeFileSync(resolve(dir, 'a.txt'), 'hello\n'); writeFileSync(resolve(dir, 'b.bin'), Buffer.from([0, 1, 255, 40]));
    const a = zip(dir, ['b.bin', 'a.txt']), b = zip(dir, ['a.txt', 'b.bin']); assert.deepEqual(a, b);
    const files = unzip(a); assert.deepEqual([...files.keys()], ['seedwork/a.txt', 'seedwork/b.bin']); assert.deepEqual(files.get('seedwork/b.bin'), readFileSync(resolve(dir, 'b.bin')));
    assert.throws(() => zip(dir, ['../a.txt']), /Unsafe/);
  } finally { clean(dir); }
});

test('release manifests verify sources and reject changed or unlisted code', () => {
  const dir = temp(); try {
    copySource(dir); const report = prepare(dir); assert.equal(report.tools, 42); assert.equal(report.starters.length, 7); assert.ok(verify(dir).passed);
    writeFileSync(resolve(dir, 'unexpected.mjs'), 'export const x=1;'); assert.throws(() => verify(dir), /Unlisted/); rmSync(resolve(dir, 'unexpected.mjs'));
    writeFileSync(resolve(dir, 'seedwork.mjs'), 'changed'); assert.throws(() => verify(dir), /Changed file/);
  } finally { clean(dir); }
});

test('CLI exposes machine-readable doctor, context, tools and plan schema offline', () => {
  for (const cmd of ['doctor', 'context', 'tools', 'schema']) {
    const run = spawnSync(process.execPath, ['seedwork.mjs', cmd], { cwd: root, encoding: 'utf8', env: { ...process.env, PYTHON: '/no-python' } });
    assert.equal(run.status, 0, run.stderr); const out = JSON.parse(run.stdout); assert.ok(out);
    if (cmd === 'tools') assert.equal(out.tools.length, 42);
    if (cmd === 'doctor') assert.equal(out.compiler.network, false);
  }
});

test('CLI rejects unknown commands and invalid plan options', () => {
  for (const args of [['unknown'], ['new', '--out'], ['new', '--plan', 'none', '--out', 'x', '--secret', 'y']]) {
    const run = spawnSync(process.execPath, ['seedwork.mjs', ...args], { cwd: root, encoding: 'utf8' }); assert.notEqual(run.status, 0); assert.equal(typeof JSON.parse(run.stdout).error, 'string');
  }
});

test('new project is self-contained, keeps original source, and carries every planned asset', () => {
  const dir = temp(); try {
    const out = resolve(dir, 'game'), result = writePlan(plan(), out, { standalone: true }); assert.ok(result.standalone);
    for (const name of ['server.mjs', 'public/vendor/three-r140.min.js', 'notices/seedwork-prior-MIT.txt', 'README.md', 'START_HERE_CHATGPT.md', 'project/start.seedpack.json']) assert.ok(existsSync(resolve(out, name)), name);
    const pack = read(resolve(out, 'project/start.seedpack.json')); assert.equal(pack.world.name, plan().world.name); assert.equal(Object.keys(pack.assets).length, 2);
    assert.equal(existsSync(resolve(out, '.seedwork')), false); assert.equal(existsSync(resolve(out, '.cache')), false); assert.equal(existsSync(resolve(out, 'modeler/kit')), false);
    assert.deepEqual(readFileSync(resolve(out, 'server.mjs')), readFileSync(resolve(root, 'server.mjs')));
    assert.throws(() => writePlan(plan(), out, { standalone: true }), /exists/);
  } finally { clean(dir); }
});

async function port() {
  const s = createServer(); s.listen(0, '127.0.0.1'); await once(s, 'listening'); const p = s.address().port; await new Promise(done => s.close(done)); return p;
}
async function launch(dir, p) {
  const child = spawn(process.execPath, ['server.mjs'], { cwd: dir, env: { ...process.env, PORT: String(p), SEEDWORK_DIR: resolve(dir, '.seedwork'), PYTHON: '/missing' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; child.stdout.on('data', b => log += b); child.stderr.on('data', b => log += b);
  for (let i = 0; i < 160; i++) {
    if (child.exitCode !== null) throw new Error(log);
    try { const r = await fetch(`http://127.0.0.1:${p}/api/world`); if (r.ok) return child; } catch {}
    await delay(50);
  }
  child.kill(); throw new Error(`Server did not start: ${log}`);
}
async function stop(child) { if (!child || child.exitCode !== null) return; const done = once(child, 'exit'); child.kill('SIGTERM'); await done; }

test('first launch imports the generated bundle and restart preserves an edited world', async () => {
  const dir = temp(), p = await port(); let child;
  try {
    const out = resolve(dir, 'game'); writePlan(plan(), out, { standalone: true }); child = await launch(out, p);
    const base = `http://127.0.0.1:${p}`, state = await (await fetch(`${base}/api/world`)).json(); assert.equal(state.world.name, plan().world.name);
    const session = await (await fetch(`${base}/api/session`)).json();
    const change = await fetch(`${base}/api/tool`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.token}` }, body: JSON.stringify({ name: 'environment_preset', args: { name: 'rain' }, rev: state.rev, key: 'restart-test' }) });
    assert.equal(change.status, 200, await change.text());
    const before = await (await fetch(`${base}/api/world`)).json(); await stop(child); child = await launch(out, p);
    const after = await (await fetch(`${base}/api/world`)).json(); assert.deepEqual(after.world, before.world); assert.equal(after.rev, before.rev);
  } finally { await stop(child); clean(dir); }
});
