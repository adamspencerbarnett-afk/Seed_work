import test from 'node:test';
import assert from 'node:assert/strict';
import '../public/vendor/three-r140.min.js';
import { Runtime } from '../sdk/three.mjs';
import { createGlbLoader, disposeTree, sha256 } from '../sdk/glb.mjs';
import { Observer } from '../sdk/observe.mjs';
import { DevLink } from '../sdk/dev.mjs';
import { emptyScene, makeItem, applyOps, checkScene, queryScene, sceneDiff } from '../sdk/core/scene.mjs';
import { quat, point, snapPose, bounds, atPath } from '../sdk/core/math.mjs';
import { fixture } from './fixture.mjs';
import { createHash } from 'node:crypto';
const T = globalThis.THREE;
const asset = (hash = 'a'.repeat(64)) => ({ hash, name: 'Box', size: [1, 1, 1], boxes: [[[-.5, 0, -.5], [.5, 1, .5]]], tags: ['test'], sockets: { origin: { pos: [0, 0, 0], rot: [0, 0, 0] }, top: { pos: [0, 1, 0], rot: [0, 0, 0] } } });
const doc = (count = 1) => ({ ...emptyScene(), assets: { box: asset() }, items: Array.from({ length: count }, (_, i) => makeItem({ id: `box_${i}`, asset: 'box', pos: [i * 2, 0, 0] })) });
const root = () => { const g = new T.Group(); g.add(new T.Mesh(new T.BoxGeometry(), new T.MeshStandardMaterial())); return g; };
const near = (a, b, eps = 1e-8) => assert.ok(a.every((v, i) => Math.abs(v - b[i]) < eps), `${a} != ${b}`);
const defer = () => { let resolve, reject; const promise = new Promise((a, b) => { resolve = a; reject = b; }); return { resolve, reject, promise }; };

test('socket transforms match Three.js matrices over 1000 varied poses', () => {
  for (let i = 0; i < 1000; i++) {
    const o = makeItem({ id: 'x', asset: 'box', pos: [Math.sin(i) * 8, i / 100, Math.cos(i)], rot: [i * 1.317, i * 7.33, i * -2.1], scale: .2 + i / 1000 });
    const p = [.13, .77, -.52], matrix = new T.Matrix4().compose(new T.Vector3(...o.pos), new T.Quaternion(...quat(o.rot)), new T.Vector3().setScalar(o.scale));
    near(point(o, p), new T.Vector3(...p).applyMatrix4(matrix).toArray());
    const b = bounds(o, asset()), expected = new T.Box3(new T.Vector3(-.5, 0, -.5), new T.Vector3(.5, 1, .5)).applyMatrix4(matrix);
    near(b[0], expected.min.toArray()); near(b[1], expected.max.toArray());
    const source = { pos: [.2, .4, -.1], rot: [33, -18, 54] }, anchor = { pos: [-.1, 1.4, .5], rot: [-7, 9, 19] }, target = { ...o, pos: [9, 4, 3], rot: [i % 170, i % 117, i % 93], scale: 1.4 };
    const pose = snapPose(o, source, target, anchor), placed = { ...o, ...pose };
    near(point(placed, source.pos), point(target, anchor.pos), 1e-5);
    const q1 = new T.Quaternion(...quat(placed.rot)).multiply(new T.Quaternion(...quat(source.rot))), q2 = new T.Quaternion(...quat(target.rot)).multiply(new T.Quaternion(...quat(anchor.rot)));
    assert.ok(1 - Math.abs(q1.dot(q2)) < 1e-7);
  }
});
test('path assembly is distance-spaced, deterministic, and preserves requested count', () => {
  near(atPath([[0, 0, 0], [0, 0, 2], [6, 0, 2]], .5).pos, [2, 0, 2]);
  const ops = [{ op: 'asset_use', key: 'box', ref: 'test.box' }, { op: 'items_path', asset: 'box', prefix: 'row', path: [[0, 0, 0], [0, 0, 8]], count: 5 }];
  const run = () => applyOps(emptyScene(), ops, { resolveAsset: () => asset() });
  assert.deepEqual(run(), run()); assert.deepEqual(run().doc.items.map(v => v.pos[2]), [0, 2, 4, 6, 8]);
  assert.throws(() => atPath([[0, 0, 0], [0, 0, 0]], .2));
});
test('scene operations are atomic, closed, and preserve source documents', () => {
  const d = doc(), before = structuredClone(d);
  assert.throws(() => applyOps(d, [{ op: 'item_set', id: 'box_0', patch: { scale: 2 } }, { op: 'item_remove', id: 'missing' }]));
  assert.deepEqual(d, before);
  assert.throws(() => applyOps(d, [{ op: 'item_set', id: 'box_0', patch: { code: 'anything' } }]));
  assert.throws(() => checkScene({ ...d, items: [d.items[0], d.items[0]] }), /already exists/);
  assert.throws(() => checkScene(JSON.parse('{"__proto__":{}}')));
});
test('locked assets, edit bounds and binding declarations are enforced', () => {
  const d = doc(), opts = { policy: { locked: ['box_0'] } };
  assert.throws(() => applyOps(d, [{ op: 'item_set', id: 'box_0', patch: { name: 'Changed' } }], opts), /locked/);
  assert.throws(() => applyOps(d, [{ op: 'asset_socket', asset: 'box', name: 'top', pos: [0, 2, 0], rot: [0, 0, 0] }], opts), /locked/);
  assert.throws(() => applyOps(d, [{ op: 'item_set', id: 'box_0', patch: { pos: [9, 0, 0] } }], { policy: { bounds: [[-2, -2, -2], [2, 2, 2]] } }), /outside/);
  assert.throws(() => applyOps(d, [{ op: 'bind_set', id: 'box_0', slot: 'hinge', target: 'missing' }]), /not declared/);
});
test('asset revisions affect existing IDs and metadata queries paginate after filtering', () => {
  const a = doc(5), b = structuredClone(a); b.assets.box.hash = 'b'.repeat(64);
  assert.equal(sceneDiff(a, b).affected.length, 5);
  const q = queryScene(a, { ids: ['box_4', 'box_2'], limit: 1 });
  assert.equal(q.total, 2); assert.equal(q.items[0].id, 'box_2'); assert.equal(q.next, 1);
});
test('runtime uses only an injected scene subtree, without renderer, controls or RAF', async () => {
  const scene = new T.Scene(), external = new T.Group(); scene.add(external);
  const r = new Runtime({ THREE: T, parent: scene, load: async () => ({ root: root() }) });
  assert.equal(scene.children.length, 2); await r.setScene(doc(3)); assert.equal(external.parent, scene);
  assert.equal(r.get('box_0').matrixAutoUpdate, false); await r.dispose(); assert.deepEqual(scene.children, [external]);
});
test('repeated placements share source geometry and material with one asset load', async () => {
  let loads = 0, frees = 0;
  const source = root(), r = new Runtime({ THREE: T, parent: new T.Scene(), load: async () => { loads++; return { root: source, dispose: () => frees++ }; } });
  await r.setScene(doc(100)); assert.equal(loads, 1);
  const a = r.get('box_0').children[0].children[0], b = r.get('box_99').children[0].children[0];
  assert.equal(a.geometry, b.geometry); assert.equal(a.material, b.material); assert.notEqual(a, b);
  await r.dispose(); await r.dispose(); assert.equal(frees, 1);
});
test('unchanged scene and transform-only updates do not reload or replace nodes', async () => {
  const r = new Runtime({ THREE: T, parent: new T.Scene(), load: async () => ({ root: root() }) });
  const d = doc(3); await r.setScene(d); const group = r.get('box_1'), child = group.children[0];
  const unchanged = await r.setScene(d); assert.equal(unchanged.counts.transforms, 0); assert.equal(unchanged.counts.created, 0);
  d.items[1].pos = [5, 0, 0]; const moved = await r.setScene(d);
  assert.equal(moved.counts.transforms, 1); assert.equal(r.get('box_1'), group); assert.equal(group.children[0], child); assert.equal(r.inspect().assetLoads, 1);
  await r.dispose();
});
test('asset replacement preserves instance wrappers and frees superseded source', async () => {
  const freed = [], r = new Runtime({ THREE: T, parent: new T.Scene(), load: async a => ({ root: root(), dispose: () => freed.push(a.hash) }) });
  const d = doc(); await r.setScene(d); const group = r.get('box_0'), child = group.children[0]; d.assets.box.hash = 'b'.repeat(64); await r.setScene(d);
  assert.equal(r.get('box_0'), group); assert.notEqual(group.children[0], child); assert.deepEqual(freed, ['a'.repeat(64)]); await r.dispose(); assert.equal(freed.length, 2);
});
test('partial asset load failure leaves the prior rendered scene and metadata intact', async () => {
  let frees = 0; const r = new Runtime({ THREE: T, parent: new T.Scene(), load: async a => { if (a.hash[0] === 'b') throw Error('decode failed'); return { root: root(), dispose: () => frees++ }; } });
  await r.setScene(doc(), { rev: 1 }); const group = r.get('box_0'); const d = doc(2); d.assets.other = asset('b'.repeat(64)); d.items[1].asset = 'other';
  await assert.rejects(r.setScene(d, { rev: 2 }), /decode/); assert.equal(r.get('box_0'), group); assert.equal(r.inspect().objects, 1); assert.deepEqual(r.meta, { rev: 1 }); assert.equal(frees, 0);
  await r.dispose(); assert.equal(frees, 1);
});
test('overlapping asynchronous loads commit only the newest scene', async () => {
  const wait = defer(), freed = [], r = new Runtime({ THREE: T, parent: new T.Scene(), load: async a => { if (a.hash[0] === 'a') await wait.promise; return { root: root(), dispose: () => freed.push(a.hash) }; } });
  const first = r.setScene(doc(), { rev: 1 }); const a = assert.rejects(first, e => e.code === 'SUPERSEDED');
  const d = doc(); d.assets.box.hash = 'b'.repeat(64); await r.setScene(d, { rev: 2 }); wait.resolve(); await a;
  assert.equal(r.meta.rev, 2); assert.deepEqual(freed, ['a'.repeat(64)]); await r.dispose();
});
test('detach aborts cooperative pending loads and frees successful pending resources', async () => {
  const r = new Runtime({ THREE: T, parent: new T.Scene(), load: (a, { signal }) => new Promise((_, reject) => { signal.addEventListener('abort', () => reject(Error('cancelled')), { once: true }); if (signal.aborted) reject(Error('cancelled')); }) });
  const load = r.setScene(doc()); const fails = assert.rejects(load, e => e.code === 'SUPERSEDED'); await r.dispose(); await fails;
  assert.equal(r.root.parent, null); assert.equal(r.inspect().cachedAssets, 0);
});
test('borrowed resources are not disposed and subscribers cannot invalidate committed state', async () => {
  const source = root(); let frees = 0; source.children[0].geometry.addEventListener('dispose', () => frees++);
  const r = new Runtime({ THREE: T, parent: new T.Scene(), load: async () => ({ root: source }) }); r.subscribe(() => { throw Error('host callback failed'); });
  const result = await r.setScene(doc()); assert.equal(result.warnings.length, 1); assert.equal(r.inspect().objects, 1); await r.dispose(); assert.equal(frees, 0);
});
test('static runtime rejects rigged meshes without attaching partial content', async () => {
  let freed = 0; const g = root(); g.children[0].isSkinnedMesh = true;
  const r = new Runtime({ THREE: T, parent: new T.Scene(), load: async () => ({ root: g, dispose: () => freed++ }) });
  await assert.rejects(r.setScene(doc()), e => e.code === 'UNSUPPORTED'); assert.equal(r.inspect().objects, 0); assert.equal(freed, 1); await r.dispose();
});
test('GLB loader verifies SHA-256 before decode and preserves buffer bytes', async () => {
  const bytes = fixture(), hash = createHash('sha256').update(bytes).digest('hex'); let parsed = 0;
  class Loader { parse(data, path, done) { parsed++; assert.deepEqual(Buffer.from(data), bytes); done({ scene: root() }); } }
  const load = createGlbLoader({ Loader, fetch: async () => new Response(bytes) });
  const out = await load(asset(hash)); assert.equal(parsed, 1); out.dispose();
  await assert.rejects(load(asset()), e => e.code === 'HASH_MISMATCH'); assert.equal(parsed, 1);
  assert.equal(await sha256(new TextEncoder().encode('abc')), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
});
test('GLB loader rejects external URIs and optional unsupported extensions before decode', async () => {
  for (const edit of [d => d.images = [{ uri: 'https://external.example/x.png' }], d => d.extensionsUsed = ['UNSUPPORTED_extension']]) {
    const bytes = fixture(edit), hash = createHash('sha256').update(bytes).digest('hex'); let parsed = false;
    class Loader { parse() { parsed = true; } }
    const load = createGlbLoader({ Loader, fetch: async () => new Response(bytes) });
    await assert.rejects(load(asset(hash))); assert.equal(parsed, false);
  }
});
test('resource disposal deduplicates geometry, material, texture and bitmap handles', () => {
  const g = root(), node = g.children[0], tex = new T.Texture(); const count = { g: 0, m: 0, t: 0, b: 0 };
  tex.image = { close: () => count.b++ }; node.material.map = tex; node.material.normalMap = tex; g.add(node.clone());
  node.geometry.addEventListener('dispose', () => count.g++); node.material.addEventListener('dispose', () => count.m++); tex.addEventListener('dispose', () => count.t++);
  disposeTree(g); assert.deepEqual(count, { g: 1, m: 1, t: 1, b: 1 });
});
const observe = () => {
  const r = new Runtime({ THREE: T, parent: new T.Scene(), load: async () => ({ root: root() }) });
  const renderer = { domElement: { width: 800, height: 600, toDataURL: () => 'data:image/png;base64,YWJj' }, toneMappingExposure: 1, toneMapping: 4, outputEncoding: 3001, getPixelRatio: () => 1, info: { render: { calls: 4, triangles: 12 }, memory: { textures: 1, geometries: 1 }, programs: [] } };
  return { r, renderer, o: new Observer({ runtime: r, renderer, camera: new T.PerspectiveCamera(), tests: { good: () => ({ passed: true, checks: [{ name: 'ok', passed: true }] }) } }) };
};
test('observer captures only after a host frame and never resizes or renders', async () => {
  const { o, renderer, r } = observe(); const pending = o.capture(); assert.equal(o.pending.length, 1); o.afterFrame({ time: 100, cpuMs: 3 }); const out = await pending;
  assert.equal(out.image.width, 800); assert.equal(out.image.height, 600); assert.equal(renderer.domElement.width, 800); assert.equal(o.pending.length, 0); o.dispose(); await r.dispose();
});
test('observer profiling distinguishes timing samples from resource counts and missing GPU data', async () => {
  const { o, r } = observe(); o.afterFrame({ time: 100, cpuMs: 2 }); o.afterFrame({ time: 116, cpuMs: 3 });
  const p = o.profile(); assert.equal(p.frameIntervalMs.p50, 16); assert.equal(p.frameIntervalMs.samples, 1); assert.equal(p.cpuWorkMs.samples, 2); assert.equal(p.gpuMs, null); assert.equal(p.vramBytes, null); o.dispose(); await r.dispose();
});
test('capture cancellation cleans the pending request without disposing a borrowed observer', async () => {
  const { o, r } = observe(), abort = new AbortController(); const pending = o.capture({ signal: abort.signal }); abort.abort(); await assert.rejects(pending, e => e.code === 'CANCELLED'); assert.equal(o.pending.length, 0); assert.equal(o.closed, false); o.dispose(); await r.dispose();
});
test('host test evidence is invalidated by a scene change during execution', async () => {
  const { o, r } = observe(), wait = defer(); o.tests.slow = () => wait.promise;
  const pending = o.test('slow'); await r.setScene(doc(), { rev: 2 }); wait.resolve({ passed: true, checks: [] }); await assert.rejects(pending, e => e.code === 'STALE_EVIDENCE'); o.dispose(); await r.dispose();
});
test('dev connection invokes a supplied fetch without rebinding its receiver', async () => {
  const { o, r } = observe(); let opened = false;
  const get = async function(url) { assert.equal(this, undefined); if (url.endsWith('/open')) { opened = true; return Response.json({ id: 'h_one', token: 'secret' }); } if (url.endsWith('/close')) return Response.json({ closed: true }); return new Promise((_, reject) => setTimeout(() => reject(Error('offline')), 1)); };
  const link = new DevLink({ runtime: r, observer: o, project: 'test', token: 'author', fetch: get }); await link.open(); assert.equal(opened, true); await link.close(); o.dispose(); await r.dispose();
});

test('superseded unshared loads are cancelled immediately instead of wasting further work', async () => {
  let aborted = 0;
  const r = new Runtime({ THREE: T, parent: new T.Scene(), load: (a, { signal }) => a.hash[0] === 'a' ? new Promise((_, reject) => { const stop = () => { aborted++; reject(Error('cancelled')); }; signal.addEventListener('abort', stop, { once: true }); if (signal.aborted) stop(); }) : Promise.resolve({ root: root() }) });
  const pending = r.setScene(doc()), fail = assert.rejects(pending, e => e.code === 'SUPERSEDED');
  const next = doc(); next.assets.box.hash = 'b'.repeat(64); await r.setScene(next); await fail;
  assert.equal(aborted, 1); assert.equal(r.inspect().objects, 1); await r.dispose();
});


test('default loader snapshots owned resources and leaves later host environment textures alone', async () => {
  const bytes = fixture(), hash = createHash('sha256').update(bytes).digest('hex'), source = root();
  const owned = new T.Texture(), borrowed = new T.Texture(); let ownedFree = 0, borrowedFree = 0;
  owned.addEventListener('dispose', () => ownedFree++); borrowed.addEventListener('dispose', () => borrowedFree++);
  source.children[0].material.map = owned;
  class Loader { parse(data, path, done) { done({ scene: source }); } }
  const load = createGlbLoader({ Loader, fetch: async () => new Response(bytes) });
  const result = await load(asset(hash));
  source.children[0].material.map = borrowed; source.children[0].material.envMap = borrowed;
  result.dispose(); result.dispose(); assert.equal(ownedFree, 1); assert.equal(borrowedFree, 0);
});

test('owned resource cleanup attempts remaining resources even when one disposer throws', () => {
  const source = root(), node = source.children[0]; let freed = 0;
  node.geometry.dispose = () => { throw Error('broken custom geometry'); };
  node.material.addEventListener('dispose', () => freed++);
  assert.throws(() => disposeTree(source), AggregateError); assert.equal(freed, 1);
});


test('live query refreshes a transformed ancestor without traversing unrelated host siblings', async () => {
  const scene = new T.Scene(), outer = new T.Group(), parent = new T.Group(), sibling = new T.Group();
  scene.add(outer); outer.add(parent); scene.add(sibling);
  const r = new Runtime({ THREE: T, parent, load: async () => ({ root: root() }) });
  await r.setScene(doc()); scene.updateMatrixWorld(true);
  outer.position.set(7, 3, -2); outer.rotation.y = Math.PI/2;
  let touched = 0; sibling.updateMatrixWorld = () => touched++;
  const actual = r.query().items[0].matrixWorld;
  outer.updateMatrix(); parent.updateMatrix();
  const expected = new T.Matrix4().multiplyMatrices(outer.matrix, parent.matrix).multiply(r.root.matrix).multiply(r.get(doc().items[0].id).matrix);
  assert.deepEqual(actual, expected.toArray()); assert.equal(touched, 0);
  await r.dispose();
});
