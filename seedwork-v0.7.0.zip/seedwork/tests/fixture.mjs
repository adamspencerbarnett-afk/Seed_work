export function fixture(edit = () => {}) {
  const doc = {asset:{version:'2.0'},scene:0,scenes:[{nodes:[0]}],nodes:[{mesh:0}],meshes:[{primitives:[{attributes:{POSITION:0},indices:1}]}],buffers:[{byteLength:44}],bufferViews:[{buffer:0,byteOffset:0,byteLength:36},{buffer:0,byteOffset:36,byteLength:6}],accessors:[{bufferView:0,componentType:5126,count:3,type:'VEC3',min:[0,0,0],max:[1,1,0]},{bufferView:1,componentType:5123,count:3,type:'SCALAR'}]};
  edit(doc);
  const str=Buffer.from(JSON.stringify(doc)),len=Math.ceil(str.length/4)*4,bytes=Buffer.alloc(28+len+44);
  bytes.writeUInt32LE(0x46546c67,0);bytes.writeUInt32LE(2,4);bytes.writeUInt32LE(bytes.length,8);bytes.writeUInt32LE(len,12);bytes.writeUInt32LE(0x4e4f534a,16);bytes.fill(32,20,20+len);str.copy(bytes,20);bytes.writeUInt32LE(44,20+len);bytes.writeUInt32LE(0x004e4942,24+len);
  const pos=Buffer.from(new Float32Array([0,0,0,1,0,0,0,1,0]).buffer),ind=Buffer.from(new Uint16Array([0,1,2]).buffer);pos.copy(bytes,28+len);ind.copy(bytes,64+len);return bytes;
}
