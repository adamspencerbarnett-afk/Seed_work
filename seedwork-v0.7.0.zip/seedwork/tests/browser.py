from pathlib import Path
from playwright.sync_api import sync_playwright
import argparse
import base64
import json
import os
import subprocess
import time
import urllib.error
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument('--url', default='http://127.0.0.1:4173')
parser.add_argument('--fixture', action='store_true')
parser.add_argument('--out', default='reports')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
checks = []
errors = []
xvfb = None

def record(name, condition, detail=None):
    item = {'name': name, 'passed': bool(condition)}
    if detail is not None:
        item['detail'] = detail
    checks.append(item)
    print(('PASS ' if condition else 'FAIL ') + name, flush=True)
    if not condition:
        raise AssertionError(f'{name}: {detail}')

if args.fixture:
    xvfb = subprocess.Popen(['Xvfb', ':98', '-screen', '0', '1440x900x24', '-nolisten', 'tcp'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    os.environ['DISPLAY'] = ':98'
    time.sleep(0.6)

try:
    with sync_playwright() as pw:
        exe = os.environ.get('CHROMIUM')
        if not exe and Path('/usr/bin/chromium').exists():
            exe = '/usr/bin/chromium'
        flags = ['--disable-dev-shm-usage']
        if args.fixture:
            flags += ['--no-sandbox', '--enable-unsafe-swiftshader', '--use-angle=swiftshader']
        browser = pw.chromium.launch(executable_path=exe, headless=True, args=flags)
        page = browser.new_page(viewport={'width': 1440, 'height': 900}, device_scale_factor=1)
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('console', lambda m: print('CONSOLE', m.type, m.text[:400], flush=True) if m.type == 'error' else None)
        if args.fixture:
            def route(r):
                path = r.request.url.split('http://seedwork.test', 1)[-1]
                if r.request.method == 'OPTIONS':
                    r.fulfill(status=204, headers={'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*'})
                    return
                req = urllib.request.Request(args.url + path, data=r.request.post_data_buffer, method=r.request.method)
                for key in ('content-type', 'authorization'):
                    if key in r.request.headers:
                        req.add_header(key, r.request.headers[key])
                try:
                    with urllib.request.urlopen(req, timeout=20) as res:
                        data, status, typ = res.read(), res.status, res.headers['Content-Type']
                except urllib.error.HTTPError as e:
                    data, status, typ = e.read(), e.code, 'application/json'
                r.fulfill(status=status, body=data, headers={'Content-Type': typ, 'Access-Control-Allow-Origin': '*'})
            page.route('http://seedwork.test/**', route)
            page.evaluate('''() => { window.EventSource = class { constructor() {} close() {} }; Object.defineProperty(crypto, 'randomUUID', {value: () => {const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const s=[...b].map(v=>v.toString(16).padStart(2,"0")).join("");return `${s.slice(0,8)}-${s.slice(8,12)}-${s.slice(12,16)}-${s.slice(16,20)}-${s.slice(20)}`;}}); }''')
            html = (root / 'public/index.html').read_text().replace('<head>', '<head><base href="http://seedwork.test/">')
            page.set_content(html, wait_until='load')
        else:
            page.goto(args.url, wait_until='networkidle')
        page.wait_for_function('window.seedwork?.ready === true', timeout=90000)
        page.evaluate('seedwork.engine.freeze = true')
        page.evaluate('async () => { window.core = await import("/core/world.mjs"); }')
        initial = page.evaluate('seedwork.world')
        base = {'name': 'Verdant Reach', 'biome': 'forest', 'seed': 1847}

        def run(name, data=None):
            result = page.evaluate('async v => await seedwork.run(v.name, v.args)', {'name': name, 'args': data or {}})
            if result is None:
                raise AssertionError(page.locator('#tool-result').inner_text())
            return result

        def idle():
            page.wait_for_function('!document.body.classList.contains("busy")', timeout=30000)

        def click_mutation(selector):
            rev = page.evaluate('seedwork.rev')
            page.locator(selector).click()
            page.wait_for_function('v => seedwork.rev > v', arg=rev, timeout=30000)
            idle()

        def ground(x, z):
            point = page.evaluate('p => { const e = seedwork.engine, r = e.canvas.getBoundingClientRect(), v = new THREE.Vector3(p.x, core.height(seedwork.world,p.x,p.z),p.z).project(e.camera); return {x:r.left+(v.x+1)*r.width/2,y:r.top+(1-v.y)*r.height/2}; }', {'x': x, 'z': z})
            return point

        run('world_make', base)
        page.locator('#home').click()
        page.wait_for_timeout(900)
        record('Engine booted with vendored Three.js and editable objects', page.evaluate('THREE.REVISION === "140" && seedwork.world.objects.length === 194 && document.querySelector("#splash").hidden'))
        record('Instanced batches have stable picking IDs', page.evaluate('seedwork.engine.batches.every(b => b.isInstancedMesh && b.count === b.userData.ids.length)'))
        page.screenshot(path=str(out / 'editor.png'))
        page.evaluate('seedwork.engine.dirty = true')
        page.locator('.scene-item').first.click()
        record('Scene-tree selection opens the inspector', page.evaluate('seedwork.selected === seedwork.world.objects[0].id && !document.querySelector("#object-inspector").hidden'))
        obj = page.evaluate('seedwork.selected')
        old = page.evaluate('seedwork.world.objects[0].scale')
        page.locator('#obj-scale').fill('2')
        page.locator('#obj-scale').press('Tab')
        idle()
        record('Inspector scale commits to the shared world', page.evaluate('seedwork.world.objects[0].scale') == 2)
        click_mutation('#undo')
        record('Undo restores the previous value', page.evaluate('seedwork.world.objects[0].scale') == old)
        click_mutation('#redo')
        record('Redo restores the edited value', page.evaluate('seedwork.world.objects[0].scale') == 2)
        count = page.evaluate('seedwork.world.objects.length')
        click_mutation('#duplicate')
        record('Duplicate creates and selects a distinct object', page.evaluate('seedwork.world.objects.length') == count + 1 and page.evaluate('seedwork.selected') != obj)
        click_mutation('#delete')
        record('Delete removes the selected object', page.evaluate('seedwork.world.objects.length') == count)
        run('world_make', base)
        page.locator('[data-tab="assets"]').click()
        record('Asset library contains 11 rendered thumbnails', page.locator('.asset-card img').count() == 11 and page.evaluate('[...document.querySelectorAll(".asset-card img")].every(i => i.naturalWidth > 0)'))
        page.locator('[data-cat="Props"]').click()
        record('Asset-category filtering shows only props', page.locator('.asset-card').count() == 3)
        page.locator('[data-asset="crystal"]').click()
        point = ground(0, 11)
        before = page.evaluate('seedwork.world.objects.length')
        rev = page.evaluate('seedwork.rev')
        page.mouse.click(point['x'], point['y'])
        page.wait_for_function('v => seedwork.rev > v', arg=rev)
        record('A real viewport click places the selected prefab', page.evaluate('seedwork.world.objects.length') == before + 1 and page.evaluate('seedwork.world.objects.at(-1).type') == 'crystal')
        page.locator('[data-mode="move"]').click()
        point = ground(-4, 12)
        rev = page.evaluate('seedwork.rev')
        page.mouse.click(point['x'], point['y'])
        page.wait_for_function('v => seedwork.rev > v', arg=rev)
        record('Move tool maps a viewport click back to world coordinates', page.evaluate('Math.abs(seedwork.world.objects.at(-1).x+4) < 0.15 && Math.abs(seedwork.world.objects.at(-1).z-12)<0.15'))
        page.locator('[data-mode="sculpt"]').click()
        before = page.evaluate('({n:seedwork.world.terrain.stamps.length,h:core.height(seedwork.world,0,11)})')
        point = ground(0, 11)
        rev = page.evaluate('seedwork.rev')
        page.mouse.click(point['x'], point['y'])
        page.wait_for_function('v => seedwork.rev > v', arg=rev)
        record('Terrain brush changes the rendered height field', page.evaluate('seedwork.world.terrain.stamps.length') == before['n'] + 1 and page.evaluate('core.height(seedwork.world,0,11)') > before['h'] + 0.5)
        click_mutation('#undo')
        record('Terrain undo restores the original sampled height', abs(page.evaluate('core.height(seedwork.world,0,11)') - before['h']) < 1e-6)
        page.locator('#grid').click()
        record('Grid toggle updates the actual scene helper', page.evaluate('seedwork.engine.grid.visible'))
        page.locator('#grid').click()
        page.locator('[data-tab="tools"]').click()
        page.locator('#tool-name').select_option('object_scatter')
        page.locator('#tool-args').fill(json.dumps({'type': 'crystal', 'count': 4, 'radius': 30, 'seed': 23}))
        click_mutation('#run-tool')
        record('Tool console executes structured scatter arguments', json.loads(page.locator('#tool-result').inner_text())['placed'] == 4)
        page.locator('#tool-args').fill('{broken')
        page.locator('#run-tool').click()
        record('Malformed tool JSON is rejected without a page crash', page.locator('#toast').evaluate('e => !e.hidden && e.classList.contains("error")'))
        page.locator('[data-tab="world"]').click()
        page.locator('#prompt').fill('A sparse snowy valley at sunset without village, seed 732')
        click_mutation('#generate')
        record('Recipe UI applies only recognized generation settings', page.evaluate('seedwork.world.biome === "snow" && seedwork.world.sky.time === "sunset" && seedwork.world.terrain.shape === "valley" && seedwork.world.seed === 732 && !seedwork.world.objects.some(o=>o.type==="house")'))
        for biome in ('desert', 'fantasy', 'forest'):
            run('world_make', {'biome': biome, 'seed': 1847})
            record(f'{biome.title()} preset builds and renders', page.evaluate('seedwork.engine.root.children.length > 10 && seedwork.engine.terrain.geometry.attributes.position.count === 9409'))
        saved = page.evaluate('seedwork.world')
        saved['name'] = 'Portable Round Trip'
        page.locator('#file').set_input_files({'name': 'roundtrip.world.json', 'mimeType': 'application/json', 'buffer': json.dumps(saved).encode()})
        page.wait_for_function('seedwork.world.name === "Portable Round Trip"')
        record('Native JSON import preserves every world field', page.evaluate('seedwork.world') == saved)
        rev = page.evaluate('seedwork.rev')
        page.locator('#file').set_input_files({'name': 'invalid.json', 'mimeType': 'application/json', 'buffer': b'{"version":99}'})
        idle()
        record('Invalid world import leaves the current document intact', page.evaluate('seedwork.rev') == rev and page.evaluate('seedwork.world.name') == 'Portable Round Trip')
        run('world_make', base)
        page.locator('[data-tab="assets"]').click()
        page.locator('[data-cat="All"]').click()
        page.locator('[data-mode="select"]').click()
        page.wait_for_timeout(7500)
        page.locator('.scene-item').nth(1).click()
        page.locator('#home').click()
        page.evaluate('seedwork.engine.renderer.setPixelRatio(1)')
        page.wait_for_timeout(700)
        page.screenshot(path=str(out / 'assets.png'))
        page.evaluate('seedwork.engine.dirty = true')
        before = page.evaluate('JSON.stringify(seedwork.world)')
        page.locator('#play').click()
        record('Playable preview starts with a valid player spawn', page.evaluate('seedwork.engine.playing && document.body.classList.contains("is-playing") && core.canWalk(seedwork.world,seedwork.engine.player.x,seedwork.engine.player.z)'))
        start = page.evaluate('({...seedwork.engine.player})')
        page.locator('#viewport > canvas').focus()
        page.keyboard.down('w')
        page.wait_for_function('seedwork.engine.keys.has("KeyW")')
        page.evaluate('()=>{for(let i=0;i<10;i++)seedwork.engine.updatePlay(.03)}')
        page.keyboard.up('w')
        moved = page.evaluate('({...seedwork.engine.player})')
        record('WASD input moves the first-person player over ten fixed simulation steps', abs(start['x'] - moved['x']) + abs(start['z'] - moved['z']) > 0.1)
        page.keyboard.down('Space')
        page.evaluate('seedwork.engine.updatePlay(0.03)')
        record('Space triggers the preview hop', page.evaluate('seedwork.engine.jump > 0'))
        page.keyboard.up('Space')
        collect = page.evaluate('() => { const e=seedwork.engine,o=seedwork.world.objects.find(o=>o.type==="crystal"); e.player.x=o.x;e.player.z=o.z;e.jump=0;e.vel=0;e.updatePlay(0.01); return {n:e.collected.size,hidden:e.hidden.length}; }')
        record('Crystals are collected in preview-only state', collect['n'] >= 1 and collect['hidden'] > 0 and page.evaluate('JSON.stringify(seedwork.world)') == before)
        page.evaluate('seedwork.engine.renderer.setPixelRatio(1)')
        page.wait_for_timeout(500)
        page.screenshot(path=str(out / 'play.png'))
        page.keyboard.press('Escape')
        record('Exiting preview restores collected instances without document changes', page.evaluate('!seedwork.engine.playing && seedwork.engine.hidden.length === 0 && seedwork.engine.collected.size === 0 && seedwork.engine.batches.every(b=>{let m=new THREE.Matrix4();for(let i=0;i<b.count;i++){b.getMatrixAt(i,m);if(Math.abs(m.determinant())<1e-12)return false;}return true;})') and page.evaluate('JSON.stringify(seedwork.world)') == before)
        page.add_script_tag(content=(root / 'public/vendor/GLTFLoader-r140.js').read_text())
        glb = page.evaluate('async () => { const buf=seedwork.glb(seedwork.engine.root);window.testGlb=buf; return await new Promise((res,rej)=>new THREE.GLTFLoader().parse(buf,"",g=>{let meshes=0;g.scene.traverse(o=>{if(o.isMesh)meshes++;});res({bytes:buf.byteLength,meshes,version:g.parser.json.asset.version,accessors:g.parser.json.accessors.length});},rej)); }')
        record('Exported GLB is parsed by the Three.js GLTFLoader', glb['meshes'] > 194 and glb['version'] == '2.0', glb)
        data = page.evaluate('() => {const a=new Uint8Array(testGlb);let s="";for(let i=0;i<a.length;i+=32768)s+=String.fromCharCode(...a.subarray(i,i+32768));return btoa(s);}')
        (out / 'world.glb').write_bytes(base64.b64decode(data))
        (out / 'world.world.json').write_text(json.dumps(page.evaluate('seedwork.world'), indent=2))
        page.locator('[data-tab="world"]').click()
        page.locator('[data-mode="select"]').click()
        page.locator('#scene-search').fill('unmatched_object_123')
        record('Scene search reports empty results', page.locator('.scene-item').count() == 0 and 'No matching' in page.locator('#scene-list').inner_text())
        page.locator('#scene-search').fill('')
        page.locator('#validate').click()
        page.wait_for_function('document.querySelector("#dialog").open')
        record('World integrity tool reports its reachability limitation', 'Reachability and complex collision are not validated.' in page.locator('#dialog').inner_text())
        page.locator('#close-dialog').click()
        page.set_viewport_size({'width': 900, 'height': 720})
        page.wait_for_timeout(400)
        record('Compact desktop layout retains a usable canvas without page overflow', page.evaluate('seedwork.engine.canvas.clientWidth > 400 && document.documentElement.scrollWidth <= window.innerWidth'))
        page.set_viewport_size({'width': 1440, 'height': 900})
        page.locator('#home').click()
        page.wait_for_timeout(500)
        page.screenshot(path=str(out / 'final.png'))
        record('No uncaught browser JavaScript errors', len(errors) == 0, errors)
        browser.close()
finally:
    report = {'mode': 'about:blank / local HTTP fixture; SSE mocked' if args.fixture else 'direct browser navigation', 'checks': checks, 'passed': sum(c['passed'] for c in checks), 'failed': sum(not c['passed'] for c in checks), 'errors': errors}
    (out / 'browser.json').write_text(json.dumps(report, indent=2))
    if xvfb:
        xvfb.terminate()
