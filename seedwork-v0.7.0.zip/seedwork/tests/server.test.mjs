import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { once } from 'node:events';
import http from 'node:http';
import { createInterface } from 'node:readline';

const delay = n => new Promise(r => setTimeout(r, n));

test('local HTTP server and MCP bridge', async t => {
  const dir = await mkdtemp(resolve(tmpdir(), 'seedwork-'));
  const port = 19000 + Math.floor(Math.random() * 2000), url = `http://127.0.0.1:${port}`;
  const env = { ...process.env, PORT: String(port), SEEDWORK_DIR: dir };
  let server = spawn(process.execPath, ['server.mjs'], { cwd: resolve(import.meta.dirname, '..'), env, stdio: ['ignore', 'pipe', 'pipe'] });
  let stderr = ''; server.stderr.on('data', c => { stderr += c; });
  t.after(async () => { server.kill('SIGTERM'); await delay(100); await rm(dir, { recursive: true, force: true }); });
  let session;
  for (let i = 0; i < 80; i++) { try { const res = await fetch(`${url}/api/session`); session = await res.json(); break; } catch { await delay(50); } }
  assert.ok(session?.token, stderr);
  let token = session.token;
  const req = async (path, data, method = 'POST', headers = {}) => {
    if (data && method !== 'GET' && data.key === undefined) data = { ...data, key: crypto.randomUUID() };
    if (data && path === '/api/tool' && data.rev === undefined) data.rev = (await (await fetch(`${url}/api/world`)).json()).rev;
    const res = await fetch(`${url}${path}`, { method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, ...headers }, ...(data === undefined ? {} : { body: JSON.stringify(data) }) });
    return { status: res.status, data: await res.json(), headers: res.headers };
  };
  const call = (name, args = {}, rev) => req('/api/tool', { name, args, ...(rev === undefined ? {} : { rev }) });
  await t.test('serves local code without exposing backend files', async () => {
    assert.equal((await fetch(url)).status, 200); assert.equal((await fetch(`${url}/src/engine.js`)).status, 200);
    assert.equal((await fetch(`${url}/server.mjs`)).status, 404); assert.equal((await fetch(`${url}/.seedwork/token`)).status, 404);
    assert.equal((await fetch(url)).headers.get('x-content-type-options'), 'nosniff');
  });
  await t.test('rejects cross-origin requests', async () => assert.equal((await req('/api/tool', { name: 'world_inspect' }, 'POST', { Origin: 'https://untrusted.example' })).status, 403));
  await t.test('rejects untrusted Host headers', async () => {
    const code = await new Promise((resolve, reject) => { const r = http.get(`${url}/api/session`, { headers: { Host: 'untrusted.example' } }, res => { res.resume(); resolve(res.statusCode); }); r.on('error', reject); });
    assert.equal(code, 403);
  });
  await t.test('rejects missing authorization', async () => assert.equal((await fetch(`${url}/api/tool`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"name":"world_make"}' })).status, 401));
  await t.test('mutation persists to an atomic JSON document', async () => {
    const out = await call('object_add', { type: 'lamp', x: 0, z: 13 }); assert.equal(out.status, 200);
    const saved = JSON.parse(await readFile(resolve(dir, 'world.json'), 'utf8'));
    assert.deepEqual(saved.world, out.data.world); assert.equal(saved.rev, out.data.rev);
  });
  await t.test('stale revisions are rejected without applying edits', async () => {
    const before = (await req('/api/world', undefined, 'GET')).data;
    const out = await call('terrain_set', { relief: 24 }, before.rev - 1); assert.equal(out.status, 409);
    assert.equal(out.data.world.terrain.relief, before.world.terrain.relief);
  });
  await t.test('invalid documents cannot overwrite saved state', async () => {
    const before = (await req('/api/world', undefined, 'GET')).data;
    assert.equal((await req('/api/world', { rev: before.rev, world: { version: 9 } }, 'PUT')).status, 400);
    const after = (await req('/api/world', undefined, 'GET')).data; assert.equal(after.rev, before.rev);
  });
  await t.test('undo and redo restore the exact document', async () => {
    const before = (await req('/api/world', undefined, 'GET')).data.world;
    const edit = (await call('terrain_set', { relief: 16 })).data.world;
    assert.deepEqual((await call('world_undo')).data.world, before);
    assert.deepEqual((await call('world_redo')).data.world, edit);
  });
  await t.test('SSE emits committed revisions to live clients', async () => {
    const abort = new AbortController();
    const res = await fetch(`${url}/api/events`, { signal: abort.signal }), reader = res.body.getReader();
    await reader.read();
    const out = await call('spawn_set', { x: 0, z: 14 });
    const event = await Promise.race([reader.read(), delay(3000).then(() => { throw new Error('SSE timed out'); })]);
    assert.match(new TextDecoder().decode(event.value), new RegExp(`"rev":${out.data.rev}`)); abort.abort();
  });
  await t.test('MCP initializes, lists tools, reports errors and edits the HTTP world', async () => {
    const proc = spawn(process.execPath, ['mcp.mjs'], { cwd: resolve(import.meta.dirname, '..'), env, stdio: ['pipe', 'pipe', 'pipe'] });
    const lines = createInterface({ input: proc.stdout });
    const waiting = new Map(); let seq = 0;
    lines.on('line', line => { const msg = JSON.parse(line); waiting.get(msg.id)?.(msg); waiting.delete(msg.id); });
    const rpc = (method, params = {}) => new Promise((resolve, reject) => {
      const id = ++seq, timer = setTimeout(() => reject(new Error(`MCP timed out: ${method}`)), 5000);
      waiting.set(id, msg => { clearTimeout(timer); resolve(msg); });
      proc.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', id, method, params })}\n`);
    });
    try {
      assert.equal((await rpc('tools/list')).error.code, -32002);
      const init = await rpc('initialize', { protocolVersion: '2025-11-25', capabilities: {}, clientInfo: { name: 'test', version: '1' } });
      assert.equal(init.result.protocolVersion, '2025-11-25');
      proc.stdin.write('{"jsonrpc":"2.0","method":"notifications/initialized"}\n');
      assert.equal((await rpc('tools/list')).result.tools.length, 42);
      assert.equal((await rpc('tools/call', { name: 'model_template', arguments: { template: 'arch' } })).result.isError, false);
      assert.equal((await rpc('ping')).result.constructor, Object);
      const before = (await req('/api/world', undefined, 'GET')).data.world.objects.length;
      const out = await rpc('tools/call', { name: 'object_add', arguments: { type: 'crate', x: 1, z: 10, _rev: (await req('/api/world', undefined, 'GET')).data.rev, _key: crypto.randomUUID() } });
      assert.equal(out.result.isError, false);
      assert.equal((await req('/api/world', undefined, 'GET')).data.world.objects.length, before + 1);
      assert.equal((await rpc('tools/call', { name: 'object_add', arguments: { type: 'bad' } })).result.isError, true);
      assert.equal((await rpc('server/discover', { _meta: { 'io.modelcontextprotocol/protocolVersion': '2026-07-28', 'io.modelcontextprotocol/clientCapabilities': {} } })).result.supportedVersions.includes('2026-07-28'), true);
    } finally { proc.stdin.end(); await once(proc, 'exit'); lines.close(); }
  });
  await t.test('malformed JSON is rejected and the server remains healthy', async () => {
    const r = await fetch(`${url}/api/tool`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: '{broken' });
    assert.equal(r.status, 400); assert.equal((await call('world_validate')).status, 200);
  });
  await t.test('world import restores a portable document', async () => {
    const now = (await req('/api/world', undefined, 'GET')).data;
    const out = await req('/api/world', { world: session.world, rev: now.rev }, 'PUT');
    assert.equal(out.status, 200); assert.deepEqual(out.data.world, session.world);
  });
  await t.test('restart restores the persisted world and rotates the token', async () => {
    const before = (await req('/api/world', undefined, 'GET')).data;
    const exit = once(server, 'exit'); server.kill('SIGTERM'); await exit;
    server = spawn(process.execPath, ['server.mjs'], { cwd: resolve(import.meta.dirname, '..'), env, stdio: ['ignore', 'pipe', 'pipe'] });
    let after;
    for (let i = 0; i < 80; i++) { try { after = await (await fetch(`${url}/api/session`)).json(); break; } catch { await delay(50); } }
    assert.deepEqual(after.world, before.world); assert.equal(after.rev, before.rev); assert.notEqual(after.token, token); assert.equal(after.undo, 0); token = after.token;
  });
});
