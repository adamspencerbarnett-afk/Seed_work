import argparse
import asyncio
import base64
import hashlib
import io
import json
import os
import urllib.error
import urllib.request
from pathlib import Path

import numpy as np
from PIL import Image
from playwright.async_api import async_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--url', default='http://127.0.0.1:4173')
parser.add_argument('--out', default='reports/host')
parser.add_argument('--fixture', action='store_true')
parser.add_argument('--runtime', action='store_true')
parser.add_argument('--cold', action='store_true')
parser.add_argument('--dpr', type=float, default=1)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
checks, errors, requests = [], [], []


def record(name, value, detail=None):
    item = {'name': name, 'passed': bool(value)}
    if detail is not None:
        item['detail'] = detail
    checks.append(item)
    print(('PASS ' if value else 'FAIL ') + name, flush=True)
    if not value:
        raise AssertionError(f'{name}: {detail}')


def send(path, method, data, headers):
    req = urllib.request.Request(args.url + path, data=data, method=method, headers={k: v for k, v in headers.items() if k in ('content-type', 'authorization')})
    try:
        with urllib.request.urlopen(req, timeout=60) as res:
            return res.status, dict(res.headers), res.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()


async def fixture(page):
    await page.expose_function('fixtureDigest', lambda text: base64.b64encode(hashlib.sha256(base64.b64decode(text)).digest()).decode())
    await page.evaluate('''() => {
      Object.defineProperty(crypto,'randomUUID',{value:()=>{const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const s=[...b].map(v=>v.toString(16).padStart(2,'0')).join('');return `${s.slice(0,8)}-${s.slice(8,12)}-${s.slice(12,16)}-${s.slice(16,20)}-${s.slice(20)}`;}});
      Object.defineProperty(crypto,'subtle',{value:{digest:async (algorithm,bytes)=>{if(algorithm!=='SHA-256')throw Error('Unsupported fixture hash');const b=new Uint8Array(bytes.buffer??bytes,bytes.byteOffset??0,bytes.byteLength);let s='';for(let i=0;i<b.length;i+=16384)s+=String.fromCharCode(...b.subarray(i,i+16384));return Uint8Array.from(atob(await fixtureDigest(btoa(s))),c=>c.charCodeAt(0)).buffer;}}});
    }''')

    async def route(r):
        if r.request.method == 'OPTIONS':
            await r.fulfill(status=204, headers={'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*'})
            return
        path = r.request.url.split('http://seedwork.test', 1)[-1]
        requests.append(path)
        status, headers, data = await asyncio.to_thread(send, path, r.request.method, r.request.post_data_buffer, r.request.headers)
        try:
            await r.fulfill(status=status, body=data, headers={'Content-Type': headers.get('Content-Type', 'application/octet-stream'), 'Access-Control-Allow-Origin': '*'})
        except Exception:
            if not page.is_closed():
                raise

    await page.route('http://seedwork.test/**', route)
    path = '/index.html' if args.runtime else '/host/index.html'
    _, _, data = await asyncio.to_thread(send, path, 'GET', None, {})
    base = 'http://seedwork.test/' if args.runtime else 'http://seedwork.test/host/'
    await page.set_content(data.decode().replace('<head>', f'<head><base href="{base}">'), wait_until='load')


async def main():
    async with async_playwright() as pw:
        flags = ['--disable-dev-shm-usage']
        if args.fixture:
            flags += ['--no-sandbox', '--enable-unsafe-swiftshader', '--use-angle=swiftshader']
        browser = await pw.chromium.launch(executable_path=os.environ.get('CHROMIUM', '/usr/bin/chromium'), headless=True, args=flags)
        page = await browser.new_page(viewport={'width': 1540, 'height': 1000}, device_scale_factor=args.dpr)
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('console', lambda m: print('CONSOLE', m.type, m.text[:240], flush=True) if m.type == 'error' else None)
        try:
            if args.fixture:
                await fixture(page)
            else:
                page.on('request', lambda r: requests.append(r.url))
                await page.goto(args.url + ('/' if args.runtime else '/host/'), wait_until='load')
            if args.runtime:
                await page.wait_for_function('window.gameDemo?.ready || window.gameDemo?.error', timeout=60000)
                record('runtime-only scene loads without authoring service', await page.evaluate('gameDemo.ready'), await page.evaluate('gameDemo.error ?? null'))
                record('host preserves native device pixel ratio', await page.evaluate('gameDemo.game.renderer.getPixelRatio() === devicePixelRatio'))
                record('all sixteen published items loaded', await page.evaluate('gameDemo.runtime.inspect().objects === 16'))
                record('six source assets loaded exactly once', await page.evaluate('gameDemo.runtime.inspect().assetLoads === 6'))
                record('no authoring API request', not any('/api/' in r for r in requests))
                record('runtime-only route remains passable', await page.evaluate('gameDemo.game.tests.route().passed'))
                record('runtime-only original gate works', await page.evaluate('gameDemo.game.tests.gate().passed'))
                record('runtime-only original game retains ownership', await page.evaluate('gameDemo.game.tests.host_integrity().passed'))
                await page.screenshot(path=str(out / 'runtime.png'))
                record('no browser exceptions', not errors, errors)
                return
            await page.wait_for_function('window.seedworkLab?.game.state.frames > 2', timeout=45000)
            await page.evaluate('seedworkLab.game.ready')
            record('host runs before toolkit attaches', await page.evaluate('!seedworkLab.kit && seedworkLab.game.state.frames > 2'))
            await page.evaluate('''() => { const g=seedworkLab.game;window.hostRef={renderer:g.renderer,camera:g.camera,own:g.own,children:[...g.scene.children]}; }''')
            await page.click('#walk')
            before = await page.evaluate('seedworkLab.game.state.player[2]')
            await page.keyboard.down('w')
            await page.evaluate('seedworkLab.game.step(.2)')
            await page.keyboard.up('w')
            record('host keyboard and movement work before attach', await page.evaluate('seedworkLab.game.state.player[2]') < before)
            await page.click('#orbit')

            async def click(id):
                await page.click('#' + id)
                await page.wait_for_function('seedworkLab.ready', timeout=45000)

            async def tool(name, data=None):
                return await page.evaluate('v=>seedworkLab.call(v.name,v.args)', {'name': name, 'args': data or {}})

            async def preview():
                await click('preview')
                record('exact draft acknowledged by the host', await page.evaluate('seedworkLab.change && seedworkLab.kit.runtime.meta.change === seedworkLab.change.id && seedworkLab.kit.runtime.meta.seq === seedworkLab.change.seq'), await page.locator('#log').inner_text())

            async def evidence():
                await click('test')
                record('all required host tests pass', await page.evaluate('seedworkLab.change.evidence.filter(e=>e.type === "test").length === 3 && seedworkLab.change.evidence.filter(e=>e.type === "test").every(e=>e.passed)'), await page.locator('#log').inner_text())
                await click('capture')
                record('native capture retained for the same draft', await page.evaluate('seedworkLab.change.evidence.some(e=>e.type === "capture")'))

            async def commit(rev):
                await page.check('#ack')
                await click('approve')
                record('explicit reviewer action approves exact draft', await page.evaluate('!!seedworkLab.change?.approval'), await page.locator('#log').inner_text())
                await click('commit')
                await page.wait_for_function('(rev)=>seedworkLab.kit.runtime.meta?.rev === rev && !seedworkLab.kit.runtime.meta.change', arg=rev, timeout=20000)
                record('atomic publication advances one project revision', await page.evaluate('seedworkLab.project.rev') == rev)

            await click('attach')
            await page.wait_for_function('seedworkLab.kit?.runtime.meta && !seedworkLab.kit.runtime.meta.change', timeout=30000)
            record('attachment adds one group, not a renderer or game loop', await page.evaluate('seedworkLab.game.scene.children.length === hostRef.children.length+1 && seedworkLab.game.renderer === hostRef.renderer && seedworkLab.game.camera === hostRef.camera && seedworkLab.game.own === hostRef.own'))
            record('committed host project starts empty', await page.evaluate('seedworkLab.project.rev === 0 && seedworkLab.kit.runtime.inspect().objects === 0'))
            world = await page.evaluate('seedworkLab.api("/api/world")')
            await click('stage')
            record('courtyard created through one bounded batch', await page.evaluate('seedworkLab.change.seq === 1 && seedworkLab.change.diff.count === 16'))
            record('draft does not mutate committed content', await page.evaluate('seedworkLab.project.rev === 0 && seedworkLab.project.doc.items.length === 0 && seedworkLab.kit.runtime.inspect().objects === 0'))
            bad = await page.evaluate('''async () => {const c=seedworkLab.change;try{await seedworkLab.call('change_apply',{id:c.id,seq:c.seq,key:crypto.randomUUID(),ops:[{op:'item_set',id:'bench_w',patch:{pos:[-3,0,0]}},{op:'item_remove',id:'missing'}]});return null;}catch(e){return e.code;}}''')
            record('invalid second operation rejects the whole batch', bool(bad))
            await page.evaluate('seedworkLab.refresh()')
            record('failed batch does not advance sequence', await page.evaluate('seedworkLab.change.seq === 1'))
            await preview()
            record('six assets serve sixteen placements', await page.evaluate('seedworkLab.kit.runtime.inspect().objects === 16 && seedworkLab.kit.runtime.inspect().assetLoads === 6 && seedworkLab.kit.runtime.inspect().cachedAssets === 6'))
            record('repeated placements share geometry and materials', await page.evaluate('''() => {const r=seedworkLab.kit.runtime;let a,b;r.get('west_001').traverse(n=>{if(n.isMesh&&!a)a=n});r.get('east_001').traverse(n=>{if(n.isMesh&&!b)b=n});return a.geometry===b.geometry && a.material===b.material;}'''))
            q = await tool('scene_query', {'host': await page.evaluate('seedworkLab.kit.link.id'), 'query': {'ids': ['entry']}})
            record('live query includes host-owned semantics', {e['id'] for e in q['external']} == {'route', 'gate'})
            record('live query includes actual transform and snapshot', len(q['items']) == 1 and len(q['items'][0]['matrixWorld']) == 16 and q['meta']['change'])
            early = await page.evaluate('''async()=>{const c=seedworkLab.change;try{await seedworkLab.call('change_commit',{id:c.id,seq:c.seq,rev:0,key:crypto.randomUUID()});return null;}catch(e){return e.code;}}''')
            record('publication rejected before tests and approval', bool(early))
            await page.evaluate('window.hostState = { player:[...seedworkLab.game.state.player], gate:seedworkLab.game.state.gate, walk:seedworkLab.game.state.walk }')
            await evidence()
            record('host tests restore gameplay state', await page.evaluate('JSON.stringify(hostState) === JSON.stringify({player:seedworkLab.game.state.player,gate:seedworkLab.game.state.gate,walk:seedworkLab.game.state.walk})'))
            image = await page.locator('#capture-img').get_attribute('src')
            raw = base64.b64decode(image.split(',')[1])
            img = Image.open(io.BytesIO(raw)).convert('RGB')
            size = await page.evaluate('[seedworkLab.game.renderer.domElement.width,seedworkLab.game.renderer.domElement.height]')
            record('capture uses native framebuffer dimensions', list(img.size) == size, size)
            record('capture contains actual nonblank scene pixels', float(np.asarray(img).std()) > 10)
            (out / 'courtyard-frame.png').write_bytes(raw)
            profile = await tool('scene_profile', {'host': await page.evaluate('seedworkLab.kit.link.id')})
            (out / 'profile.json').write_text(json.dumps(profile, indent=2))
            record('profiling reports measured counters without inventing GPU timing', profile['frames'] > 2 and profile['gpuMs'] is None and profile['vramBytes'] is None and profile['cpuWorkMs']['samples'] > 0)
            await page.screenshot(path=str(out / 'editor.png'))
            await page.evaluate('window.beforeCommit={doc:seedworkLab.kit.runtime.snapshot().doc,entry:seedworkLab.kit.runtime.get("entry"),bench:seedworkLab.kit.runtime.get("bench_w"),loads:seedworkLab.kit.runtime.inspect().assetLoads}')
            await commit(1)
            record('committing preview reuses live groups and loaded resources', await page.evaluate('seedworkLab.kit.runtime.get("entry")===beforeCommit.entry && seedworkLab.kit.runtime.inspect().assetLoads===beforeCommit.loads'))
            record('host project publication does not change World Studio', world == await page.evaluate('seedworkLab.api("/api/world")'))
            await page.evaluate('seedworkLab.begin("Widen entrance and move bench")')
            await page.evaluate('seedworkLab.apply([{op:"item_set",id:"entry",patch:{scale:1.45}},{op:"item_set",id:"bench_w",patch:{pos:[-4.8,.035,.2]}}])')
            await preview()
            record('transform-only edit preserves object handles and asset cache', await page.evaluate('seedworkLab.kit.runtime.get("entry")===beforeCommit.entry && seedworkLab.kit.runtime.get("bench_w")===beforeCommit.bench && seedworkLab.kit.runtime.inspect().assetLoads===beforeCommit.loads'))
            record('unrelated objects and bindings are unchanged', await page.evaluate('''()=>{const r=seedworkLab.kit.runtime.snapshot().doc;return r.items.filter(i=>!['entry','bench_w'].includes(i.id)).every(i=>JSON.stringify(i)===JSON.stringify(beforeCommit.doc.items.find(j=>j.id===i.id))) && JSON.stringify(r.items.find(i=>i.id==='entry').bindings)===JSON.stringify(beforeCommit.doc.items.find(i=>i.id==='entry').bindings)}'''))
            await page.evaluate('seedworkLab.apply([{op:"item_set",id:"crate",patch:{pos:[0,.035,7]}}])')
            await preview()
            await click('test')
            record('real host traversal detects a blocked route', await page.evaluate('seedworkLab.change.evidence.some(e=>e.type === "test" && e.test === "route" && !e.passed)'))
            blocked = await page.evaluate('''async()=>{try{await seedworkLab.api('/api/project/approve',{id:seedworkLab.change.id,seq:seedworkLab.change.seq,rev:seedworkLab.project.rev});return null;}catch(e){return e.code;}}''')
            record('failed gameplay evidence prevents approval', bool(blocked))
            await page.evaluate('seedworkLab.apply([{op:"item_snap",id:"crate",socket:"origin",to:"pallet",targetSocket:"top"}])')
            record('repair invalidates old evidence', await page.evaluate('seedworkLab.change.evidence.length === 0 && !seedworkLab.change.approval'))
            await preview()
            await evidence()
            await commit(2)
            await page.evaluate('window.revised = seedworkLab.kit.runtime.snapshot().doc')
            await click('undo')
            await preview()
            record('undo is an exact staged historical scene', await page.evaluate('JSON.stringify(seedworkLab.kit.runtime.snapshot().doc)===JSON.stringify(beforeCommit.doc) && seedworkLab.project.rev===2'))
            await evidence()
            await commit(3)
            await click('redo')
            await preview()
            record('redo restores the exact revised scene before approval', await page.evaluate('JSON.stringify(seedworkLab.kit.runtime.snapshot().doc)===JSON.stringify(revised) && seedworkLab.project.rev===3'))
            await evidence()
            await commit(4)
            await page.evaluate('seedworkLab.begin("Discardable preview")')
            await page.evaluate('seedworkLab.apply([{op:"item_set",id:"drum",patch:{pos:[7,.035,7]}}])')
            await preview()
            await click('discard')
            await page.wait_for_function('!seedworkLab.kit.runtime.meta.change && seedworkLab.kit.runtime.meta.rev === 4', timeout=20000)
            record('discard resets the host without creating a revision', await page.evaluate('seedworkLab.project.rev===4 && JSON.stringify(seedworkLab.kit.runtime.snapshot().doc)===JSON.stringify(revised)'))

            for name, view in [('overview', [.48, .65, 32]), ('entrance', [.17, .25, 12, [0, 1.2, 3.5]]), ('bench', [1.2, .4, 7, [-4.8, .7, .2]])]:
                await page.evaluate('(v)=>seedworkLab.game.view(...v)', view)
                await page.evaluate('''async()=>{const r=seedworkLab.kit.runtime,s=r.snapshot(),d=structuredClone(s.doc);d.items.find(i=>i.id==='bench_w').pos[2]+=.1;await r.setScene(d,s.meta);await r.setScene(s.doc,s.meta);}''')
                ref = await page.evaluate('seedworkLab.kit.observer.capture()')
                if args.cold:
                    await page.evaluate('''async()=>{const r=seedworkLab.kit.runtime,s=r.snapshot();await r.setScene({...s.doc,items:[]},s.meta);await r.setScene(s.doc,s.meta);}''')
                else:
                    await page.evaluate('''()=>{const r=seedworkLab.kit.runtime,s=r.snapshot(),group=new THREE.Group();window.independent=group;for(const item of s.doc.items){const node=new THREE.Group();node.position.fromArray(item.pos);node.rotation.set(...item.rot.map(v=>v*Math.PI/180),'XYZ');node.scale.setScalar(item.scale);node.add(r.pool.entries.get(s.doc.assets[item.asset].hash).value.root.clone(true));group.add(node);}seedworkLab.game.scene.add(group);r.root.visible=false;}''')
                rebuilt = await page.evaluate('seedworkLab.kit.observer.capture()')
                if not args.cold:
                    await page.evaluate('()=>{seedworkLab.game.scene.remove(independent);independent.clear();seedworkLab.kit.runtime.root.visible=true;}')
                a, b = base64.b64decode(ref['image']['data']), base64.b64decode(rebuilt['image']['data'])
                (out / f'{name}-incremental.png').write_bytes(a)
                (out / f'{name}-rebuild.png').write_bytes(b)
                aa, bb = np.asarray(Image.open(io.BytesIO(a)).convert('RGBA')), np.asarray(Image.open(io.BytesIO(b)).convert('RGBA'))
                diff = int(np.any(aa != bb, axis=2).sum())
                record(f'{name}: incremental versus {"cold asset reload" if args.cold else "independent placement rebuild"} pixels', diff == 0, {'changedPixels': diff, 'pixels': int(aa.shape[0] * aa.shape[1]), 'maxChannelDifference': int(np.abs(aa.astype(int)-bb.astype(int)).max()), 'source': 'Cold asset reload and new placement nodes.' if args.cold else 'Same decoded assets; independently constructed groups/transforms. This isolates placement reuse from cold decode/draw-order variation.'})
            await page.evaluate('seedworkLab.game.view(.48,.65,32)')
            await page.evaluate('window.detaching={runtime:seedworkLab.kit.runtime,observer:seedworkLab.kit.observer,frames:seedworkLab.game.state.frames}')
            await click('detach')
            await page.wait_for_function('seedworkLab.game.state.frames > detaching.frames+1')
            record('detach leaves the game scene and renderer intact', await page.evaluate('!seedworkLab.kit && seedworkLab.game.renderer===hostRef.renderer && seedworkLab.game.scene.children.length===hostRef.children.length && seedworkLab.game.own===hostRef.own'))
            record('detached runtime releases its content and resources', await page.evaluate('detaching.runtime.inspect().closed && detaching.runtime.inspect().objects===0 && detaching.runtime.inspect().cachedAssets===0 && detaching.observer.closed'))
            await click('walk')
            before = await page.evaluate('seedworkLab.game.state.player[2]')
            await page.keyboard.down('s')
            await page.evaluate('seedworkLab.game.step(.2)')
            await page.keyboard.up('s')
            record('original controls work after detach', await page.evaluate('seedworkLab.game.state.player[2]') > before)
            await click('orbit')
            await click('attach')
            await page.wait_for_function('seedworkLab.kit.runtime.meta?.rev===4 && !seedworkLab.kit.runtime.meta.change', timeout=30000)
            record('reattachment restores only the committed scene', await page.evaluate('seedworkLab.kit.runtime.inspect().objects===16 && seedworkLab.kit.runtime.inspect().assetLoads===6 && JSON.stringify(seedworkLab.kit.runtime.snapshot().doc)===JSON.stringify(revised)'))
            record('host layout stays within the viewport', await page.evaluate('document.querySelector("#game").getBoundingClientRect().bottom < innerHeight && document.documentElement.scrollWidth <= innerWidth'))
            final = await page.evaluate('seedworkLab.kit.runtime.snapshot().doc')
            (out / 'courtyard.scene.json').write_text(json.dumps(final, indent=2))
            await page.screenshot(path=str(out / 'published.png'))
            record('no uncaught browser exceptions', not errors, errors)
        finally:
            await browser.close()
            (out / 'results.json').write_text(json.dumps({'checks': checks, 'passed': sum(c['passed'] for c in checks), 'total': len(checks), 'errors': errors, 'fixture': args.fixture, 'runtimeOnly': args.runtime, 'coldReload': args.cold, 'devicePixelRatio': args.dpr, 'environment': 'Chromium with SwiftShader and an async real-HTTP fixture. Opaque-origin fixture uses SHA-256/UUID facades; native Node WebCrypto is tested separately. No host bridge or gameplay hooks mocked.' if args.fixture else 'Normal browser navigation', 'requests': requests}, indent=2))


asyncio.run(main())
