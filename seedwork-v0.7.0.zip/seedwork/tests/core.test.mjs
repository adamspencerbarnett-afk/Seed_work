import test from 'node:test';
import assert from 'node:assert/strict';
import { make, check, clone, hash, rand, height, rawHeight, SEG, add, scatter, recipe, findSpawn, canWalk, TYPES, BIOMES, MAX } from '../core/world.mjs';
import { tool, TOOLS, catalog, validate } from '../core/tools.mjs';

const base = make();

test('identical seeds and options produce identical documents', () => assert.deepEqual(make(), make()));
test('different seeds change the document', () => assert.notDeepEqual(make({ seed: 1 }), make({ seed: 2 })));
test('seeded random sequences are repeatable', () => { const a = rand('seed'), b = rand('seed'); assert.deepEqual(Array.from({ length: 50 }, a), Array.from({ length: 50 }, b)); });
test('hash is a stable unsigned integer', () => { assert.equal(hash('x'), hash('x')); assert.ok(hash('x') >= 0 && hash('x') <= 4294967295); });
for (const biome of BIOMES) test(`generates a valid ${biome} world`, () => { const w = make({ biome }); assert.equal(check(w), w); assert.ok(w.objects.length > 100); assert.ok(findSpawn(w)); });
test('zero density creates no foliage', () => { const w = make({ density: 0 }); assert.equal(w.objects.filter(o => ['oak', 'pine', 'mushroom', 'cactus'].includes(o.type)).length, 0); });
test('scene IDs are unique', () => assert.equal(new Set(base.objects.map(o => o.id)).size, base.objects.length));
test('world documents survive a JSON round trip', () => assert.deepEqual(check(JSON.parse(JSON.stringify(base))), base));
test('height sampling matches mesh grid vertices', () => { const s = base.terrain.size; for (const ix of [0, 10, 33, 50, 95]) for (const iz of [0, 10, 33, 50, 95]) { const x = ix / SEG * s - s / 2, z = iz / SEG * s - s / 2; assert.ok(Math.abs(height(base, x, z) - rawHeight(base, x, z)) < 1e-8); } });
test('default spawn is dry and unblocked', () => { const p = findSpawn(base); assert.ok(canWalk(base, p.x, p.z)); assert.ok(height(base, p.x, p.z) > base.terrain.water); });
test('flooded terrain rejects preview spawn', () => { const w = make({ relief: 0, water: 8, village: false, ruins: false, crystals: false, density: 0 }); assert.throws(() => findSpawn(w), /No dry/); });
test('solid objects block the player', () => { const w = clone(base); add(w, 'crate', 0, 13); assert.equal(canWalk(w, 0, 13), false); });
test('non-solid objects do not block the player', () => { const w = clone(base); add(w, 'crate', 0, 13, { solid: false }); assert.equal(canWalk(w, 0, 13), true); });
test('sufficiently elevated objects do not block ground movement', () => { const w = clone(base); add(w, 'crate', 0, 13, { y: 20 }); assert.equal(canWalk(w, 0, 13), true); });
test('create update and remove use immutable document changes', () => {
  const before = clone(base), out = tool(base, 'object_add', { type: 'rock', x: 3, z: 4 });
  assert.deepEqual(base, before); assert.equal(out.world.objects.length, base.objects.length + 1);
  const id = out.result.object.id, changed = tool(out.world, 'object_update', { id, x: 5, scale: 1.5 });
  assert.equal(changed.world.objects.at(-1).scale, 1.5); assert.equal(out.world.objects.at(-1).scale, 1);
  assert.equal(tool(changed.world, 'object_remove', { id }).world.objects.length, base.objects.length);
});
test('IDs do not collide after deletion', () => { const w = clone(base); w.objects.splice(3, 1); add(w, 'rock', 1, 1); check(w); });
test('raise and lower strokes alter sampled terrain', () => {
  const args = { x: 0, z: 0, radius: 7, power: 2 }, h = height(base, 0, 0);
  assert.ok(height(tool(base, 'terrain_brush', { ...args, mode: 'raise' }).world, 0, 0) > h + 1.9);
  assert.ok(height(tool(base, 'terrain_brush', { ...args, mode: 'lower' }).world, 0, 0) < h - 1.9);
});
test('flatten honors a target level at its center', () => { const w = tool(base, 'terrain_brush', { x: 0, z: 0, radius: 10, power: 1, mode: 'flatten', level: 9 }).world; assert.equal(height(w, 0, 0), 9); });
test('flatten power cannot exceed one', () => assert.throws(() => tool(base, 'terrain_brush', { x: 0, z: 0, radius: 10, power: 2, mode: 'flatten' }), /power/));
test('brush history is bounded', () => { const w = clone(base); w.terrain.stamps = Array.from({ length: 96 }, () => ({ x: 0, z: 0, radius: 2, power: 1, mode: 'raise', level: 0 })); assert.throws(() => tool(w, 'terrain_brush', { x: 0, z: 0, radius: 2, power: 1, mode: 'raise' }), /96/); });
test('scatter is deterministic and reports actual placement', () => {
  const args = { type: 'lamp', count: 20, radius: 24, seed: 73 }, a = clone(base), b = clone(base);
  assert.deepEqual(scatter(a, args), scatter(b, args)); assert.deepEqual(a, b);
  for (const o of a.objects.slice(base.objects.length)) assert.ok(height(a, o.x, o.z) >= a.terrain.water + 0.7);
});
test('a saturated scatter region returns fewer than requested safely', () => { const out = tool(base, 'object_scatter', { type: 'tower', count: 100, radius: 1 }); assert.ok(out.result.placed < 100); check(out.world); });
test('object and operation budgets are enforced', () => { const w = clone(base); w.objects = Array.from({ length: MAX }, (_, i) => ({ ...base.objects[0], id: `crystal_${i}` })); assert.throws(() => tool(w, 'object_add', { type: 'rock', x: 0, z: 0 }), /limit/); assert.throws(() => scatter(w, { type: 'rock', count: 1 }), /exceeds/); });
test('world inspection and validation do not mutate state', () => { const a = tool(base, 'world_inspect', { objects: true }), b = tool(base, 'world_validate'); assert.equal(a.changed, false); assert.equal(b.changed, false); assert.equal(a.result.objects.length, base.objects.length); assert.equal(b.result.valid, true); });
test('keyword recipes recognize supported settings and negation', () => {
  const r = recipe('A dense snowy island at sunset without a village, no ruins, no crystals, seed 82');
  assert.equal(r.options.biome, 'snow'); assert.equal(r.options.time, 'sunset'); assert.equal(r.options.seed, 82);
  const w = make(r.options); assert.equal(w.objects.filter(o => ['house', 'tower', 'arch', 'crystal'].includes(o.type)).length, 0);
});
test('unsupported prose is explicitly reported rather than invented', () => { const r = recipe('Train dolphins to compose sonnets'); assert.equal(Object.keys(r.options).length, 0); assert.match(r.notes.join(), /No supported keywords/); assert.match(r.limitation, /not an AI/); });
test('seed zero and upper bound are valid', () => { check(make({ seed: 0 })); check(make({ seed: 4294967295 })); });
test('generation inputs are validated before terrain creation', () => { assert.throws(() => make({ biome: 'unknown' }), /Unknown biome/); assert.throws(() => make({ relief: NaN }), /finite/); assert.throws(() => make({ village: 'yes' }), /boolean/); });
for (const [label, change] of [
  ['NaN', w => { w.terrain.relief = NaN; }], ['Infinity', w => { w.objects[0].x = Infinity; }],
  ['unknown version', w => { w.version = 2; }], ['duplicate ID', w => { w.objects[1].id = w.objects[0].id; }],
  ['unknown object type', w => { w.objects[0].type = 'javascript'; }], ['out-of-bounds object', w => { w.objects[0].x = 1000; }],
  ['negative scale', w => { w.objects[0].scale = -1; }], ['code-bearing field', w => { w.script = 'alert(1)'; }],
  ['missing terrain', w => { delete w.terrain; }], ['non-integer seed', w => { w.seed = 0.5; }]
]) test(`validator rejects ${label}`, () => { const w = clone(base); change(w); assert.throws(() => check(w)); });
test('unknown and prototype-bearing tool arguments are rejected', () => {
  assert.throws(() => tool(base, 'terrain_set', JSON.parse('{"__proto__":{"polluted":true}}')), /reserved key|unknown field/);
  assert.throws(() => tool(base, 'object_add', { type: 'rock', x: 1, z: 2, code: 'evil' }), /reserved key|unknown field/);
  assert.equal({}.polluted, undefined);
});
test('shrinking terrain rejects out-of-bounds preserved objects', () => { const w = clone(base); add(w, 'rock', 58, 0); assert.throws(() => tool(w, 'terrain_set', { size: 64 }), /Object X/); });
test('all 27 world tools expose closed schemas and safety hints', () => { assert.equal(TOOLS.length, 27); for (const t of catalog()) { assert.equal(t.inputSchema.additionalProperties, false); assert.equal(typeof t.annotations.readOnlyHint, 'boolean'); } });
test('missing IDs and missing required fields fail', () => { assert.throws(() => tool(base, 'object_update', { id: 'missing', scale: 1 }), /not found/); assert.throws(() => tool(base, 'object_add', { type: 'rock' }), /requires/); assert.throws(() => tool(base, 'run_code', {}), /Unknown tool/); });

test('inspection exposes terrain and sky without sharing mutable result references', () => { const out = tool(base, 'world_inspect'); assert.deepEqual(out.result.terrain, base.terrain); assert.deepEqual(out.result.sky, base.sky); out.result.terrain.relief = 24; out.result.sky.time = 'night'; assert.notEqual(base.terrain.relief, 24); assert.notEqual(base.sky.time, 'night'); });
