import argparse
import asyncio
import base64
import io
import json
import os
import urllib.error
import urllib.request
from pathlib import Path

import numpy as np
from PIL import Image
from playwright.async_api import async_playwright

p = argparse.ArgumentParser()
p.add_argument('--url', default='http://127.0.0.1:4173')
p.add_argument('--out', default='reports/environment')
args = p.parse_args()
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
checks, errors, comparisons = [], [], []

def record(name, ok, detail=None):
    checks.append({'name': name, 'passed': bool(ok), 'detail': detail})
    print(('PASS ' if ok else 'FAIL ') + name, flush=True)
    if not ok:
        raise AssertionError(f'{name}: {detail}')

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path=os.environ.get('CHROMIUM', '/usr/bin/chromium'), headless=True, args=['--disable-dev-shm-usage', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
        page = await browser.new_page(viewport={'width': 1440, 'height': 960}, device_scale_factor=1)
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
        async def route(r):
            if r.request.method == 'OPTIONS':
                await r.fulfill(status=204, headers={'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*'})
                return
            path = r.request.url.split('http://seedwork.test', 1)[-1]
            def read():
                req = urllib.request.Request(args.url + path, data=r.request.post_data_buffer, method=r.request.method)
                for k in ['content-type', 'authorization']:
                    if k in r.request.headers:
                        req.add_header(k, r.request.headers[k])
                try:
                    with urllib.request.urlopen(req, timeout=60) as res:
                        return res.status, res.headers.get('Content-Type'), res.read()
                except urllib.error.HTTPError as e:
                    return e.code, e.headers.get('Content-Type'), e.read()
            status, typ, data = await asyncio.to_thread(read)
            await r.fulfill(status=status, body=data, headers={'Content-Type': typ or 'application/octet-stream', 'Access-Control-Allow-Origin': '*'})
        await page.route('http://seedwork.test/**', route)
        html = urllib.request.urlopen(args.url + '/environment/').read().decode()
        await page.set_content(html.replace('<head>', '<head><base href="http://seedwork.test/environment/">'), wait_until='load')
        await page.wait_for_function('window.envLab?.ready', timeout=90000)
        await page.evaluate('envLab.pause()')
        record('Gallery boots using the host renderer and r140', await page.evaluate('THREE.REVISION === "140" && envLab.env.renderer === undefined'))
        record('Seven presets and ten condition controls are present', await page.locator('[data-preset]').count() == 7 and await page.locator('[data-field]').count() == 10)
        for name in ['clear', 'rain', 'snow', 'ice', 'autumn', 'mist', 'thaw']:
            await page.locator(f'[data-preset="{name}"]').click()
            record(f'{name} preset applies through the UI', await page.evaluate('envLab.state.preset') == name)
            await page.evaluate('(n) => envLab.fixed(n, 3)', name)
            await page.evaluate('envLab.render()')
            await page.screenshot(path=str(out / f'{name}-editor.png'))
            shots, infos = [], []
            for ref in [True, False]:
                shot = await page.evaluate('ref => { envLab.env.setReference(ref); envLab.render(); return { png: envLab.renderer.domElement.toDataURL("image/png"), stats: envLab.env.inspect(), render: {...envLab.renderer.info.render} }; }', ref)
                data = base64.b64decode(shot.pop('png').split(',')[1])
                (out / f'{name}-{"reference" if ref else "optimized"}.png').write_bytes(data)
                shots.append(np.array(Image.open(io.BytesIO(data))))
                infos.append(shot)
            diff = np.any(shots[0] != shots[1], axis=2)
            info = {'preset': name, 'changedPixels': int(diff.sum()), 'pixels': int(diff.size), 'reference': infos[0], 'optimized': infos[1]}
            comparisons.append(info)
            record(f'{name} optimization preserves every captured pixel', not diff.any(), {'changedPixels': int(diff.sum())})
            record(f'{name} omits only inactive instances', sum(e['submitted'] for e in infos[1]['stats']['emitters']) == sum(e['visible'] for e in infos[1]['stats']['emitters']))
        await page.evaluate("envLab.fixed('ice', 3)")
        await page.locator('#detail').click()
        await page.evaluate('envLab.render()')
        await page.screenshot(path=str(out / 'ice-detail-editor.png'))
        record('Surface camera control changes the actual view', await page.evaluate('envLab.state.dist') == 9.5)
        await page.locator('#home').click()
        await page.evaluate('envLab.render()')
        await page.locator('[data-field="weather.rain"]').evaluate('(e) => { e.value=.43; e.dispatchEvent(new Event("input", {bubbles:true})); }')
        record('Rain slider changes the configured emitter density', await page.evaluate('envLab.env.climate.config.weather.rain') == .43)
        await page.locator('[data-field="surface.wet"]').evaluate('(e) => { e.value=.61; e.dispatchEvent(new Event("input", {bubbles:true})); }')
        record('Wetness slider drives material state', await page.evaluate('envLab.env.uniforms.envSurface.value.x') == .61)
        saved = await page.evaluate('envLab.env.snapshot()')
        await page.locator('summary').click()
        await page.locator('#tool').select_option('environment_preset')
        await page.locator('#args').fill('{"name":"snow"}')
        await page.locator('#run').click()
        record('Local AI tool console applies validated presets', await page.evaluate('envLab.env.climate.config.weather.snow') == .65)
        await page.locator('#args').fill('{"name":"not-a-preset"}')
        await page.locator('#run').click()
        record('Invalid local tool calls preserve the scene', 'Unknown' in await page.locator('#result').inner_text() and await page.evaluate('envLab.env.climate.config.weather.snow') == .65)
        await page.locator('#file').set_input_files({'name': 'climate.json', 'mimeType': 'application/json', 'buffer': json.dumps(saved).encode()})
        await page.wait_for_function('envLab.env.climate.config.weather.rain === .43')
        record('Uploaded climate restores the live surface state', await page.evaluate('envLab.env.snapshot()') == saved)
        async with page.expect_download() as d:
            await page.locator('#save').click()
        saved_file = out / 'saved-climate.json'
        await (await d.value).save_as(saved_file)
        record('Climate download preserves validated configuration and time', json.loads(saved_file.read_text()) == saved)
        await page.evaluate("envLab.fixed('thaw', 3)")
        before = await page.evaluate('({...envLab.env.climate.surface})')
        await page.evaluate('() => { for(let i=0;i<60;i++) envLab.env.update(1); envLab.render(); }')
        after = await page.evaluate('({...envLab.env.climate.surface})')
        record('Positive temperature visibly evolves snow and ice amounts', after['snow'] < before['snow'] and after['ice'] < before['ice'])
        sample = await page.evaluate('({covered:envLab.env.field.sample(-5.5,1.6), open:envLab.env.field.sample(0,10)})')
        record('The shelter field distinguishes covered porch from open ground', sample['covered']['roof'] - sample['covered']['ground'] > 2 and abs(sample['open']['roof'] - sample['open']['ground']) < .001, sample)
        await page.evaluate('envLab.env.setReference(false)')
        warm = await page.evaluate('({memory:{...envLab.renderer.info.memory}, info:envLab.env.inspect()})')
        await page.evaluate('() => { for(let j=0;j<3;j++) for(const n of ["clear","rain","snow","ice","autumn","mist","thaw"]){ envLab.fixed(n,3); } }')
        after = await page.evaluate('({memory:{...envLab.renderer.info.memory}, info:envLab.env.inspect()})')
        record('Repeated presets keep texture and geometry allocation stable', warm['memory'] == after['memory'], {'before':warm['memory'], 'after':after['memory']})
        record('Repeated presets do not rebuild the exposure grid or material shaders', warm['info']['field']['builds'] == after['info']['field']['builds'] and warm['info']['shaderCompiles'] == after['info']['shaderCompiles'])
        record('No JavaScript or shader errors were logged in gallery', not errors, errors)
        await page.evaluate('() => { envLab.pause(); envLab.env.dispose(); }')
        record('Detachment removes only the environment and restores borrowed materials', await page.evaluate('!envLab.env.root.parent && envLab.study.root.parent === envLab.study.scene && !envLab.study.groups.ground.children[0].material.name.includes("environment")'))
        await page.close()
        page = await browser.new_page(viewport={'width':1440,'height':960}, device_scale_factor=1)
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
        await page.route('http://seedwork.test/**', route)
        await page.evaluate('''() => { window.EventSource = class { constructor() {} close() {} }; Object.defineProperty(crypto, 'randomUUID', { value: () => {const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const s=[...b].map(v=>v.toString(16).padStart(2,'0')).join('');return `${s.slice(0,8)}-${s.slice(8,12)}-${s.slice(12,16)}-${s.slice(16,20)}-${s.slice(20)}`; }}); }''')
        html = urllib.request.urlopen(args.url + '/').read().decode()
        await page.set_content(html.replace('<head>','<head><base href="http://seedwork.test/">'),wait_until='load')
        await page.wait_for_function('window.seedwork?.ready', timeout=120000)
        await page.evaluate('seedwork.engine.freeze = true')
        record('Original editor boots with the environment integration', await page.evaluate('seedwork.ready'))
        await page.evaluate('seedwork.run("environment_preset", {name:"off"})')
        await page.locator('#env-preset').select_option('snow')
        await page.locator('#apply-env').click()
        await page.wait_for_function('seedwork.world.environment?.weather.snow === .65 && !!seedwork.engine.weatherKit', timeout=90000)
        record('World Studio applies authored snow through its revision-safe tool', await page.evaluate('seedwork.engine.weatherKit.climate.config.weather.snow') == .65)
        await page.evaluate('seedwork.engine.render()')
        record('Static GLB rejects live weather shaders rather than exporting the wrong material', await page.evaluate('() => { try { seedwork.glb(seedwork.engine.root); return false; } catch(e) { return e.message.includes("cannot be serialized"); } }'))
        record('Explicit base-material export does not serialize environment clones', await page.evaluate('() => { const b=seedwork.glb(seedwork.engine.root,{material:m=>seedwork.engine.weatherKit.sourceMaterial(m)}); const n=new DataView(b).getUint32(12,true); const d=JSON.parse(new TextDecoder().decode(new Uint8Array(b,20,n))); return d.materials.every(m=>!m.name.includes("environment")); }'))
        await page.screenshot(path=str(out/'world-snow-editor.png'))
        before_rev = await page.evaluate('seedwork.rev')
        await page.locator('#undo').click()
        await page.wait_for_function('r => seedwork.rev > r && !seedwork.world.environment', arg=before_rev)
        record('Undo detaches weather and restores the base world', await page.evaluate('!seedwork.engine.weatherKit'))
        before_rev = await page.evaluate('seedwork.rev')
        await page.locator('#redo').click()
        await page.wait_for_function('r => seedwork.rev > r && !!seedwork.engine.weatherKit', arg=before_rev)
        record('Redo restores the authored environment', await page.evaluate('seedwork.world.environment.weather.snow') == .65)
        identity = await page.evaluate('() => { window.kitBefore = seedwork.engine.weatherKit; return seedwork.engine.weatherKit.field.builds; }')
        await page.evaluate('seedwork.run("object_add", {type:"rock", x:20,z:20})')
        record('Unrelated object changes reuse the existing climate and exposure field', await page.evaluate('seedwork.engine.weatherKit === window.kitBefore && seedwork.engine.weatherKit.field.builds') == identity)
        await page.evaluate('seedwork.run("terrain_brush", {x:0,z:0,mode:"raise",radius:3,power:1})')
        record('Terrain edits invalidate exposure without recreating the environment', await page.evaluate('seedwork.engine.weatherKit === window.kitBefore && seedwork.engine.weatherKit.field.builds > ' + str(identity)))
        await page.evaluate('seedwork.run("environment_preset", {name:"autumn"})')
        await page.evaluate('seedwork.engine.render()')
        await page.screenshot(path=str(out/'world-autumn-editor.png'))
        await page.locator('#clear-env').click()
        await page.wait_for_function('!seedwork.engine.weatherKit')
        record('Explicit detach removes the saved environment config', await page.evaluate('!seedwork.world.environment'))
        record('No editor JavaScript or shader errors were logged', not errors, errors)
        await browser.close()

try:
    asyncio.run(main())
finally:
    (out/'results.json').write_text(json.dumps({'fixture': True, 'renderer': 'Chromium / SwiftShader', 'checks': checks, 'errors': errors, 'comparisons': comparisons}, indent=2))
