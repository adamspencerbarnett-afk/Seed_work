import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { make, check, add, clone, types, meta, canWalk, blocked, height } from '../core/world.mjs';
import { collider } from '../core/spatial.mjs';
import { checkModels, checkRecipe, inputRefs, bindings } from '../core/models.mjs';
import { tool, TOOLS } from '../core/tools.mjs';
import { inspectGlb } from '../core/asset.mjs';

const root = resolve(import.meta.dirname, '..');
const entries = JSON.parse(readFileSync(resolve(root, 'modeler/starter/index.json'))).models;
const entry = id => entries.find(v => v.template === id);
const model = id => { const { report, ...d } = clone(entry(id).result); return d; };
const world = () => { const w = make({ shape: 'valley', relief: 0, water: -5, density: 0, village: false, ruins: false, crystals: false }); w.models = { m_arch: model('arch'), m_part: model('part') }; w.objects = []; return w; };
const delay = ms => new Promise(r => setTimeout(r, ms));

test('native model descriptors validate and enumerate alongside legacy prefabs', () => {
  const w = world(); check(w); assert.equal(types(w).length, 13); assert.equal(meta(w, 'm_arch').cat, 'Models'); assert.equal(Object.keys(bindings(w)).length, 2);
});
test('native model placements retain real-scale defaults and save roundtrip', () => {
  const w = world(), o = add(w, 'm_arch', 0, 0); assert.equal(o.scale, 1); assert.deepEqual(check(JSON.parse(JSON.stringify(w))), w);
});
test('native model schema rejects unknown types, unsafe keys and malformed boxes', () => {
  const w = world(); assert.throws(() => add(w, 'm_missing', 0, 0));
  const bad = clone(w.models); bad.m_arch.boxes[0][0][0] = NaN; assert.throws(() => checkModels(bad));
  assert.throws(() => checkModels({ '../file': model('part') }));
});
test('recipe validation closes unsafe path and prototype routes', () => {
  const d = clone(entry('part').result.recipe); d.materials.steel.image = '../secret.png'; assert.throws(() => checkRecipe(d));
  assert.throws(() => inputRefs(JSON.parse('{"constructor":{}}'))); assert.throws(() => checkRecipe({ ...d, lods: [1, .5] }));
});
test('world generation and recipe tools retain native model definitions', () => {
  const w = world(); assert.deepEqual(tool(w, 'world_make', { seed: 87 }).world.models, w.models); assert.deepEqual(tool(w, 'world_recipe', { prompt: 'snow seed 11' }).world.models, w.models);
});
test('compound arch collision leaves the doorway open and blocks its jambs', () => {
  const w = world(), o = add(w, 'm_arch', 0, 0), y = height(w, 0, 0);
  assert.equal(blocked(w, o, 0, 0, y, y), false); assert.equal(blocked(w, o, 1.015, 0, y, y), true);
  o.rot = 90; assert.equal(blocked(w, o, 0, 1.015, y, y), true); assert.equal(blocked(w, o, .7, 0, y, y), false);
});
test('indexed native compound collision agrees with the reference at 10000 points', () => {
  const w = world(); add(w, 'm_arch', 0, 0, { rot: 34, scale: 1.2 }); add(w, 'm_part', 4, 5, { scale: 2 }); const c = collider(w);
  for (let i = 0; i < 10000; i++) { const x = Math.sin(i * 13.17) * 12, z = Math.cos(i * 7.21) * 12; assert.equal(c.walk(x, z), canWalk(w, x, z)); }
});
test('all compiled starters are embedded static GLBs and preserve triangle and image counts', () => {
  for (const e of entries) { const r = e.result; assert.equal(inspectGlb(readFileSync(resolve(root, 'modeler/starter', r.hash + '.glb'))).hash, r.hash); assert.equal(r.report.raw.drawn_triangles, r.report.packed.drawn_triangles); assert.equal(r.report.raw.image_bytes, r.report.packed.image_bytes); }
});
test('native modeling tool catalog is closed and complete', () => {
  assert.equal(TOOLS.length, 27); assert.equal(TOOLS.filter(t => t.name.startsWith('model_')).length, 7); assert.ok(TOOLS.every(t => t.inputSchema.additionalProperties === false));
});

test('native model API lifecycle, publication and portability', async t => {
  const dirs = [mkdtempSync(resolve(tmpdir(), 'seedwork-models-')), mkdtempSync(resolve(tmpdir(), 'seedwork-copy-'))];
  const port = 23000 + Math.floor(Math.random() * 1000), urls = [0, 1].map(i => `http://127.0.0.1:${port + i}`), servers = [];
  for (let i = 0; i < 2; i++) servers.push(spawn(process.execPath, ['server.mjs'], { cwd: root, env: { ...process.env, PORT: String(port + i), SEEDWORK_DIR: dirs[i], ...(i ? { SEEDWORK_PYTHON: 'missing-seedwork-python' } : {}) }, stdio: 'ignore' }));
  t.after(async () => { servers.forEach(p => p.kill('SIGTERM')); await delay(300); dirs.forEach(p => rmSync(p, { force: true, recursive: true })); });
  const tokens = [];
  for (let i = 0; i < 2; i++) for (let tries = 0; tries < 100; tries++) { try { const v = await (await fetch(urls[i] + '/api/session')).json(); tokens[i] = v.token; break; } catch { await delay(50); } }
  assert.equal(tokens.filter(Boolean).length, 2);
  const req = async (path, data, method = 'POST', i = 0) => { if (data && method !== 'GET') { data = { ...data, key: data.key ?? crypto.randomUUID() }; if (path === '/api/tool' && data.rev === undefined) data.rev = (await (await fetch(urls[i] + '/api/world')).json()).rev; } const r = await fetch(urls[i] + path, { method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tokens[i]}` }, ...(data === undefined ? {} : { body: JSON.stringify(data) }) }); return { status: r.status, ...(await r.json()) }; };
  const call = (name, args = {}, i = 0) => req('/api/tool', { name, args }, 'POST', i);
  const cat = await req('/api/model/catalog', undefined, 'GET');
  const starter = cat.templates.find(t => t.id === 'part').starter;
  let built;
  await t.test('all seven precompiled starters are available using only Node.js', async () => {
    assert.equal(cat.templates.filter(t => t.starter).length, 7); const noPython = await req('/api/model/catalog', undefined, 'GET', 1); assert.equal(noPython.health.ok, true); assert.equal(noPython.templates.filter(t => t.starter).length, 7);
    assert.equal((await call('model_publish', { key: 'm_prebuilt', job: noPython.templates[0].starter }, 1)).status, 200);
  });
  await t.test('compilation queues work without editing the world and returns audited results', async () => {
    assert.ok(cat.health.ok); const before = await req('/api/world', undefined, 'GET'); const d = clone(entry('part').result.recipe); d.parts[0].size[0] = .47;
    let result = await call('model_build', { recipe: d }); assert.equal(result.status, 200); const id = result.result.job.id;
    for (let i = 0; i < 200; i++) { result = await call('model_status', { job: id }); if (['ready', 'failed'].includes(result.result.job.state)) break; await delay(100); }
    built = result.result.job; assert.equal(built.state, 'ready', built.error); assert.ok(built.result.report.exact.passed); assert.equal((await req('/api/world', undefined, 'GET')).rev, before.rev);
    const cached = await call('model_build', { recipe: d }); assert.ok(cached.result.job.cached);
  });
  await t.test('publication is undoable and preserves existing placements when revised', async () => {
    assert.equal((await call('model_publish', { job: starter, key: 'm_part' })).status, 200); await call('object_add', { type: 'm_part', x: 2, z: 8 });
    const before = (await req('/api/world', undefined, 'GET')).world.objects; const updated = await call('model_publish', { job: built.id, key: 'm_part' }); assert.equal(updated.status, 200); assert.deepEqual(updated.world.objects, before);
    assert.ok(Math.abs(updated.world.models.m_part.width - .47) < 1e-6); assert.ok(Math.abs((await call('world_undo')).world.models.m_part.width - .30) < 1e-6); await call('world_redo');
  });
  let sourceBuild, inputHash;
  await t.test('uploaded source PNGs are retained in editable model recipes', async () => {
    const png = readFileSync(resolve(root, 'public/assets/materials/wood-color.png'));
    const res = await fetch(urls[0] + '/api/model/input', { method: 'POST', headers: { 'Content-Type': 'image/png', Authorization: `Bearer ${tokens[0]}` }, body: png }); const info = await res.json(); assert.equal(res.status, 200); inputHash = info.hash;
    const d = clone(entry('part').result.recipe); d.name = 'Source_Map_Part'; d.materials.steel = { kind: 'image', image: info.ref, tex_size: info.width, rough: .7, metal: 0 };
    let r = await call('model_build', { recipe: d }); const id = r.result.job.id;
    for (let i = 0; i < 200; i++) { r = await call('model_status', { job: id }); if (['ready', 'failed'].includes(r.result.job.state)) break; await delay(100); }
    sourceBuild = r.result.job; assert.equal(sourceBuild.state, 'ready', sourceBuild.error); assert.equal((await call('model_publish', { job: id, key: 'm_source' })).status, 200);
    const pack = await req('/api/bundle', undefined, 'GET'); assert.equal(Object.keys(pack.inputs).length, 1); assert.equal(Buffer.compare(Buffer.from(pack.inputs[inputHash], 'base64'), png), 0);
  });
  await t.test('a native world bundle roundtrips into a clean independent server', async () => {
    const pack = await req('/api/bundle', undefined, 'GET'); delete pack.status; const next = await req('/api/world', undefined, 'GET', 1);
    const result = await req('/api/bundle', { pack, rev: next.rev }, 'PUT', 1); assert.equal(result.status, 200); assert.deepEqual(result.world, pack.world);
    assert.equal((await fetch(urls[1] + '/api/asset/' + built.result.hash)).status, 200);
  });
  await t.test('transferred source maps rebuild identically on a fresh compiler', async () => {
    servers[1].kill('SIGTERM'); await delay(400);
    servers[1] = spawn(process.execPath, ['server.mjs'], { cwd: root, env: { ...process.env, PORT: String(port + 1), SEEDWORK_DIR: dirs[1] }, stdio: 'ignore' });
    for (let i = 0; i < 100; i++) { try { tokens[1] = (await (await fetch(urls[1] + '/api/session')).json()).token; break; } catch { await delay(50); } }
    let r = await call('model_build', { recipe: sourceBuild.result.recipe }, 1); const id = r.result.job.id;
    for (let i = 0; i < 200; i++) { r = await call('model_status', { job: id }, 1); if (['ready', 'failed'].includes(r.result.job.state)) break; await delay(100); }
    assert.equal(r.result.job.state, 'ready', r.result.job.error); assert.equal(r.result.job.result.hash, sourceBuild.result.hash);
  });
  await t.test('placed models cannot be silently removed', async () => {
    assert.equal((await call('model_remove', { key: 'm_part' })).status, 400); assert.equal((await call('model_remove', { key: 'm_part', removeObjects: true })).status, 200); assert.ok((await call('world_undo')).world.models.m_part);
  });
  await t.test('bad recipe paths and implicit LOD are rejected before queuing', async () => {
    const d = clone(entry('part').result.recipe); d.materials.steel.image = 'http://remote/image.png'; assert.equal((await call('model_build', { recipe: d })).status, 400); delete d.materials.steel.image; d.lods = [1, .5]; assert.equal((await call('model_build', { recipe: d })).status, 400);
  });
  await t.test('running or queued builds can be cancelled without publishing', async () => {
    const d = clone(entry('drum').result.recipe); d.seed = 89173; const r = await call('model_build', { recipe: d }); assert.equal(r.status, 200); const cancelled = await call('model_cancel', { job: r.result.job.id }); assert.equal(cancelled.result.job.state, 'cancelled');
  });
  await t.test('a corrupted artifact is rejected even for an in-memory ready job', async () => {
    writeFileSync(resolve(dirs[0], 'assets', built.result.hash + '.glb'), 'bad'); assert.equal((await call('model_publish', { job: built.id, key: 'm_bad' })).status, 400);
  });
});
