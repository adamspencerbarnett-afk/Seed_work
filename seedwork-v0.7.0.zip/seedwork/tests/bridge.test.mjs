import test from 'node:test';
import assert from 'node:assert/strict';
import { Bridge } from '../services/bridge.mjs';
import { emptyScene } from '../sdk/core/scene.mjs';
import { digest } from '../services/store.mjs';
const snapshot = (rev = 0, change = null) => { const doc = emptyScene(); return { doc, meta: { project: 'test', rev, change, seq: change ? 1 : null, hash: digest(doc) } }; };
const setup = (t, options) => {
  let live = snapshot(); const b = new Bridge({ manifest: { id: 'test' }, live: () => live }, options);
  t.after(() => b.close()); const h = b.connect({ project: 'test', name: 'Host', three: '140', tests: ['route'], capabilities: ['capture', 'query', 'profile', 'test'] });
  return { b, h, next: () => b.next(h.id, h.token), done: (c, result) => b.complete(h.id, h.token, c.id, result ?? { meta: c.args.meta }), live: v => { live = v; } };
};
const sync = async x => { const c = await x.next(); assert.equal(c.method, 'sync'); x.done(c); };
test('initial committed sync precedes queued preview and cannot overwrite the preview later', async t => {
  const x = setup(t), stage = snapshot(0, 'c_one'), pending = x.b.request(x.h.id, 'preview', stage);
  await sync(x); const c = await x.next(); assert.equal(c.method, 'preview'); x.done(c); await pending;
  assert.deepEqual(x.b.list()[0].scene, stage.meta); assert.equal(x.b.peer(x.h.id).desired, null);
});
test('host tokens are scoped, hidden from discovery, and bound to one session', t => {
  const { b, h } = setup(t); assert.throws(() => b.auth(h.id, 'bad'), e => e.code === 'UNAUTHORIZED'); assert.equal(b.list()[0].token, undefined);
  assert.throws(() => b.connect({ project: 'other', name: 'Other', three: '140', tests: [], capabilities: [] }), e => e.code === 'PROJECT_MISMATCH');
});
test('unsupported host capability and unregistered tests fail before queueing', async t => {
  const { b, h } = setup(t); assert.throws(() => b.request(h.id, 'exec'), e => e.code === 'UNSUPPORTED'); assert.throws(() => b.request(h.id, 'test', { test: 'missing' }), e => e.code === 'UNSUPPORTED');
});
test('a stale response is rejected without accepting evidence and host remains usable', async t => {
  const x = setup(t); await sync(x);
  const pending = x.b.request(x.h.id, 'query'), fail = assert.rejects(pending, e => e.code === 'STALE_EVIDENCE'), c = await x.next();
  const reply = x.done(c, { meta: { ...snapshot().meta, rev: 99 } }); assert.equal(reply.accepted, false); await fail;
  const second = x.b.request(x.h.id, 'query'), cmd = await x.next(); x.done(cmd, { meta: snapshot().meta, items: [] }); assert.deepEqual((await second).items, []);
});
test('command results cannot be submitted by another host or replayed twice', async t => {
  const x = setup(t); const c = await x.next(), other = x.b.connect({ project: 'test', name: 'Other', three: '140', tests: [], capabilities: [] });
  assert.throws(() => x.b.complete(other.id, other.token, c.id, { meta: c.args.meta }), e => e.code === 'EXPIRED');
  x.done(c); assert.throws(() => x.done(c), e => e.code === 'EXPIRED');
});
test('disconnect rejects outstanding commands and clears broker state', async t => {
  const x = setup(t); await sync(x); const pending = x.b.request(x.h.id, 'capture'), fails = assert.rejects(pending, e => e.code === 'HOST_OFFLINE'); x.b.disconnect(x.h.id); await fails; assert.equal(x.b.commands.size, 0); assert.equal(x.b.list().length, 0);
});
test('command timeout accepts no late response and schedules a committed reset', async t => {
  const x = setup(t, { timeout: 25, idle: 2000 }); await sync(x);
  const pending = x.b.request(x.h.id, 'capture'), fails = assert.rejects(pending, e => e.code === 'HOST_TIMEOUT'), c = await x.next();
  await new Promise(resolve => setTimeout(resolve, 60)); await fails;
  assert.throws(() => x.done(c, { meta: snapshot().meta }), e => e.code === 'EXPIRED'); const reset = await x.next(); assert.equal(reset.method, 'sync'); x.done(reset);
});
test('commits reset matching preview hosts but preserve unrelated live drafts', async t => {
  const x = setup(t); await sync(x); const p = x.b.request(x.h.id, 'preview', snapshot(0, 'c_one')), c = await x.next(); x.done(c); await p;
  x.b.sync({ change: 'c_other', ...snapshot(1) }); assert.equal(x.b.peer(x.h.id).desired, null);
  x.b.sync({ change: 'c_one', ...snapshot(1) }); const reset = await x.next(); assert.equal(reset.args.meta.rev, 1); x.done(reset); assert.equal(x.b.list()[0].scene.change, null);
});
test('one long poll per host is enforced and abort releases the waiter', async t => {
  const x = setup(t); await sync(x); const abort = new AbortController(); const pending = x.b.next(x.h.id, x.h.token, abort.signal);
  assert.throws(() => x.b.next(x.h.id, x.h.token), e => e.code === 'CONCURRENT_POLL'); abort.abort(); assert.equal(await pending, null); assert.equal(x.b.peer(x.h.id).waiting, null);
});
