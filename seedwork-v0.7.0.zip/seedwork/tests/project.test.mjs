import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Projects } from '../services/project.mjs';
import { Journal, receipt, digest } from '../services/store.mjs';
import { Worlds } from '../services/world.mjs';
import { copy, stable } from '../sdk/core/schema.mjs';
const manifest = { schema: 'seedwork.project/1', id: 'test', name: 'Test host', units: 'm', up: 'Y', bounds: [[-20, -1, -20], [20, 20, 20]], locked: [], bindings: ['door'], requiredTests: ['route'], review: true, requireCapture: true, evidenceMaxAge: 600 };
const asset = { hash: 'a'.repeat(64), name: 'Test asset', size: [1, 1, 1], boxes: [[[-.5, 0, -.5], [.5, 1, .5]]], tags: ['wood'], sockets: { origin: { pos: [0, 0, 0], rot: [0, 0, 0] }, top: { pos: [0, 1, 0], rot: [0, 0, 0] } }, source: { kind: 'test', ref: 'test.box' } };
const key = () => crypto.randomUUID();
const create = t => {
  const dir = mkdtempSync(join(tmpdir(), 'sw-project-')), file = join(dir, 'project.json'), events = [];
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const p = new Projects(file, manifest, () => ({ 'test.box': copy(asset) }), () => {}, event => events.push(event));
  return { p, file, dir, events };
};
const begin = p => p.begin({ rev: p.state().rev, key: key(), label: 'Add prop' });
const populate = (p, c) => p.apply({ id: c.id, seq: c.seq, key: key(), ops: [{ op: 'asset_use', key: 'box', ref: 'test.box' }, { op: 'item_add', id: 'box_0', asset: 'box', pos: [0, 0, 0] }] });
const evidence = (p, c, host = 'h_test', passed = true) => {
  const meta = p.stage(c.id, c.seq).meta;
  p.evidence(host, 'preview', { meta });
  p.evidence(host, 'capture', { meta, capture: 'c'.repeat(64) });
  p.evidence(host, 'test', { meta, test: 'route', passed, checks: [{ name: 'Host path', passed }] });
};
const hosts = (p, c, host = 'h_test') => [{ id: host, scene: p.stage(c.id, c.seq).meta }];
const commit = (p, c, host = 'h_test') => {
  evidence(p, c, host); p.approve({ id: c.id, seq: c.seq, rev: p.state().rev }, hosts(p, c, host));
  return p.commit({ id: c.id, seq: c.seq, rev: p.state().rev, key: key() }, hosts(p, c, host));
};

test('project stages are isolated from the committed scene and from each other', t => {
  const { p } = create(t), a = begin(p), b = begin(p); populate(p, a);
  assert.equal(p.state().items, 0); assert.equal(p.change(b.id).doc.items.length, 0); assert.equal(p.change(a.id).doc.items.length, 1); assert.equal(p.state().rev, 0);
});
test('observed revision, sequence and retry key are mandatory', t => {
  const { p } = create(t);
  assert.throws(() => p.begin({ label: 'x', rev: 0 }), e => e.code === 'INVALID');
  assert.throws(() => p.begin({ label: 'x', key: key() }), e => e.code === 'PRECONDITION');
  const c = begin(p); assert.throws(() => p.apply({ id: c.id, key: key(), ops: [{ op: 'asset_use', key: 'box', ref: 'test.box' }] }), e => e.code === 'PRECONDITION');
});
test('begin and apply retries return the same result without duplicated objects', t => {
  const { p } = create(t), args = { rev: 0, key: key(), label: 'Retry-safe task' };
  const a = p.begin(args), again = p.begin(args); assert.equal(a.id, again.id); assert.equal(again.replayed, true);
  const edit = { id: a.id, seq: 0, key: key(), ops: [{ op: 'asset_use', key: 'box', ref: 'test.box' }, { op: 'item_add', id: 'box', asset: 'box', pos: [0, 0, 0] }] };
  p.apply(edit); assert.equal(p.apply(edit).replayed, true); assert.equal(p.change(a.id).seq, 1); assert.equal(p.change(a.id).doc.items.length, 1);
  assert.throws(() => p.apply({ ...edit, seq: 1 }), e => e.code === 'KEY_REUSED');
});
test('an invalid operation rolls back the complete batch including draft sequence', t => {
  const { p } = create(t), c = begin(p), before = copy(p.db.state);
  assert.throws(() => p.apply({ id: c.id, seq: 0, key: key(), ops: [{ op: 'asset_use', key: 'box', ref: 'test.box' }, { op: 'item_add', id: 'box', asset: 'box', pos: [0, 0, 0] }, { op: 'item_remove', id: 'missing' }] }), e => e.details.operation === 2);
  assert.deepEqual(p.db.state, before);
});
test('commit requires preview, capture, passing registered tests and explicit approval', t => {
  const { p } = create(t), c = populate(p, begin(p)), args = { id: c.id, seq: c.seq, rev: 0, key: key() };
  assert.throws(() => p.commit(args, hosts(p, c)), e => e.code === 'EVIDENCE_REQUIRED');
  evidence(p, c); assert.throws(() => p.commit(args, hosts(p, c)), e => e.code === 'APPROVAL_REQUIRED');
  p.approve({ id: c.id, seq: c.seq, rev: 0 }, hosts(p, c)); const out = p.commit(args, hosts(p, c));
  assert.equal(out.rev, 1); assert.equal(p.state().items, 1); assert.equal(p.state().undo, 1);
});
test('failed or expired host evidence cannot be approved', t => {
  const { p } = create(t), c = populate(p, begin(p)); evidence(p, c, 'h_test', false);
  assert.throws(() => p.approve({ id: c.id, seq: 1, rev: 0 }, hosts(p, c)), e => e.details.missing.includes('test:route'));
  evidence(p, c); for (const e of p.change(c.id).evidence) e.at = Date.now() - 700000;
  assert.throws(() => p.approve({ id: c.id, seq: 1, rev: 0 }, hosts(p, c)), e => e.code === 'EVIDENCE_REQUIRED');
});
test('evidence must belong to the same preview host, hash and sequence', t => {
  const { p } = create(t), c = populate(p, begin(p)); evidence(p, c, 'h_test');
  const meta = p.stage(c.id, c.seq).meta;
  p.evidence('h_other', 'preview', { meta }); assert.ok(p.check(c.id).missing.includes('capture'));
  assert.throws(() => p.evidence('h_other', 'capture', { meta: { ...meta, hash: 'b'.repeat(64) }, capture: 'c'.repeat(64) }), e => e.code === 'STALE_EVIDENCE');
  assert.throws(() => p.evidence('h_other', 'capture', { meta: { ...meta, seq: 0 }, capture: 'c'.repeat(64) }), e => e.code === 'CONFLICT');
});
test('any draft edit clears captures, tests, preview and prior approval', t => {
  const { p } = create(t), c = populate(p, begin(p)); evidence(p, c); p.approve({ id: c.id, seq: 1, rev: 0 }, hosts(p, c));
  const edited = p.apply({ id: c.id, seq: 1, key: key(), ops: [{ op: 'item_set', id: 'box_0', patch: { pos: [2, 0, 0] } }] });
  assert.equal(edited.seq, 2); assert.equal(edited.approval, null); assert.equal(edited.preview, null); assert.deepEqual(edited.evidence, []);
});
test('latest failing test replaces older success and invalidates approval', t => {
  const { p } = create(t), c = populate(p, begin(p)); evidence(p, c); p.approve({ id: c.id, seq: 1, rev: 0 }, hosts(p, c));
  p.evidence('h_test', 'test', { meta: p.stage(c.id, 1).meta, test: 'route', passed: false, checks: [{ name: 'blocked', passed: false }] });
  assert.equal(p.change(c.id).approval, null); assert.ok(p.check(c.id).missing.includes('test:route')); assert.equal(p.change(c.id).evidence.filter(e => e.type === 'test').length, 1);
});
test('offline preview host cannot approve or commit a scene', t => {
  const { p } = create(t), c = populate(p, begin(p)); evidence(p, c);
  assert.throws(() => p.approve({ id: c.id, seq: 1, rev: 0 }, []), e => e.code === 'EVIDENCE_REQUIRED');
  p.approve({ id: c.id, seq: 1, rev: 0 }, hosts(p, c)); assert.throws(() => p.commit({ id: c.id, seq: 1, rev: 0, key: key() }, []), e => e.code === 'EVIDENCE_REQUIRED');
});
test('a competing commit makes older drafts stale rather than rebasing them silently', t => {
  const { p } = create(t), a = populate(p, begin(p)), b = begin(p); commit(p, a);
  assert.equal(p.view(p.change(b.id)).stale, true);
  assert.throws(() => p.apply({ id: b.id, seq: 0, key: key(), ops: [{ op: 'asset_use', key: 'box', ref: 'test.box' }] }), e => e.code === 'CONFLICT');
  assert.throws(() => p.stage(b.id, 0), e => e.code === 'CONFLICT');
});
test('commit retry is safe after another edit and restart preserves durable receipts', t => {
  const { p, file } = create(t), c = populate(p, begin(p)); evidence(p, c); p.approve({ id: c.id, seq: 1, rev: 0 }, hosts(p, c));
  const args = { id: c.id, seq: 1, rev: 0, key: key() }; p.commit(args, hosts(p, c)); const once = readFileSync(file, 'utf8');
  assert.equal(p.commit(args, []).replayed, true); assert.equal(p.state().rev, 1);
  const restored = new Projects(file, manifest, () => ({ 'test.box': asset }), () => {}); assert.equal(restored.commit(args, []).replayed, true); assert.equal(restored.state().rev, 1); assert.ok(once.length);
});
test('restart retains drafts but invalidates live-host evidence and approval', t => {
  const { p, file } = create(t), c = populate(p, begin(p)); evidence(p, c); p.approve({ id: c.id, seq: 1, rev: 0 }, hosts(p, c));
  const restored = new Projects(file, manifest, () => ({ 'test.box': asset }), () => {}), draft = restored.change(c.id);
  assert.equal(draft.doc.items.length, 1); assert.equal(draft.seq, 1); assert.equal(draft.approval, null); assert.equal(draft.preview, null); assert.equal(draft.evidence.length, 0);
});
test('undo and redo are exact reviewed proposals, with persistent history', t => {
  const { p, file } = create(t), c = populate(p, begin(p)), initial = p.state().doc; commit(p, c); const authored = p.state().doc;
  const undo = p.begin({ rev: 1, key: key(), label: 'Undo', history: 'undo' }); assert.deepEqual(p.change(undo.id).doc, initial); assert.deepEqual(p.state().doc, authored);
  assert.throws(() => p.apply({ id: undo.id, seq: 0, key: key(), ops: [{ op: 'asset_use', key: 'box', ref: 'test.box' }] }), e => e.code === 'HISTORY_LOCK');
  commit(p, undo); assert.deepEqual(p.state().doc, initial); assert.equal(p.state().redo, 1);
  const restored = new Projects(file, manifest, () => ({ 'test.box': asset }), () => {}), redo = restored.begin({ rev: 2, key: key(), label: 'Redo', history: 'redo' }); commit(restored, redo); assert.deepEqual(restored.state().doc, authored);
});
test('discard leaves committed content untouched and emits a host reset notification', t => {
  const { p, events } = create(t), c = populate(p, begin(p)), args = { id: c.id, seq: 1, key: key() };
  p.discard(args); assert.equal(p.state().items, 0); assert.equal(p.state().rev, 0); assert.equal(events.length, 1); assert.equal(events[0].meta.change, null); assert.equal(p.discard(args).replayed, true); assert.equal(events.length, 1);
});
test('failed persistence never exposes an uncommitted in-memory change', t => {
  const { p } = create(t), before = copy(p.db.state); p.db.persist = () => { throw Error('disk full'); };
  assert.throws(() => begin(p), /disk full/); assert.deepEqual(p.db.state, before);
});
test('asset search filters before bounded pagination and omits recipes from results', t => {
  const { p } = create(t); assert.equal(p.search({ tags: ['wood'] }).assets.length, 1); assert.equal(p.search({ maxSize: [.5, 2, 2] }).assets.length, 0);
  const found = p.search().assets[0]; assert.equal(found.ref, 'test.box'); assert.equal(found.source.recipe, undefined); assert.equal(found.boxCount, 1);
});
test('journal rejects async work and receipts reject mismatched arguments', () => {
  let writes = 0; const j = new Journal(null, { receipts: [], value: 0 }, () => {}, () => writes++);
  assert.throws(() => j.atomic(async s => s.value++), e => e.code === 'ASYNC_TRANSACTION'); assert.equal(j.state.value, 0); assert.equal(writes, 0);
  const args = { op: 'x' }; j.atomic(s => receipt(s, 'key', args, () => ({ value: ++s.value })));
  j.atomic(s => receipt(s, 'key', args, () => ({ value: ++s.value }))); assert.equal(j.state.value, 1);
  assert.throws(() => j.atomic(s => receipt(s, 'key', { op: 'y' }, () => ({}))), e => e.code === 'KEY_REUSED');
});
test('world batch is one durable revision and one undo step, with atomic failure', async t => {
  const { dir } = create(t), w = new Worlds(join(dir, 'world.json'), {}, () => {}), before = copy(w.state().world);
  const args = { ops: [{ name: 'terrain_set', args: { relief: 8 } }, { name: 'terrain_set', args: { water: -4 } }] };
  const request = key(), out = await w.call('world_batch', args, 0, request);
  assert.equal(out.rev, 1); assert.equal(out.undo, 1); assert.equal(out.result.operations, 2);
  assert.equal((await w.call('world_batch', args, 0, request)).replayed, true); assert.equal(w.state().rev, 1);
  const saved = copy(w.state().world);
  await assert.rejects(w.call('world_batch', { ops: [{ name: 'terrain_set', args: { relief: 13 } }, { name: 'object_remove', args: { id: 'missing' } }] }, 1, key()));
  assert.deepEqual(w.state().world, saved); assert.equal(w.state().rev, 1);
  await w.call('world_undo', {}, 1, key()); assert.deepEqual(w.state().world, before);
});
test('world missing revision is rejected even though a valid retry key is present', async t => {
  const { dir } = create(t), w = new Worlds(join(dir, 'world.json'), {}, () => {});
  await assert.rejects(w.call('terrain_set', { relief: 8 }, undefined, key()), e => e.code === 'PRECONDITION'); assert.equal(w.state().rev, 0);
});
test('world retry returns current state instead of rolling the client back to receipt revision', async t => {
  const { dir } = create(t), w = new Worlds(join(dir, 'world.json'), {}, () => {}), request = key();
  await w.call('terrain_set', { relief: 8 }, 0, request); await w.call('terrain_set', { relief: 12 }, 1, key());
  const replay = await w.call('terrain_set', { relief: 8 }, 0, request); assert.equal(replay.rev, 2); assert.equal(replay.receiptRev, 1); assert.equal(replay.world.terrain.relief, 12);
});

test('a connected host displaying another draft cannot approve earlier evidence', t => {
  const { p } = create(t), c = populate(p, begin(p)); evidence(p, c);
  const wrong = [{ id: 'h_test', scene: { ...p.stage(c.id, c.seq).meta, change: 'c_other' } }];
  assert.throws(() => p.approve({ id: c.id, seq: 1, rev: 0 }, wrong), e => e.code === 'EVIDENCE_REQUIRED');
  p.approve({ id: c.id, seq: 1, rev: 0 }, hosts(p, c));
  assert.throws(() => p.commit({ id: c.id, seq: 1, rev: 0, key: key() }, wrong), e => e.code === 'EVIDENCE_REQUIRED');
});
