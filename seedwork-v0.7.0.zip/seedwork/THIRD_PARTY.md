# Attribution and bundled permissions — Seedwork 0.7.0

## Project stewardship and original additions

Project direction, requested design and release credit: **Adam S. Barnett**. This toolkit was developed with AI assistance. This credit does not claim that Adam authored Three.js, owns third-party implementations, or personally wrote every line.

The new Node model compiler, file-based plan workflow and release tooling were authored for this release. They use credited Three.js geometry constructors rather than claiming to have independently implemented Three.js. Imports do not erase authorship of surrounding original code, and a translation or conversion does not by itself remove upstream rights.

The short commercial permission grant for new controlled rights is in the root README. Earlier Seedwork code, recipes, material generators, SDK and procedural artwork retain their original MIT notice in `notices/seedwork-prior-MIT.txt`; the SDK also retains `sdk/LICENSE`. These inherited notices were moved or preserved, not revoked or assigned to a different person. The permission grant is not a replacement for those notices.

## Three.js r140 and GLTFLoader

Files: `public/vendor/three-r140.min.js`, `public/vendor/GLTFLoader-r140.js`, and `public/vendor/THREE-LICENSE.txt`.

Copyright © 2010–2022 Three.js authors. MIT. The complete notice and existing source headers remain bundled. Source: https://github.com/mrdoob/three.js/tree/r140 . License: https://github.com/mrdoob/three.js/blob/r140/LICENSE .

The earlier Seedwork package obtained these JavaScript blocks from the Three.js distribution embedded in the preinstalled trimesh viewer template. No trimesh Python implementation or viewer application is bundled. The runtime reports revision 140. The minified loader is a carried-forward formatting variant; it is **not** claimed to be byte-identical to the upstream unminified file.

On September 24, 2026 the upstream r140 file identifiers were checked through GitHub. The core runtime matches the upstream file when its missing final newline is restored for comparison. The license is byte-identical. The loader's local and upstream hashes differ, as expected for the formatting variant; this release records that difference rather than asserting independently established full equivalence. See `notices/vendor-verification.json`. Pinned does not mean current or security-certified.

## Procedural content

The 31 base PNG maps in `public/assets/materials/` were authored procedurally for earlier Seedwork releases, not downloaded scans, measured material samples or proprietary artwork. Their manifest remains alongside them. Environment particles, leaf/ice detail, app mark, procedural prefabs and example recipes are Seedwork-authored content under the applicable inherited notice and release permission.

All seven native GLBs under `modeler/starter/` have been rebuilt with the new Node compiler. `modeler/starter/index.json` records their recipes, hashes, source fingerprint and exact compaction audit. Their geometry is compiled from original Seedwork recipes with Three.js and original assembly code; their embedded PBR maps are produced by the new compiler. They are not the old kit's precompiled outputs.

No font binaries, paid asset library, neural weights, proprietary Higgsfield content, Poly Haven download or third-party water repository source is included. Documentation images in this release are application captures, not upstream promotional images.

## Removed component

The uploaded AI 3D Chat Kit 9.1 had no clear top-level redistribution permission. Its source, demonstrations, compiled outputs and Python package environment are excluded. The new compiler is a separately implemented subset, not a license-clearing translation of that kit. Unsupported legacy stamp, sculpt and decal operations are rejected explicitly. Seedwork-authored recipe documents and public data format compatibility remain; their retention does not purport to license the removed implementation.

## User content and optional developer tools

User imports, future plug-ins and external generation services retain their own terms. Importing or converting an asset does not make it royalty-free. Review those terms separately before publishing a game.

Node.js, browsers, TypeScript, optional Python browser-test packages and GitHub-hosted Actions are not bundled binaries or runtime package dependencies in this ZIP. The offline Node editor/compiler/test workflow does not install packages. Optional browser/type validation requires its documented developer tools separately. GitHub Actions references are pinned and run only on GitHub when the repository owner enables them.
