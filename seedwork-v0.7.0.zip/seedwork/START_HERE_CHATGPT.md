# Start here: build a world with Seedwork 0.7.0

## Message to paste into ChatGPT

> I have attached the Seedwork world-builder release. Extract it when your available tools support archives. Read START_HERE_CHATGPT.md, AGENTS.md, seedwork-capabilities.json, plan.schema.json and the relevant tool schemas before making changes. Help me build a playable world, using the supplied deterministic modeling/world tools rather than replacing the engine with a new ad-hoc demo. My idea is: [describe the setting, game type, camera and what the player does]. Ask for any essential missing requirements, propose a small first playable milestone, then produce a validated plan and an updated self-contained project ZIP. Preserve notices, existing features and user files. Never claim that a build, browser capture, performance test or live connection worked unless you actually ran it.

## What the upload provides

This release contains the engine source, renderer, loader, original procedural assets, independent model compiler, editor, environment tools, tests, examples and documentation. There are no model weights or paid generation services. An AI assistant adds planning, coding and review using the tools available in its current environment.

An upload does not register Seedwork tools with ChatGPT, start a browser on your computer, or expose your local server. ChatGPT file handling and code execution vary by account, model and workspace. If the conversation cannot extract the ZIP, extract it locally and upload this guide, `seedwork-capabilities.json`, `tools.manifest.json`, the relevant source files and the world/recipe being edited. If Node execution is unavailable in the conversation, the assistant should provide a plan and complete changed files for local validation, explicitly marking unrun checks.

## First working loop

Inside an environment with Node.js 22+, start by running:

```sh
node seedwork.mjs doctor
node seedwork.mjs context
node seedwork.mjs schema
```

Choose a supplied plan under `examples/plans/`, then create or edit a JSON plan. Plans describe supported operations and optional model templates/recipes; they do not contain executable commands or remote URLs. Validate structure before generating:

```sh
node seedwork.mjs validate --plan examples/plans/autumn-settlement.json
node seedwork.mjs new --plan examples/plans/autumn-settlement.json --out ../my-world
```

The output contains the application plus `project/plan.json`, `project/start.seedpack.json`, a JSON-only world, and a generation report. Run the resulting project locally:

```sh
cd ../my-world
node server.mjs
```

Open `http://127.0.0.1:4173/`. Inspect the world in the editor, use Play world, and save a world-plus-assets bundle before major revisions. Loading only the world JSON does not transfer imported GLB or PNG bytes. The generated project is a playable authoring scaffold; its game rules still need deliberate implementation and testing.

## Continue efficiently

Inspect the relevant scene region and current revision; reuse existing assets; modify a recipe only when necessary; batch ordinary world changes; review the actual result; run the existing tests; return complete source changes and the preserved project. For an existing game, use the embedded SDK contracts and registered host tests rather than taking ownership of its renderer or controls.

Live editing through the local API needs the running local server and its generated authoring token. The stdio MCP bridge supports the documented local clients, not direct browser upload installation. A hosted ChatGPT integration would need a separately deployed/authenticated supported app or MCP transport; this release intentionally does not expose its loopback service to the internet.

## Required truth checks

Keep the 0.5 advanced-water gap and the unsupported legacy sculpt/stamp features visible. Do not relabel procedural art as scans. Do not treat source-file availability as proof that the browser rendered it. Do not report CPU microbenchmarks as full-game FPS. Do not lower detail automatically to pass a performance target. Do not delete third-party notices or assume newly imported content is commercially usable.

## Current official guidance

Reviewed September 24, 2026. Capabilities and product UI can change; use current official documentation when setting up an external connection.

- OpenAI, data analysis and supported file capabilities: https://help.openai.com/en/articles/8437071-data-analysis-with-chatgpt
- OpenAI, developer mode and MCP apps, including the local/remote distinction: https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt
- OpenAI, Apps SDK overview: https://help.openai.com/en/articles/12515353-build-with-the-apps-sdk
