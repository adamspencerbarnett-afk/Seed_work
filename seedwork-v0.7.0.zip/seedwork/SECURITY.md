# Security and release boundaries

Seedwork is a local development toolkit. Keep the service bound to loopback. Do not expose it publicly or tunnel it to an assistant without separate authenticated remote-service design and review. A ZIP upload does not need such exposure.

`.seedwork/` holds session credentials and editable user data. It is excluded from packaged source. Host authoring credentials authorize local review/publication; the review UI is a workflow boundary, not proof of human identity. Never commit those credentials, environment files or private input maps.

Recipes and plans are validated data. Unknown fields and unsupported operations fail. The worker executes trusted bundled code through a fixed Node entry point; it does not evaluate recipe scripts or build shell commands. Process limits and timeouts reduce risk but do not constitute a complete adversarial sandbox. Treat imported GLBs and PNGs as untrusted and preserve the input validators.

Offline generation is read-only with respect to existing output directories. Release scripts reject symlinks and exclude known runtime/cache/private paths. Checksums detect changed packaged files; they are not signatures or proof that code is safe. Dependency r140 remains old and needs a separate migration/security review before high-trust deployment.

Do not attach credentials or private game assets to public bug reports. Report reproducible security issues privately to the eventual repository maintainer; no fabricated contact address is supplied in this preparation.
