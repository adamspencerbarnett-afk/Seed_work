import http from 'node:http';
import { readFileSync, writeFileSync, mkdirSync, renameSync, existsSync, statSync, unlinkSync, openSync, closeSync } from 'node:fs';
import { dirname, resolve, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { check } from './core/world.mjs';
import { inspectGlb, ASSET_MAX } from './core/asset.mjs';
import { Modeler, inspectPng } from './modeler/service.mjs';
import { bindings, worldInputs } from './core/models.mjs';
import { Worlds } from './services/world.mjs';
import { Projects, assetFrom } from './services/project.mjs';
import { Bridge } from './services/bridge.mjs';
import { ToolService, toolCatalog } from './services/tools.mjs';
import { Fault, obj, id, str, int, validate } from './sdk/core/schema.mjs';
import { needRev } from './services/store.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT ?? 4173);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('PORT must be an integer from 1024 to 65535.');
const dir = resolve(process.env.SEEDWORK_DIR ?? resolve(root, '.seedwork'));
mkdirSync(dir, { recursive: true, mode: 0o700 });
const lock = resolve(dir, 'server.lock');
if (existsSync(lock)) {
  const pid = Number(readFileSync(lock, 'utf8'));
  if (!Number.isSafeInteger(pid) || pid <= 0) throw new Error(`Invalid ${lock}. Check for another server before removing it.`);
  let alive = true;
  try { process.kill(pid, 0); } catch (e) { if (e.code === 'ESRCH') alive = false; }
  if (alive) throw new Error(`SEEDWORK_DIR is already owned by process ${pid}. Use a different data directory.`);
  unlinkSync(lock);
}
const fd = openSync(lock, 'wx', 0o600); writeFileSync(fd, String(process.pid)); closeSync(fd);
process.on('exit', () => { try { if (readFileSync(lock, 'utf8') === String(process.pid)) unlinkSync(lock); } catch {} });
const assetDir = resolve(dir, 'assets'), captures = resolve(dir, 'captures');
for (const p of [assetDir, captures]) mkdirSync(p, { recursive: true, mode: 0o700 });
const assetFile = hash => resolve(assetDir, `${hash}.glb`);
function checkAssets(w) {
  for (const hash of Object.values(bindings(w))) if (!existsSync(assetFile(hash))) throw new Error('World references a missing GLB. Import its .seedpack.json bundle instead of standalone JSON.');
  for (const hash of worldInputs(w)) if (!existsSync(resolve(dir, 'model-inputs', `${hash}.png`))) throw new Error('World references a missing recipe input PNG. Import its bundle.');
}
const modeler = new Modeler(root, dir, assetFile);
const clients = new Set();
const notify = event => { for (const client of clients) client.write(`data: ${JSON.stringify(event)}\n\n`); };
const firstStart = !existsSync(resolve(dir, 'world.json'));
const worlds = new Worlds(resolve(dir, 'world.json'), modeler, checkAssets, notify);
checkAssets(worlds.state().world);
const manifest = JSON.parse(readFileSync(resolve(process.env.SEEDWORK_PROJECT ?? resolve(root, 'seedwork.json')), 'utf8'));
const assets = () => {
  const out = {};
  for (const entry of modeler.catalog.templates) {
    if (!entry.starter) continue;
    const result = modeler.get(entry.starter).result;
    out[`starter.${entry.id}`] = assetFrom(result, `starter.${entry.id}`, [entry.id, 'procedural', ...Object.values(result.recipe.materials ?? {}).map(m => m.kind).filter(Boolean)]);
  }
  for (const [key, model] of Object.entries(worlds.state().world.models ?? {})) out[`world.${key}`] = assetFrom(model, `world.${key}`, ['published', ...Object.values(model.recipe.materials ?? {}).map(m => m.kind).filter(Boolean)]);
  for (const job of modeler.jobs.values()) if (job.state === 'ready' && job.created !== 0) {
    const ref = `build.${job.id.slice(0, 48)}`;
    out[ref] = assetFrom(job.result, ref, ['local-build', ...Object.values(job.result.recipe.materials ?? {}).map(m => m.kind).filter(Boolean)]);
  }
  return out;
};
let bridge;
const project = new Projects(resolve(dir, 'project.json'), manifest, assets, doc => {
  for (const asset of Object.values(doc.assets)) if (!existsSync(assetFile(asset.hash))) throw new Fault('MISSING_ASSET', 'Project references a missing GLB.', { hash: asset.hash });
}, event => { bridge.sync(event); notify({ projectRev: event.meta.rev, source: event.type }); });
bridge = new Bridge(project);
const tools = new ToolService(worlds, project, bridge, captures);
const token = randomBytes(32).toString('hex');
writeFileSync(resolve(dir, 'token'), token, { mode: 0o600 });
const own = [`http://127.0.0.1:${port}`, `http://localhost:${port}`];
const allowed = (process.env.SEEDWORK_ORIGINS ?? '').split(',').map(s => s.trim()).filter(Boolean);
for (const origin of allowed) {
  const url = new URL(origin);
  if (url.origin !== origin || url.protocol !== 'http:' || !['localhost', '127.0.0.1'].includes(url.hostname) || url.username || url.password) throw new Error('SEEDWORK_ORIGINS accepts exact loopback http origins only.');
}
const auth = req => {
  const a = Buffer.from(String(req.headers.authorization ?? '').replace(/^Bearer /, '')), b = Buffer.from(token);
  return a.length === b.length && timingSafeEqual(a, b);
};
function json(res, code, value) {
  if (res.destroyed || res.writableEnded) return;
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(value));
}
async function raw(req, max, type) {
  if (!String(req.headers['content-type']).startsWith(type)) throw new Fault('CONTENT_TYPE', `Content-Type must be ${type}.`);
  let total = 0; const chunks = [];
  for await (const chunk of req) { total += chunk.length; if (total > max) throw new Fault('LIMIT', `Request exceeds ${max / 1024 / 1024} MiB.`, {}, 413); chunks.push(chunk); }
  return Buffer.concat(chunks);
}
const body = async (req, max = 8 * 1024 * 1024) => JSON.parse((await raw(req, max, 'application/json')).toString('utf8'));
const writeBlob = (target, bytes) => { if (!existsSync(target)) { writeFileSync(`${target}.tmp`, bytes, { mode: 0o600 }); renameSync(`${target}.tmp`, target); } };
const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.glb': 'model/gltf-binary', '.txt': 'text/plain; charset=utf-8' };
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
  if (!own.map(s => new URL(s).host).includes(req.headers.host)) return json(res, 403, { error: 'Untrusted Host header.' });
  const origin = req.headers.origin, external = origin && allowed.includes(origin);
  if (origin && !own.includes(origin) && !external) return json(res, 403, { error: 'Cross-origin access is not allowed.' });
  if (req.headers['sec-fetch-site'] === 'cross-site' && !external) return json(res, 403, { error: 'Cross-site access is not allowed.' });
  if (external) {
    res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization'); res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
  }
  try {
    const url = new URL(req.url, own[0]), path = decodeURIComponent(url.pathname);
    if (path === '/api/session' && req.method === 'GET') {
      if (external) throw new Fault('UNAUTHORIZED', 'Use an explicitly supplied token for a cross-origin development host.', {}, 403);
      return json(res, 200, { token, version: '0.7.0', runtime: 'Editor Three.js r140; SDK uses the host namespace', ...worlds.state(), project: project.state(false) });
    }
    if (path === '/api/world' && req.method === 'GET') return json(res, 200, worlds.state());
    if (path === '/api/model/catalog' && req.method === 'GET') return json(res, 200, { ...modeler.catalog, health: await modeler.health });
    if (path === '/api/tools' && req.method === 'GET') return json(res, 200, { tools: toolCatalog(url.searchParams.get('wire') === '1') });
    if (/^\/api\/asset\/[a-f0-9]{64}$/.test(path) && req.method === 'GET') {
      const target = assetFile(path.split('/').at(-1));
      if (!existsSync(target)) throw new Fault('NOT_FOUND', 'Asset not found.', {}, 404);
      res.writeHead(200, { 'Content-Type': 'model/gltf-binary', 'Cache-Control': 'private, max-age=31536000, immutable' }); res.end(readFileSync(target)); return;
    }
    if (path === '/api/events' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
      res.write(': connected\n\n'); clients.add(res); req.on('close', () => clients.delete(res)); return;
    }
    if (['/api/host/next', '/api/host/done', '/api/host/close'].includes(path) && req.method === 'POST') {
      const data = await body(req, 16 * 1024 * 1024), secret = String(req.headers.authorization ?? '').replace(/^Bearer /, '');
      validate(data, obj({ id, command: id, result: { type: 'object' }, error: { type: 'object' } }, ['id']));
      if (path === '/api/host/next') {
        const abort = new AbortController(); res.on('close', () => abort.abort());
        return json(res, 200, await bridge.next(data.id, secret, abort.signal));
      }
      if (path === '/api/host/done') return json(res, 200, bridge.complete(data.id, secret, data.command, data.result, data.error));
      bridge.auth(data.id, secret); bridge.disconnect(data.id); return json(res, 200, { closed: true });
    }
    if (path.startsWith('/api/')) {
      if (!auth(req)) throw new Fault('UNAUTHORIZED', 'A local authoring token is required.', {}, 401);
      if (req.method === 'POST' && path === '/api/host/open') return json(res, 200, bridge.connect(await body(req, 65536)));
      if (req.method === 'GET' && path === '/api/project') return json(res, 200, { ...project.state(), manifest: project.manifest, hosts: bridge.list(), changes: project.inspect().changes });
      if (req.method === 'POST' && path === '/api/project/approve') {
        const data = await body(req); validate(data, obj({ id, seq: int(), rev: int() }, ['id', 'seq', 'rev']));
        return json(res, 200, project.approve(data, bridge.list()));
      }
      if (req.method === 'GET' && /^\/api\/capture\/[a-f0-9]{64}$/.test(path)) {
        const file = resolve(captures, `${path.split('/').at(-1)}.png`);
        if (!existsSync(file)) throw new Fault('NOT_FOUND', 'Capture not found.', {}, 404);
        res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'no-store' }); res.end(readFileSync(file)); return;
      }
      if (req.method === 'POST' && path === '/api/tool') { const data = await body(req); try { return json(res, 200, await tools.call(data)); } catch (e) { if (data && !data.name?.startsWith('change_') && !data.name?.startsWith('project_') && !data.name?.startsWith('scene_')) e.worldConflict = true; throw e; } }
      if (req.method === 'POST' && path === '/api/asset') {
        const bytes = await raw(req, ASSET_MAX, 'model/gltf-binary'), info = inspectGlb(bytes); writeBlob(assetFile(info.hash), bytes); return json(res, 200, info);
      }
      if (req.method === 'POST' && path === '/api/model/input') {
        const bytes = await raw(req, 16 * 1024 * 1024, 'image/png'), info = inspectPng(bytes);
        writeBlob(resolve(modeler.inputs, `${info.hash}.png`), bytes); return json(res, 200, { ...info, ref: `inputs/${info.hash}.png` });
      }
      if (req.method === 'GET' && path === '/api/bundle') return json(res, 200, bundle());
      if (req.method === 'PUT' && path === '/api/bundle') return json(res, 200, importBundle(await body(req, 104 * 1024 * 1024)));
      if (req.method === 'PUT' && path === '/api/world') { const data = await body(req); return json(res, 200, worlds.replace(data.world, data.rev, data.key)); }
      throw new Fault('NOT_FOUND', 'API route not found.', {}, 404);
    }
    if (!['GET', 'HEAD'].includes(req.method)) throw new Fault('METHOD', 'Method not allowed.', {}, 405);
    const publicRoot = resolve(root, 'public');
    let target;
    const library = ['/core/', '/sdk/'].find(prefix => path.startsWith(prefix));
    if (library) { const base = resolve(root, library.slice(1)); target = resolve(root, `.${path}`); if (!target.startsWith(base + sep)) throw new Fault('PATH', 'Invalid path.', {}, 403); }
    else { target = resolve(publicRoot, path === '/' ? 'index.html' : path === '/host' || path === '/host/' ? 'host/index.html' : path === '/environment' || path === '/environment/' ? 'environment/index.html' : `.${path}`); if (!target.startsWith(publicRoot + sep)) throw new Fault('PATH', 'Invalid path.', {}, 403); }
    if (!existsSync(target) || !statSync(target).isFile()) throw new Fault('NOT_FOUND', 'File not found.', {}, 404);
    res.writeHead(200, { 'Content-Type': mime[extname(target)] ?? 'application/octet-stream', 'Cache-Control': 'no-cache' }); res.end(req.method === 'HEAD' ? undefined : readFileSync(target));
  } catch (e) {
    json(res, e.status ?? 400, { error: e.message, code: e.code ?? 'INVALID', details: e.details ?? {}, ...(e.code === 'CONFLICT' && e.worldConflict ? worlds.state() : {}) });
  }
});
function bundle() {
  const world = worlds.state().world, hashes = [...new Set(Object.values(bindings(world)))], inputs = worldInputs(world); checkAssets(world);
  const total = hashes.reduce((n, h) => n + statSync(assetFile(h)).size, 0) + inputs.reduce((n, h) => n + statSync(resolve(modeler.inputs, `${h}.png`)).size, 0);
  if (total > 64 * 1024 * 1024) throw new Error('Bundle exceeds the 64 MiB binary-data limit. Copy the local data folder for larger projects.');
  return { seedworkPack: 1, world, assets: Object.fromEntries(hashes.map(h => [h, readFileSync(assetFile(h)).toString('base64')])), inputs: Object.fromEntries(inputs.map(h => [h, readFileSync(resolve(modeler.inputs, `${h}.png`)).toString('base64')])) };
}
function importBundle(data) {
  needRev(data.rev, worlds.state().rev);
  const pack = data.pack;
  if (pack?.seedworkPack !== 1 || !pack.assets || typeof pack.assets !== 'object' || Array.isArray(pack.assets)) throw new Error('Invalid Seedwork bundle.');
  const next = check(pack.world), blobs = [], hashes = [...new Set(Object.values(bindings(next)))], inputs = worldInputs(next);
  if (Object.keys(pack.assets).some(h => !hashes.includes(h))) throw new Error('Bundle includes an unreferenced asset.');
  if (pack.inputs !== undefined && (!pack.inputs || typeof pack.inputs !== 'object' || Array.isArray(pack.inputs) || Object.keys(pack.inputs).some(h => !inputs.includes(h)))) throw new Error('Invalid or unreferenced bundle recipe inputs.');
  let total = 0;
  for (const [set, keys, file, inspect] of [[pack.assets, hashes, assetFile, inspectGlb], [pack.inputs ?? {}, inputs, h => resolve(modeler.inputs, `${h}.png`), inspectPng]]) {
    for (const h of keys) {
      if (typeof set[h] !== 'string' || !/^[A-Za-z0-9+/]*={0,2}$/.test(set[h])) throw new Error('Bundle is missing a valid base64 asset.');
      const bytes = Buffer.from(set[h], 'base64'); total += bytes.length;
      if (total > 64 * 1024 * 1024) throw new Error('Bundle assets exceed 64 MiB.');
      if (inspect(bytes).hash !== h) throw new Error('Bundle asset hash mismatch.'); blobs.push([file(h), bytes]);
    }
  }
  for (const [target, bytes] of blobs) writeBlob(target, bytes);
  return worlds.replace(next, data.rev, data.key, 'bundle-import');
}
if (firstStart && existsSync(resolve(root, 'project/start.seedpack.json'))) {
  const file = resolve(root, 'project/start.seedpack.json');
  if (statSync(file).size > 96 * 1024 * 1024) throw new Error('Initial project bundle exceeds 96 MiB.');
  importBundle({ pack: JSON.parse(readFileSync(file, 'utf8')), rev: 0, key: 'initial-project' });
}
server.requestTimeout = 20000; server.headersTimeout = 10000;
const pulse = setInterval(() => { for (const c of clients) c.write(': heartbeat\n\n'); }, 15000); pulse.unref();
server.on('error', e => { console.error(`Cannot start Seedwork: ${e.message}`); process.exit(1); });
server.listen(port, '127.0.0.1', () => {
  try { worlds.flush(); project.db.persist(project.db.state); } catch (e) { console.error(e.message); process.exit(1); }
  console.log(`Seedwork v0.7.0 · Community Release · ${own[0]}\nHost integration: ${own[0]}/host/\nLocal data: ${dir}\nPress Ctrl+C to stop.`);
});
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => {
  modeler.stop(); bridge.close(); clearInterval(pulse);
  for (const c of clients) c.end();
  server.close(() => process.exit(0)); server.closeIdleConnections();
});
