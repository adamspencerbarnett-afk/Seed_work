# Seedwork 0.7.0 — Community World Builder

A self-contained AI-assisted authoring toolkit by Adam S. Barnett, with credited Three.js and inherited Seedwork contributions. Download the ZIP, extract it, and run `node server.mjs` using Node.js 22 or newer. No npm/Python setup, paid account, network asset download or runtime API key is required.

Upload the release ZIP to a file-capable ChatGPT conversation and ask it to read `START_HERE_CHATGPT.md`. The included offline CLI lets an assistant validate a world plan and create a new editable/playable project with all referenced assets. Uploading files does not install live tools or connect to the user's localhost.

Included: world editor, native Node model compiler, seven editable starter assemblies, four biomes, environment/weather tools, embedded-game SDK, staged review workflow, 42 validated tools, source and asset manifests, tests and release instructions.

Commercial permission for controlled original contributions is in README. Required inherited Seedwork and Three.js MIT notices are retained. The unknown-license uploaded modeling kit was removed and all native starter GLBs rebuilt.

Limitations: Three.js remains r140; v0.5 advanced water source was unavailable and is not merged; native artwork is procedural; legacy sculpt/stamp/decal authoring is excluded; this is a scaffold, not a complete generated game. See `docs/TESTS.md` for actual release evidence and known visual limitations.
